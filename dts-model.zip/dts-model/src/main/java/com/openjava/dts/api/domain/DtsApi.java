package com.openjava.dts.api.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;

/**
 * 实体
 * @author hl
 *
 */
@ApiModel("DtsApi")
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@Entity
@Table(name = "DTS_API")
public class DtsApi implements Persistable<Long>,Serializable {
	
	@ApiModelProperty("id")
	@Id
	@Column(name = "id")
	private Long id;
	
	@ApiModelProperty("接口名称")
	@Length(min=0, max=128)
	@Column(name = "name")
	private String name;
	
	@ApiModelProperty("机构id")
	@Length(min=0, max=128)
	@Column(name = "org_id")
	private String orgId;
	
	@ApiModelProperty("机构名字")
	@Length(min=0, max=128)
	@Column(name = "org_name")
	private String orgName;
	
	@ApiModelProperty("接口url")
	@Length(min=0, max=255)
	@Column(name = "url")
	private String url;
	
	@ApiModelProperty("连接数限制0不限")
	@Max(99999999L)
	@Column(name = "connect_count")
	private Integer connectCount;
	
	@ApiModelProperty("限流0不限")
	@Max(9223372036854775806L)
	@Column(name = "limit_flow")
	private Long limitFlow;
	
	@ApiModelProperty("desc")
	@Length(min=0, max=500)
	@Column(name = "desc")
	private String desc;
	
	@ApiModelProperty("keyword")
	@Length(min=0, max=500)
	@Column(name = "keyword")
	private String keyword;
	
	@ApiModelProperty("白名单")
	@Length(min=0, max=500)
	@Column(name = "white_ip")
	private String whiteIp;
	
	@ApiModelProperty("1正常2禁用")
	@Max(9L)
	@Column(name = "statue")
	private Integer statue;
	
	@ApiModelProperty("1正常2删")
	@Max(9L)
	@Column(name = "del_statue")
	private Integer delStatue;
	
	@ApiModelProperty("create_uid")
	@Max(9223372036854775806L)
	@Column(name = "create_uid")
	private Long createUid;
	
	@ApiModelProperty("create_time")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "create_time")
	private Date createTime;
	
	@ApiModelProperty("create_uname")
	@Length(min=0, max=128)
	@Column(name = "create_uname")
	private String createUname;
	
	@ApiModelProperty("update_uid")
	@Max(9223372036854775806L)
	@Column(name = "update_uid")
	private Long updateUid;
	
	@ApiModelProperty("update_time")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "update_time")
	private Date updateTime;
	
	@ApiModelProperty("update_uname")
	@Length(min=0, max=128)
	@Column(name = "update_uname")
	private String updateUname;
	
	
	@ApiModelProperty("是否新增")
	@Transient
    private Boolean isNew;

	/**
	@Transient
    @JsonIgnore
    @Override
    public Long getId() {
        return this.id;
	}
    **/

    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
    	if(isNew != null) {
    		return isNew;
    	}
    	if(this.id != null) {
    		return false;
    	}
    	return true;
    }
    
}