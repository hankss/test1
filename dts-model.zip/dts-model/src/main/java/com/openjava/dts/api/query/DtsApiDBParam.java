package com.openjava.dts.api.query;

import org.ljdp.core.db.RoDBQueryParam;

/**
 * 查询对象
 * @author hl
 *
 */
public class DtsApiDBParam extends RoDBQueryParam {
	private Long eq_id;//id --主键查询
	
	private String like_name;//接口名称 like ?
	private String eq_orgId;//机构id = ?
	private String like_orgName;//机构名字 like ?
	private String like_keyword;//keyword like ?
	private String like_whiteIp;//白名单 like ?
	private Integer eq_delStatue;//1正常2删 = ?
	private Integer eq_statue;//1正常2禁用 = ?
	
	public Long getEq_id() {
		return eq_id;
	}
	public void setEq_id(Long id) {
		this.eq_id = id;
	}
	
	public String getLike_name() {
		return like_name;
	}
	public void setLike_name(String name) {
		this.like_name = name;
	}
	public String getEq_orgId() {
		return eq_orgId;
	}
	public void setEq_orgId(String orgId) {
		this.eq_orgId = orgId;
	}
	public String getLike_orgName() {
		return like_orgName;
	}
	public void setLike_orgName(String orgName) {
		this.like_orgName = orgName;
	}
	public String getLike_keyword() {
		return like_keyword;
	}
	public void setLike_keyword(String keyword) {
		this.like_keyword = keyword;
	}
	public String getLike_whiteIp() {
		return like_whiteIp;
	}
	public void setLike_whiteIp(String whiteIp) {
		this.like_whiteIp = whiteIp;
	}
	public Integer getEq_delStatue() {
		return eq_delStatue;
	}
	public void setEq_delStatue(Integer delStatue) {
		this.eq_delStatue = delStatue;
	}
	public Integer getEq_statue() {
		return eq_statue;
	}
	public void setEq_statue(Integer statue) {
		this.eq_statue = statue;
	}
}