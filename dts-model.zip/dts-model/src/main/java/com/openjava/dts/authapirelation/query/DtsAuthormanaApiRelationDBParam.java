package com.openjava.dts.authapirelation.query;

import org.ljdp.core.db.RoDBQueryParam;

/**
 * 查询对象
 * @author hl
 *
 */
public class DtsAuthormanaApiRelationDBParam extends RoDBQueryParam {
	private Long eq_id;//id --主键查询
	
	private Long eq_apiId;//api_id = ?
	private Long eq_createId;//create_id = ?
	private Long eq_authManageId;//auth_manage_id = ?
	
	public Long getEq_id() {
		return eq_id;
	}
	public void setEq_id(Long id) {
		this.eq_id = id;
	}
	
	public Long getEq_apiId() {
		return eq_apiId;
	}
	public void setEq_apiId(Long apiId) {
		this.eq_apiId = apiId;
	}
	public Long getEq_createId() {
		return eq_createId;
	}
	public void setEq_createId(Long createId) {
		this.eq_createId = createId;
	}
	public Long getEq_authManageId() {
		return eq_authManageId;
	}
	public void setEq_authManageId(Long authManageId) {
		this.eq_authManageId = authManageId;
	}
}