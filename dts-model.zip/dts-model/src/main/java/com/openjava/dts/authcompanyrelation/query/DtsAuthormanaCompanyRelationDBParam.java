package com.openjava.dts.authcompanyrelation.query;

import org.ljdp.core.db.RoDBQueryParam;

/**
 * 查询对象
 * @author hl
 *
 */
public class DtsAuthormanaCompanyRelationDBParam extends RoDBQueryParam {
	private Long eq_id;//id --主键查询
	
	private Long eq_authorManaId;//author_mana_id = ?
	private Long eq_companyId;//company_id = ?
	private Long eq_createUid;//create_uid = ?
	
	public Long getEq_id() {
		return eq_id;
	}
	public void setEq_id(Long id) {
		this.eq_id = id;
	}
	
	public Long getEq_authorManaId() {
		return eq_authorManaId;
	}
	public void setEq_authorManaId(Long authorManaId) {
		this.eq_authorManaId = authorManaId;
	}
	public Long getEq_companyId() {
		return eq_companyId;
	}
	public void setEq_companyId(Long companyId) {
		this.eq_companyId = companyId;
	}
	public Long getEq_createUid() {
		return eq_createUid;
	}
	public void setEq_createUid(Long createUid) {
		this.eq_createUid = createUid;
	}
}