package com.openjava.dts.authoriztionmanage.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;

/**
 * 实体
 * @author hl
 *
 */
@ApiModel("DtsAuthorizationManage")
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@Entity
@Table(name = "DTS_AUTHORIZATION_MANAGE")
public class DtsAuthorizationManage implements Persistable<Long>,Serializable {
	
	@ApiModelProperty("id")
	@Id
	@Column(name = "id")
	private Long id;
	
	@ApiModelProperty("名称")
	@Length(min=0, max=128)
	@Column(name = "name")
	private String name;
	
	@ApiModelProperty("描述")
	@Length(min=0, max=200)
	@Column(name = "desc")
	private String desc;
	
	@ApiModelProperty("机构id")
	@Length(min=0, max=128)
	@Column(name = "org_id")
	private String orgId;
	
	@ApiModelProperty("机构名字")
	@Length(min=0, max=128)
	@Column(name = "org_name")
	private String orgName;
	
	@ApiModelProperty("绑定接口条数")
	@Max(999999L)
	@Column(name = "api_count")
	private Integer apiCount;
	
	@ApiModelProperty("使用状态1正常2停用")
	@Max(9L)
	@Column(name = "statue")
	private Integer statue;
	
	@ApiModelProperty("文档url")
	@Length(min=0, max=255)
	@Column(name = "des_url")
	private String desUrl;
	
	@ApiModelProperty("白名单")
	@Length(min=0, max=500)
	@Column(name = "white_ip")
	private String whiteIp;
	
	@ApiModelProperty("create_time")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "create_time")
	private Date createTime;
	
	@ApiModelProperty("create_uid")
	@Max(9223372036854775806L)
	@Column(name = "create_uid")
	private Long createUid;
	
	@ApiModelProperty("create_name")
	@Length(min=0, max=255)
	@Column(name = "create_name")
	private String createName;
	
	@ApiModelProperty("update_time")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "update_time")
	private Date updateTime;
	
	@ApiModelProperty("update_uid")
	@Max(9223372036854775806L)
	@Column(name = "update_uid")
	private Long updateUid;
	
	@ApiModelProperty("1.正常2删除")
	@Max(9L)
	@Column(name = "del_statue")
	private Integer delStatue;


	@ApiModelProperty("所授权公司企业列表,[{\"id\":1, \"name\": \"xxx公司\", \"type\": \"1\", \"typeName\": \"系统开发商\"}]")
	@Transient
	private String companyList;

	@ApiModelProperty("联连api列表 [{\"id\":1, \"name\": \"xxx接口\"}]")
	@Transient
	private String apiList;
	
	@ApiModelProperty("是否新增")
	@Transient
    private Boolean isNew;

	/**
	@Transient
    @JsonIgnore
    @Override
    public Long getId() {
        return this.id;
	}
	 **/
    
    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
    	if(isNew != null) {
    		return isNew;
    	}
    	if(this.id != null) {
    		return false;
    	}
    	return true;
    }
    
}