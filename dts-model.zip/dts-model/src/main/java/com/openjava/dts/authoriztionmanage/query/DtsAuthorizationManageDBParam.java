package com.openjava.dts.authoriztionmanage.query;

import lombok.Data;
import org.ljdp.core.db.RoDBQueryParam;

/**
 * 查询对象
 * @author hl
 *
 */
@Data
public class DtsAuthorizationManageDBParam extends RoDBQueryParam {
	private Long eq_id;//id --主键查询
	
	private String like_name;//名称 like ?
	private String like_desc;//描述 like ?
	private String eq_orgId;//机构id = ?
	private String eq_companyId;
	private String like_orgName;//机构名字 like ?
	private String like_whiteIp;//白名单 like ?
	private Long eq_createUid;//create_uid = ?
	private Integer eq_delStatue;//1.正常2删除 = ?
}