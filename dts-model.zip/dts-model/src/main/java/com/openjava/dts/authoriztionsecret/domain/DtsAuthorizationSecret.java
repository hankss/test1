package com.openjava.dts.authoriztionsecret.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;

/**
 * 实体
 * @author hl
 *
 */
@ApiModel("DtsAuthorizationSecret")
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@Entity
@Table(name = "DTS_AUTHORIZATION_SECRET")
public class DtsAuthorizationSecret implements Persistable<Long>,Serializable {
	
	@ApiModelProperty("id")
	@Id
	@Column(name = "id")
	private Long id;
	
	@ApiModelProperty("开发商运维商id")
	@Max(9223372036854775806L)
	@Column(name = "company_id")
	private Long companyId;
	
	@ApiModelProperty("授权管理id")
	@Max(9223372036854775806L)
	@Column(name = "authmana_id")
	private Long authmanaId;
	
	@ApiModelProperty("appid")
	@Length(min=0, max=128)
	@Column(name = "appid")
	private String appid;
	
	@ApiModelProperty("appsecret")
	@Length(min=0, max=128)
	@Column(name = "appsecret")
	private String appsecret;
	
	@ApiModelProperty("加密类型")
	@Length(min=0, max=128)
	@Column(name = "encrypt_type")
	private String encryptType;
	
	@ApiModelProperty("签名类型")
	@Length(min=0, max=128)
	@Column(name = "signature_type")
	private String signatureType;
	
	@ApiModelProperty("联连数")
	@Max(99999999L)
	@Column(name = "connect_count")
	private Integer connectCount;
	
	@ApiModelProperty("白名单")
	@Length(min=0, max=200)
	@Column(name = "white_ip")
	private String whiteIp;
	
	@ApiModelProperty("限流kb")
	@Max(999999999999999999L)
	@Column(name = "limit_flow")
	private Long limitFlow;
	
	@ApiModelProperty("1正常2禁用")
	@Max(9L)
	@Column(name = "statue")
	private Integer statue;
	
	@ApiModelProperty("create_uid")
	@Max(9223372036854775806L)
	@Column(name = "create_uid")
	private Long createUid;
	
	@ApiModelProperty("create_time")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "create_time")
	private Date createTime;
	
	@ApiModelProperty("create_uname")
	@Length(min=0, max=255)
	@Column(name = "create_uname")
	private String createUname;
	
	@ApiModelProperty("update_uid")
	@Max(9223372036854775806L)
	@Column(name = "update_uid")
	private Long updateUid;
	
	@ApiModelProperty("update_time")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "update_time")
	private Date updateTime;
	
	
	@ApiModelProperty("是否新增")
	@Transient
    private Boolean isNew;

	/**
	@Transient
    @JsonIgnore
    @Override
    public Long getId() {
        return this.id;
	}
	 **/
    
    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
    	if(isNew != null) {
    		return isNew;
    	}
    	if(this.id != null) {
    		return false;
    	}
    	return true;
    }
    
}