package com.openjava.dts.authoriztionsecret.query;

import org.ljdp.core.db.RoDBQueryParam;

/**
 * 查询对象
 * @author hl
 *
 */
public class DtsAuthorizationSecretDBParam extends RoDBQueryParam {
	private Long eq_id;//id --主键查询
	
	private Long eq_companyId;//开发商运维商id = ?
	private Long eq_authmanaId;//授权管理id = ?
	private String like_appid;//appid like ?
	private String like_appsecret;//appsecret like ?
	private String like_whiteIp;//白名单 like ?
	private Integer eq_statue;//1正常2禁用 = ?
	private Long eq_createUid;//create_uid = ?
	
	public Long getEq_id() {
		return eq_id;
	}
	public void setEq_id(Long id) {
		this.eq_id = id;
	}
	
	public Long getEq_companyId() {
		return eq_companyId;
	}
	public void setEq_companyId(Long companyId) {
		this.eq_companyId = companyId;
	}
	public Long getEq_authmanaId() {
		return eq_authmanaId;
	}
	public void setEq_authmanaId(Long authmanaId) {
		this.eq_authmanaId = authmanaId;
	}
	public String getLike_appid() {
		return like_appid;
	}
	public void setLike_appid(String appid) {
		this.like_appid = appid;
	}
	public String getLike_appsecret() {
		return like_appsecret;
	}
	public void setLike_appsecret(String appsecret) {
		this.like_appsecret = appsecret;
	}
	public String getLike_whiteIp() {
		return like_whiteIp;
	}
	public void setLike_whiteIp(String whiteIp) {
		this.like_whiteIp = whiteIp;
	}
	public Integer getEq_statue() {
		return eq_statue;
	}
	public void setEq_statue(Integer statue) {
		this.eq_statue = statue;
	}
	public Long getEq_createUid() {
		return eq_createUid;
	}
	public void setEq_createUid(Long createUid) {
		this.eq_createUid = createUid;
	}
}