package com.openjava.dts.constants;


/**
 * 组件类型定议
 */

public enum DtsComponentTypeEnum {

    DATASOURCE_SRC_IN(1,"数据源输入"),
    COLLECT_DB_IN(2,"归集库输入"),
    RESOURCE_IN(3,"资源目录输入"),
    TASK_IN(4,"需求任务输入"),
    COLLECT_DB_OUT(5,"归集库输出"),
    RESOURCE_OUT(6,"资源目录输出"),
    TASK_OUT(7,"需求任务输出"),
    FIELD_TTANSFER(8,"字段转换"),
    TABLE_JOIN(9,"表整合"),
    FIELD_FITER(10,"字段过滤"),
    USER_DEFINED_OUT(11,"自定数据源"),
    USER_DEFINED_QUERY_SQL(12,"自定查询sql"),
    MAIN_LAKE_RESOURCE_FOLDER_IN(13,"主湖资源目录输入"),
    MAIN_LAKE_RESOURCE_FOLDER_OUT(14,"主湖资源目录输出"),
    BATCH_DATASOURCE_IN(15,"批量数据源输入"),
    BATCH_DATASOURCE_IN_CHILD(150,"批量数据源输入子组件"),
    BATCH_COLLECT_OUT(16,"批量归集库输出"),
    BATCH_COLLECT_OUT_CHILD(160,"批量归集库输出子组件"),
    DUPLICATION_FILTER(17,"数据去重转换"),
    NULL_REPLACEMENT(18,"空值替换转换"),
    CONTENT_CLEANUP(19,"字段内容清洗转换"),
    DATA_ORDER(20,"数据排序转换"),
    EXPRESSION(21,"表达式转换"),
    STANDARD_OUT(22,"标准库输出"),
    STANDARD_IN(23,"标准库输入"),
    BASE_IN(24,"基础库输入"),
    BASE_OUT(25,"基础库输出"),
    SUBJECT_IN(26,"主题库输入"),
    SUBJECT_OUT(27,"主题库输出"),
    SPECIAL_TOPIC_OUT(28,"专题库输出")
    ;


    private Integer type;
    private String desc;

    private DtsComponentTypeEnum( Integer type , String desc){
        this.type = type ;
        this.desc = desc ;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

}
