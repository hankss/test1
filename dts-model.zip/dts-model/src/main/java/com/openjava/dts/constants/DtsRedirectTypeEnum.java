package com.openjava.dts.constants;

public enum DtsRedirectTypeEnum {

    data_integration,//0：数据集成自身页面
    requirement_task,//1：需求任务
    assistance_task,//2:数据协作
    resource_folder,//3：资源目录
    data_set//4：数据集

}
