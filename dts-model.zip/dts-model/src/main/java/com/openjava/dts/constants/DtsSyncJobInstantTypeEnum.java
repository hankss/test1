package com.openjava.dts.constants;

public enum DtsSyncJobInstantTypeEnum {

    JOB_TYPE(0),JOB_COMPONENT_TYPE(1);

    private Integer type;

    private DtsSyncJobInstantTypeEnum(Integer type){
        this.type=type;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }
}
