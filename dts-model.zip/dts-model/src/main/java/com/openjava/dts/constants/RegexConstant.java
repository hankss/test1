package com.openjava.dts.constants;

/**
 * 正则匹配常量
 *
 * @author Jiahai
 */
public class RegexConstant {
    /**
     * 正则匹配 —— 仅匹配中文
     */
    public static final String ONLY_CHINESE = "[\\u4E00-\\u9FA5]+";

    /**
     * 正则匹配 —— 仅匹配汉字、数字
     */
    public static final String CHINESE_NUMBER = "[\\u4E00-\\u9FA5_0-9]+";

    /**
     * 正则匹配 —— 仅支持由字母、数字或下划线组成的字符串
     */
    public static final String LETTER_NUMBER_UNDERLINE = "^\\w+$";

    /**
     * 正则匹配 —— 字母、数字、汉字、下划线
     */
    public static final String LETTER_NUMBER_CHINESE_UNDERLINE = "^[a-zA-Z0-9_\\u4e00-\\u9fa5]+$";

    /**
     * 正则匹配 —— 只能以汉字或字母开头
     */
    public static final String CHARACTER_AS_CHINESE_OR_LETTER = "^([\\u4E00-\\u9FA5A-Za-z]).*";
}
