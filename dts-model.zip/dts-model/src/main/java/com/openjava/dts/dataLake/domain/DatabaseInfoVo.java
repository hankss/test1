package com.openjava.dts.dataLake.domain;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Author JiaHai
 * @Description 数据库连接信息包装类
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DatabaseInfoVo implements Serializable {
    private static final long serialVersionUID = 428826517592959082L;

    @ApiModelProperty("IP")
    private String ip;
    @ApiModelProperty("端口号")
    private String port;
    @ApiModelProperty("数据库名")
    private String databaseName;
    @ApiModelProperty("schema")
    private String schema;

    @ApiModelProperty("用户名")
    private String username;
    @ApiModelProperty("密码")
    private String password;

    @ApiModelProperty("数据库类型")
    private Long databaseType;

    @ApiModelProperty("JDBC尾部的其他参数")
    private String otherParam;

    @ApiModelProperty("当前数据库表名（汇聚使用）")
    private String tableName;
}
