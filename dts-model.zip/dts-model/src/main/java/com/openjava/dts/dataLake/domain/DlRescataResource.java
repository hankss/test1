package com.openjava.dts.dataLake.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * @Author JiaHai
 * @Description 资源目录宽表
 */
@Entity
@Table(name = "DL_RESCATA_RESOURCE")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DlRescataResource implements Serializable {
    private static final long serialVersionUID = -7813970958617698932L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "dlResourceCode")
    @SequenceGenerator(name = "dlResourceCode", sequenceName = "DL_RESOURCE_CODE", allocationSize = 1)
    @ApiModelProperty("资源目录宽表ID")
    @Column(name = "RESOURCE_ID")
    private Long resourceId;
    @ApiModelProperty("信息资源编码")
    @Column(name = "RESOURCE_CODE")
    private String resourceCode;
    @ApiModelProperty("源头信息资源编码")
    @Column(name = "SOURCE_INFO_CODE")
    private String sourceInfoCode;
    @ApiModelProperty("分库类别（dl.resource.repository.type）（1汇集库、2中心库、3基础库、4主题库、5专题库）")
    @Column(name = "REPOSITORY_TYPE")
    private Long repositoryType;
    @ApiModelProperty(value = "资源名称",required = true)
    @Column(name = "RESOURCE_NAME")
    private String resourceName;
    @ApiModelProperty(value = "资源类别（dl.resource.type）（1数据库、2文本、3图片、4音频、5视频）",required = true)
    @Column(name = "RESOURCE_TYPE")
    private Long resourceType;
    @ApiModelProperty("存储标识")
    @Column(name = "RESOURCE_TABLE_NAME")
    private String resourceTableName;
    @ApiModelProperty("公开范围（dl.resource.open.scope）（1全部对外公开、2全部对内公开、3部分对内公开、4不公开）")
    @Column(name = "OPEN_SCOPE")
    private Long openScope;
    @ApiModelProperty("是否只限内部使用（public.YN）（1是、0否）")
    @Column(name = "IS_INTERNAL_USE_ONLY")
    private Long isInternalUseOnly;
    @ApiModelProperty("资源来源")
    @Column(name = "RESOURCE_SOURCE")
    private String resourceSource;

    @ApiModelProperty(value = "提供单位UUID",required = true)
    @Column(name = "PROVIDE_DEPT_ID")
    private String provideDeptId;
    @ApiModelProperty("提供单位名称")
    @Column(name = "PROVIDE_DEPT_NAME")
    private String provideDeptName;
    @ApiModelProperty("提供局UUID")
    @Column(name = "PROVIDE_DEPT_TOP_ID")
    private String provideDeptTopId;
    @ApiModelProperty("提供局名称")
    @Column(name = "PROVIDE_DEPT_TOP_NAME")
    private String provideDeptTopName;
    @ApiModelProperty("提供单位全路径UUID")
    @Column(name = "PROVIDE_DEPT_FULL_PATH")
    private String provideDeptFullPath;

    @ApiModelProperty("更新周期（dl.resource.update.cycle）（1实时、2每日、3每周、4每月、5每季度、6每半年、7每年、8一次性、9不提供、10其他）")
    @Column(name = "UPDATE_CYCLE")
    private Long updateCycle;
    @ApiModelProperty("提供时限")
    @Column(name = "PROVIDE_TIME_LIMIT")
    private String provideTimeLimit;

    @ApiModelProperty("业务负责人账号")
    @Column(name = "BUSINESS_OWNER_ACCOUNT")
    private String businessOwnerAccount;
    @ApiModelProperty("业务负责人姓名")
    @Column(name = "BUSINESS_OWNER")
    private String businessOwner;

    @ApiModelProperty("是否短信提醒（public.YN）（1是，0否）")
    @Column(name = "IS_SMS_ALERTS")
    private Long isSmsAlerts;
    @ApiModelProperty("是否同意在地图上展示（public.YN）（1是、0否）")
    @Column(name = "IS_SHOW_ON_MAP")
    private Long isShowOnMap;
    @ApiModelProperty("资源摘要")
    @Column(name = "RESOURCE_SUMMARY")
    private String resourceSummary;
    @ApiModelProperty("关键字")
    @Column(name = "KEYWORD")
    private String keyword;
    @ApiModelProperty("版本号")
    @Column(name = "VERSION")
    private Long version;
    @ApiModelProperty("信息主体（dl.resource.information.agent）（1法人、2自然人、3自然人/法人、4城市部件、5数据信息、6其他）")
    @Column(name = "INFORMATION_AGENT")
    private Long informationAgent;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    @ApiModelProperty("资源发布日期")
    @Column(name = "CREATE_TIME")
    private Date createTime;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    @ApiModelProperty("最近数据更新时间")
    @Column(name = "UPDATE_TIME")
    private Date updateTime;
    @ApiModelProperty("资源状态（dl.resource.resource.state）（1正常、2无效、3停更、4草稿）")
    @Column(name = "RESOURCE_STATE")
    private Long resourceState;
    @ApiModelProperty("资源安全级别（dl.resource.security.level）（1未分级、2内部、3秘密、4机密、5绝密）")
    @Column(name = "SECURITY_LEVEL")
    private Long securityLevel;
    @ApiModelProperty("数据标签")
    @Column(name = "DATA_LABEL")
    private String dataLabel;
    @ApiModelProperty("获取地址")
    private String url;
    @ApiModelProperty("是否为最新版（public.YN）（1是、0否）")
    @Column(name = "IS_LATEST")
    private Long isLatest;
    @ApiModelProperty("数据提供方式（dl.resource.data.provide.mode）（1前置机读取、2附件上传、3接口获取、4FTP）")
    @Column(name = "SOURCE_MODE")
    private Long sourceMode;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    @ApiModelProperty("资源状态变动时间")
    @Column(name = "RESOURCE_STATE_UPDATE_TIME")
    private Date resourceStateUpdateTime;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    @ApiModelProperty("数据提供时间")
    @Column(name = "PROVIDE_TIME")
    private Date provideTime;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DISABLED_TIME")
    @ApiModelProperty("禁用时间")
    private Date disabledTime;

    @ApiModelProperty("创建人UUID")
    @Column(name = "CREATE_UUID")
    private Long createUuid;
    @ApiModelProperty("创建人账号")
    @Column(name = "CREATE_ACCOUNT")
    private String createAccount;
    @ApiModelProperty("创建人名称")
    @Column(name = "CREATE_FULLNAME")
    private String createFullname;

    @ApiModelProperty("创建部门UUID")
    @Column(name = "CREATE_DEPT_ID")
    private String createDeptId;
    @ApiModelProperty("创建部门名称")
    @Column(name = "CREATE_DEPT_NAME")
    private String createDeptName;
    @ApiModelProperty("创建局UUID")
    @Column(name = "CREATE_DEPT_TOP_ID")
    private String createDeptTopId;
    @ApiModelProperty("创建局名称")
    @Column(name = "CREATE_DEPT_TOP_NAME")
    private String createDeptTopName;

/*    @ApiModelProperty("ID")
    @Column(name = "ID_TOKIMNHJ")
    private String idTokimnhj;
    @ApiModelProperty("目录ID")
    @Column(name = "DIR_ID_TOKIMNHJ")
    private String dirIdTokimnhj;
    @ApiModelProperty("增加时间")
    @Column(name = "ADDTIME_TOKIMNHJ")
    private Date addTimeTokimnhj;
    @ApiModelProperty("更新时间")
    @Column(name = "UPDATETIME_TOKIMNHJ")
    private Date updateTimeTokimnhj;
    @ApiModelProperty("状态")
    @Column(name = "STATE_TOKIMNHJ")
    private String stateTokimnhj;
    @ApiModelProperty("防窜改码")
    @Column(name = "HASH_TOKIMNHJ")
    private String hashTokimnhj;
    @ApiModelProperty("防窜改码时间")
    @Column(name = "DATA_HASH_TOKIMNHJ")
    private Date dataHashTokimnhj;*/
}
