package com.openjava.dts.dataLake.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

/**
 * @author 丘健里
 * @date 2020/1/8
 */
@ApiModel("字段（列名）信息list")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ColumnInfoVo {

    @ApiModelProperty("字段定义（code）")
    private String columnDefinition;

    @ApiModelProperty("字段名（中文）")
    private String columnName;
}
