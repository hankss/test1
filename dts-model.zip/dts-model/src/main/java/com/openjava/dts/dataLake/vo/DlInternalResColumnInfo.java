package com.openjava.dts.dataLake.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Transient;
import java.io.Serializable;

/**
 * @Author JiaHai
 * @Description 资源父子节点关系
 */
@ApiModel()
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DlInternalResColumnInfo implements Serializable {

    @ApiModelProperty( "字段ID")
    private Long id;
    @ApiModelProperty("字段Code")
    private Long code;
    @ApiModelProperty( "字段中文名")
    private String name;
    @ApiModelProperty( "表字段名")
    private String definition;
    @ApiModelProperty( "表注释")
    private String comment;
    @ApiModelProperty("数据类型")
    private Long type;
    @ApiModelProperty("公开属性（1公开，2不公开）")
    private Long scope;
    @ApiModelProperty( "是否有查阅权限")
    private Boolean viewable;
    @ApiModelProperty( "是否有不脱敏权限")
    private Boolean sensitived;
    @ApiModelProperty( "是否有解密权限")
    private Boolean decryption;
    @ApiModelProperty( "字段长度")
    private Long length;
    @ApiModelProperty( "小数位数")
    private Long decimal;
    @ApiModelProperty( "是否加密")
    private Long isEncrypt;
    @ApiModelProperty( "是否脱敏")
    private Long isDesens;
    @ApiModelProperty( "是否主键")
    private Long isPrimaryKey;
    @ApiModelProperty("默认值")
    private String defaultValue;
    @ApiModelProperty("数据类型-值")
    @Transient
    private String typeValue;

}
