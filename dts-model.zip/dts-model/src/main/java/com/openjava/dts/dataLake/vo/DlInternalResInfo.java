package com.openjava.dts.dataLake.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @Author JiaHai
 * @Description 资源父子节点关系
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DlInternalResInfo implements Serializable {

    @ApiModelProperty( "资源目录ID")
    private Long resourceId;
    @ApiModelProperty( "资源目录编码")
    private String resourceCode;
    @ApiModelProperty( "资源目录名称")
    private String resourceName;
    @ApiModelProperty( "资源目录数据库表名")
    private String resourceTableName;
    @ApiModelProperty( "公开范围ID（1公开、2不公开）")
    private Long scope;

    @ApiModelProperty( "权限等级（1:全部权限/2:部分权限/3:没有权限）")
    private Long rightsLevel;
    @ApiModelProperty( "数据库索引")
    private Long databaseId;

    private List<DlInternalResColumnInfo> column;

}
