package com.openjava.dts.dataLake.vo;


import com.openjava.dts.dataLake.domain.DlRescataColumn;
import com.openjava.dts.dataLake.domain.DlRescataResource;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @Author JiaHai
 * @Description 资源目录相关信息包装类（资源目录、信息项、标签等）
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DlRescataResourceVo implements Serializable {
    private static final long serialVersionUID = 6882264216594493445L;

    /**
     * 资源目录
     */
    private DlRescataResource dlRescataResource;

    /**
     * 目录结构（信息项）
     */
    private List<DlRescataColumn> dlRescataColumnList;

    /**
     * true则是草稿，false则是新增
     */
    private Boolean isDraft;

    /**
     * 资源分类
     */
    private ResourceLabelVo resourceLabelVo;

}
