package com.openjava.dts.dataLake.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author 丘健里
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DlResourceSyncTaskVo implements Serializable {
    private static final long serialVersionUID = 6882264216594493445L;

    /**
     * 创建时间
     */
    private String createTime;

    /**
     * 主键ID,15为随机数
     */
    private Integer primaryKeyId;

    /**
     * 信息资源编码
     */
    private String resourceCode;

    /**
     * 同步任务ID
     */
    private Long syncTaskId;

}
