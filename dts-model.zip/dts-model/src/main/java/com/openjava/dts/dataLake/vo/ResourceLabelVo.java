package com.openjava.dts.dataLake.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Author JiaHai
 * @Description 资源标签分类 5个
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResourceLabelVo implements Serializable {
    private static final long serialVersionUID = -8767515081480569936L;

    @ApiModelProperty("主题分类")
    private Long themeSort;
    @ApiModelProperty("行业分类")
    private Long industrySort;
    @ApiModelProperty("服务分类")
    private Long serviceSort;
    @ApiModelProperty("数据领域")
    private Long dataDomain;
    @ApiModelProperty("资源形态分类")
    private Long resourceForm;
}
