package com.openjava.dts.dataLake.vo;

import com.openjava.dts.dataprovider.result.AggregateResultV2;
import com.openjava.dts.dataprovider.result.ColumnIndex;
import com.openjava.dts.ddl.dto.ColumnInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author 丘健里
 * @date 2020/1/8
 */
@ApiModel("分页查询表中数据，返回字段信息与数据")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TableDataVo {

    @ApiModelProperty("列信息")
    private List<ColumnInfoVo> columnInfoVoList;

    @ApiModelProperty("数据（按顺序）")
    private List<List<String>> data;

/*    @ApiModelProperty("数据")
    private AggregateResultV2 aggregateResultV2;*/

    @ApiModelProperty("当前页")
    private Integer page;

    @ApiModelProperty("每页条数")
    private Integer size;

    @ApiModelProperty("总数量")
    private Integer total;

}
