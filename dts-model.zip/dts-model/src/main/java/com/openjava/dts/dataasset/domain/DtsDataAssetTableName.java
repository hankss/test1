package com.openjava.dts.dataasset.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;

/**
 * 实体
 *
 * @date 2020-04-14 14:17
 */

@ApiModel("DtsDataAssetTableName")
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@Entity
@Table(name = "DTS_DATAASSET_TABLE_NAME")
public class DtsDataAssetTableName implements Persistable<Long>, Serializable {

    @ApiModelProperty("id")
    @Id
    @Column(name = "id")
    private Long id;

    @ApiModelProperty("表名(源表)")
    @Length(min = 0, max = 255)
    @Column(name = "table_source")
    private String tableSource;

    @ApiModelProperty("表名(归集库输出组件)")
    @Length(min = 0, max = 255)
    @Column(name = "table_name")
    private String tableName;

    @ApiModelProperty("表描述")
    @Length(min = 0, max = 2048)
    @Column(name = "table_desc")
    private String tableDesc;

    @ApiModelProperty("数据源id(数据源输入组件表的)")
    @Length(min = 0, max = 64)
    @Column(name = "datasource_id")
    private String datasourceId;

    @ApiModelProperty("系统id")
    @Length(min = 0, max = 255)
    @Column(name = "system_id")
    private String systemId;

    @ApiModelProperty("系统名称")
    @Length(min = 0, max = 255)
    @Column(name = "system_name")
    private String systemName;

    @ApiModelProperty("科室id")
    @Max(9223372036854775806L)
    @Column(name = "project_id")
    private Long projectId;

    @ApiModelProperty("科室名称")
    @Length(min = 0, max = 128)
    @Column(name = "project_name")
    private String projectName;

    @ApiModelProperty("创建人")
    @Max(9223372036854775806L)
    @Column(name = "create_id")
    private Long createId;

    @ApiModelProperty("创建人名字")
    @Length(min = 0, max = 64)
    @Column(name = "create_name")
    private String createName;

    @ApiModelProperty("创建人id")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "create_time")
    private Date createTime;

    @ApiModelProperty("修改人")
    @Max(9223372036854775806L)
    @Column(name = "modify_id")
    private Long modifyId;

    @ApiModelProperty("修改名字")
    @Length(min = 0, max = 64)
    @Column(name = "modify_name")
    private String modifyName;

    @ApiModelProperty("修改时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modify_time")
    private Date modifyTime;

    @ApiModelProperty("是否新增")
    @Transient
    private Boolean isNew;

    @Transient
    @Override
    public Long getId() {
        return this.id;
    }

    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
        if (isNew != null) {
            return isNew;
        }
        if (this.id != null) {
            return false;
        }
        return true;
    }

}
