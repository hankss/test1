package com.openjava.dts.dataasset.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;

/**
 * @author JianLi
 * @date 2020-07-26 13:50
 */
@ApiModel("DtsDataAsset")
@Data
@Accessors(chain = true)
@Entity
@Table(name = "dts_datasource_system_datasset_relation")
public class DtsDatasourceSystemDatassetRelation implements Persistable<Long>, Serializable {

    @ApiModelProperty("id")
    @Id
    @Column(name = "id")
    private Long id;

    @ApiModelProperty("数据源id")
    @Length(min = 0, max = 128)
    @Column(name = "datasource_id")
    private String datasourceId;

    @ApiModelProperty("系统id")
    @Max(9223372036854775806L)
    @Column(name = "system_id")
    private Long systemId;

    @ApiModelProperty("任务表数据(一个数据源下的表一个数据源下的表数据量总和数据量总和)")
    @Max(9223372036854775806L)
    @Column(name = "table_count")
    private Long tableCount;

    @ApiModelProperty("create_time")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "create_time")
    private Date createTime;

    @ApiModelProperty("create_id")
    @Max(9223372036854775806L)
    @Column(name = "create_id")
    private Long createId;

    @ApiModelProperty("create_name")
    @Length(min = 0, max = 128)
    @Column(name = "create_name")
    private String createName;

    @ApiModelProperty("是否新增")
    @Transient
    private Boolean isNew;

    @Transient
    @JsonIgnore
    @Override
    public Long getId() {
        return this.id;
    }

    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
        if (isNew != null) {
            return isNew;
        }
        if (this.id != null) {
            return false;
        }
        return true;
    }

}
