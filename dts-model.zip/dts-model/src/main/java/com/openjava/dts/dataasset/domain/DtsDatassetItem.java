package com.openjava.dts.dataasset.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;

/**
 * 实体
 * @author hl
 *
 */
@ApiModel("DtsDatassetItem")
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@Entity
@Table(name = "DTS_DATASSET_ITEM")
public class DtsDatassetItem implements Persistable<Long>,Serializable {
	
	@ApiModelProperty("id")
	@Id
	@Column(name = "id")
	private Long id;
	
	@ApiModelProperty("数据资产id")
	@Max(9223372036854775806L)
	@Column(name = "data_asset_id")
	private Long dataAssetId;
	
	@ApiModelProperty("表名")
	@Length(min=0, max=255)
	@Column(name = "table_name")
	private String tableName;
	
	@ApiModelProperty("表描述 ")
	@Length(min=0, max=1024)
	@Column(name = "table_desc")
	private String tableDesc;

	@ApiModelProperty("调度类型（1、周期调度；2、手动调度）")
	@Max(9L)
	@Column(name = "schedule_type")
	private Integer scheduleType;
	
	@ApiModelProperty("月1周2时3日4")
	@Max(9L)
	@Column(name = "schedule_cycle")
	private Integer scheduleCycle;
	
	@ApiModelProperty("0全量1增量")
	@Max(9L)
	@Column(name = "sync_type")
	private Integer syncType;
	
	@ApiModelProperty("上一次数据同步时间")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "sync_time")
	private Date syncTime;
	
	@ApiModelProperty("同步数据量万条")
	@Max(9223372036854775806L)
	@Column(name = "sync_data_count")
	private Double syncDataCount;
	
	@ApiModelProperty("数据源id")
	@Length(min=0, max=128)
	@Column(name = "datasource_id")
	private String datasourceId;
	
	@ApiModelProperty("创建人")
	@Max(9223372036854775806L)
	@Column(name = "create_id")
	private Long createId;
	
	@ApiModelProperty("创建人名字")
	@Length(min=0, max=255)
	@Column(name = "create_name")
	private String createName;
	
	@ApiModelProperty("创建人id")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "create_time")
	private Date createTime;
	
	@ApiModelProperty("修改人")
	@Max(9223372036854775806L)
	@Column(name = "modify_id")
	private Long modifyId;
	
	@ApiModelProperty("修改名字")
	@Length(min=0, max=255)
	@Column(name = "modify_name")
	private String modifyName;
	
	@ApiModelProperty("修改时间")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modify_time")
	private Date modifyTime;

	@ApiModelProperty("表的记录数")
	@Max(999999999999999999L)
	@Column(name = "data_count")
	private Long dataCount;
	
	
	@ApiModelProperty("是否新增")
	@Transient
    private Boolean isNew;
	
	@Transient
//    @JsonIgnore
    @Override
    public Long getId() {
        return this.id;
	}
    
    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
    	if(isNew != null) {
    		return isNew;
    	}
    	if(this.id != null) {
    		return false;
    	}
    	return true;
    }
    
}