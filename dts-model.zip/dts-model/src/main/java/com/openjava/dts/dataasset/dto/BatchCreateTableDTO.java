package com.openjava.dts.dataasset.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author 丘健里
 * @date 2020-04-22 10:45
 */
@ApiModel("批量建表参数DTO")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BatchCreateTableDTO {

    @ApiModelProperty("数据源ID")
    private String datasourceId;

    @ApiModelProperty("表名list")
    private List<String> tableNameList;

    @ApiModelProperty("关联系统id")
    private String systemId;

    @ApiModelProperty("关联系统名字")
    private String systemName;

    @ApiModelProperty("项目id")
    private Long projectId;

    @ApiModelProperty("项目名字")
    private String projectName;

}
