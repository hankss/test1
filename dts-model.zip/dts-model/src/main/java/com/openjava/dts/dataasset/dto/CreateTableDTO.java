package com.openjava.dts.dataasset.dto;

import com.openjava.dts.ddl.dto.ColumnInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.validator.constraints.NotBlank;

import java.util.List;

/**
 * @author: lsw
 * @Date: 2020/3/2 18:11
 */
@ApiModel("建表参数DTO")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CreateTableDTO {

    @ApiModelProperty("数据源ID")
    private String datasourceId;

    @ApiModelProperty("表名")
    private String tableName;

    @ApiModelProperty("表注释")
    private String tableComments;

    @ApiModelProperty("列信息")
    private List<ColumnInfo> columnInfoList;

    @ApiModelProperty("关联系统id")
    private String systemId;

    @ApiModelProperty("关联系统名字")
    private String systemName;

    @ApiModelProperty("项目id")
    private Long projectId;

    @ApiModelProperty("项目名字")
    private String projectName;

    public void setVarcharLength() {
        //上游获取字段接口: columnInforList , 不知道是谁写的 ,所以做下游控制
        if (CollectionUtils.isEmpty(this.columnInfoList)) {
            return;
        }
        this.columnInfoList.forEach(x -> {
            if ("varchar".equalsIgnoreCase(x.getColumnType()) ||
                    "longvarchar".equalsIgnoreCase(x.getColumnType()) ||
                    "text".equalsIgnoreCase(x.getColumnType()) ||
                    "longtext".equalsIgnoreCase(x.getColumnType())
            ) {
                //进一步限制大小为1g  10485760
                if (x.getColumnPrecision() >= 10485760) {
                    x.setColumnPrecision(10485750);
                }
            }
        });
    }

}
