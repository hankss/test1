package com.openjava.dts.dataasset.query;

import lombok.Data;
import org.ljdp.core.db.RoDBQueryParam;

/**
 * 查询对象
 *
 * @author hl
 */
@Data
public class DtsDataAssetDBParam extends RoDBQueryParam {
    private Long eq_id;//id --主键查询

    private String like_systemName;//资产名称 like ?
    private String like_databaseName;//数据库名称 like ?
    private String like_databaseSource;//数据库来源 like ?

}