package com.openjava.dts.dataasset.query;

import lombok.Data;
import org.ljdp.core.db.RoDBQueryParam;

/**
 * @author 丘健里
 * @date 2020-04-14 15:02
 */
@Data
public class DtsDataAssetTableNameDBParam extends RoDBQueryParam {
    //id --主键查询
    private Long eq_id;
    //创建人id
    private Long eq_createId;
    //数据源id
    private String eq_datasourceId;
    //系统名字
    private String like_systemName;
    //可是名字
    private String like_depName;
}
