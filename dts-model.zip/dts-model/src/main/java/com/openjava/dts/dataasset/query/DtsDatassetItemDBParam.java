package com.openjava.dts.dataasset.query;

import org.apache.commons.lang3.StringUtils;
import org.ljdp.core.db.RoDBQueryParam;
import org.springframework.format.annotation.DateTimeFormat;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 查询对象
 * @author hl
 *
 */
public class DtsDatassetItemDBParam extends RoDBQueryParam {
	private Long eq_id;//id --主键查询
	
	private Long eq_dataAssetId;//数据资产id = ?
	private String like_tableName;//表名 = ?
	private String eq_datasourceId;//数据源id = ?
	private Integer eq_syncType;//0全量1增量 = ?
	private Integer eq_scheduleCycle;//月1周2时3日4 = ?

	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date lt_createTime;//结束时间
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date gt_createTime;//开始时间

	public Date getLt_createTime() {
		return lt_createTime;
	}
	public void setLt_createTime(String lt_createTime) {
		if (StringUtils.isEmpty(lt_createTime)) {
			this.lt_createTime = null;
		}else {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			try {
				this.lt_createTime = sdf.parse(lt_createTime);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
	}
	public Date getGt_createTime() {
		return gt_createTime;
	}
	public void setGt_createTime(String gt_createTime) {
		if(StringUtils.isEmpty(gt_createTime)){
			this.gt_createTime = null;
		}else {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			try {
				this.gt_createTime = sdf.parse(gt_createTime);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Long getEq_id() {
		return eq_id;
	}
	public void setEq_id(Long id) {
		this.eq_id = id;
	}
	
	public Long getEq_dataAssetId() {
		return eq_dataAssetId;
	}
	public void setEq_dataAssetId(Long dataAssetId) {
		this.eq_dataAssetId = dataAssetId;
	}
	public String getLike_tableName() {
		return like_tableName;
	}
	public void setLike_tableName(String like_tableName) {
		this.like_tableName = like_tableName;
	}
	public String getEq_datasourceId() {
		return eq_datasourceId;
	}
	public void setEq_datasourceId(String datasourceId) {
		this.eq_datasourceId = datasourceId;
	}
	public Integer getEq_syncType() {
		return eq_syncType;
	}
	public void setEq_syncType(Integer syncType) {
		this.eq_syncType = syncType;
	}
	public Integer getEq_scheduleCycle() {
		return eq_scheduleCycle;
	}
	public void setEq_scheduleCycle(Integer scheduleCycle) {
		this.eq_scheduleCycle = scheduleCycle;
	}
}