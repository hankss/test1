package com.openjava.dts.dataasset.query;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.ljdp.core.db.RoDBQueryParam;

import java.util.Date;

/**
 * @author jianli
 * @date 2020-06-20 11:14
 */
@Data
public class DtsStandardDBParam extends RoDBQueryParam {

    @ApiModelProperty("同步方式")
    private Integer eq_syncType;

    @ApiModelProperty("调度周期")
    private Integer eq_scheduleCycle;

    @ApiModelProperty("<=创建时间")
    private Date le_createTime;

    @ApiModelProperty(">=创建时间")
    private Date ge_createTime;

    @ApiModelProperty("<=修改时间")
    private Date le_modifyTime;

    @ApiModelProperty(">=修改时间")
    private Date ge_modifyTime;

    @ApiModelProperty("表名")
    private String like_tableSource;

}
