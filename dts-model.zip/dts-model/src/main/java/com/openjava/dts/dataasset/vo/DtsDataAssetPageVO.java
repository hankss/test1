package com.openjava.dts.dataasset.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * @author by 丘健里
 * @date 2020/2/23.
 */
@ApiModel("资产管理:归集资产首页")
@Data
@EqualsAndHashCode(callSuper = false)
public class DtsDataAssetPageVO {

    private String message;
    private Integer code;

    @ApiModelProperty("总数据量")
    private Long total;

    @ApiModelProperty("总页数")
    private Integer totalPage;

    @ApiModelProperty("每页显示数量")
    private Integer size;

    @ApiModelProperty("当前页面(从0开始)")
    private Integer number;

    private List<DtsDataAssetVO> rows;
}
