package com.openjava.dts.dataasset.vo;

import com.openjava.dts.dataprovider.result.AggregateResultV2;
import com.openjava.dts.ddl.dto.ColumnInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.ljdp.component.result.DataApiResponse;

import java.util.List;

/**
 * @author by 丘健里
 * @date 2020/2/24.
 */
@ApiModel("资产管理:数据预览2.0")
@Data
@EqualsAndHashCode(callSuper = false)
public class DtsDataAssetTableVO {
    private String message;
    private Integer code;

    @ApiModelProperty("表数据预览")
    private DataApiResponse<AggregateResultV2> resp1;

    @ApiModelProperty("字段数据预览")
    private DataApiResponse<List<ColumnInfo>> resp2;

    @ApiModelProperty("更新周期")
    private String cycle;
}
