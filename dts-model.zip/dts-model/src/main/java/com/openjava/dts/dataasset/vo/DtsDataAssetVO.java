package com.openjava.dts.dataasset.vo;

import com.openjava.dts.dataasset.domain.DtsDataAsset;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Length;

import javax.persistence.Column;

/**
 * @author by 丘健里
 * @date 2020/2/23.
 */
@ApiModel("资产管理:归集资产首页")
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class DtsDataAssetVO extends DtsDataAsset {

    @ApiModelProperty("关联局系统id")
    @Length(min=0, max=128)
    @Column(name = "system_ids")
    private String systemIds;

    @ApiModelProperty("关联局系统名字")
    @Length(min=0, max=128)
    @Column(name = "system_names")
    private String systemNames;


}
