package com.openjava.dts.dataasset.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.util.Date;

/**
 * @author jianli
 * @date 2020-06-03 10:07
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class DtsDatassetItemStrengthenVO {

    @ApiModelProperty("id")
    private Long id;

    @ApiModelProperty("数据资产id")
    private Long dataAssetId;

    @ApiModelProperty("表名")
    private String tableName;

    @ApiModelProperty("表描述 ")
    private String tableDesc;

    @ApiModelProperty("月1周2时3日4")
    private Integer scheduleCycle;

    @ApiModelProperty("月周时日")
    private String scheduleCycleName;

    @ApiModelProperty("0全量1增量")
    private Integer syncType;

    @ApiModelProperty("全量,增量")
    private String syncTypeName;

    @ApiModelProperty("上一次数据同步时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    private Date syncTime;

    @ApiModelProperty("同步数据量万条")
    private Double syncDataCount;

    @ApiModelProperty("数据源id")
    private String datasourceId;

    @ApiModelProperty("创建人")
    private Long createId;

    @ApiModelProperty("创建人名字")
    private String createName;

    @ApiModelProperty("创建人id")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createTime;

    @ApiModelProperty("修改人")
    private Long modifyId;

    @ApiModelProperty("修改名字")
    private String modifyName;

    @ApiModelProperty("修改时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifyTime;

    @ApiModelProperty("表的记录数")
    private Long dataCount;

    //解析调度周期
    public void analysisScheduleCycle() {
        //月1周2时3日4手动5
        if (null == this.scheduleCycle || 5 == this.scheduleCycle) {
            this.scheduleCycleName = "手动";
        } else if (1 == this.scheduleCycle) {
            this.scheduleCycleName = "按月";
        } else if (2 == this.scheduleCycle) {
            this.scheduleCycleName = "按周";
        } else if (3 == this.scheduleCycle) {
            this.scheduleCycleName = "按日";
        } else if (4 == this.scheduleCycle) {
            this.scheduleCycleName = "按时";
        }
    }

    //解析同步方式
    public void analysisSyncType() {
        //0全量1增量
        if (null == this.syncType) {
            this.syncTypeName = "全量";
        } else if (1 == this.syncType) {
            this.syncTypeName = "增量";
        } else {
            this.syncTypeName = "全量";
        }
    }

}
