package com.openjava.dts.dataasset.vo;

import com.openjava.dts.dataasset.domain.DtsDatassetItem;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * @author by jianli
 * @date 2020/2/24.
 */
@ApiModel("资产管理明细:数据详情")
@Data
@EqualsAndHashCode(callSuper = false)
public class DtsDatassetItemVO {
    private String message;
    private Integer code;

    @ApiModelProperty("总数据量")
    private Long total;

    @ApiModelProperty("总页数")
    private Integer totalPage;

    @ApiModelProperty("每页显示数量")
    private Integer size;

    @ApiModelProperty("当前页面(从0开始)")
    private Integer number;

    @ApiModelProperty("开始数据")
    private Integer star;

    private List<DtsDatassetItem> rows;
}
