package com.openjava.dts.dataasset.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author jianli
 * @date 2020-06-08 16:54
 */

@ApiModel("系统数据库")
@Data
@Accessors(chain = true)
public class DtsSystemDatabaseVO {

    @ApiModelProperty("数据库名称")
    private String databaseName;

    @ApiModelProperty("资源数")
    private Long resourcesNumber;

    @ApiModelProperty("数据量")
    private Long totalNumber;

    @ApiModelProperty("汇聚率")
    private String convergenceRate;

    @ApiModelProperty("数据源id")
    private String datasourceId;

    @ApiModelProperty("资产id")
    private Long dataassetId;

    @ApiModelProperty("项目id")
    private Long projectId;

    /**
     * 资产id和系统id是一对一的关系,
     * 这里呢 , 前端不改的,就直接将资产id == 系统id
     */
    @ApiModelProperty("系统id")
    private Long systemId;

    @ApiModelProperty("创建时间")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    private Date createTime;

}
