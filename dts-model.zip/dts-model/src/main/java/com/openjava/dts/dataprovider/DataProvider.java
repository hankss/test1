package com.openjava.dts.dataprovider;

import com.openjava.dts.dataprovider.result.AggregateResult;
import com.openjava.dts.dataprovider.result.AggregateResultV2;
import com.openjava.dts.ddl.domain.DtsColumn;
import com.openjava.dts.ddl.dto.ColumnInfo;
import com.openjava.dts.ddl.dto.DatasourceInfo;
import com.openjava.dts.ddl.dto.TableInfo;
import com.openjava.dts.statistic.domain.DtsStatisticsDb;
import com.openjava.dts.statistic.domain.DtsStatisticsTable;
import com.openjava.dts.util.JasyptUtil;
import org.jasypt.iv.StringFixedIvGenerator;
import org.ljdp.component.exception.APIException;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Map;

/**
 * @author: lsw
 * @Date: 2019/8/1 10:14
 */
public abstract class DataProvider {
    protected DatasourceInfo datasource;

    public DatasourceInfo getDatasource() {
        return JasyptUtil.decyptDatasourceInfo(datasource);
    }

    public void setDatasource(DatasourceInfo datasource) {
        this.datasource = datasource;
    }

    /*-------------------------对外开放的方法------------------------*/

    /**
     * 检查表是否存在
     *
     * @param tableName  表名
     * @return           是否存在
     * @throws Exception 异常
     */
    public abstract  Boolean checkTableExist(String tableName) throws Exception;

    /**
     * 获取建表sql
     *
     * @param tableName     表名
     * @param tableComments 表注释
     * @param columnList    列信息
     * @return              建表语句集合
     * @throws Exception    异常
     */
    public abstract List<String> getCreateTableSql(String tableName, String tableComments, List<DtsColumn> columnList) throws Exception;

    /**
     * 创建表
     *
     * @param tableName     表名
     * @param tableComments 表注释
     * @param columnList    字段集合
     * @return              创建是否成功
     * @throws Exception    异常
     */
    public abstract Boolean createTable(String tableName, String tableComments, List<DtsColumn> columnList) throws Exception;

    /**
     * 根据sql创建表
     *
     * @param sqlList sqlList
     * @return        创建结果
     */
    public abstract Boolean createTableBySql(List<String> sqlList) throws Exception;

    /**
     * 修改表-只允修改属性
     *
     * @param tableName     表名
     * @param tableComments 表注释
     * @param columnList    字段集合
     * @return              更新是否成
     * @throws Exception    异常
     */
    public abstract Boolean updateTable(String tableName, String tableComments, List<DtsColumn> columnList) throws Exception;

    /**
     * 修改表-添加列字段
     *
     * @param tableName     表名
     * @param tableComments 表注释
     * @param columnList    字段集合
     * @return              更新是否成
     * @throws Exception    异常
     */
    public abstract Boolean addTableColumn(String tableName, String tableComments, List<DtsColumn> columnList) throws Exception;

    /**
     * 添加表字段
     *
     * @param tableName
     * @param tableComments
     * @param columnList
     * @return
     */
    public abstract List<String> addTableColumnSqlList(String tableName, String tableComments, List<DtsColumn> columnList) throws Exception;

    /**
     * 修改表-添加列字段
     *
     * @param tableName     表名
     * @param tableComments 表注释
     * @param columnList    字段集合
     * @return              更新是否成
     * @throws Exception    异常
     */
    public abstract Boolean deleteTableColumn(String tableName, String tableComments, List<DtsColumn> columnList) throws Exception;

    /**
     * 获取当前表的总条数
     * @param tableName
     * @return
     * @throws Exception
     */
    public abstract Integer getTotalNumberByTableName(String tableName) throws Exception;

    /**
     * 获取当前表的总条数--sql
     * @param tableName
     * @return
     * @throws Exception
     */
    public abstract String getTotalNumberByTableNameSql(String tableName) throws Exception;

    /**
     * 添加表字段
     *
     * @param tableName
     * @param tableComments
     * @param columnList
     * @return
     */
    public abstract List<String> deleteTableColumnSqlList(String tableName, String tableComments, List<DtsColumn> columnList) throws Exception;

    /**
     * 得到建表ddl
     *
     * @param tableName  表名
     * @return
     * @throws Exception 异常
     */
    public abstract String getTableDDL(String tableName) throws Exception;

    /**
     * 删除表
     *
     * @param tableName  表名
     * @return           删除是否成功
     * @throws Exception 异常
     */
    public abstract Boolean dropTable(String tableName) throws Exception;

    /**
     * 查询sql
     *
     * @param execSql    查询sql
     * @return           查询结果
     * @throws Exception 异常
     */
    public abstract List<String[]> doQuery(String execSql) throws Exception;

    /**
     * 查询sql
     *
     * @param execSql    查询sql
     * @return           查询结果
     * @throws Exception 异常
     */
    public abstract List<Map<String,Object>> queryForList(String execSql) throws Exception;


    public abstract Map<String, Object> queryForMap(String execSql) throws Exception;

    /**
     * 执行sql
     *
     * @param execSql    执行的sql
     * @return           执行是否成功
     * @throws Exception 异常
     */
    public abstract Boolean doExecute(String execSql) throws Exception;

    /**
     * 获取当前表的总行数
     *
     * @param execSql
     * @return
     * @throws Exception
     */
    public abstract Integer doExecuteToGetTotalNumber(String execSql) throws Exception;

    /**
     * 执行sql
     *
     * @param execSql sql语句
     * @return        结果
     * @throws Exception 异常
     */
    public abstract Boolean executeUpdate(String execSql) throws Exception;

    /**
     * 批量执行sql
     *
     * @param execSqlList sql语句
     * @return            结果
     * @throws Exception  异常
     */
    public abstract Boolean executeUpdateBatch(List<String> execSqlList) throws Exception;

    /**
     * 获取表信息
     *
     * @param tableNameLike 表名查询关键字
     * @return              表信息集合
     * @throws Exception    异常
     */
    public abstract List<TableInfo> getTableList(String tableNameLike) throws Exception;

    /**
     * 获取所有的 表名字
     *
     * @return 表信息集合
     * @throws Exception 异常
     */
    public abstract List<String> getAllTableName() throws Exception;

    /**
     * 获取表和视图信息
     *
     * @param tableNameLike 表名查询关键字
     * @return              表信息集合
     * @throws Exception    异常
     */
    public abstract List<TableInfo> getTableAndViewList(String tableNameLike) throws Exception;

    /**
     * 获取表的列信息
     *
     * @param tableName  表名
     * @return           列集合信息
     * @throws Exception 异常
     */
    public abstract List<ColumnInfo> getColumnList(String tableName) throws Exception;

    /**
     * 获取表的列信息
     *
     * @param tableName  表名
     * @return           列集合信息
     * @throws Exception 异常
     */
    public abstract List<ColumnInfo> getColumnListFromView(String tableName, String db_name) throws Exception;

    /**
     * 获取主键名的执行SQL
     *
     * @param tableNameS
     * @return
     */
    public abstract String getPrimaryKeyOfSql(String tableNameS);

    /**
     * 获取到主键名
     *
     * @param tableNameS
     * @return
     * @throws Exception
     */
    public abstract List<ColumnInfo> getPrimaryKey(String tableNameS) throws Exception;

    /**
     * 获取表字段信息(从视图获取) -- 执行SQL
     *
     * @param tableNameS
     * @return
     * @throws Exception
     */
    public abstract String getBatchTableColumnListSql(String tableNameS) throws Exception;

    /**
     * 获取表字段信息(从视图获取)
     *
     * @param tableNameS
     * @return
     * @throws Exception
     */
    public abstract List<ColumnInfo> getBatchTableColumnList(String tableNameS) throws Exception;

    /**
     * 获取表注释信息(从视图获取) -- 执行SQL
     *
     * @param tableNameS
     * @return
     * @throws Exception
     */
    public abstract String getBatchTableCommentListSql(String tableNameS) throws Exception;

    /**
     * 获取表注释信息(从视图获取)
     *
     * @param tableNameS
     * @return
     * @throws Exception
     */
    public abstract List<TableInfo> getBatchTableCommentList(String tableNameS) throws Exception;


    /**
     * 获取数据库所有列信息（列名及所属表名）
     *
     * @return 列信息集合
     * @throws Exception 异常
     */
    public abstract List<ColumnInfo> getAllColumn() throws Exception;

    /**
     * 查询表数据
     *
     * @param columns    列名集合
     * @param tableName  表名
     * @param pageable   分页
     * @param where      where条件
     * @return           查询结果（数据+列名）
     * @throws Exception 异常
     */
    public abstract AggregateResult queryTableData(List<String> columns, String tableName, String where, Pageable pageable) throws Exception;

    /**
     * 查询表数据V2
     *
     * @param columns    列名集合
     * @param tableName  表名
     * @param pageable   分页
     * @param where      where条件
     * @return           查询结果（数据+列名）
     * @throws Exception 异常
     */
    public abstract AggregateResultV2 queryTableDataV2(List<String> columns, String tableName, String where, Pageable pageable) throws Exception;

    /**
     * 查询表数据V2,但无主键信息
     * @param columns 列名集合
     * @param tableName 表名
     * @param where where条件
     * @param pageable 分页
     * @param dbName 数据库名
     * @return 查询结果（数据+列名）
     * @throws Exception 异常
     */
    public abstract AggregateResultV2 queryTableDataV2FromView(List<String> columns, String tableName, String where, Pageable pageable, String dbName) throws Exception;

    /**
     * 查询表数据，只针对Oracle
     *
     * @param columns   列名集合
     * @param tableName 表名
     * @param where     where条件
     * @param pageable  分页
     * @param dbName    数据库名
     * @param ownerList Oracle所属用户名
     * @return 查询结果（数据+列名）
     * @throws Exception 异常
     */
    public abstract AggregateResultV2 queryTableDataOnlyOracle(List<String> columns, String tableName, String where, Pageable pageable, String dbName, List<String> ownerList) throws Exception;

    /**
     * 连通测试
     *
     * @return           是否连通
     * @throws Exception 异常
     */
    public abstract boolean linkTest() throws Exception;

    /**
     * 修改表
     *
     * @return
     */
    public abstract List<String> getUpdateTableSqlList(String tableName, String tableComments, List<DtsColumn> columnList);

    /**
     * 复制表结构
     * @param tarTableName
     * @param srcTableName
     * @return
     */
    public abstract boolean copyTableStructure(String tarTableName,String srcTableName)throws Exception;

    /**
     * 重命名表名
     * @param newTableName
     * @param srcTableName
     * @return
     */
    public abstract boolean renameTable(String newTableName,String srcTableName)throws Exception;


    /**
     * 跟据表名取得表的信息
     * @param tableName
     * @return
     */
    public abstract DtsStatisticsTable getDtsStatisticsTable(String tableName)throws Exception;

    /**
     * 取得所有表的信息返回
     * @return
     */
    public abstract List<DtsStatisticsTable> getDtsStatisticsTableList()throws Exception;

    /**
     * 取得整个数据源的信息
     * @param DtsStatisticsTableList
     * @return
     */
    public abstract DtsStatisticsDb getDtsStatisticsDb(List<DtsStatisticsTable> DtsStatisticsTableList)throws Exception;

    /**
     * 取得整个数据源的信息
     * @return
     */
    public abstract DtsStatisticsDb getDtsStatisticsDb()throws Exception;

    /**
     * 取提表记录
     * @param tableName
     * @return
     */
    public abstract Long getTableDataRows(String tableName);

    /**
     * 取提表记录,带有where条件
     *
     * @param tableName 表名
     * @param where     查询条件
     * @return 返回值
     */
    public abstract Long getTableDataRowsHaveWhere(String tableName, String where);

    /**
     * 取提表记录
     *
     * @param tableNameList
     * @return
     * @throws APIException
     */
    public abstract Long getTableDataRowsFromView(List<String> tableNameList) throws APIException;


    public abstract boolean addTableColumn(String tableName, List<ColumnInfo> columnList) throws Exception;

    public abstract boolean truncateTable(String tableName) throws Exception;

    /**
     * ORACLE数据库专用获取,数据库表名和表注释
     *
     * @param tableNameLike 表名
     * @param owner         用户名
     * @param list          已同步的表
     * @param taskFlag      是否筛选同步与未同步
     * @param pageable      分页参数
     * @return
     * @throws Exception 异常
     */
    public abstract List<TableInfo> getTableListOnlyOracleV2(String tableNameLike, String owner, List<String> list, Integer taskFlag, Pageable pageable) throws Exception;

    /**
     * 获取总的表数据
     *
     * @param tableNameLike 表名字
     * @param owner         用户名
     * @param list          已同步的表
     * @param taskFlag      是否筛选同步与未同步
     * @return 表数量
     * @throws Exception 异常
     */
    public abstract long countTableListOnlyOracleV2(String tableNameLike, String owner, List<String> list, Integer taskFlag) throws Exception;

    /**
     * ORACLE数据库专用获取,数据库表名和表注释
     *
     * @param tableNameLike 表名
     * @param owner         用户名
     * @param list          已同步的表
     * @param taskFlag      是否筛选同步与未同步
     * @param pageable      分页参数
     * @return
     * @throws Exception 异常
     */
    public abstract List<TableInfo> getTableListOnlyOracle(String tableNameLike, String owner, List<String> list, Integer taskFlag, Pageable pageable) throws Exception;

    /**
     * 获取总的表数据
     *
     * @param tableNameLike 表名字
     * @param owner         用户名
     * @param list          已同步的表
     * @param taskFlag      是否筛选同步与未同步
     * @return 表数量
     * @throws Exception 异常
     */
    public abstract long countTableListOnlyOracle(String tableNameLike, String owner, List<String> list, Integer taskFlag) throws Exception;

    /**
     * 获取owner 仅限制Oracle数据库
     *
     * @return ownerList
     * @throws Exception 异常
     */
    public abstract List<String> getOwnerOnlyOracle() throws Exception;

    /**
     * oralce 获取表字段信息
     *
     * @param tableName
     * @param dbName
     * @return
     * @throws Exception
     */
    public abstract List<ColumnInfo> getColumnListOnlyOracle(String tableName, String dbName) throws Exception;

}
