package com.openjava.dts.dataprovider;

import com.openjava.dts.constants.ExceptionConstants;
import com.openjava.dts.dataprovider.annotation.ProviderName;
import com.openjava.dts.ddl.dto.DatasourceInfo;
import com.openjava.dts.util.JasyptUtil;
import org.ljdp.component.exception.APIException;
import org.reflections.Reflections;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * @author: lsw
 * @Date: 2019/8/1 10:26
 */
@Service
public class DataProviderManager implements ApplicationContextAware {
    private static Logger LOG = LoggerFactory.getLogger(DataProviderManager.class);

    private static Map<String, Class<? extends DataProvider>> providers = new HashMap<>(10);

    private static ApplicationContext applicationContext;

    static {
        //初始化，反射加载类到map供后面生成实例
        Set<Class<?>> classSet = new Reflections("com.openjava.dts.dataprovider.jdbc").getTypesAnnotatedWith(ProviderName.class);
        for (Class c : classSet) {
            if (!c.isAssignableFrom(DataProvider.class)) {
                providers.put(((ProviderName) c.getAnnotation(ProviderName.class)).name(), c);
            } else {
                LOG.error("\n[DataProviderManager]自定义DataProvider需要继承org.cboard.dataprovider.DataProvider");
            }
        }
    }

    /**
     * 获取核心工具
     * @param datasource
     * @return
     * @throws Exception
     */
    public static DataProvider getDataProvider(DatasourceInfo datasource)
            throws Exception {
        return getDataProvider(JasyptUtil.decyptDatasourceInfo(datasource), false);
    }

    /**
     * 获取核心工具
     * @param datasource
     * @param pooled
     * @return
     * @throws Exception
     */
    public static DataProvider getDataProvider(DatasourceInfo datasource, Boolean pooled) throws Exception {
        String type = getTypeByDbType(datasource.getDatabaseType());
        Class c = providers.get(type);
        if(c == null){
            throw new APIException(10001, "没有此数据库类型对应的DataProvider："+datasource.getDatabaseType());
        }
        ProviderName providerName = (ProviderName) c.getAnnotation(ProviderName.class);

        if (!providerName.name().equals(type)) {
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, ExceptionConstants.EXCEPTION_ERROR_MSG + "");
        }
        DataProvider provider = (DataProvider) c.newInstance();
        //为什么要注入到容器内部，变成bean
        if (applicationContext != null) {
            applicationContext.getAutowireCapableBeanFactory().autowireBean(provider);
        }
        //设置数据库信息
        datasource.setPooled(pooled);
        provider.setDatasource(JasyptUtil.decyptDatasourceInfo(datasource));

        return provider;
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        DataProviderManager.applicationContext = applicationContext;
    }

    public static String getTypeByDbType(Integer dbType) {
        String type = "none";
        //0:Oracle;1:MySql新版本;2;Mysql旧版本;3:PostgreSql;4:hive
        switch (dbType.intValue()) {
            case 0:
                type = "oracle";
                break;
            case 1:
                type = "mysqlNew";
                break;
            case 2:
                type = "mysqlOld";
                break;
            case 3:
                type = "postgreSql";
                break;
            case 4:
                type = "hive";
                break;
            case 5:
                type = "sqlserver";
                break;
            case 6:
                type = "huawei-hive";
                break;
            case 7:
                type = "gaussDB";
                break;
            default:
                break;
        }

        return type;
    }
}
