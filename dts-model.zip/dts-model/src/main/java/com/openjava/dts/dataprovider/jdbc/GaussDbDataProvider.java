package com.openjava.dts.dataprovider.jdbc;

import com.alibaba.fastjson.JSON;
import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.openjava.dts.constants.DtsConstants;
import com.openjava.dts.constants.ExceptionConstants;
import com.openjava.dts.dataprovider.annotation.ProviderName;
import com.openjava.dts.dataprovider.result.AggregateResultV2;
import com.openjava.dts.dataprovider.result.ColumnIndex;
import com.openjava.dts.ddl.domain.DtsColumn;
import com.openjava.dts.ddl.dto.ColumnInfo;
import com.openjava.dts.ddl.dto.DatasourceInfo;
import com.openjava.dts.ddl.dto.TableInfo;
import com.openjava.dts.statistic.domain.DtsStatisticsTable;
import com.openjava.dts.util.CreateSqlUtil;
import com.openjava.dts.util.DtsMathUtil;
import com.openjava.dts.util.EnumUtil;
import com.openjava.dts.util.JsonUtil;
import com.openjava.dts.util.column.JavaSqlTypeEnum;
import org.apache.commons.lang3.StringUtils;
import org.ljdp.component.exception.APIException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.util.CollectionUtils;

import javax.validation.constraints.NotBlank;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author: hl
 * @Date: 2020-01-07
 */
@ProviderName(name = "gaussDB")
public class GaussDbDataProvider extends JdbcDataProvider {

    private static final Logger LOG = LoggerFactory.getLogger(GaussDbDataProvider.class);

    @Override
    public String getDriver() {
        return "com.huawei.gauss.jdbc.ZenithDriver";
    }

    @Override
    protected String getValidationQuery() {
        return "select 'x' from dual";
    }

    @Override
    public String getQueryTableDataSql(String columns, String tableName, String where, Pageable pageable) {

        if(pageable ==null || pageable.getPageSize() == 0 || pageable.getPageSize() > 1000)
            pageable = PageRequest.of(0, 30);

        StringBuilder sb = new StringBuilder();
        sb.append("select ");
        if (StringUtils.isNotBlank(columns))
            sb.append(columns);
        else {
            sb.append("*");
        }
        sb.append(" from ");
        sb.append(tableName);
        if (StringUtils.isNotBlank(where)) {
            sb.append(" where ");
            sb.append(where);
        }
        if (pageable != null && pageable.getPageSize() != 0) {
            sb.append(" limit ");
            sb.append(pageable.getOffset());
            sb.append(",");
            sb.append(pageable.getPageSize());
        }else{
            sb.append(" limit 30 ");
        }
        return sb.toString();
    }


    @Override
    public List<ColumnInfo> getColumnList(String tableName) throws Exception {
        List<ColumnInfo> list = new LinkedList<>();
        PreparedStatement ps=null;
        ResultSet rs=null;
        Connection connection = null;
        try{
            connection = getConnection();
            //DatabaseMetaData metaData = connection.getMetaData();
            //ResultSet primaryKeys = metaData.getPrimaryKeys(connection.getCatalog(), connection.getSchema(),tableName);
            String primaryKeyName = null;
            //if (primaryKeys.next())
            //    primaryKeyName = primaryKeys.getString("COLUMN_NAME");
            List<ColumnInfo>  primaryL = getPrimaryKey(tableName);
            if(primaryL != null && primaryL.size()>0){
                primaryKeyName = primaryL.get(0).getColumnSource();
            }
            tableName = tableName.toUpperCase();
            //高斯兼容大小写表名的做法，给表名加上``，即可按照原表名的格式查询，否则会统一转成大写来查询
            ps = connection.prepareStatement(" select * from `"+tableName+"` limit 1");
            ps.setFetchSize(1);
            rs = ps.executeQuery();
            ResultSetMetaData resultSetMetaData = rs.getMetaData();
            int colCount = resultSetMetaData.getColumnCount();
            for(int i=1;i<=colCount;i++){
                String columnName = resultSetMetaData.getColumnName(i);
                String remarks = "";
                int javaTypesSql = resultSetMetaData.getColumnType(i);
                int precision = resultSetMetaData.getPrecision(i);
                int scale = resultSetMetaData.getScale(i);
                int nullable = resultSetMetaData.isNullable(i);
                String belongTableName = tableName;
                JavaSqlTypeEnum typeEnum = EnumUtil.getByCode(javaTypesSql, JavaSqlTypeEnum.class);
                String columnTypeName = String.valueOf(typeEnum.getName());
                ColumnInfo column = new ColumnInfo();
                column.setColumnIndex(i);
                column.setColumnSource(columnName);
                column.setColumnType(StringUtils.upperCase(columnTypeName));
                column.setColumnPrecision(precision);
                column.setColumnScale(scale);
                column.setNullable(nullable == 1);
                column.setColumnComment(remarks);
                column.setBelongTableName(belongTableName);
                if(primaryKeyName != null && primaryKeyName.equalsIgnoreCase(columnName))
                    column.setIsPrimaryKey(true);
                else
                    column.setIsPrimaryKey(false);
                list.add(column);
            }
        } catch (Exception e) {
            LOG.error("\n[gaussdb getColumnList]数据库连接或查询异常",e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR,"没有权限查看此表或表不存在");
        }finally {
            if(rs != null)
                rs.close();
            if(ps != null)
                ps.close();
            if(connection != null)
                connection.close();
        }
        List<ColumnInfo> columnCommentList = this.getColumnComment(tableName);
        list.stream().filter(Objects::nonNull).forEach(x->{ columnCommentList.forEach(a -> { if (a.getColumnSource().equals(x.getColumnSource())) x.setColumnComment(a.getColumnComment()); }); });
        return list;
    }

    public List<ColumnInfo> getColumnComment(String tableName) throws APIException {
        //获取字段注释
        StringBuilder sb = new StringBuilder("select * from user_col_comments where TABLE_NAME = '");
        sb.append(tableName).append("'");
        String doSql = sb.toString();
        List<ColumnInfo> list = Lists.newArrayList();
        try (Connection con = getConnection()) {
            Statement ps = con.createStatement();
            LOG.debug("\n[doExecuteBatch]Execute sql: " + doSql);
            ResultSet resultSet = ps.executeQuery(doSql);
            while (resultSet.next()) {
                String column_name = resultSet.getString("COLUMN_NAME");
                String table_name = resultSet.getString("TABLE_NAME");
                String comments = resultSet.getString("COMMENTS");
                ColumnInfo column = new ColumnInfo();
                column.setColumnSource(column_name);
                column.setBelongTableName(table_name);
                column.setColumnComment(comments);
                list.add(column);
            }
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
        return list;
    }

    @Override
    public AggregateResultV2 queryTableDataV2(List<String> columns, String tableName, String where, Pageable pageable) throws Exception {
        List<ColumnInfo> columnList = this.getColumnList(tableName);
        List<ColumnInfo> columnCommentList = this.getColumnComment(tableName);
        columnList.stream().filter(Objects::nonNull).forEach(x->{ columnCommentList.forEach(a -> { if (a.getColumnSource().equals(x.getColumnSource())) x.setColumnComment(a.getColumnComment()); }); });
        this.getColumnComment(tableName);
        if (CollectionUtils.isEmpty(columns))
            columns = columnList.stream().map(ColumnInfo::getColumnSource).collect(Collectors.toList());
        Map<@NotBlank String, ColumnInfo> columnInfoMap = columnList.stream().collect(Collectors.toMap(ColumnInfo::getColumnSource, (col) -> col));
        if (!CollectionUtils.isEmpty(columns)) {
            List<ColumnInfo> columnTempList = new ArrayList<>(columnList.size());
            for (String column : columns) {
                ColumnInfo columnInfo = columnInfoMap.get(column);
                if (columnInfo == null)
                    continue;
                columnTempList.add(columnInfo);
            }
            columnList = columnTempList;
        }
        List<ColumnIndex> colList = new ArrayList<>(columnList.size());
        for (ColumnInfo info : columnList) {
            ColumnIndex colIndex = new ColumnIndex();
            colIndex.setIndex(info.getColumnIndex());
            colIndex.setName(info.getColumnSource());
            String comment = info.getColumnComment();
            //取真实的注释
//            if (StringUtils.isBlank(comment))
//                comment = info.getColumnSource();
            colIndex.setComment(comment);
            colIndex.setColumnType(info.getColumnType());
            colList.add(colIndex);
        }
        //高斯兼容大小写表名的做法，给表名加上``，即可按照原表名的格式查询，否则会统一转成大写来查询
        String exec = this.getQueryTableDataSql(Joiner.on(",").skipNulls().join(columns), "`"+tableName+"`", where, pageable);
        List<Map<String, String>> list = new LinkedList<>();
        boolean isOracle = Objects.equals(this.getDatasource().getDatabaseType(), DtsConstants.DATABASE_TYPE_ORACLE);
        LOG.info(exec);
        try (Connection connection = getConnection();
             Statement stat = connection.createStatement();
             ResultSet rs = stat.executeQuery(exec)
        ) {
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            while (rs.next()) {
                Map<String, String> row = new LinkedHashMap<>(columnCount);
                for (int j = 0; j < columnCount; j++) {
                    int columType = metaData.getColumnType(j + 1);
                    String value;
                    switch (columType) {
                        case Types.DATE:
                            Date date = rs.getDate(j + 1);
                            value = (date == null? null : date.toString());
                            break;
                        default:
                            value = rs.getString(j + 1);
                            if (isOracle && Objects.equals(columType, Types.TIMESTAMP) && StringUtils.isNotBlank(value))
                                value = value.replace(".0", "");
                            break;
                    }
                    if (j >= colList.size())
                        continue;
                    row.put(colList.get(j).getName(), value);
                }
                list.add(row);
            }
        } catch (Exception e) {
            LOG.error("\n[queryTableData]数据库连接或查询异常:" + e.getMessage(),e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常");
        }
        AggregateResultV2 result = new AggregateResultV2();
        result.setData(list);
        result.setColumnList(colList);
        return result;
    }

    /**
     * 获取高斯数据库的所有表信息
     * @return
     * @throws Exception
     */
    @Override
    public List<DtsStatisticsTable> getDtsStatisticsTableList() throws Exception {
        List<DtsStatisticsTable> dtsStatisticsTableList = new LinkedList<>();
        try {
            DatasourceInfo datasourceInfo = this.getDatasource();
            StringBuilder sql = new StringBuilder("");
//            sql.append("SELECT t.VALUE as VALUE FROM DV_PARAMETERS t where t.NAME='CBO'");
//            // CBO，如果值为off，则需要手动循环每张表来单独统计总数，暂时不使用。循环提取记录信息时，判断记录数是否为NULL，为空再查询该表的总记录数
            sql.append("select * from ADM_TABLES t").append(" ");
            String owner = datasourceInfo.getUsername();
            if (owner == null || "".equals(owner)){
                return dtsStatisticsTableList;
            }
            sql.append("where t.OWNER='").append(owner).append("'");
            List<Map<String,Object>> list = this.queryForList(sql.toString());
            LOG.info("gauss 查询表语句及查询结果：{}，{}",sql.toString(), JSON.toJSONString(list));
            list.forEach(s->{
                DtsStatisticsTable record = this.getGaussStatisticsTable(s);
                if (record != null){
                    dtsStatisticsTableList.add(record);
                }
            });

        }catch (Exception var1){
            LOG.error("\n[gauss getDtsStatisticsTableList]数据库连接或查询异常:" + var1.getMessage(), var1);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, ExceptionConstants.EXCEPTION_ERROR_MSG + "数据库连接或查询异常:" + var1.getMessage());
        }
        return dtsStatisticsTableList;
    }

    /**
     * 提取每一行记录的列
     * @param row
     * @return
     */
    public DtsStatisticsTable getGaussStatisticsTable(Map<String,Object> row){
        try {
            DtsStatisticsTable table = new DtsStatisticsTable();
            table.setTableName(row.get("TABLE_NAME").toString());
            int recordCount = -1;
            if (row.get("NUM_ROWS") != null && !"".equalsIgnoreCase(row.get("NUM_ROWS").toString())){
                // 该字段的类型为Integer，可直接转换
                recordCount = (int) row.get("NUM_ROWS");
            }else {
                LOG.debug("单次查询{}表的总记录数",table.getTableName());
                recordCount = (int) this.querySingleTableInfo(table.getTableName());
            }
            if (recordCount == -1){
                table.setRows(0.0D);
            }else {
                table.setRows(DtsMathUtil.getRoundHalfUpDouble(recordCount / 10000));
            }
            double allSpace = 0d;
            long bytes = 0;
            if (row.get("BYTES") != null){
                bytes = (long) row.get("BYTES");
            }
            // allSpace单位为GB，1Gb=1*1024*1024*1024
            allSpace = DtsMathUtil.getGBfromByte(bytes);
            table.setAllSpace(allSpace);
            LOG.debug("gauss single table info:{}",JSON.toJSONString(table));
            return table;
        }catch (Exception var1){
            LOG.error("\n[gauss DtsStatisticsUtil getGaussStatisticsTable 提取单行记录的表信息失败,传参:{} ]", JsonUtil.objectToJson(row),var1);
        }
        return null;
    }

    /**
     * 统计单张表的总记录数
     * @param tableName
     * @return
     * @throws Exception
     */
    private long querySingleTableInfo(String tableName)throws Exception{
        List<Map<String,Object>> total = this.queryForList("select count(1) as TOTAL from " + tableName);
        LOG.debug("gauss query single table:{},total record count：{}",tableName,JSON.toJSONString(total));
        if (total != null && total.size() > 0 && total.get(0) != null && total.get(0).get("TOTAL") != null){
            return (long) total.get(0).get("TOTAL");
        }
        return 0L;
    }

    @Override
    protected List<String> getCreateTableSqlList(String tableName, String tableComments, List<DtsColumn> columnList) {
        String schema = this.getDatasource().getSchemaName();
        if (StringUtils.isBlank(schema)) {
            schema = "PUBLIC";
        }

        //高斯建表要加上模式名称
        tableName = "\"" + schema + "\"." + tableName;
        List<String> sqlList = new LinkedList<>();
        //建表语句
        String createTableSQL = CreateSqlUtil.createOracleTableSQL(tableName, columnList);
        //表注释语句
        String tableCommentsSql = "COMMENT ON TABLE " + tableName + " IS '" + tableComments + "'";

        //字段注释
        List<String> commentSqlList = new ArrayList<>(columnList.size());
        DtsColumn primaryKeyColumn = null;
        for (DtsColumn column : columnList) {
            StringBuilder sb = new StringBuilder();
            sb.append("COMMENT ON COLUMN ");
            sb.append(tableName);
            sb.append(".");
            sb.append(column.getColumnSource());
            sb.append(" IS '");
            sb.append(StringUtils.isNotEmpty(column.getColumnComment()) ? column.getColumnComment() : "");
            sb.append("'");

            commentSqlList.add(sb.toString());

            if (column.getIsPrimaryKey()) {
                primaryKeyColumn = column;
            }
        }

        //表主键语句
        String primaryKeySql = "";
        if (primaryKeyColumn != null) {
            StringBuilder sb = new StringBuilder();
            sb.append("ALTER TABLE ");
            sb.append(tableName);
            sb.append(" ADD constraint pk_");
            sb.append(tableName);
            sb.append("_");
            sb.append(primaryKeyColumn.getColumnSource());
            sb.append(" primary key (");
            sb.append(primaryKeyColumn.getColumnSource());
            sb.append(")");

            primaryKeySql = sb.toString();
        }

        sqlList.add(createTableSQL);
        sqlList.add(tableCommentsSql);
        sqlList.addAll(commentSqlList);
        if (StringUtils.isNotBlank(primaryKeySql)) {
            sqlList.add(primaryKeySql);
        }

        return sqlList;
    }

    @Override
    public List<TableInfo> getTableList(String tableNameLike) throws Exception {
        String owner = this.getDatasource().getUsername();
        StringBuilder sql = new StringBuilder();
        sql.append(" select t.TABLE_NAME,t.OWNER,c.COMMENTS from ADM_TABLES t left join ALL_TAB_COMMENTS c on t.TABLE_NAME=c.TABLE_NAME and t.OWNER=c.OWNER ");
        sql.append(" where t.OWNER='").append(owner).append("'");
        if (StringUtils.isNotBlank(tableNameLike)){
            sql.append(" and t.TABLE_NAME like '%").append(tableNameLike).append("%'");
        }
        List<TableInfo> list = new ArrayList<>();
        List<Map<String,Object>> result = this.queryForList(sql.toString());
        result.forEach(s->{
            TableInfo info = new TableInfo();
            info.setTableSource(s.get("TABLE_NAME").toString());
            info.setTableComment(s.getOrDefault("COMMENTS","").toString());
            list.add(info);
        });
        return list;
    }

    @Override
    public List<TableInfo> getTableAndViewList(String tableNameLike) throws Exception {
        //先查询表
        List<TableInfo> temp = this.getTableList(tableNameLike);
        String owner = this.getDatasource().getUsername();
        StringBuilder sql = new StringBuilder();
        //再查询视图
        sql.append(" select t.OWNER,t.VIEW_NAME from ADM_VIEWS t ");
        sql.append(" where t.OWNER='").append(owner).append("'");
        if (StringUtils.isNotBlank(tableNameLike)){
            sql.append(" and t.VIEW_NAME like '%").append(tableNameLike).append("%'");
        }
        List<TableInfo> list = new ArrayList<>();
        List<Map<String,Object>> result = this.queryForList(sql.toString());
        result.forEach(s->{
            TableInfo info = new TableInfo();
            info.setTableSource(s.get("VIEW_NAME").toString());
            info.setTableComment("");
            list.add(info);
        });
        list.addAll(temp);
        return list;
    }

    @Override
    public List<ColumnInfo> getPrimaryKey(String tableNameS) throws Exception {
        String doSql = getPrimaryKeyOfSql(tableNameS);
        List<ColumnInfo> list = Lists.newArrayList();
        try (Connection con = getConnection()) {
            Statement ps = con.createStatement();
            LOG.debug("\n[doExecuteBatch]Execute sql: " + doSql);
            ResultSet resultSet = ps.executeQuery(doSql);
            while (resultSet.next()) {
                String column_name = resultSet.getString("COLUMN_NAME");
                String table_name = resultSet.getString("TABLE_NAME");
                ColumnInfo column = new ColumnInfo();
                column.setColumnSource(column_name);
                column.setBelongTableName(table_name);
                list.add(column);
            }
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
        return list;
    }

    @Override
    public String getPrimaryKeyOfSql(String tableNameS) {
        //子类实现
        return "select cu.* from user_cons_columns cu, user_constraints au where cu.constraint_name = au.constraint_name and au.constraint_type = 'P' and au.table_name ='"+tableNameS+"'";
    }
}
