package com.openjava.dts.dataprovider.jdbc;

import com.openjava.dts.constants.ExceptionConstants;
import com.openjava.dts.dataprovider.annotation.ProviderName;
import com.openjava.dts.ddl.domain.DtsColumn;
import com.openjava.dts.util.CreateSqlUtil;
import org.apache.commons.lang3.StringUtils;
import org.ljdp.component.exception.APIException;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.LinkedList;
import java.util.List;


/**
 * @author zl
 * @Date 2019-08-14
 */
@ProviderName(name = "huawei-hive")
public class HuaweiHiveDataProvider extends JdbcDataProvider {
    @Override
    public String getDriver() {
        return "org.apache.hive.jdbc.HiveDriver";
    }

    @Override
    protected String getValidationQuery() {
        return "select 1";
    }

    @Override
    protected String getCheckTableExistSql(String tableName) {
        return String.format("desc %s.%s", this.getDatasource().getDatabaseName(), tableName);
    }

    @Override
    protected List<String> getCreateTableSqlList(String tableName, String tableComments, List<DtsColumn> columnList) {
        List<String> sqlList = new LinkedList<>();
        //建表语句
        String createTableSQL = CreateSqlUtil.createHiveTableSQL(tableName, columnList);
        //表注释语句
        String tableCommentsSql = String.format("ALTER TABLE %s SET TBLPROPERTIES('comment' = '%s')",tableName,tableComments);

        sqlList.add(createTableSQL);
        sqlList.add(tableCommentsSql);

        return sqlList;
    }

    @Override
    public Boolean checkTableExist(String tableName) throws Exception {
        if (StringUtils.isBlank(tableName)) {
            throw new APIException(ExceptionConstants.REQUEST_ERROR, ExceptionConstants.REQUEST_ERROR_MSG + "表名不能为空");
        }
        Boolean flag = true;
        String checkTableSql = this.getCheckTableExistSql(tableName);
        try{
            doQuery(checkTableSql);
        }catch (Exception e){
            e.printStackTrace();
            flag = false;
        }
        return flag;
    }

    @Override
    public String getQueryTableDataSql(String columns, String tableName, String where, Pageable pageable) {
        if(pageable ==null || pageable.getPageSize() == 0 || pageable.getPageSize() > 1000)
            pageable = PageRequest.of(0, 30);
        StringBuilder sb = new StringBuilder();
        sb.append("select * from ");
        sb.append(tableName);
        if (StringUtils.isNotBlank(where)) {
            sb.append(" where ");
            sb.append(where);
        }
        if (pageable != null && pageable.getPageSize() != 0) {
            sb.append(" limit ");
            sb.append(pageable.getPageSize());
        }

        return sb.toString();
    }

    /**
     * 复制表结构
     * @param tarTableName
     * @param srcTableName
     * @return
     */
    @Override
    public boolean copyTableStructure(String tarTableName, String srcTableName) {
        //TODO 目前没有对接hive
        return false;
    }

    /**
     * 重命名表
     * @param newTableName
     * @param srcTableName
     * @return
     */
    @Override
    public boolean renameTable(String newTableName, String srcTableName) {
        //TODO 目前没有对接hive
        return false;
    }
}
