package com.openjava.dts.dataprovider.jdbc;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidDataSourceFactory;
import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Charsets;
import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.hash.Hashing;
import com.openjava.dts.constants.DtsConstants;
import com.openjava.dts.constants.ExceptionConstants;
import com.openjava.dts.dataprovider.DataProvider;
import com.openjava.dts.dataprovider.result.AggregateResult;
import com.openjava.dts.dataprovider.result.AggregateResultV2;
import com.openjava.dts.dataprovider.result.ColumnIndex;
import com.openjava.dts.ddl.domain.DtsColumn;
import com.openjava.dts.ddl.dto.ColumnInfo;
import com.openjava.dts.ddl.dto.TableInfo;
import com.openjava.dts.statistic.domain.DtsStatisticsDb;
import com.openjava.dts.statistic.domain.DtsStatisticsTable;
import com.openjava.dts.util.EnumUtil;
import com.openjava.dts.util.JasyptUtil;
import com.openjava.dts.util.JsonUtil;
import com.openjava.dts.util.ValidateUtil;
import com.openjava.dts.util.column.JavaSqlTypeEnum;
import org.apache.commons.lang3.StringUtils;
import org.ljdp.component.exception.APIException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Pageable;
import org.springframework.util.CollectionUtils;

import javax.sql.DataSource;
import javax.validation.constraints.NotBlank;
import java.net.ConnectException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.SQLSyntaxErrorException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Collectors;

/**
 * @author: lsw
 * @Date: 2019/8/1 10:15
 */
public class JdbcDataProvider extends DataProvider {
    private static final Logger LOG = LoggerFactory.getLogger(JdbcDataProvider.class);

    private boolean pooled = false;

    private static final ConcurrentMap<String, DataSource> datasourceMap = new ConcurrentHashMap<>(32);

    /**
     * 检测表是否存在
     *
     * @param tableName 表名
     * @return 是否存在
     * @throws Exception 异常
     */
    @Override
    public Boolean checkTableExist(String tableName) throws Exception {
        if (StringUtils.isBlank(tableName)) {
            throw new APIException(ExceptionConstants.REQUEST_ERROR, ExceptionConstants.REQUEST_ERROR_MSG + "表名不能为空");
        }

        String checkTableSql = this.getCheckTableExistSql(tableName);
        List<String[]> checkResult = doQuery(checkTableSql);
        if (CollectionUtils.isEmpty(checkResult)) {
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, ExceptionConstants.EXCEPTION_ERROR_MSG + "检测结果为空");
        }

        String[] resultArr = checkResult.get(0);
        String result = resultArr[0];

        return "1".equals(result);
    }

    @Override
    public List<String> getCreateTableSql(String tableName, String tableComments, List<DtsColumn> columnList) throws Exception {
        List<String> createTableSqlList = this.getCreateTableSqlList(tableName, tableComments, columnList);
        if (CollectionUtils.isEmpty(createTableSqlList)) {
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, ExceptionConstants.EXCEPTION_ERROR_MSG + "建表语句为空");
        }

        return createTableSqlList;
    }

    /**
     * 创建表
     *
     * @param tableName  表名
     * @param columnList 列属性信息
     * @return 创建是否成功
     */
    @Override
    public Boolean createTable(String tableName, String tableComments, List<DtsColumn> columnList) throws Exception {
        try {
            List<String> createTableSqlList = this.getCreateTableSqlList(tableName, tableComments, columnList);
            if (CollectionUtils.isEmpty(createTableSqlList)) {
                throw new APIException(ExceptionConstants.EXCEPTION_ERROR, ExceptionConstants.EXCEPTION_ERROR_MSG + "建表语句为空");
            }
            Boolean result = true;
            if (DtsConstants.DATABASE_TYPE_HIVE.equals(this.datasource.getDatabaseType())
                    || DtsConstants.DATABASE_TYPE_HIVE_HUAWEI.equals(this.datasource.getDatabaseType())) {
                //hive用execute，不然报错
                for (String sql : createTableSqlList) {
                    result = result && doExecute(sql);
                }
            } else {
                //单条执行
                /*for (String sql : createTableSqlList) {
                    result = result && executeUpdate(sql);
                }*/

                //批量执行
                result = createBatchReal(createTableSqlList);
            }

            return result;
        } catch (Exception e) {
            LOG.error("\n[createTable]创建表失败,表已存在或数据源连接失败:", e);
            LOG.error("\n[源表字段信息: {}]", columnList);
            throw new APIException(DtsConstants.REQUEST_ERROR, "创建表失败,表已存在或数据源连接失败.");
        }
    }

    /**
     * 批量执行sql
     *
     * @param execSqlList sql列表
     * @return 结果
     * @throws APIException 异常
     */
    private boolean createBatchReal(List<String> execSqlList) throws APIException {
        try (Connection con = getConnection();
             Statement ps = con.createStatement()) {
            for (String sql : execSqlList) {
                ps.addBatch(sql);
            }
            //执行批量处理语句
            ps.executeBatch();
            //清除批量打包
            ps.clearBatch();

            return true;
        } catch (Exception e) {
            LOG.error("\n[createBatchReal]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
    }

    private boolean createBatchReal2(List<String> execSqlList) throws APIException {
        try (Connection con = getConnection()) {
            PreparedStatement pstmt = con.prepareStatement(execSqlList.get(0));
            for (int i = 1; i < execSqlList.size(); i++) {
                pstmt.addBatch(execSqlList.get(i));
            }

            //执行批量处理语句
            pstmt.executeBatch();
            //清除批量打包
            pstmt.clearBatch();

            return true;
        } catch (Exception e) {
            LOG.error("\n[createBatchReal]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
    }

    @Override
    public Boolean createTableBySql(List<String> sqlList) throws Exception {
        ValidateUtil.notEmpty(sqlList, "建表语句不能为空");

        try {
            return executeUpdateBatch(sqlList);
        } catch (Exception e) {
            throw new APIException(DtsConstants.REQUEST_ERROR, "创建表失败,sql错误或数据源连接失败");
        }
    }

    /**
     * 修改表
     *
     * @param tableName  表名
     * @param columnList 列属性信息
     * @return
     */
    @Override
    public Boolean updateTable(String tableName, String tableComments, List<DtsColumn> columnList) throws Exception {
        List<String> createTableSqlList = this.getUpdateTableSqlList(tableName, tableComments, columnList);
        if (CollectionUtils.isEmpty(createTableSqlList)) {
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, ExceptionConstants.EXCEPTION_ERROR_MSG + "修改表语句为空");
        }
        Boolean result = true;
        for (String sql : createTableSqlList) {
            doExecute(sql);
        }
        return result;
    }

    /**
     * 添加列的字段
     *
     * @param tableName     表名
     * @param tableComments 表注释
     * @param columnList    字段集合
     * @return
     * @throws Exception
     */
    @Override
    public Boolean addTableColumn(String tableName, String tableComments, List<DtsColumn> columnList) throws Exception {
        List<String> addTableColumnSqlList = this.addTableColumnSqlList(tableName, tableComments, columnList);
        if (CollectionUtils.isEmpty(addTableColumnSqlList)) {
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, ExceptionConstants.EXCEPTION_ERROR_MSG + "修改表语句为空");
        }
        Boolean result = true;
        for (String sql : addTableColumnSqlList) {
            doExecute(sql); //执行SQL
        }
        return result;
    }

    @Override
    public List<String> addTableColumnSqlList(String tableName, String tableComments, List<DtsColumn> columnList) throws Exception {
        return Collections.emptyList();
    }

    /**
     * 添加列的字段
     *
     * @param tableName     表名
     * @param tableComments 表注释
     * @param columnList    字段集合
     * @return
     * @throws Exception
     */
    @Override
    public Boolean deleteTableColumn(String tableName, String tableComments, List<DtsColumn> columnList) throws Exception {
        List<String> addTableColumnSqlList = this.deleteTableColumnSqlList(tableName, tableComments, columnList);
        if (CollectionUtils.isEmpty(addTableColumnSqlList)) {
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, ExceptionConstants.EXCEPTION_ERROR_MSG + "修改表语句为空");
        }
        Boolean result = true;
        for (String sql : addTableColumnSqlList) {
            doExecute(sql); //执行SQL
        }
        return result;
    }

    /**
     * 获取当前表的总条数
     *
     * @param tableName
     * @return
     * @throws Exception
     */
    @Override
    public Integer getTotalNumberByTableName(String tableName) throws Exception {
        String sql = this.getTotalNumberByTableNameSql(tableName);
        if (StringUtils.isBlank(sql)) {
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, ExceptionConstants.EXCEPTION_ERROR_MSG + "修改表语句为空");
        }
        //执行SQL
        Integer totalRow = doExecuteToGetTotalNumber(sql);
        return totalRow;
    }

    @Override
    public String getTotalNumberByTableNameSql(String tableName) throws Exception {
        StringBuilder sb = new StringBuilder("SELECT COUNT(*) record FROM ");//注意空格
        sb.append(tableName);
        return sb.toString();
    }

    @Override
    public List<String> deleteTableColumnSqlList(String tableName, String tableComments, List<DtsColumn> columnList) throws Exception {
        return Collections.emptyList();
    }

    @Override
    public String getTableDDL(String tableName) throws Exception {
        PreparedStatement ps = null;
        String ddlStr = "";
        try (Connection connection = getConnection()) {
            String sql = String.format("SHOW CREATE TABLE %s", tableName);
            ps = connection.prepareStatement(sql);
            ResultSet resultSet = ps.executeQuery();
            while (resultSet.next()) {
                ddlStr = resultSet.getString(2);
            }
            return ddlStr;
        } catch (Exception e) {
            LOG.error("\n[getTableDDL]数据库连接或查询异常:" + e.getMessage(), e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, ExceptionConstants.EXCEPTION_ERROR_MSG + "数据库连接或查询异常:" + e.getMessage());
        }
    }

    @Override
    public Boolean dropTable(String tableName) throws Exception {
        String dropTableSql = this.getDropTableSql(tableName);
        return doExecute(dropTableSql);
    }

    @Override
    public List<String[]> doQuery(String execSql) throws Exception {
        List<String[]> list = new LinkedList<>();
        LOG.debug("\n[doQuery]执行sql:\n" + execSql);
        try (
                Connection connection = getConnection();
                Statement stat = connection.createStatement();
                ResultSet rs = stat.executeQuery(execSql)
        ) {
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            while (rs.next()) {
                String[] row = new String[columnCount];
                for (int j = 0; j < columnCount; j++) {
                    int columType = metaData.getColumnType(j + 1);
                    switch (columType) {
                        case Types.DATE:
                            Date date = rs.getDate(j + 1);
                            row[j] = (date == null ? null : date.toString());
                            break;
                        default:
                            row[j] = rs.getString(j + 1);
                            break;
                    }
                }
                list.add(row);
            }
        } catch (Exception e) {
            LOG.error("\n[queryTableData]数据库连接或查询异常,sql:{}", execSql, e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, ExceptionConstants.EXCEPTION_ERROR_MSG + "数据库连接或查询异常:" + execSql + "。\n" + e.getMessage());
        }
        return list;
    }

    @Override
    public List<Map<String, Object>> queryForList(String execSql) throws Exception {
        List<Map<String, Object>> mapList = new ArrayList<>();
        Connection connection = null;
        Statement stat = null;
        ResultSet resultSet = null;
        try {
            connection = getConnection();
            stat = connection.createStatement();
            resultSet = stat.executeQuery(execSql);
            ResultSetMetaData rsmd = resultSet.getMetaData();
            while (resultSet.next()) {
                Map<String, Object> map = new HashMap<>();
                for (int i = 0; i < rsmd.getColumnCount(); i++) {
                    String col_name = rsmd.getColumnName(i + 1);
                    Object col_value = resultSet.getObject(col_name);
                    if (col_value == null) {
                        col_value = "";
                    }
                    map.put(col_name, col_value);
                }
                mapList.add(map);
            }
        } catch (Exception e) {
            LOG.error("\n[queryTableData]数据库连接或查询异常,sql:{}", execSql, e);
            throw e;
        } finally {
            if (resultSet != null)
                resultSet.close();
            if (stat != null)
                stat.close();
            if (connection != null)
                connection.close();
        }
        return mapList;
    }

    @Override
    public Map<String, Object> queryForMap(String execSql) throws Exception {
        Connection connection = null;
        Statement stat = null;
        ResultSet resultSet = null;
        Map<String, Object> map = new HashMap<>();
        try {
            connection = getConnection();
            stat = connection.createStatement();
            resultSet = stat.executeQuery(execSql);
            ResultSetMetaData rsmd = resultSet.getMetaData();
            if (resultSet.next()) {
                for (int i = 0; i < rsmd.getColumnCount(); i++) {
                    String col_name = rsmd.getColumnName(i + 1);
                    Object col_value = resultSet.getObject(col_name);
                    if (col_value == null) {
                        col_value = "";
                    }
                    map.put(col_name, col_value);
                }
                return map;
            } else {
                return null;
            }
        } catch (Exception e) {
            LOG.error("\n[queryTableData]数据库连接或查询异常,sql:{}", execSql, e);
            return null;
        } finally {
            if (resultSet != null)
                resultSet.close();
            if (stat != null)
                stat.close();
            if (connection != null)
                connection.close();
        }
    }

    @Override
    public Boolean doExecute(String execSql) throws Exception {
//        LOG.debug("\n[doExecute]Execute sql: " + execSql);
        try (Connection con = getConnection();
             Statement ps = con.createStatement();) {
//            con.setAutoCommit(false);
            return ps.execute(execSql);
//            con.commit();
        } catch (Exception e) {
            LOG.error("\n[doExecute]数据库连接或查询异常,sql:{}", execSql, e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常");
        }
    }

    @Override
    public Integer doExecuteToGetTotalNumber(String execSql) throws Exception {
//        LOG.debug("\n[doExecute]Execute sql: " + execSql);
        try (Connection con = getConnection();
             Statement ps = con.createStatement();) {
//            con.setAutoCommit(false);
            ResultSet rs = ps.executeQuery(execSql);
            int count = 0;
            if (rs.next()) {
                count = rs.getInt("record");
            }
            return count;
//            con.commit();
        } catch (Exception e) {
            LOG.error("\n[doExecute]数据库连接或查询异常,sql:{}", execSql, e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常");
        }
    }

    //执行插入或更新语句应该使用executeUpdate。
    @Override
    public Boolean executeUpdate(String execSql) throws Exception {
//        LOG.debug("\n[doExecute]Execute sql: " + execSql);
        try (Connection con = getConnection();
             Statement ps = con.createStatement();) {
//            con.setAutoCommit(false);
            int result = ps.executeUpdate(execSql);
//            con.commit();

            return result == 0;
        } catch (Exception e) {
            LOG.error("\n[doExecute]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + execSql + "\n" + e.getMessage());
        }
    }

    @Override
    public Boolean executeUpdateBatch(List<String> execSqlList) throws Exception {
        try (Connection con = getConnection()) {
            con.setAutoCommit(false);
            Statement ps = con.createStatement();
            for (String execSql : execSqlList) {
                LOG.debug("\n[doExecuteBatch]Execute sql: " + execSql);
                int i = ps.executeUpdate(execSql);
                if (i != 0) {
                    throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + execSql + "\n");
                }
            }
            con.commit();

            return true;
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
    }

    @Override
    public Long getTableDataRows(String tableName) {
        String sql_count = "";
        try {
            Long rows = 0l;
            sql_count = String.format("SELECT COUNT(1) as sz from %s", tableName);
            Map<String, Object> sql_count_re = queryForMap(sql_count);
            if (sql_count_re != null) {
                if (sql_count_re.get("SZ") != null)
                    rows = Long.parseLong(sql_count_re.get("SZ").toString());
                else
                    rows = Long.parseLong(sql_count_re.get("sz").toString());
            } else {
                LOG.error("--------->没此表记录,表:{},查询sql:{}", tableName, sql_count);
                return null;
            }
            return rows;
        } catch (Exception e) {
            LOG.error("\n[getTableDataRows]查询异常,sql:{}", sql_count, e);
            return null;
        }
    }

    @Override
    public Long getTableDataRowsHaveWhere(String tableName, String where) {
        String sql_count = "";
        try {
            Long rows = 0L;
            sql_count = String.format("SELECT COUNT(1) as sz from %s", tableName);
            if (StringUtils.isNotBlank(where)) {
                StringBuilder sb = new StringBuilder(sql_count);
                sb.append(" WHERE ").append(where);
                sql_count = sb.toString();
            }
            Map<String, Object> sql_count_re = queryForMap(sql_count);
            if (sql_count_re != null) {
                if (sql_count_re.get("SZ") != null)
                    rows = Long.parseLong(sql_count_re.get("SZ").toString());
                else
                    rows = Long.parseLong(sql_count_re.get("sz").toString());
            } else {
                LOG.error("--------->没此表记录,表:{},查询sql:{}", tableName, sql_count);
                return null;
            }
            return rows;
        } catch (Exception e) {
            LOG.error("\n[getTableDataRows]查询异常,sql:{}", sql_count, e);
            return null;
        }
    }

    @Override
    public Long getTableDataRowsFromView(List<String> tableNameList) throws APIException {
        //postgres 因为pg_class里面的记录数太不准确了,所以使用count(1),gaussDb暂时也是使用这个
        StringBuilder sb = new StringBuilder("SELECT COUNT(1) as rows from ");
        List<Long> rowsList = Lists.newArrayList();
        for (String x : tableNameList) {
            String execSql = sb.append("\"").append(x).append("\"").toString();
            try (
                    Connection con = getConnection();
                    Statement ps = con.createStatement();
            ) {
                ResultSet rs = ps.executeQuery(execSql);
                Long rows = 0L;
                if (rs.next()) {
                    rows = rs.getLong("rows");
                }
                rowsList.add(rows);
            } catch (Exception e) {
                LOG.error("\n[doExecute]数据库连接或查询异常,sql:{}", execSql, e);
                throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常");
            }
        }
        return rowsList.parallelStream().filter(Objects::nonNull).reduce(0L, Long::sum);
    }

    @Override
    public List<TableInfo> getTableList(String tableNameLike) throws Exception {
        tableNameLike = StringUtils.isNotBlank(tableNameLike) ? tableNameLike : null;
        try (Connection connection = getConnection()) {
            DatabaseMetaData metaData = connection.getMetaData();
            //暂且只返回类型：TABLE（全部表类型。典型的类型是 "TABLE"、"VIEW"、"SYSTEM TABLE"、"GLOBAL TEMPORARY"、"LOCAL TEMPORARY"、"ALIAS" 和 "SYNONYM"。）
            ResultSet tableRet = metaData.getTables(connection.getCatalog(), connection.getSchema(), tableNameLike, new String[]{"TABLE"});
            List<TableInfo> tableInfoList = new LinkedList<>();
            while (tableRet.next()) {
                TableInfo tableInfo = new TableInfo();
                tableInfo.setTableSource(tableRet.getString("TABLE_NAME"));
                tableInfo.setTableComment(tableRet.getString("REMARKS"));
                tableInfoList.add(tableInfo);
            }
            return tableInfoList;
        } catch (Exception e) {
            LOG.error("\n[getTableList]数据库连接或查询异常,连接信息:{}", JsonUtil.objectToJson(JasyptUtil.encryptDtsDatasourceInfo(this.datasource)), e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, ExceptionConstants.EXCEPTION_ERROR_MSG + "数据库连接或查询异常:" + e.getMessage());
        }
    }

    @Override
    public List<String> getAllTableName() throws Exception {
        //子类重写 pg
        return null;
    }

    @Override
    public List<ColumnInfo> getColumnList(String tableName) throws Exception {
        List<ColumnInfo> list = null;
        Map<Integer, ColumnInfo> map = new HashMap<>();
        try (Connection connection = getConnection()) {
            DatabaseMetaData metaData = connection.getMetaData();
            //精准匹配表，获取主键信息
            ResultSet primaryKeys = metaData.getPrimaryKeys(connection.getCatalog(), connection.getSchema(), tableName);
            String primaryKeyName = null;
            if (primaryKeys.next()) {
                primaryKeyName = primaryKeys.getString("COLUMN_NAME");
            }

            //精准匹配表，获取表字段信息q
            ResultSet colRet = metaData.getColumns(connection.getCatalog(), connection.getSchema(), tableName, null);
            while (colRet.next()) {
                //字段名
                String columnName = colRet.getString("COLUMN_NAME");
                //字段注释
                String remarks = colRet.getString("REMARKS");
                //对应typesSql的值
                int javaTypesSql = colRet.getInt("DATA_TYPE");
                //字段长度
                int precision = colRet.getInt("COLUMN_SIZE");
                //精度
                int scale = colRet.getInt("DECIMAL_DIGITS");
                //是否为空：0就表示Not Null，1表示可以是Null
                int nullable = colRet.getInt("NULLABLE");
                //字段索引定位：从1开始
                int position = colRet.getInt("ORDINAL_POSITION");
                //默认值 TODO oracle获取会报错
//                String defaultValue = colRet.getString("COLUMN_DEF");
                //所属数据表名
                String belongTableName = colRet.getString("TABLE_NAME");
                JavaSqlTypeEnum typeEnum = EnumUtil.getByCode(javaTypesSql, JavaSqlTypeEnum.class);
                String columnTypeName = String.valueOf(typeEnum.getName());
                if("bit".equalsIgnoreCase(columnTypeName) && precision ==1)
                    columnTypeName = "boolean";
                ColumnInfo column = new ColumnInfo();
                column.setColumnIndex(position);
                column.setColumnSource(columnName);
                column.setColumnType(StringUtils.upperCase(columnTypeName));
                column.setColumnPrecision(precision);
                column.setColumnScale(scale);
                column.setNullable(nullable == 1);
                column.setColumnComment(remarks);
//                column.setDefaultValue(defaultValue);
                column.setBelongTableName(belongTableName);
                column.setIsPrimaryKey(Objects.equals(primaryKeyName, columnName));
                map.put(position, column);
            }
            list = new LinkedList<>(map.values());
        } catch (Exception e) {
            LOG.error("\n[getColumnList]数据库连接或查询异常:" + e.getMessage(), e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, ExceptionConstants.EXCEPTION_ERROR_MSG + "数据库连接或查询异常:" + e.getMessage());
        }

        return list;
    }

    @Override
    public List<ColumnInfo> getColumnListFromView(String tableName, String db_name) throws Exception {
        //子类实现
        return null;
    }

    @Override
    public String getPrimaryKeyOfSql(String tableNameS) {
        //子类实现
        return null;
    }

    @Override
    public List<ColumnInfo> getPrimaryKey(String tableNameS) throws Exception {
        //第一种方式
//        ColumnInfo column = new ColumnInfo();
//        StringBuilder sb = new StringBuilder("SHOW KEYS FROM ");
//        sb.append(tableName);
//        try (Connection con = getConnection()) {
//            Statement ps = con.createStatement();
////            LOG.debug("\n[doExecuteBatch]Execute sql: " + sb.toString());
//            ResultSet resultSet = ps.executeQuery(sb.toString());
//            while (resultSet.next()) {
//                String column_name = resultSet.getString("Column_name");
//                column.setColumnSource(column_name);
//                return column;
//            }
//        } catch (Exception e) {
//            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
//            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
//        }

        //第二种方式
//        ColumnInfo column = new ColumnInfo();
//        try (Connection connection = getConnection()) {
//            DatabaseMetaData metaData = connection.getMetaData();
//            //精准匹配表，获取主键信息
//            ResultSet primaryKeys = metaData.getPrimaryKeys(connection.getCatalog(), connection.getSchema(), tableName);
//            String primaryKeyName = null;
//            if (primaryKeys.next()) {
//                primaryKeyName = primaryKeys.getString("COLUMN_NAME");
//            }
//            column.setColumnSource(primaryKeyName);
//            return column;
//        }

        //第三种方式，从数据库的元数据表中获取字段信息
        String doSql = getPrimaryKeyOfSql(tableNameS);
        List<ColumnInfo> list = Lists.newArrayList();
        try (Connection con = getConnection()) {
            Statement ps = con.createStatement();
            LOG.debug("\n[doExecuteBatch]Execute sql: " + doSql);
            ResultSet resultSet = ps.executeQuery(doSql);
            while (resultSet.next()) {
                //字段名字
                String column_name = resultSet.getString("COLUMN_NAME");
                //字段类型
                String data_type = resultSet.getString("DATA_TYPE");
                //字段长度
                Integer character_maximum_length = resultSet.getInt("CHARACTER_MAXIMUM_LENGTH");
                //字段默认值
                String column_default = resultSet.getString("COLUMN_DEFAULT");
                //字段是否为null
                String is_nullable = resultSet.getString("IS_NULLABLE");
                //字段备注
                String column_comment = resultSet.getString("COLUMN_COMMENT");
                //表名字
                String table_name = resultSet.getString("TABLE_NAME");

                ColumnInfo column = new ColumnInfo();
                column.setColumnSource(column_name);
                column.setColumnType(data_type);
                column.setColumnPrecision(character_maximum_length);
                column.setDefaultValue(column_default);
                column.setNullable(Objects.equals(is_nullable, "YES"));
                column.setColumnComment(column_comment);
                column.setBelongTableName(table_name);
                list.add(column);
            }
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
        return list;
    }

    @Override
    public String getBatchTableColumnListSql(String tableNameS) throws Exception {
        //子类实现
        return null;
    }

    @Override
    public List<ColumnInfo> getBatchTableColumnList(String tableNameS) throws Exception {
        //子类实现
        return null;
    }

    @Override
    public String getBatchTableCommentListSql(String tableNameS) throws Exception {
        //子类实现
        return null;
    }

    @Override
    public List<TableInfo> getBatchTableCommentList(String tableNameS) throws Exception {
        //子类实现
        return null;
    }

    @Override
    public List<ColumnInfo> getAllColumn() throws Exception {
        List<ColumnInfo> columnInfoList = new LinkedList<>();
        String exec = this.getQueryAllColumnSql();
        LOG.debug(exec);
        try (
                Connection connection = getConnection();
                Statement stat = connection.createStatement();
                ResultSet rs = stat.executeQuery(exec)
        ) {
            while (rs.next()) {
                ColumnInfo columnInfo = new ColumnInfo();
                columnInfo.setBelongTableName(rs.getString(1));
                columnInfo.setColumnSource(rs.getString(2));

                columnInfoList.add(columnInfo);
            }
        } catch (Exception e) {
            LOG.error("\n[getAllColumn]数据库连接或查询异常:" + e.getMessage(),e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:"+e.getMessage());
        }

        return columnInfoList;
    }

    @Override
    public AggregateResult queryTableData(List<String> columns, String tableName, String where, Pageable pageable) throws Exception {
        List<ColumnInfo> columnList = this.getColumnList(tableName);
        boolean isPostgres = Objects.equals(this.getDatasource().getDatabaseType(), DtsConstants.DATABASE_TYPE_POSTGRES);
        if (isPostgres) {
            columns = columnList.stream().filter(Objects::nonNull).sorted(Comparator.comparing(ColumnInfo::getColumnIndex)).map(ColumnInfo::getColumnSource).collect(Collectors.toList());
        }
        columns = CollectionUtils.isEmpty(columns) ? Collections.emptyList() : columns;
        String exec = this.getQueryTableDataSql(Joiner.on(",").skipNulls().join(columns), tableName, where, pageable);
        List<String[]> list = new LinkedList<>();
        boolean isOracle = Objects.equals(this.getDatasource().getDatabaseType(), DtsConstants.DATABASE_TYPE_ORACLE);

        if (LOG.isDebugEnabled()) {
            LOG.debug(exec);
        }
        try (
            Connection connection = getConnection();
            Statement stat = connection.createStatement();
            ResultSet rs = stat.executeQuery(exec)
        ) {
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            while (rs.next()) {
                String[] row = new String[columnCount];
                for (int j = 0; j < columnCount; j++) {
                    int columType = metaData.getColumnType(j + 1);
                    switch (columType) {
                        case Types.DATE:
                            Date date = rs.getDate(j + 1);
                            row[j] = (date == null? null : date.toString());
                            break;
                        default:
                            row[j] = rs.getString(j + 1);
                            //去除ORACLE数据库TIMESTAMP的秒数据
                            if (isOracle && Objects.equals(columType, Types.TIMESTAMP) && StringUtils.isNotBlank(row[j])) {
                                row[j] = row[j].replace(".0", "");
                            }
                            break;
                    }
                }
                list.add(row);
            }
        } catch (Exception e) {
            LOG.error("\n[queryTableData]数据库连接或查询异常:" + e.getMessage(),e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:"+e.getMessage());
        }

        //获取表的字段信息
//        List<ColumnInfo> columnList = this.getColumnList(tableName);
        Map<@NotBlank String, ColumnInfo> columnInfoMap = columnList.stream().collect(Collectors.toMap(ColumnInfo::getColumnSource, (col) -> col));
        //根据columns，过滤，排序
        if (!CollectionUtils.isEmpty(columns)) {
            List<ColumnInfo> columnTempList = new ArrayList<>(columnList.size());
            for (String column : columns) {
                ColumnInfo columnInfo = columnInfoMap.get(column);
                if (columnInfo == null) {
                    continue;
                }

                columnTempList.add(columnInfo);
            }

            columnList = columnTempList;
        }

        List<ColumnIndex> colList = new ArrayList<>(columnList.size());
        for (ColumnInfo info : columnList) {
            ColumnIndex colIndex = new ColumnIndex();
            colIndex.setIndex(info.getColumnIndex());
            colIndex.setName(info.getColumnSource());
            colIndex.setComment(info.getColumnComment());
            colIndex.setColumnType(info.getColumnType());
            colList.add(colIndex);
        }

        //完整结果（字段信息+表数据）
        AggregateResult result = new AggregateResult();
        result.setData(list.toArray(new String[][]{}));
        result.setColumnList(colList);

        return result;
    }

    @Override
    public AggregateResultV2 queryTableDataV2(List<String> columns, String tableName, String where, Pageable pageable) throws Exception {
        //获取表的字段信息
        List<ColumnInfo> columnList = this.getColumnList(tableName);
        //如果columns为空，则用查询出来的字段
        if (CollectionUtils.isEmpty(columns)) {
            columns = columnList.stream().map(ColumnInfo::getColumnSource).collect(Collectors.toList());
        }

//        Map<@NotBlank String, ColumnInfo> columnInfoMap = columnList.stream().collect(Collectors.toMap(ColumnInfo::getColumnSource, (col) -> col));
        Map<String, ColumnInfo> columnInfoMap = Maps.newHashMap();
        for (ColumnInfo c : columnList) {
            columnInfoMap.put(c.getColumnSource(), c);
        }


        //根据columns，过滤，排序
        if (!CollectionUtils.isEmpty(columns)) {
            List<ColumnInfo> columnTempList = new ArrayList<>(columnList.size());
            for (String column : columns) {
                ColumnInfo columnInfo = columnInfoMap.get(column);
                if (columnInfo == null) {
                    continue;
                }

                columnTempList.add(columnInfo);
            }

            columnList = columnTempList;
        }

        List<ColumnIndex> colList = new ArrayList<>(columnList.size());
        for (ColumnInfo info : columnList) {
            ColumnIndex colIndex = new ColumnIndex();
            colIndex.setIndex(info.getColumnIndex());
            colIndex.setName(info.getColumnSource());
            String comment = info.getColumnComment();
 //取真实注释
//            if (StringUtils.isBlank(comment)) {
//                comment = info.getColumnComment();
//            }
            colIndex.setComment(comment);
            colIndex.setColumnType(info.getColumnType());
            colList.add(colIndex);
        }

        //获取数据
        String exec = this.getQueryTableDataSql(Joiner.on(",").skipNulls().join(columns), tableName, where, pageable);
        List<Map<String, String>> list = new LinkedList<>();
        boolean isOracle = Objects.equals(this.getDatasource().getDatabaseType(), DtsConstants.DATABASE_TYPE_ORACLE);
        LOG.debug(exec);
        try (
            Connection connection = getConnection();
            Statement stat = connection.createStatement();
            ResultSet rs = stat.executeQuery(exec)
        ) {
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            while (rs.next()) {
                Map<String, String> row = new LinkedHashMap<>(columnCount);
                for (int j = 0; j < columnCount; j++) {
                    int columType = metaData.getColumnType(j + 1);
                    String value;
                    switch (columType) {
                        case Types.DATE:
                            Date date = rs.getDate(j + 1);
                            value = (date == null? null : date.toString());
                            break;
                        default:
                            value = rs.getString(j + 1);
                            //去除ORACLE数据库TIMESTAMP的秒数据
                            if (isOracle && Objects.equals(columType, Types.TIMESTAMP) && StringUtils.isNotBlank(value)) {
                                value = value.replace(".0", "");
                            }
                            break;
                    }

                    if (j >= colList.size()) {
                        continue;
                    }
                    row.put(colList.get(j).getName(), value);
                }

                list.add(row);
            }
        } catch (Exception e) {
            LOG.error("\n[queryTableData]数据库连接或查询异常:" + e.getMessage(),e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常");
        }

        //完整结果（字段信息+表数据）
        AggregateResultV2 result = new AggregateResultV2();
        result.setData(list);
        result.setColumnList(colList);

        return result;
    }

    @Override
    public AggregateResultV2 queryTableDataV2FromView(List<String> columns, String tableName, String where, Pageable pageable, String dbName) throws Exception {
        //子类实现
        return null;
    }

    @Override
    public AggregateResultV2 queryTableDataOnlyOracle(List<String> columns, String tableName, String where, Pageable pageable, String dbName, List<String> ownerList) throws Exception {
        //子类实现
        return null;
    }

    @Override
    public boolean linkTest() throws Exception {
        String validationQuery = this.getValidationQuery();
        LOG.debug("\n[linkTest]Execute query: {}", validationQuery);
        try (Connection con = getConnection();
             Statement ps = con.createStatement()) {
            ps.executeQuery(validationQuery);
        } catch (Exception e) {
            LOG.error("\n[linkTest]数据库连接异常，请检查数据库连接参数是否有误:" + e.getMessage(),e);
            //throw new APIException(DtsConstants.EXCEPTION_ERROR, "数据库连接异常，请检查数据库连接参数是否有误");
            throw e;
        }
        return false;
    }

    /*-------------------获取连接代码-------------------*/

    /**
     * 获取数据库连接
     * @return
     * @throws Exception
     */
    public Connection getConnection() throws Exception {
        try {
            Connection conn = null;
            if (pooled) {
                //标识每一个连接
                String dataSourceUUID = JSONObject.toJSON(datasource).toString();
                String key = Hashing.md5().newHasher().putString(dataSourceUUID, Charsets.UTF_8).hash().toString();
                DataSource ds = datasourceMap.get(key);
                if (ds == null) {
                    synchronized (key.intern()) {
                        ds = datasourceMap.get(key);
                        if (ds == null) {
                            Map<String, String> conf = new HashMap<>(16);
                            conf.put(DruidDataSourceFactory.PROP_DRIVERCLASSNAME, this.getDriver());
                            conf.put(DruidDataSourceFactory.PROP_URL, this.getJdbcUrl());
                            conf.put(DruidDataSourceFactory.PROP_USERNAME, JasyptUtil.decyptText(datasource.getUsername()));
                            if (StringUtils.isNotBlank(JasyptUtil.decyptText(datasource.getPassword()))) {
                                conf.put(DruidDataSourceFactory.PROP_PASSWORD, JasyptUtil.decyptText(datasource.getPassword()));
                            }
                            conf.put(DruidDataSourceFactory.PROP_INITIALSIZE, "3");
                            //其他优化参数
                            //最大连接池数量
                            conf.put(DruidDataSourceFactory.PROP_MAXACTIVE, "100");
                            //最小连接池数量
                            conf.put(DruidDataSourceFactory.PROP_MINIDLE, "1");
                            //获取连接时最大等待时间，单位毫秒
                            conf.put(DruidDataSourceFactory.PROP_MAXWAIT, "20000");
                            //是否缓存preparedStatement，也就是PSCache
                            conf.put(DruidDataSourceFactory.PROP_POOLPREPAREDSTATEMENTS, "false");
                            //要启用PSCache，必须配置大于0，当大于0时，poolPreparedStatements自动触发修改为true
                            conf.put(DruidDataSourceFactory.PROP_MAXOPENPREPAREDSTATEMENTS, "20");
                            //用来检测连接是否有效的sql
                            conf.put(DruidDataSourceFactory.PROP_VALIDATIONQUERY, this.getValidationQuery());
                            //接是否有效的sql的最大等待时间
                            conf.put(DruidDataSourceFactory.PROP_VALIDATIONQUERY_TIMEOUT, "1");
                            //申请连接时执行validationQuery检测连接是否有效，做了这个配置会降低性能。
                            conf.put(DruidDataSourceFactory.PROP_TESTONBORROW, "false");
                            //归还连接时执行validationQuery检测连接是否有效，做了这个配置会降低性能
                            conf.put(DruidDataSourceFactory.PROP_TESTONRETURN, "false");
                            //建议配置为true，不影响性能，并且保证安全性。申请连接的时候检测，如果空闲时间大于timeBetweenEvictionRunsMillis，执行validationQuery检测连接是否有效。
                            conf.put(DruidDataSourceFactory.PROP_TESTWHILEIDLE, "true");
                            //属性类型是字符串，通过别名的方式配置扩展插件，常用的插件有：
                            //监控统计用的filter:stat日志用的filter:log4j防御sql注入的filter:wall
                            conf.put(DruidDataSourceFactory.PROP_FILTERS, "stat");
                            //oralce获取注释
                            if (datasource.getDatabaseType().intValue() == DtsConstants.DATABASE_TYPE_ORACLE) {
                                conf.put("remarksReporting", "true");
                            }
                            // mysql 获取表注释 的配置
                            if (datasource.getDatabaseType() == DtsConstants.DATABASE_TYPE_MYSQL_NEW.intValue()
                                    || datasource.getDatabaseType() == DtsConstants.DATABASE_TYPE_MYSQL_OLD.intValue()) {
                                conf.put("useInformationSchema", "true");
                            }
                            DruidDataSource druidDS = (DruidDataSource) DruidDataSourceFactory.createDataSource(conf);
                            druidDS.setBreakAfterAcquireFailure(true);
                            druidDS.setConnectionErrorRetryAttempts(2);
                            datasourceMap.put(key, druidDS);
                            ds = datasourceMap.get(key);
                        }
                    }
                }
                try {
                    conn = ds.getConnection();
                } catch (SQLException e) {
                    datasourceMap.remove(key);
                    LOG.error("\n[getConnection]数据库连接失败:" + e.getMessage(), e);
                    LOG.error("\n[getConnection]数据库连接失败,dataSource:{}", JSONObject.toJSON(datasource));
                    throw e;
                }
                return conn;
            } else {
                Class.forName(this.getDriver());
                Properties props = new Properties();
                props.setProperty("user", JasyptUtil.decyptText(datasource.getUsername()));
                if (StringUtils.isNotBlank(JasyptUtil.decyptText(datasource.getPassword()))) {
                    props.setProperty("password", JasyptUtil.decyptText(datasource.getPassword()));
                }
                //oralce获取注释
                if (datasource.getDatabaseType().intValue() == DtsConstants.DATABASE_TYPE_ORACLE) {
                    props.put("remarksReporting", "true");
                }
                // mysql 获取表注释 的配置
                if (datasource.getDatabaseType() == DtsConstants.DATABASE_TYPE_MYSQL_NEW.intValue()
                        || datasource.getDatabaseType() == DtsConstants.DATABASE_TYPE_MYSQL_OLD.intValue()) {
                    props.put("useInformationSchema", "true");
                }
                DriverManager.setLoginTimeout(20);
                return DriverManager.getConnection(this.getJdbcUrl(), props);
            }
        }catch (ConnectException e){
            LOG.error("\n[getConnection]数据库连接超时,dataSource:{}", JSONObject.toJSON(datasource),e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR,"数据库连接超时!");
        }catch (SQLSyntaxErrorException e){
            LOG.error("\n[getConnection]数据库操作异常,dataSource:{}", JSONObject.toJSON(datasource),e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR,"数据库操作异常,原因:"+e.getMessage());
        }catch(SQLException   e){
            LOG.error("\n[getConnection]数据库操作异常,dataSource:{}", JSONObject.toJSON(datasource),e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR,"数据库操作异常,原因:"+e.getMessage());
        }catch(Exception e){
            LOG.error("\n[getConnection]数据库操作异常,dataSource:{}", JSONObject.toJSON(datasource),e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR,"数据库操作异常,原因:"+e.getMessage());
        }
    }

    /*-----------------需要被子类重载的方法------------------*/

    /**
     * 获取驱动
     * @return
     */
    public String getDriver() {
        // 不同数据库驱动不同
        return "";
    }

    /**
     * 获取jdbcUrl
     * @return
     */
    private String getJdbcUrl() {
        if (StringUtils.isNotBlank(this.getDatasource().getJdbcUrl())) {
            //对获取到JDBC URL进行解密
            return JasyptUtil.decyptText(this.getDatasource().getJdbcUrl());
        }

        //自定义数据源未设置jdbcurl，则根据IP等信息进行拼接
        return this.getConnectUrl();
    }

    /**
     * 获取ValidationQuery的sql
     *
     * @return sql
     */
    protected String getValidationQuery() {
        //不同数据库检测语句不同
        return "";
    }

    /**
     * 检查表是否存在的sql
     *
     * @param tableName 表名
     * @return sql
     */
    protected String getCheckTableExistSql(String tableName) {
        //不同数据库检测表是否存在的sql不同
        return "";
    }

    /**
     * 获取建表sql语句集合
     *
     * @param tableName     表名
     * @param tableComments 表注释
     * @param columnList    字段集合
     * @return              sql集合
     */
    protected List<String> getCreateTableSqlList(String tableName, String tableComments, List<DtsColumn> columnList) {
        //不同数据库建表sql不同
        return Collections.emptyList();
    }

    @Override
    public List<String> getUpdateTableSqlList(String tableName, String tableComments, List<DtsColumn> columnList) {
        return Collections.emptyList();
    }

    /**
     * 获取删表sql
     *
     * @param tableName 表名
     * @return sql
     */
    protected String getDropTableSql(String tableName) {
        //全部数据库删除表语言都是这个？
        return "DROP TABLE IF EXISTS " + tableName;
    }

    /**
     * 获取查询表数据sql
     *
     * @param columns   列名
     * @param tableName 表名
     * @param where     条件
     * @return          sql语句
     */
    protected String getQueryTableDataSql(String columns, String tableName, String where, Pageable pageable) {
        return "";
    }

    /**
     * 获取所有列的查询sql
     *
     * @return sql
     */
    protected String getQueryAllColumnSql() {
        return "";
    }

    /**
     * 复制表结构
     * @param tarTableName
     * @param srcTableName
     * @return
     */
    @Override
    public boolean copyTableStructure(String tarTableName, String srcTableName) throws Exception{
        //子类重写
        return false;
    }

    /**
     * 重命名表
     * @param newTableName
     * @param srcTableName
     * @return
     */
    @Override
    public boolean renameTable(String newTableName, String srcTableName) throws Exception{
        //子类重写
        return false;
    }

    /**
     * 根据表名取得单个表表信息,数据行数,占用空间等
     * @param tableName
     * @return
     */
    @Override
    public DtsStatisticsTable getDtsStatisticsTable(String tableName) throws Exception{
        //子类重写
        return null;
    }

    /**
     * 取得所有表的信息返回
     * @return
     */
    @Override
    public  List<DtsStatisticsTable> getDtsStatisticsTableList() throws Exception{
        //子类重写
        return null;
    }
    /**
     * 取得整个数据源的信息
     * @param DtsStatisticsTableList
     * @return
     */
    @Override
    public  DtsStatisticsDb getDtsStatisticsDb(List<DtsStatisticsTable> DtsStatisticsTableList)throws Exception{
        //子类重写
        return null;
    }

    /**
     * 取得整个数据源的信息
     * @return
     */
    @Override
    public  DtsStatisticsDb getDtsStatisticsDb() throws Exception{
        //子类重写
        return null;
    }
    /**
     * 处理建表中的列信息
     *
     * @param column 列信息
     */
    public void dealCreateTableColumn(DtsColumn column) {

    }

    /**
     * 获取连接用URL
     *
     * @return jdbc连接
     */
    public String getConnectUrl() {
        return null;
    }


    @Override
    public boolean addTableColumn(String tableName, List<ColumnInfo> columnList) throws APIException{
        //子类重写
        return true;
    }

    @Override
    public boolean truncateTable(String tableName) throws Exception {
        return false;
    }

    @Override
    public List<TableInfo> getTableAndViewList(String tableNameLike) throws Exception {
        tableNameLike = StringUtils.isNotBlank(tableNameLike) ? tableNameLike : null;
        try (Connection connection = getConnection()) {
            DatabaseMetaData metaData = connection.getMetaData();
            //暂且只返回类型：TABLE（全部表类型。典型的类型是 "TABLE"、"VIEW"、"SYSTEM TABLE"、"GLOBAL TEMPORARY"、"LOCAL TEMPORARY"、"ALIAS" 和 "SYNONYM"。）
            ResultSet tableRet = metaData.getTables(connection.getCatalog(), connection.getSchema(), tableNameLike, new String[]{"TABLE","VIEW"});
            List<TableInfo> tableInfoList = new LinkedList<>();
            while(tableRet.next()) {
                TableInfo tableInfo = new TableInfo();
                tableInfo.setTableSource(tableRet.getString("TABLE_NAME"));
                tableInfo.setTableComment(tableRet.getString("REMARKS"));
                tableInfoList.add(tableInfo);
            }
            return tableInfoList;
        } catch (Exception e) {
            LOG.error("\n[getTableList]数据库连接或查询异常,连接信息:{}", JsonUtil.objectToJson(JasyptUtil.encryptDtsDatasourceInfo(this.datasource)), e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, ExceptionConstants.EXCEPTION_ERROR_MSG + "数据库连接或查询异常:"+e.getMessage());
        }
    }

    @Override
    public List<TableInfo> getTableListOnlyOracleV2(String tableNameLike, String owner, List<String> list, Integer taskFlag, Pageable pageable) throws Exception {
        //ORACLE 子类重写
        return null;
    }

    @Override
    public long countTableListOnlyOracleV2(String tableNameLike, String owner, List<String> list, Integer taskFlag) throws Exception {
        //ORACLE 子类重写
        return 0;
    }

    @Override
    public List<TableInfo> getTableListOnlyOracle(String tableNameLike, String owner, List<String> list, Integer taskFlag, Pageable pageable) throws Exception {
        //ORACLE 子类重写
        return null;
    }

    @Override
    public long countTableListOnlyOracle(String tableNameLike, String owner, List<String> list, Integer taskFlag) throws Exception {
        //ORACLE 子类重写
        return 0;
    }

    @Override
    public List<String> getOwnerOnlyOracle() throws Exception {
        //子类重写
        return null;
    }

    @Override
    public List<ColumnInfo> getColumnListOnlyOracle(String tableName, String dbName) throws Exception {
        //子类重写
        return null;
    }

}
