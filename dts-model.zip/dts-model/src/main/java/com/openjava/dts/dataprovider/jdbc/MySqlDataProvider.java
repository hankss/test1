package com.openjava.dts.dataprovider.jdbc;

import com.google.common.collect.Lists;
import com.openjava.dts.constants.ExceptionConstants;
import com.openjava.dts.ddl.domain.DtsColumn;
import com.openjava.dts.ddl.dto.ColumnInfo;
import com.openjava.dts.ddl.dto.TableInfo;
import com.openjava.dts.util.CreateSqlUtil;
import com.openjava.dts.util.EnumUtil;
import com.openjava.dts.util.column.JavaSqlTypeEnum;
import org.apache.commons.lang3.StringUtils;
import org.ljdp.component.exception.APIException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;

/**
 * @author: lsw
 * @Date: 2019/8/1 10:23
 */
public class MySqlDataProvider extends JdbcDataProvider {
    private static final Logger LOG = LoggerFactory.getLogger(MySqlDataProvider.class);

    /*@Override
    protected String getJdbcUrl() {
        StringBuilder sb = new StringBuilder();
        String ip = datasource.getHostIp();
        String port = String.valueOf(datasource.getPort());
        String dataBaseName = datasource.getDatabaseName();

        sb.append("jdbc:mysql://");
        sb.append(ip);
        sb.append(":");
        sb.append(port);
        sb.append("/");
        sb.append(dataBaseName);
        sb.append("?useUnicode=true&characterEncoding=utf-8&useSSL=false");

        return sb.toString();
    }*/

    @Override
    protected String getValidationQuery() {
        return "select 'x' from dual";
    }

    @Override
    protected String getCheckTableExistSql(String tableName) {
        return String.format("SELECT COUNT(1) FROM INFORMATION_SCHEMA.TABLES " +
                "WHERE TABLE_SCHEMA = '%s' AND table_name = '%s'", this.getDatasource().getDatabaseName(), tableName);
    }

    @Override
    protected List<String> getCreateTableSqlList(String tableName, String tableComments, List<DtsColumn> columnList) {
        List<String> sqlList = new LinkedList<>();
        //建表语句
        String createTableSQL = CreateSqlUtil.createMysqlTableSQL(tableName, columnList);
        //表注释语句
        String tableCommentsSql = "ALTER TABLE " + tableName + " COMMENT '" + tableComments + "'";

        DtsColumn primaryKeyColumn = null;

        List<String> commentSqlList = new ArrayList<>(columnList.size());
        for (DtsColumn column : columnList) {
            StringBuilder sb = new StringBuilder();
            sb.append("ALTER TABLE ");
            sb.append(tableName);
            sb.append(" MODIFY COLUMN ");
            sb.append(column.getColumnSource());
            sb.append(" ");
            System.out.println(column.getColumnType());

            //TODO 完成MYSQL的类型转换后，这里不再需要再转一次
            if ("VARCHAR".equalsIgnoreCase(column.getColumnType())) {
                sb.append(column.getColumnType());
                sb.append("(");
                sb.append(column.getColumnPrecision());
                sb.append(")");
            }else if("NUMBER".equalsIgnoreCase(column.getColumnType())){
                if(column.getColumnScale()>0){
                    sb.append("DOUBLE");
                    sb.append("(");
                    sb.append(column.getColumnPrecision()).append(",").append(column.getColumnScale());
                    sb.append(")");
                }else{
                    sb.append("BIGINT");
                }
            } else {
                sb.append(column.getColumnType());
            }

            sb.append(" COMMENT '");
            sb.append(StringUtils.isNotEmpty(column.getColumnComment()) ? column.getColumnComment() : "");
            sb.append("'");

            commentSqlList.add(sb.toString());

            if (column.getIsPrimaryKey()) {
                primaryKeyColumn = column;
            }
        }

        //表主键语句
        String primaryKeySql = "";
        if (primaryKeyColumn != null) {
            StringBuilder sb = new StringBuilder();
            sb.append("ALTER TABLE ");
            sb.append(tableName);
            sb.append(" ADD PRIMARY KEY( ");
            sb.append(primaryKeyColumn.getColumnSource());
            sb.append(" )");

            primaryKeySql = sb.toString();
        }

        sqlList.add(createTableSQL);
        sqlList.add(tableCommentsSql);
        sqlList.addAll(commentSqlList);
        if (StringUtils.isNotBlank(primaryKeySql)) {
            sqlList.add(primaryKeySql);
        }

        return sqlList;
    }

    @Override
    public String getPrimaryKeyOfSql(String tableNameS) {
        //mysql中可以直接从INFORMATION_SCHEMA.COLUMNS一次获取到多张表的主键信息，走一次IO操作
        //1.tableNameS进来之后，将每一个表名加上单引号
        String[] split = tableNameS.split(",");
        StringBuilder sb1 = new StringBuilder("(");
        for (String s : split) {
            sb1.append("'");
            sb1.append(s);
            sb1.append("'");
            sb1.append(",");
        }
        //会多一个逗号 ('tableName1','tableName2',
        String substring = sb1.toString().substring(0, sb1.toString().length() - 1);
        StringBuilder sb2 = new StringBuilder(substring);
        sb2.append(")");

        StringBuilder sb = new StringBuilder("SELECT " +
                "TABLE_NAME,COLUMN_NAME,DATA_TYPE,CHARACTER_MAXIMUM_LENGTH,COLUMN_DEFAULT,IS_NULLABLE,COLUMN_COMMENT " +
                "FROM INFORMATION_SCHEMA.COLUMNS " +
                "WHERE COLUMN_KEY = 'PRI' AND table_name IN ");
        sb.append(sb2.toString());
        return sb.toString();
    }

    @Override
    public String getBatchTableColumnListSql(String tableNameS) throws Exception {
        //mysql中可以直接从INFORMATION_SCHEMA.COLUMNS一次获取到多张表的字段信息，走一次IO操作
        //1.tableNameS进来之后，将每一个表名加上单引号
        String[] split = tableNameS.split(",");
        StringBuilder sb1 = new StringBuilder("(");
        for (String s : split) {
            sb1.append("'");
            sb1.append(s);
            sb1.append("'");
            sb1.append(",");
        }
        //会多一个逗号 ('tableName1','tableName2',
        String substring = sb1.toString().substring(0, sb1.toString().length() - 1);
        StringBuilder sb2 = new StringBuilder(substring);
        sb2.append(")");

        StringBuilder sb = new StringBuilder("SELECT " +
                "TABLE_NAME,COLUMN_NAME,DATA_TYPE,CHARACTER_MAXIMUM_LENGTH,COLUMN_DEFAULT,IS_NULLABLE,COLUMN_COMMENT,COLUMN_KEY " +
                "FROM INFORMATION_SCHEMA.COLUMNS " +
                "WHERE ");
        sb.append(" TABLE_SCHEMA = '").append(this.datasource.getUsername()).append("' and ");
        sb.append("table_name IN ").append(sb2.toString());
        return sb.toString();
    }

    @Override
    public List<ColumnInfo> getBatchTableColumnList(String tableNameS) throws Exception {
        //获取表的字段信息,从视图获取
        String doSql = getBatchTableColumnListSql(tableNameS);
        List<ColumnInfo> list = Lists.newArrayList();
        try (Connection con = getConnection()) {
            Statement ps = con.createStatement();
            LOG.debug("\n[doExecuteBatch]Execute sql: " + doSql);
            ResultSet resultSet = ps.executeQuery(doSql);
            while (resultSet.next()) {
                //字段名字
                String column_name = resultSet.getString("COLUMN_NAME");
                //字段类型
                String data_type = resultSet.getString("DATA_TYPE");
                //字段长度
                Integer character_maximum_length = (int)resultSet.getLong("CHARACTER_MAXIMUM_LENGTH");
                //字段默认值
                String column_default = resultSet.getString("COLUMN_DEFAULT");
                //字段是否为null
                String is_nullable = resultSet.getString("IS_NULLABLE");
                //字段备注
                String column_comment = resultSet.getString("COLUMN_COMMENT");
                //表名字
                String table_name = resultSet.getString("TABLE_NAME");
                String primary = resultSet.getString("COLUMN_KEY");

                ColumnInfo column = new ColumnInfo();
                column.setColumnSource(column_name);
                column.setColumnType(data_type);
                column.setColumnPrecision(character_maximum_length);
                column.setDefaultValue(column_default);
                column.setNullable(Objects.equals(is_nullable, "YES"));
                column.setIsPrimaryKey(primary==null?false:primary.equals("PRI")?true:false);
                column.setColumnComment(column_comment);
                column.setBelongTableName(table_name);
                list.add(column);
            }
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
        return list;
    }

    @Override
    public String getBatchTableCommentListSql(String tableNameS) throws Exception {
        //mysql中可以直接从INFORMATION_SCHEMA.COLUMNS一次获取到多张表的字段信息，走一次IO操作
        //1.tableNameS进来之后，将每一个表名加上单引号
        String[] split = tableNameS.split(",");
        StringBuilder sb1 = new StringBuilder("(");
        for (String s : split) {
            sb1.append("'");
            sb1.append(s);
            sb1.append("'");
            sb1.append(",");
        }
        //会多一个逗号 ('tableName1','tableName2',
        String substring = sb1.toString().substring(0, sb1.toString().length() - 1);
        StringBuilder sb2 = new StringBuilder(substring);
        sb2.append(")");

        StringBuilder sb = new StringBuilder("SELECT TABLE_NAME,TABLE_COMMENT FROM INFORMATION_SCHEMA.`TABLES` WHERE table_name IN ");
        sb.append(sb2.toString());
        return sb.toString();
    }

    @Override
    public List<TableInfo> getBatchTableCommentList(String tableNameS) throws Exception {
        //获取表的字段信息,从视图获取
        String doSql = this.getBatchTableCommentListSql(tableNameS);
        List<TableInfo> list = Lists.newArrayList();
        try (Connection con = getConnection()) {
            Statement ps = con.createStatement();
            LOG.debug("\n[doExecuteBatch]Execute sql: " + doSql);
            ResultSet resultSet = ps.executeQuery(doSql);
            while (resultSet.next()) {
                //表注释TABLE_COMMENT
                String table_comment = resultSet.getString("TABLE_COMMENT");
                //表名字
                String table_name = resultSet.getString("TABLE_NAME");

                TableInfo tableInfo = new TableInfo();
                tableInfo.setTableSource(table_name);
                tableInfo.setTableComment(table_comment);
                list.add(tableInfo);
            }
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
        return list;
    }

    @Override
    public List<String> getUpdateTableSqlList(String tableName, String tableComments, List<DtsColumn> columnList) {
        List<String> sqlList = new LinkedList<>();
        //表注释语句
        String tableCommentsSql = "ALTER TABLE " + tableName + " COMMENT '" + tableComments + "'";
        List<String> commentSqlList = new ArrayList<>(columnList.size());
        for (DtsColumn column : columnList) {
            StringBuilder sb = new StringBuilder();
            sb.append("ALTER TABLE ");
            sb.append(tableName);
            sb.append(" MODIFY COLUMN ");
            sb.append(column.getColumnSource());
            sb.append(" ");
            System.out.println(column.getColumnType());
            //TODO 完成MYSQL的类型转换后，这里不再需要再转一次
            if ("VARCHAR".equalsIgnoreCase(column.getColumnType())) {
                sb.append(column.getColumnType());
                sb.append("(");
                sb.append(column.getColumnPrecision());
                sb.append(")");
            }else if("NUMBER".equalsIgnoreCase(column.getColumnType())){
                if(column.getColumnScale()>0){
                    sb.append("DOUBLE");
                    sb.append("(");
                    sb.append(column.getColumnPrecision()).append(",").append(column.getColumnScale());
                    sb.append(")");
                }else{
                    sb.append("BIGINT");
                }
            } else {
                sb.append(column.getColumnType());
            }
            sb.append(" COMMENT '");
            sb.append(StringUtils.isNotEmpty(column.getColumnComment()) ? column.getColumnComment() : "");
            sb.append("'");
            commentSqlList.add(sb.toString());

        };
        sqlList.add(tableCommentsSql);
        sqlList.addAll(commentSqlList);
        return sqlList;
    }


    @Override
    public String getQueryTableDataSql(String columns, String tableName, String where, Pageable pageable) {

        if(pageable ==null || pageable.getPageSize() == 0 || pageable.getPageSize() > 1000)
            pageable = PageRequest.of(0, 30);

        StringBuilder sb = new StringBuilder();
        sb.append("select ");
        if (StringUtils.isNotBlank(columns)) {
            sb.append(this.setMysqlColumn(columns));
        } else {
            sb.append("*");
        }
        sb.append(" from ");
        sb.append(tableName);

        if (StringUtils.isNotBlank(where)) {
            sb.append(" where ");
            sb.append(where);
        }

        if (pageable != null && pageable.getPageSize() != 0) {
            sb.append(" limit ");
            sb.append(pageable.getOffset());
            sb.append(",");
            sb.append(pageable.getPageSize());
        }else{
            sb.append(" limit 30 ");
        }

        return sb.toString();
    }

    public String setMysqlColumn(String columns) {
        if (StringUtils.isBlank(columns)) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        String[] split = columns.split(",");
        Arrays.stream(split).filter(Objects::nonNull).forEach(x -> sb.append("`").append(x).append("`").append(","));
        //最后还有一个逗号
        String substring = sb.toString().substring(0, sb.toString().length() - 1);
        return substring;
    }

    @Override
    protected String getQueryAllColumnSql() {
        return "SELECT TABLE_NAME,column_name FROM information_schema.COLUMNS";
    }

    /**
     * 复制表结构
     * @param tarTableName
     * @param srcTableName
     * @return
     */
    @Override
    public boolean copyTableStructure(String tarTableName, String srcTableName) throws Exception{
        String sql = "create table "+tarTableName+" like "+srcTableName;
        return doExecute(sql);
    }

    /**
     * 重命名表
     * @param newTableName
     * @param srcTableName
     * @return
     */
    @Override
    public boolean renameTable(String newTableName, String srcTableName) throws Exception{
        String sql = "alter table "+srcTableName+" rename to "+newTableName;
        return doExecute(sql);
    }

    /**
     * 获取连接用URL
     * @return
     */
    @Override
    public String getConnectUrl() {
        StringBuilder sb = new StringBuilder();
        String ip = datasource.getHostIp();
        String port = String.valueOf(datasource.getPort());
        String dataBaseName = datasource.getDatabaseName();

        // 高版本
        sb.append("jdbc:mysql://");
        sb.append(ip);
        sb.append(":");
        sb.append(port);
        sb.append("/");
        sb.append(dataBaseName);
        sb.append("?useUnicode=true&characterEncoding=utf-8&useSSL=false");

        return sb.toString();
    }

    @Override
    public List<ColumnInfo> getColumnList(String tableName) throws Exception {
        List<ColumnInfo> list = null;
        Map<Integer, ColumnInfo> map = new HashMap<>();
        try (Connection connection = getConnection()) {
            DatabaseMetaData metaData = connection.getMetaData();
            String primaryKeyName = null;
            List<ColumnInfo>  primaryL = getPrimaryKey(connection.getSchema(),tableName);////ResultSet primaryKeys = metaData.getPrimaryKeys(connection.getCatalog(), connection.getSchema(), tableName);
            if(primaryL != null && primaryL.size()>0)
                primaryKeyName = primaryL.get(0).getColumnSource();
            ResultSet colRet = metaData.getColumns(connection.getCatalog(), connection.getSchema(), tableName, null);
            while (colRet.next()) {
                String columnName = colRet.getString("COLUMN_NAME");
                String remarks = colRet.getString("REMARKS");
                int javaTypesSql = colRet.getInt("DATA_TYPE");
                int precision = colRet.getInt("COLUMN_SIZE");
                int scale = colRet.getInt("DECIMAL_DIGITS");
                int nullable = colRet.getInt("NULLABLE");
                int position = colRet.getInt("ORDINAL_POSITION");
                String belongTableName = colRet.getString("TABLE_NAME");
                JavaSqlTypeEnum typeEnum = EnumUtil.getByCode(javaTypesSql, JavaSqlTypeEnum.class);
                String columnTypeName = String.valueOf(typeEnum.getName());
                ColumnInfo column = new ColumnInfo();
                column.setColumnIndex(position);
                column.setColumnSource(columnName);
                column.setColumnType(StringUtils.upperCase(columnTypeName));
                column.setColumnPrecision(precision >= 10485760 ? 10485750 : precision);
                column.setColumnScale(scale);
                column.setNullable(nullable == 1);
                column.setColumnComment(remarks);
                column.setBelongTableName(belongTableName);
                if(primaryKeyName != null && primaryKeyName.equalsIgnoreCase(columnName))
                    column.setIsPrimaryKey(true);
                else
                    column.setIsPrimaryKey(false);
                map.put(position, column);
            }
            list = new LinkedList<>(map.values());
        } catch (Exception e) {
            LOG.error("\n[getColumnList]数据库连接或查询异常:" + e.getMessage(), e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, ExceptionConstants.EXCEPTION_ERROR_MSG + "数据库连接或查询异常:" + e.getMessage());
        }
        return list;
    }

    public List<ColumnInfo> getPrimaryKey(String dbName,String tableNameS) throws Exception {
        String doSql = getPrimaryKeyOfSql(dbName,tableNameS);
        List<ColumnInfo> list = Lists.newArrayList();
        try (Connection con = getConnection()) {
            Statement ps = con.createStatement();
            LOG.debug("\n[doExecuteBatch]Execute sql: " + doSql);
            ResultSet resultSet = ps.executeQuery(doSql);
            while (resultSet.next()) {
                String column_name = resultSet.getString("column_name");
                String table_name = resultSet.getString("table_name");
                ColumnInfo column = new ColumnInfo();
                column.setColumnSource(column_name);
                column.setBelongTableName(table_name);
                list.add(column);
            }
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
        return list;
    }

    public String getPrimaryKeyOfSql(String dbName, String tableName) {
        StringBuilder sb = new StringBuilder(
                " SELECT k.column_name,t.table_name,table_schema " +
                        " FROM  information_schema.table_constraints t " +
                        " JOIN information_schema.key_column_usage k USING (constraint_name, table_schema,table_name) " +
                        " WHERE t.constraint_type = 'PRIMARY KEY' ");
        if (StringUtils.isNotBlank(dbName)) {
            sb.append(" AND t.table_schema = '").append(dbName).append("' AND t.table_name = '").append(tableName).append("'");
        } else {
            sb.append(" AND t.table_name = '").append(tableName).append("'");
        }
        LOG.info("[doSql] : {}", sb.toString());
        return sb.toString();
    }

}
