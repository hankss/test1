package com.openjava.dts.dataprovider.jdbc;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.openjava.dts.constants.DtsConstants;
import com.openjava.dts.constants.ExceptionConstants;
import com.openjava.dts.dataprovider.annotation.ProviderName;
import com.openjava.dts.dataprovider.result.AggregateResultV2;
import com.openjava.dts.dataprovider.result.ColumnIndex;
import com.openjava.dts.ddl.dto.ColumnInfo;
import com.openjava.dts.ddl.dto.DatasourceInfo;
import com.openjava.dts.statistic.domain.DtsStatisticsDb;
import com.openjava.dts.statistic.domain.DtsStatisticsTable;
import com.openjava.dts.util.DtsMathUtil;
import com.openjava.dts.util.DtsStatisticsUtil;
import com.openjava.dts.util.JasyptUtil;
import org.apache.commons.lang3.StringUtils;
import org.ljdp.component.exception.APIException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Pageable;
import org.springframework.util.CollectionUtils;

import java.math.BigInteger;
import java.sql.*;
import java.sql.Date;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author: lsw
 * @Date: 2019/8/1 10:24
 */
@ProviderName(name = "mysqlNew")
public class MySqlNewDataProvider extends MySqlDataProvider {

    private static final Logger LOG = LoggerFactory.getLogger(JdbcDataProvider.class);
    @Override
    public String getDriver() {
        return "com.mysql.cj.jdbc.Driver";
    }

    /**
     * 跟据表名取得单个表表信息,数据行数,占用空间等
     * 数据统计最大的问题是性能和网络的稳定性,细节之多暂放下回-海浪
     * @param tableName
     * @return
     */
    @Override
    public DtsStatisticsTable getDtsStatisticsTable(String tableName) throws Exception {
        DtsStatisticsTable dtsStatisticsTable = new DtsStatisticsTable();
        try{
            dtsStatisticsTable.setTableName(tableName);Double rows = 0.00;
            String sql_count = String.format("SELECT COUNT(*) as sz from %s", tableName);
            Map<String, Object> sql_count_re = queryForMap(sql_count);
            if (sql_count_re != null) {
                rows = Double.parseDouble(sql_count_re.get("sz").toString());
                if (rows.doubleValue() == 0)
                    dtsStatisticsTable.setRows(0.0);
                else
                    dtsStatisticsTable.setRows(DtsMathUtil.getRoundHalfUpDouble(rows.doubleValue() / 10000));
            }else{
                LOG.error("--------->pg没此表记录,表:{},查询sql:{}", tableName,sql_count);
                return null;
            }
            dtsStatisticsTable.setRows(rows);
            Double allSpace = 0.00;
            if(rows.doubleValue() > 0.1) {
                String allSpaceSql = String.format("select DATA_LENGTH,INDEX_LENGTH,TABLE_ROWS from information_schema.tables where TABLE_NAME='%s'", tableName);
                Map<String, Object> allSpaceSql_re = queryForMap(allSpaceSql);
                if (allSpaceSql_re != null) {
                    long dataLength = ((BigInteger)allSpaceSql_re.get("DATA_LENGTH")).longValue();
                    long indexLength = ((BigInteger )allSpaceSql_re.get("INDEX_LENGTH")).longValue();
                    dtsStatisticsTable.setDataSpace(DtsMathUtil.getGBfromByte(dataLength));
                    dtsStatisticsTable.setIndexSpace(DtsMathUtil.getGBfromByte(indexLength));
                    allSpace = DtsMathUtil.getGBfromByte(dataLength+indexLength);
                }else
                    LOG.error("--------->pg没此表空间大小等记录,表:{},查询sql:{}",tableName,allSpaceSql);
                allSpace = DtsMathUtil.getRoundHalfUpDouble(allSpace);
            }else if(rows.doubleValue() == 0){
                allSpace = 0.00;
            }else
                allSpace = 0.01;
            dtsStatisticsTable.setAllSpace(allSpace);
        } catch (Exception e) {
            LOG.error("\n[MYSQL NEW getDtsStatisticsTable]数据库连接或查询异常:",e);
            return null;
        }
        return dtsStatisticsTable;
    }

    /**
     * 取得所有表的信息返回
     * @return
     */
    @Override
    public List<DtsStatisticsTable> getDtsStatisticsTableList() throws Exception {
        DatasourceInfo datasourceInfo = this.getDatasource();
        List<DtsStatisticsTable> DtsList = new LinkedList<>();
        try{
            String db = DtsStatisticsUtil.getNewMysqlDbName(JasyptUtil.decyptText(datasourceInfo.getJdbcUrl()));
            //String tn_sql = String.format("SELECT * FROM information_schema.tables ");//TO DO
            String tn_sql = String.format("SELECT * FROM information_schema.tables where TABLE_SCHEMA='%s'",db);
            List<Map<String,Object>> list1 = this.queryForList(tn_sql);
            for(Map map:list1){
                DtsStatisticsTable table = DtsStatisticsUtil.getMysqlNewStatisticsTable(map);
                if(table != null)
                   DtsList.add(table);
            }
            return DtsList;
        } catch (Exception e) {
            LOG.error("\n[MYSQL getDtsStatisticsTableList]数据库连接或查询异常:" + e.getMessage(), e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, ExceptionConstants.EXCEPTION_ERROR_MSG + "数据库连接或查询异常:" + e.getMessage());
        }
    }
    /**
     * 取得整个数据源的信息
     * @param DtsStatisticsTableList
     * @return
     */
    @Override
    public DtsStatisticsDb getDtsStatisticsDb(List<DtsStatisticsTable> DtsStatisticsTableList)throws Exception{
        //子类重写
        return null;
    }

    /**
     * 取得整个数据源的信息
     * @return
     */
    @Override
    public  DtsStatisticsDb getDtsStatisticsDb()throws Exception{
        //子类重写

        return null;

    }

    @Override
    public Long getTableDataRowsFromView(List<String> tableNameList) throws APIException {
        //获取到当前表的记录数
        StringBuilder sb = new StringBuilder("SELECT table_name ,table_rows FROM `information_schema`.`tables` WHERE table_name in ");
        sb.append(" ( ");
        tableNameList.stream().filter(Objects::nonNull).forEach(x -> sb.append("'").append(x).append("'").append(","));
        //去掉最后一个逗号
        String execSql = sb.toString().substring(0, sb.toString().length() - 1).concat(" ) ");
        try (
                Connection con = getConnection();
                Statement ps = con.createStatement();
        ) {
            ResultSet rs = ps.executeQuery(execSql);
            List<Long> rowsList = Lists.newArrayList();
            while (rs.next()) {
                Long rows = rs.getLong("table_rows");
                rowsList.add(rows);
            }
            return rowsList.parallelStream().filter(Objects::nonNull).reduce(0L, Long::sum);
        } catch (Exception e) {
            LOG.error("\n[doExecute]数据库连接或查询异常,sql:{}", execSql, e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常");
        }
    }

    @Override
    public AggregateResultV2 queryTableDataV2FromView(List<String> columns, String tableName, String where, Pageable pageable, String dbName) throws Exception {
        //获取表的字段信息
        List<ColumnInfo> columnList = this.getColumnListFromView(tableName, dbName);
        //如果columns为空，则用查询出来的字段
        if (CollectionUtils.isEmpty(columns)) {
            columns = columnList.stream().map(ColumnInfo::getColumnSource).collect(Collectors.toList());
        }
        Map<String, ColumnInfo> columnInfoMap = Maps.newHashMap();
        for (ColumnInfo c : columnList) {
            columnInfoMap.put(c.getColumnSource(), c);
        }
        //根据columns，过滤，排序
        if (!CollectionUtils.isEmpty(columns)) {
            List<ColumnInfo> columnTempList = new ArrayList<>(columnList.size());
            for (String column : columns) {
                ColumnInfo columnInfo = columnInfoMap.get(column);
                if (columnInfo == null) {
                    continue;
                }
                columnTempList.add(columnInfo);
            }
            columnList = columnTempList;
        }
        List<ColumnIndex> colList = new ArrayList<>(columnList.size());
        for (ColumnInfo info : columnList) {
            ColumnIndex colIndex = new ColumnIndex();
            colIndex.setIndex(info.getColumnIndex());
            colIndex.setName(info.getColumnSource());
            String comment = info.getColumnComment();
            //取真实注释
//            if (StringUtils.isBlank(comment)) {
//                comment = info.getColumnComment();
//            }
            colIndex.setComment(comment);
            colIndex.setColumnType(info.getColumnType());
            colList.add(colIndex);
        }

        //获取数据
        String exec = this.getQueryTableDataSql(Joiner.on(",").skipNulls().join(columns), tableName, where, pageable);
        List<Map<String, String>> list = new LinkedList<>();
        boolean isOracle = Objects.equals(this.getDatasource().getDatabaseType(), DtsConstants.DATABASE_TYPE_ORACLE);
        LOG.debug(exec);
        try (
                Connection connection = getConnection();
                Statement stat = connection.createStatement();
                ResultSet rs = stat.executeQuery(exec)
        ) {
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            while (rs.next()) {
                Map<String, String> row = new LinkedHashMap<>(columnCount);
                for (int j = 0; j < columnCount; j++) {
                    int columType = metaData.getColumnType(j + 1);
                    String value;
                    switch (columType) {
                        case Types.DATE:
                            Date date = rs.getDate(j + 1);
                            value = (date == null? null : date.toString());
                            break;
                        default:
                            value = rs.getString(j + 1);
                            //去除ORACLE数据库TIMESTAMP的秒数据
                            if (isOracle && Objects.equals(columType, Types.TIMESTAMP) && StringUtils.isNotBlank(value)) {
                                value = value.replace(".0", "");
                            }
                            break;
                    }

                    if (j >= colList.size()) {
                        continue;
                    }
                    row.put(colList.get(j).getName(), value);
                }

                list.add(row);
            }
        } catch (Exception e) {
            LOG.error("\n[queryTableData]数据库连接或查询异常:" + e.getMessage(),e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常");
        }

        //完整结果（字段信息+表数据）
        AggregateResultV2 result = new AggregateResultV2();
        result.setData(list);
        result.setColumnList(colList);

        return result;
    }

    /**
     * 获取字段信息，从视图中获取
     *
     * @param tableName
     * @return
     * @throws Exception
     */
    @Override
    public List<ColumnInfo> getColumnListFromView(String tableName, String db_name) throws Exception {
        //字段名字，字段注释，字段类型，长度，精度，是否为null，字段位置，所属表名，是否是主键(这个另外的一条io做)
        StringBuilder sb = new StringBuilder("SELECT " +
                "TABLE_NAME, " +
                "COLUMN_NAME, " +
                "ORDINAL_POSITION, " +
                "IS_NULLABLE, " +
                "DATA_TYPE, " +
                "CHARACTER_OCTET_LENGTH, " +
                "NUMERIC_PRECISION, " +
                "NUMERIC_SCALE, " +
                "COLUMN_KEY, " +
                "COLUMN_COMMENT " +
                "FROM information_schema.`COLUMNS` " +
                "where table_name = '");
        sb.append(tableName).append("' ").append(" and ").append(" table_schema = '").append(db_name).append("' ");

        //执行的sql
        String doSql = sb.toString();
        List<ColumnInfo> list = Lists.newArrayList();
        try (Connection con = getConnection()) {
            Statement ps = con.createStatement();
            LOG.info("\n[doExecuteBatch]Execute sql: " + doSql);
            ResultSet resultSet = ps.executeQuery(doSql);
            while (resultSet.next()) {
                //所属数据表名
                String belongTableName = resultSet.getString("TABLE_NAME");
                //字段名
                String columnName = resultSet.getString("COLUMN_NAME");
                //字段注释
                String columnComment = resultSet.getString("COLUMN_COMMENT");
                //对应typesSql的值
                String columnType = resultSet.getString("DATA_TYPE");
                //字段长度
                Long precision = resultSet.getLong("CHARACTER_OCTET_LENGTH");
                //精度
                int scale = resultSet.getInt("NUMERIC_SCALE");
                //是否为空：N就表示Not Null，Y表示可以是Null
                String nullable = resultSet.getString("IS_NULLABLE");
                //字段索引定位：从1开始
                int position = resultSet.getInt("ORDINAL_POSITION");
                //是否是主键
                String isPrimary = resultSet.getString("COLUMN_KEY");

                ColumnInfo column = new ColumnInfo();
                column.setColumnSource(columnName);
                column.setColumnComment(columnComment);
                column.setColumnType(columnType);
                column.setColumnPrecision(precision > Integer.MAX_VALUE ? Integer.MAX_VALUE : precision.intValue());
                column.setColumnScale(scale);
                column.setColumnIndex(position);
                column.setNullable("YES".equals(nullable));
                column.setBelongTableName(belongTableName);
                column.setIsPrimaryKey("PRI".equals(isPrimary));
                list.add(column);
            }
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
        return list;
    }

}
