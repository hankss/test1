package com.openjava.dts.dataprovider.jdbc;

import com.openjava.dts.dataprovider.annotation.ProviderName;

/**
 * @author: lsw
 * @Date: 2019/8/1 10:24
 */
@ProviderName(name = "mysqlOld")
public class MySqlOldDataProvider extends MySqlDataProvider {
    @Override
    public String getDriver() {
        return "com.mysql.jdbc.Driver";
    }
}
