package com.openjava.dts.dataprovider.jdbc;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.openjava.dts.constants.DtsConstants;
import com.openjava.dts.constants.ExceptionConstants;
import com.openjava.dts.dataprovider.annotation.ProviderName;
import com.openjava.dts.dataprovider.result.AggregateResultV2;
import com.openjava.dts.dataprovider.result.ColumnIndex;
import com.openjava.dts.ddl.domain.DtsColumn;
import com.openjava.dts.ddl.dto.ColumnInfo;
import com.openjava.dts.ddl.dto.DatasourceInfo;
import com.openjava.dts.ddl.dto.TableInfo;
import com.openjava.dts.statistic.domain.DtsStatisticsDb;
import com.openjava.dts.statistic.domain.DtsStatisticsTable;
import com.openjava.dts.util.CreateSqlUtil;
import com.openjava.dts.util.DtsMathUtil;
import com.openjava.dts.util.DtsStatisticsUtil;
import com.openjava.dts.util.EnumUtil;
import com.openjava.dts.util.column.JavaSqlTypeEnum;
import org.apache.commons.lang3.StringUtils;
import org.ljdp.component.exception.APIException;
import org.ljdp.component.sequence.ConcurrentSequence;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.util.CollectionUtils;

import javax.management.ObjectName;
import javax.validation.constraints.NotBlank;
import java.math.BigDecimal;
import java.sql.*;
import java.sql.Date;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author: lsw
 * @Date: 2019/8/1 10:15
 */
@ProviderName(name = "oracle")
public class OracleDataProvider extends JdbcDataProvider {

    @Override
    public String getDriver() {
        return "oracle.jdbc.OracleDriver";
    }

    private final Logger LOG = LoggerFactory.getLogger(this.getClass());

    /**
     * 已经同步标志
     */
    private final static Integer YesTask = 1;

    /**
     * 未同步标志
     */
    private final static Integer NoTask = 2;


    @Override
    protected String getValidationQuery() {
        return "select 'x' from dual";
    }

    @Override
    protected String getCheckTableExistSql(String tableName) {
        return String.format("SELECT COUNT(1) FROM USER_TAB_COMMENTS S WHERE S.TABLE_NAME = '%s'", tableName);
    }

    @Override
    protected List<String> getCreateTableSqlList(String tableName, String tableComments, List<DtsColumn> columnList) {
        List<String> sqlList = new LinkedList<>();
        //建表语句
        String createTableSQL = CreateSqlUtil.createOracleTableSQL(tableName, columnList);
        //表注释语句
        String tableCommentsSql = "COMMENT ON TABLE " + tableName + " IS '" + tableComments + "'";

        //字段注释
        List<String> commentSqlList = new ArrayList<>(columnList.size());
        DtsColumn primaryKeyColumn = null;
        for (DtsColumn column : columnList) {
            StringBuilder sb = new StringBuilder();
            sb.append("COMMENT ON COLUMN ");
            sb.append(tableName);
            sb.append(".");
            sb.append(column.getColumnSource());
            sb.append(" IS '");
            sb.append(StringUtils.isNotEmpty(column.getColumnComment()) ? column.getColumnComment() : "");
            sb.append("'");

            commentSqlList.add(sb.toString());

            if (column.getIsPrimaryKey()) {
                primaryKeyColumn = column;
            }
        }

        //表主键语句
        String primaryKeySql = "";
        if (primaryKeyColumn != null) {
            StringBuilder sb = new StringBuilder();
            sb.append("ALTER TABLE ");
            sb.append(tableName);
            sb.append(" ADD constraint pk_");
            sb.append(tableName);
            sb.append("_");
            sb.append(primaryKeyColumn.getColumnSource());
            sb.append(" primary key (");
            sb.append(primaryKeyColumn.getColumnSource());
            sb.append(")");

            primaryKeySql = sb.toString();
        }

        sqlList.add(createTableSQL);
        sqlList.add(tableCommentsSql);
        sqlList.addAll(commentSqlList);
        if (StringUtils.isNotBlank(primaryKeySql)) {
            sqlList.add(primaryKeySql);
        }

        return sqlList;
    }

    @Override
    public List<String> getUpdateTableSqlList(String tableName, String tableComments, List<DtsColumn> columnList) {
        List<String> sqlList = new LinkedList<>();
        //表注释语句
        String tableCommentsSql = "COMMENT ON TABLE " + tableName + " IS '" + tableComments + "'";
        //字段注释
        List<String> commentSqlList = new ArrayList<>(columnList.size());
        DtsColumn primaryKeyColumn = null;
        for (DtsColumn column : columnList) {
            StringBuilder sb = new StringBuilder();
            sb.append("COMMENT ON COLUMN ");
            sb.append(tableName);
            sb.append(".");
            sb.append(column.getColumnSource());
            sb.append(" IS '");
            sb.append(StringUtils.isNotEmpty(column.getColumnComment()) ? column.getColumnComment() : "");
            sb.append("'");
            commentSqlList.add(sb.toString());
        }
        sqlList.add(tableCommentsSql);
        sqlList.addAll(commentSqlList);
        return sqlList;
    }

    @Override
    public List<ColumnInfo> getColumnList(String tableName) throws Exception {
        if (tableName.contains("\"")) {
            tableName = tableName.replace("\"", "");
        }
        List<ColumnInfo> list = new LinkedList<>();
        try (Connection connection = getConnection()) {
            DatabaseMetaData metaData = connection.getMetaData();
            String primaryKeyName = null;
            List<ColumnInfo>  primaryL = getPrimaryKey(connection.getSchema(),tableName);////ResultSet primaryKeys = metaData.getPrimaryKeys(connection.getCatalog(), connection.getSchema(), tableName);
            if(primaryL != null && primaryL.size()>0)
                primaryKeyName = primaryL.get(0).getColumnSource();
            //精准匹配表，获取表字段信息q
            ResultSet colRet = metaData.getColumns(connection.getCatalog(), connection.getSchema(), tableName,null);
            while(colRet.next()) {
                String columnName = colRet.getString("COLUMN_NAME");
                String remarks = colRet.getString("REMARKS");
                int javaTypesSql = colRet.getInt("DATA_TYPE");
                int precision = colRet.getInt("COLUMN_SIZE");
                int scale = colRet.getInt("DECIMAL_DIGITS");
                int nullable = colRet.getInt("NULLABLE");
                int position = colRet.getInt("ORDINAL_POSITION");
                //默认值 TODO oracle获取会报错
//                String defaultValue = colRet.getString("COLUMN_DEF");
                String belongTableName = colRet.getString("TABLE_NAME");
                JavaSqlTypeEnum typeEnum = EnumUtil.getByCode(javaTypesSql, JavaSqlTypeEnum.class);
                String columnTypeName = String.valueOf(typeEnum.getName());
                ColumnInfo column = new ColumnInfo();
                column.setColumnIndex(position);
                column.setColumnSource(columnName);
                column.setColumnType(StringUtils.upperCase(columnTypeName));
                column.setColumnPrecision(precision);
                column.setColumnScale(scale);
                column.setNullable(nullable == 1);
                column.setColumnComment(remarks);
//                column.setDefaultValue(defaultValue);
                column.setBelongTableName(belongTableName);
                column.setIsPrimaryKey(Objects.equals(primaryKeyName, columnName));

                list.add(column);
            }
        } catch (Exception e) {
            LOG.error("\n[getColumnList]数据库连接或查询异常:" + e.getMessage(),e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, ExceptionConstants.EXCEPTION_ERROR_MSG + "数据库连接或查询异常:"+e.getMessage());
        }
        return list;
    }

    /**
     * 获取字段信息，从视图中获取，无主键信息
     *
     * @param tableName
     * @return
     * @throws Exception
     */
    @Override
    public List<ColumnInfo> getColumnListFromView(String tableName, String db_name) throws Exception {
        //字段名字，字段注释，字段类型，长度，精度，是否为null，字段位置，所属表名，是否是主键(这个另外的一条io做)
        StringBuilder sb = new StringBuilder("SELECT \n" +
                "UTC.TABLE_NAME,\n" +
                "UTC.COLUMN_NAME,\n" +
                "UTC.DATA_TYPE,\n" +
                "UTC.DATA_LENGTH,\n" +
                "UTC.NULLABLE,\n" +
                "UTC.DATA_SCALE,\n" +
                "UTC.COLUMN_ID,\n" +
                "UCC.COMMENTS\n" +
                "FROM user_tab_cols UTC left join user_col_comments UCC\n" +
                "ON UTC.TABLE_NAME = UCC.TABLE_NAME AND UTC.COLUMN_NAME = UCC.COLUMN_NAME\n" +
                "where UTC.TABLE_NAME = '");
        if (StringUtils.isNotBlank(db_name)) {
            sb.append(db_name).append(".").append(tableName).append("'");
        } else {
            sb.append(tableName).append("'");
        }

        //执行的sql
        String doSql = sb.toString();
        List<ColumnInfo> list = Lists.newArrayList();
        try (Connection con = getConnection()) {
            Statement ps = con.createStatement();
//            LOG.debug("\n[doExecuteBatch]Execute sql: " + doSql);
            LOG.info("\n[doExecuteBatch]Execute sql: " + doSql);
            ResultSet resultSet = ps.executeQuery(doSql);
            while (resultSet.next()) {
                //所属数据表名
                String belongTableName = resultSet.getString("TABLE_NAME");
                //字段名
                String columnName = resultSet.getString("COLUMN_NAME");
                //字段注释
                String columnComment = resultSet.getString("COMMENTS");
                //对应typesSql的值
                String columnType = resultSet.getString("DATA_TYPE");
                //字段长度
                int precision = resultSet.getInt("DATA_LENGTH");
                //精度
                int scale = resultSet.getInt("DATA_SCALE");
                //是否为空：N就表示Not Null，Y表示可以是Null
                String nullable = resultSet.getString("NULLABLE");
                //字段索引定位：从1开始
                int position = resultSet.getInt("COLUMN_ID");

                ColumnInfo column = new ColumnInfo();
                column.setColumnSource(columnName);
                column.setColumnComment(columnComment);
                column.setColumnType(columnType);
                column.setColumnPrecision(precision);
                column.setColumnScale(scale);
                column.setColumnIndex(position);
                column.setNullable("Y".equals(nullable));
                column.setBelongTableName(belongTableName);
                column.setIsPrimaryKey(false);
                list.add(column);
            }
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
        return list;
    }

    /**
     * Oracle获取字段信息
     *
     * @param tableName 表名
     * @param db_name   必须有值
     * @return 字段信息
     * @throws Exception 异常
     */
    @Override
    public List<ColumnInfo> getColumnListOnlyOracle(String tableName, String db_name) throws Exception {
        //字段名字，字段注释，字段类型，长度，精度，是否为null，字段位置，所属表名，是否是主键(这个另外的一条io做)
        StringBuilder sb = new StringBuilder("SELECT \n" +
                " ATC.TABLE_NAME,\n" +
                " ATC.COLUMN_NAME,\n" +
                " ATC.DATA_TYPE,\n" +
                " ATC.DATA_LENGTH,\n" +
                " ATC.NULLABLE,\n" +
                " ATC.DATA_SCALE,\n" +
                " ATC.COLUMN_ID,\n" +
                " ACC.COMMENTS\n" +
                " FROM ALL_TAB_COLUMNS ATC\n" +
                " LEFT JOIN ALL_COL_COMMENTS ACC ON ACC.TABLE_NAME = ATC.TABLE_NAME AND ACC.COLUMN_NAME = ATC.COLUMN_NAME ");
        sb.append("WHERE ATC.OWNER =  '").append(db_name).append("'").append(" AND ATC.TABLE_NAME = '").append(tableName).append("'")
                .append(" AND ACC.OWNER = '").append(db_name).append("'").append(" AND ACC.TABLE_NAME = '").append(tableName).append("'")
                .append(" ORDER BY ATC.COLUMN_ID");
        //执行的sql
        String doSql = sb.toString();
        List<ColumnInfo> list = Lists.newArrayList();
        try (Connection con = getConnection()) {
            Statement ps = con.createStatement();
//            LOG.debug("\n[doExecuteBatch]Execute sql: " + doSql);
            LOG.info("\n[doExecuteBatch]Execute sql: " + doSql);
            ResultSet resultSet = ps.executeQuery(doSql);
            while (resultSet.next()) {
                //所属数据表名
                String belongTableName = resultSet.getString("TABLE_NAME");
                //字段名
                String columnName = resultSet.getString("COLUMN_NAME");
                //字段注释
                String columnComment = resultSet.getString("COMMENTS");
                //对应typesSql的值
                String columnType = resultSet.getString("DATA_TYPE");
                //字段长度
                int precision = resultSet.getInt("DATA_LENGTH");
                //精度
                int scale = resultSet.getInt("DATA_SCALE");
                //是否为空：N就表示Not Null，Y表示可以是Null
                String nullable = resultSet.getString("NULLABLE");
                //字段索引定位：从1开始
                int position = resultSet.getInt("COLUMN_ID");

                ColumnInfo column = new ColumnInfo();
                column.setColumnSource(columnName);
                column.setColumnComment(columnComment);
                column.setColumnType(columnType);
                column.setColumnPrecision(precision);
                column.setColumnScale(scale);
                column.setColumnIndex(position);
                column.setNullable("Y".equals(nullable));
                column.setBelongTableName(belongTableName);
                column.setIsPrimaryKey(false);
                list.add(column);
            }
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
        return list;
    }

    @Override
    public String getPrimaryKeyOfSql(String tableNameS) {
        //1.tableNameS进来之后，将每一个表名加上单引号
        String[] split = tableNameS.split(",");
        StringBuilder sb1 = new StringBuilder("(");
        for (String s : split) {
            sb1.append("'");
            sb1.append(s);
            sb1.append("'");
            sb1.append(",");
        }
        //会多一个逗号 ('tableName1','tableName2',
        String substring = sb1.toString().substring(0, sb1.toString().length() - 1);
        StringBuilder sb2 = new StringBuilder(substring);
        sb2.append(")");

        StringBuilder sb = new StringBuilder("select cu.* \n" +
                "from user_cons_columns cu, user_constraints au \n" +
                "where cu.constraint_name = au.constraint_name " +
                "and au.constraint_type = 'P' " +
                "and au.table_name IN ");
        return sb.append(sb2.toString()).toString();
    }

    @Override
    public List<ColumnInfo> getPrimaryKey(String tableNameS) throws Exception {
        String doSql = this.getPrimaryKeyOfSql(tableNameS);

        List<ColumnInfo> list = Lists.newArrayList();
        try (Connection con = getConnection()) {
            Statement ps = con.createStatement();
            LOG.debug("\n[doExecuteBatch]Execute sql: " + doSql);
            ResultSet resultSet = ps.executeQuery(doSql);
            while (resultSet.next()) {
                //字段名字
                String column_name = resultSet.getString("COLUMN_NAME");
                //表名字
                String table_name = resultSet.getString("TABLE_NAME");

                ColumnInfo column = new ColumnInfo();
                column.setColumnSource(column_name);
                column.setBelongTableName(table_name);
                list.add(column);
            }
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
        return list;
    }

    @Override
    public String getBatchTableColumnListSql(String tableNameS) throws Exception {
        //mysql中可以直接从INFORMATION_SCHEMA.COLUMNS一次获取到多张表的字段信息，走一次IO操作
        //1.tableNameS进来之后，将每一个表名加上单引号
        String[] split = tableNameS.split(",");
        StringBuilder sb1 = new StringBuilder("(");
        for (String s : split) {
            sb1.append("'");
            sb1.append(s);
            sb1.append("'");
            sb1.append(",");
        }
        //会多一个逗号 ('tableName1','tableName2',
        String substring = sb1.toString().substring(0, sb1.toString().length() - 1);
        StringBuilder sb2 = new StringBuilder(substring);
        sb2.append(")");

        StringBuilder sb = new StringBuilder("select a.Table_name,a.column_name,a.data_type,a.data_length,a.data_precision,a.nullable,a.column_id,b.comments\n" +
                "from user_tab_columns a left join user_col_comments b on a.TABLE_NAME=b.table_name and a.COLUMN_NAME=b.column_name \n" +
                "where a.TABLE_NAME IN ");
        sb.append(sb2.toString());
        return sb.toString();
    }

    @Override
    public List<ColumnInfo> getBatchTableColumnList(String tableNameS) throws Exception {
        //获取表的字段信息,从视图获取
        String doSql = getPrimaryKeyOfSql(tableNameS);
        List<ColumnInfo> list = Lists.newArrayList();
        try (Connection con = getConnection()) {
            Statement ps = con.createStatement();
            LOG.debug("\n[doExecuteBatch]Execute sql: " + doSql);
            ResultSet resultSet = ps.executeQuery(doSql);
            while (resultSet.next()) {
                //字段名字
                String column_name = resultSet.getString("COLUMN_NAME");
                //字段类型
                String data_type = resultSet.getString("DATA_TYPE");
                //字段默认值
                String column_default = resultSet.getString("COLUMN_DEFAULT");
                //字段是否为null
                String is_nullable = resultSet.getString("NULLABLE");
                //字段备注
                String column_comment = resultSet.getString("COMMENTS");
                //表名字
                String table_name = resultSet.getString("TABLE_NAME");

                ColumnInfo column = new ColumnInfo();
                column.setColumnSource(column_name);
                column.setColumnType(data_type);
                column.setDefaultValue(column_default);
                column.setNullable(Objects.equals(is_nullable, "Y"));
                column.setColumnComment(column_comment);
                column.setBelongTableName(table_name);
                list.add(column);
            }
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
        return list;
    }

    @Override
    public String getBatchTableCommentListSql(String tableNameS) throws Exception {
        //mysql中可以直接从INFORMATION_SCHEMA.COLUMNS一次获取到多张表的字段信息，走一次IO操作
        //1.tableNameS进来之后，将每一个表名加上单引号
        String[] split = tableNameS.split(",");
        StringBuilder sb1 = new StringBuilder("(");
        for (String s : split) {
            sb1.append("'");
            sb1.append(s);
            sb1.append("'");
            sb1.append(",");
        }
        //会多一个逗号 ('tableName1','tableName2',
        String substring = sb1.toString().substring(0, sb1.toString().length() - 1);
        StringBuilder sb2 = new StringBuilder(substring);
        sb2.append(")");

        StringBuilder sb = new StringBuilder("select * \n" +
                "from user_tab_comments \n" +
                "where Table_Name IN ");
        sb.append(sb2.toString());
        return sb.toString();
    }

    @Override
    public List<TableInfo> getBatchTableCommentList(String tableNameS) throws Exception {
        //获取表的字段信息,从视图获取
        String doSql = getPrimaryKeyOfSql(tableNameS);
        List<TableInfo> list = Lists.newArrayList();
        try (Connection con = getConnection()) {
            Statement ps = con.createStatement();
            LOG.debug("\n[doExecuteBatch]Execute sql: " + doSql);
            ResultSet resultSet = ps.executeQuery(doSql);
            while (resultSet.next()) {
                //表注释TABLE_COMMENT
                String table_comment = resultSet.getString("COMMENTS");
                //表名字
                String table_name = resultSet.getString("TABLE_NAME");

                TableInfo tableInfo = new TableInfo();
                tableInfo.setTableSource(table_name);
                tableInfo.setTableComment(table_comment);
                list.add(tableInfo);
            }
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
        return list;
    }

    @Override
    public AggregateResultV2 queryTableDataV2(List<String> columns, String tableName, String where, Pageable pageable) throws Exception {
        tableName = "\"" + tableName + "\"";
        //获取表的字段信息
        List<ColumnInfo> columnList = this.getColumnList(tableName);
        //如果columns为空，则用查询出来的字段
        if (CollectionUtils.isEmpty(columns)) {
            columns = columnList.stream().map(ColumnInfo::getColumnSource).collect(Collectors.toList());
        }

        Map<@NotBlank String, ColumnInfo> columnInfoMap = columnList.stream().collect(Collectors.toMap(ColumnInfo::getColumnSource, (col) -> col));
        //根据columns，过滤，排序
        if (!CollectionUtils.isEmpty(columns)) {
            List<ColumnInfo> columnTempList = new ArrayList<>(columnList.size());
            for (String column : columns) {
                ColumnInfo columnInfo = columnInfoMap.get(column);
                if (columnInfo == null) {
                    continue;
                }

                columnTempList.add(columnInfo);
            }

            columnList = columnTempList;
        }

        List<ColumnIndex> colList = new ArrayList<>(columnList.size());
        for (ColumnInfo info : columnList) {
            ColumnIndex colIndex = new ColumnIndex();
            colIndex.setIndex(info.getColumnIndex());
            colIndex.setName(info.getColumnSource());
            colIndex.setColumnType(info.getColumnType());
            String comment = info.getColumnComment();
            //取真实的字段注释
          /*  if (StringUtils.isBlank(comment)) {
                comment = info.getColumnSource();
            }*/
            colIndex.setComment(comment);

            colList.add(colIndex);
        }

        //获取数据
        String exec = this.getQueryTableDataSql(Joiner.on(",").skipNulls().join(columns), tableName, where, pageable);
        List<Map<String, String>> list = new LinkedList<>();
        boolean isOracle = Objects.equals(this.getDatasource().getDatabaseType(), DtsConstants.DATABASE_TYPE_ORACLE);
        LOG.debug(exec);
        try (
                Connection connection = getConnection();
                Statement stat = connection.createStatement();
                ResultSet rs = stat.executeQuery(exec)
        ) {
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            while (rs.next()) {
                Map<String, String> row = new LinkedHashMap<>(columnCount);
                for (int j = 0; j < columnCount; j++) {
                    int columType = metaData.getColumnType(j + 1);
                    String value;
                    switch (columType) {
                        case Types.DATE:
                            Date date = rs.getDate(j + 1);
                            value = (date == null ? null : date.toString());
                            break;
                        default:
                            value = rs.getString(j + 1);
                            //去除ORACLE数据库TIMESTAMP的秒数据
                            if (isOracle && Objects.equals(columType, Types.TIMESTAMP) && StringUtils.isNotBlank(value)) {
                                value = value.replace(".0", "");
                            }
                            break;
                    }

                    if (j >= colList.size()) {
                        continue;
                    }
                    row.put(colList.get(j).getName(), value);
                }

                list.add(row);
            }
        } catch (Exception e) {
            LOG.error("\n[queryTableData]数据库连接或查询异常:" + e.getMessage(), e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常");
        }

        //完整结果（字段信息+表数据）
        AggregateResultV2 result = new AggregateResultV2();
        result.setData(list);
        result.setColumnList(colList);

        return result;
    }

    @Override
    public AggregateResultV2 queryTableDataV2FromView(List<String> columns, String tableName, String where, Pageable pageable,String dbName) throws Exception {
        //获取表的字段信息
        List<ColumnInfo> columnList = this.getColumnListFromView(tableName,null);
        tableName = "\"" + tableName + "\"";
        LOG.info("字段信息：{}",columnList);
        //如果columns为空，则用查询出来的字段
        if (CollectionUtils.isEmpty(columns)) {
            columns = columnList.stream().map(ColumnInfo::getColumnSource).collect(Collectors.toList());
        }

        Map<@NotBlank String, ColumnInfo> columnInfoMap = columnList.stream().collect(Collectors.toMap(ColumnInfo::getColumnSource, (col) -> col));
        //根据columns，过滤，排序
        if (!CollectionUtils.isEmpty(columns)) {
            List<ColumnInfo> columnTempList = new ArrayList<>(columnList.size());
            for (String column : columns) {
                ColumnInfo columnInfo = columnInfoMap.get(column);
                if (columnInfo == null) {
                    continue;
                }

                columnTempList.add(columnInfo);
            }

            columnList = columnTempList;
        }

        List<ColumnIndex> colList = new ArrayList<>(columnList.size());
        for (ColumnInfo info : columnList) {
            ColumnIndex colIndex = new ColumnIndex();
            colIndex.setIndex(info.getColumnIndex());
            colIndex.setName(info.getColumnSource());
            colIndex.setColumnType(info.getColumnType());
            String comment = info.getColumnComment();
            //取真实的字段注释
          /*  if (StringUtils.isBlank(comment)) {
                comment = info.getColumnSource();
            }*/
            colIndex.setComment(comment);

            colList.add(colIndex);
        }

        //获取数据
        String exec = this.getQueryTableDataSql(Joiner.on(",").skipNulls().join(columns), tableName, where, pageable);
        List<Map<String, String>> list = new LinkedList<>();
        boolean isOracle = Objects.equals(this.getDatasource().getDatabaseType(), DtsConstants.DATABASE_TYPE_ORACLE);
        LOG.debug(exec);
        try (
                Connection connection = getConnection();
                Statement stat = connection.createStatement();
                ResultSet rs = stat.executeQuery(exec)
        ) {
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            while (rs.next()) {
                Map<String, String> row = new LinkedHashMap<>(columnCount);
                for (int j = 0; j < columnCount; j++) {
                    int columType = metaData.getColumnType(j + 1);
                    String value;
                    switch (columType) {
                        case Types.DATE:
                            Date date = rs.getDate(j + 1);
                            value = (date == null ? null : date.toString());
                            break;
                        default:
                            value = rs.getString(j + 1);
                            //去除ORACLE数据库TIMESTAMP的秒数据
                            if (isOracle && Objects.equals(columType, Types.TIMESTAMP) && StringUtils.isNotBlank(value)) {
                                value = value.replace(".0", "");
                            }
                            break;
                    }

                    if (j >= colList.size()) {
                        continue;
                    }
                    row.put(colList.get(j).getName(), value);
                }

                list.add(row);
            }
        } catch (Exception e) {
            LOG.error("\n[queryTableData]数据库连接或查询异常:" + e.getMessage(), e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常");
        }

        //完整结果（字段信息+表数据）
        AggregateResultV2 result = new AggregateResultV2();
        result.setData(list);
        result.setColumnList(colList);

        return result;
    }

    @Override
    public String getQueryTableDataSql(String columns, String tableName, String where, Pageable pageable) {

        if(pageable ==null || pageable.getPageSize() == 0 || pageable.getPageSize() > 1000)
            pageable = PageRequest.of(0, 30);

        StringBuilder sb = new StringBuilder();
        sb.append(" select ");
        if (StringUtils.isNotBlank(columns)) {
            if (this.judgeChar(columns)) {
                sb.append(columns);
            } else {
                //如果字段是小写的或者是Oracle数据库关键字,那么需要加上""
                String[] split = columns.split(",");
                StringBuilder sb2 = new StringBuilder();
                for (int i = 0; i < split.length; i++) {
                    sb2.append("\"");
                    sb2.append(split[i]);
                    sb2.append("\"");
                    if (i != split.length - 1) {
                        sb2.append(",");
                    }
                }
                sb.append(sb2.toString());
            }
        } else {
            sb.append(" * ");
        }
        sb.append(" from (select ROWNUM as rowno, t_n.* from (");
        sb.append(tableName);
//        sb.append(") t_n) t_n2 where t_n2.rowno between ");
        sb.append(") t_n ");
        if (StringUtils.isNotBlank(where)) {
            sb.append(" where ");
            sb.append(where);
        }
        sb.append(") t_n2 where t_n2.rowno between ");
        sb.append(pageable.getOffset() + 1);
        sb.append(" and ");
        sb.append(pageable.getOffset() + pageable.getPageSize());

        return sb.toString();
    }

    public String getQueryTableDataOnlyOracle(String columns, String tableName, String where, Pageable pageable, String owner) {

        if (pageable == null || pageable.getPageSize() == 0 || pageable.getPageSize() > 1000)
            pageable = PageRequest.of(0, 30);

        StringBuilder sb = new StringBuilder();
        sb.append(" select ");
        if (StringUtils.isNotBlank(columns)) {
            if (this.judgeChar(columns)) {
                sb.append(columns);
            } else {
                //如果字段是小写的或者是Oracle数据库关键字,那么需要加上""
                String[] split = columns.split(",");
                StringBuilder sb2 = new StringBuilder();
                for (int i = 0; i < split.length; i++) {
                    sb2.append("\"");
                    sb2.append(split[i]);
                    sb2.append("\"");
                    if (i != split.length - 1) {
                        sb2.append(",");
                    }
                }
                sb.append(sb2.toString());
            }
        } else {
            sb.append(" * ");
        }
        sb.append(" from (select ROWNUM as rowno, t_n.* from (");
        if (StringUtils.isNotBlank(owner)) {
            sb.append(owner).append(".").append(tableName);
        } else {
            sb.append(tableName);
        }
//        sb.append(") t_n) t_n2 where t_n2.rowno between ");
        sb.append(") t_n ");
        if (StringUtils.isNotBlank(where)) {
            sb.append(" where ");
            sb.append(where);
        }
        sb.append(") t_n2 where t_n2.rowno between ");
        sb.append(pageable.getOffset() + 1);
        sb.append(" and ");
        sb.append(pageable.getOffset() + pageable.getPageSize());

        return sb.toString();
    }

    @Override
    protected String getQueryAllColumnSql() {
        return "SELECT TABLE_NAME,COLUMN_NAME FROM USER_TAB_COLUMNS";
    }

    /**
     * 复制表结构
     *
     * @param tarTableName
     * @param srcTableName
     * @return
     */
    @Override
    public boolean copyTableStructure(String tarTableName, String srcTableName) throws Exception {
        String sql = "create table " + tarTableName + " as select * from " + srcTableName + " where 1=2";
        return doExecute(sql);
    }

    /**
     * 重命名表
     *
     * @param newTableName
     * @param srcTableName
     * @return
     */
    @Override
    public boolean renameTable(String newTableName, String srcTableName) throws Exception {
        String sql = "alter table " + srcTableName + " rename to " + newTableName;
        return doExecute(sql);
    }

    /**
     * -hl
     * 根据表名取得单个表表信息,数据行数,占用空间等
     * (有一个表，查出它的行数，占用空间，将数据放到DtsStatisticsTable返回)
     * 这个地方已经连接上了数据源库，本次继承父类之后
     *
     * @param tableName 表名
     * @return
     */
    @Override
    public DtsStatisticsTable getDtsStatisticsTable(String tableName)throws Exception{
        DtsStatisticsTable dtsStatisticsTable = new DtsStatisticsTable();
        try{
            dtsStatisticsTable.setTableName(tableName);Double rows = 0.00;
            String sql_count = String.format("SELECT COUNT(*) as sz FROM %s", tableName);
            Map<String, Object> sql_count_re = queryForMap(sql_count);
            if(sql_count_re != null) {
                rows = Double.valueOf(((BigDecimal)sql_count_re.get("SZ")).doubleValue());
                rows = DtsMathUtil.getRoundHalfUpDouble(rows.doubleValue() / 10000);
            }else{
                LOG.error("--------->pg没此表记录,表:{},查询sql:{}", tableName,sql_count);
                return null;
            }
            dtsStatisticsTable.setRows(rows);
            Double allSpace = 0.00;
            if(rows.doubleValue() > 0.1) {
                String allSpaceSql = String.format("SELECT segment_name AS TABLENAME,BYTES / 1024 / 1024 / 1024 GB FROM user_segments WHERE segment_name = '%s'", tableName);
                Map<String, Object> allSpaceSql_re = queryForMap(allSpaceSql);
                if(allSpaceSql_re != null) {
                    allSpace = Double.valueOf(((BigDecimal)allSpaceSql_re.get("GB")).doubleValue());
                }else
                    LOG.error("--------->pg没此表空间大小等记录,表:{},查询sql:{}",tableName,allSpaceSql);
                allSpace = DtsMathUtil.getRoundHalfUpDouble(allSpace);
            }else if(rows.doubleValue() == 0){
                allSpace = 0.00;
            }else
                allSpace = 0.01;
            dtsStatisticsTable.setAllSpace(allSpace);
        } catch (Exception e) {
            LOG.error("\n[getDtsStatisticsTable]数据库连接或查询异常:",e);
            return null;
        }
        return dtsStatisticsTable;
    }

    /**
     * 取得所有表的信息返回
     * @return
     */
    @Override
    public List<DtsStatisticsTable> getDtsStatisticsTableList() throws Exception{
        DatasourceInfo datasourceInfo = getDatasource();
        List<DtsStatisticsTable> list = new LinkedList<>();
        try{
            //String sql = "select TABLE_NAME from all_tables a where a.OWNER = upper('"+datasourceInfo.getUsername()+"')";
            //String sql = "select TABLE_NAME from user_tables";
            String sql = "select user_tables.TABLE_NAME,user_tables.NUM_ROWS,user_segments.BYTES / 1024 / 1024 / 1024 GB from user_tables left join user_segments on user_tables.TABLE_NAME = user_segments.segment_name";
            List<Map<String,Object>> list1 = this.queryForList(sql);
            for(Map map:list1){
                DtsStatisticsTable table = DtsStatisticsUtil.getOracleStatisticsTable(map);
                if(table != null)
                    list.add(table);
            }
            return list;
        } catch (Exception e) {
            LOG.error("\n[ORACLE getDtsStatisticsTableList]数据库连接或查询异常:" + e.getMessage(), e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, ExceptionConstants.EXCEPTION_ERROR_MSG + "数据库连接或查询异常:" + e.getMessage());
        }
    }

    /**
     * 取得整个数据源的信息
     *
     * @param DtsStatisticsTableList
     * @return
     */

    @Override
    public DtsStatisticsDb getDtsStatisticsDb(List<DtsStatisticsTable> DtsStatisticsTableList) throws Exception{
        return null;
    }

    /**
     * 取得整个数据源的信息
     *
     * @return
     */
    @Override
    public DtsStatisticsDb getDtsStatisticsDb() throws Exception{
        return null;
    }

    /**
     * 获取批次id
     *
     * @return
     */
    private long getBatchId() {
        final long sequence;
        sequence = ConcurrentSequence.getInstance().getSequence();
        return sequence;
    }

    @Override
    public String getConnectUrl() {
        // jdbc:oracle:thin:@nhc.smart-info.cn:8521:orcl
        StringBuilder sb = new StringBuilder();
        String ip = datasource.getHostIp();
        String port = String.valueOf(datasource.getPort());
        String dataBaseName = datasource.getDatabaseName();

        sb.append("jdbc:oracle:thin:@");
        sb.append(ip);
        sb.append(":");
        sb.append(port);
        sb.append("/");
        sb.append(dataBaseName);

        return sb.toString();
    }

    /**
     * 判断输入表名是大写还是小写,,,,,,判断是否全是大写
     * @param str
     */
    public Boolean judgeChar(String str) {
        //获取字符串中的字母
        str = str.replaceAll("[^a-z^A-Z]", "");
        boolean result = str.matches("[A-Z]+"); //true表示全部为大写字母
        //boolean result2 = str.matches("[a-z]+");//true表示全部为小写字母
        return result;
    }

    @Override
    public Long getTableDataRowsFromView(List<String> tableNameList) throws APIException {
        //获取到当前表的记录数
        StringBuilder sb = new StringBuilder("select t.table_name TABELNAME,t.num_rows NUMROWS from user_tables t where t.TABLE_NAME in ( ");
        tableNameList.stream().filter(Objects::nonNull).forEach(x -> sb.append("'").append(x).append("'").append(","));
        String execSql = sb.toString().substring(0, sb.toString().length() - 1).concat(" )");
        try (
                Connection con = getConnection();
                Statement ps = con.createStatement();
        ) {
            ResultSet rs = ps.executeQuery(execSql);
            List<Long> rowsList = Lists.newArrayList();
            while (rs.next()) {
                Long rows = rs.getLong("NUMROWS");
                rowsList.add(rows);
            }
            return rowsList.parallelStream().filter(Objects::nonNull).reduce(0L, Long::sum);
        } catch (Exception e) {
            LOG.error("\n[doExecute]数据库连接或查询异常,sql:{}", execSql, e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常");
        }
    }

    public List<ColumnInfo> getPrimaryKey(String dbName,String tableNameS) throws Exception {
        String doSql = getPrimaryKeyOfSql(dbName,tableNameS);
        List<ColumnInfo> list = Lists.newArrayList();
        try (Connection con = getConnection()) {
            Statement ps = con.createStatement();
            LOG.debug("\n[doExecuteBatch]Execute sql: " + doSql);
            ResultSet resultSet = ps.executeQuery(doSql);
            while (resultSet.next()) {
                String column_name = resultSet.getString("COLUMN_NAME");
                String table_name = resultSet.getString("TABLE_NAME");
                ColumnInfo column = new ColumnInfo();
                column.setColumnSource(column_name);
                column.setBelongTableName(table_name);
                list.add(column);
            }
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
        return list;
    }

    public String getPrimaryKeyOfSql(String dbName, String tableName) {
        String sql = "select * from user_cons_columns where constraint_name = (select constraint_name from user_constraints where table_name = '"+tableName+"' and constraint_type ='P')";
        return sql;
    }

    @Override
    public List<TableInfo> getTableListOnlyOracle(String tableNameLike, String owner, List<String> list, Integer taskFlag ,Pageable pageable) throws Exception {
        if (pageable == null || pageable.getPageSize() == 0 || pageable.getPageSize() > 1000) {
            pageable = PageRequest.of(0, 20);
        }
        List<TableInfo> tableInfoList = Lists.newArrayList();
        if (StringUtils.isBlank(owner)) {
            return Collections.emptyList();
        } else {
            owner = owner.toUpperCase();
        }
        StringBuilder sb = new StringBuilder("SELECT AT.TABLE_NAME,ATC.COMMENTS FROM ALL_TABLES AT\n" +
                "LEFT JOIN ALL_TAB_COMMENTS ATC ON AT.TABLE_NAME = ATC.TABLE_NAME\n" +
                "WHERE AT.OWNER = ");
        sb.append("'").append(owner).append("'")
                .append(" AND ATC.OWNER = ").append("'").append(owner).append("'");
        if (StringUtils.isNotBlank(tableNameLike)) {
            sb.append(" AND AT.TABLE_NAME LIKE ").append("'").append("%").append(tableNameLike).append("%").append("'")
                    .append(" AND ").append("ATC.TABLE_NAME LIKE ").append("'").append("%").append(tableNameLike).append("%").append("'");
        }
        if (Objects.nonNull(taskFlag) && org.apache.commons.collections4.CollectionUtils.isNotEmpty(list)) {
//            String join = Joiner.on(",").skipNulls().join(list);
            StringBuilder join = new StringBuilder();
            list.stream().filter(Objects::nonNull).forEach(x->{
                join.append("'").append(x).append("'").append(",");
            });
            String tableNames = join.toString().substring(0, join.toString().length() - 1);
            if (YesTask.equals(taskFlag)) {
                sb.append(" AND AT.TABLE_NAME IN (").append(tableNames).append(")")
                        .append(" AND ")
                        .append("ATC.TABLE_NAME IN (").append(tableNames).append(")");
            } else if (NoTask.equals(taskFlag)) {
                sb.append(" AND AT.TABLE_NAME NOT IN (").append(tableNames).append(")")
                        .append(" AND ")
                        .append("ATC.TABLE_NAME NOT IN (").append(tableNames).append(")");
            }
        }

        //对Oracle的查询SQL进行分页
        StringBuilder sb1 = new StringBuilder("SELECT P.TABLE_NAME,P.COMMENTS\n" +
                "FROM (SELECT T.*, ROWNUM RN \n" +
                "        FROM (SELECT * \n" +
                "                FROM (");
        sb1.append(sb.toString()).append(") A\n" +
                "               ORDER BY A.TABLE_NAME ASC) T\n" +
                "        WHERE ROWNUM <= ");
        int x = Math.max((pageable.getPageNumber()), 0);
        sb1.append((x * pageable.getPageSize()) + pageable.getPageSize());
        sb1.append(") P\n" +
                "WHERE RN >");
        sb1.append(x * pageable.getPageSize());

        LOG.info("【doSQL：】{}", sb1.toString());
        try (Connection con = getConnection()) {
            Statement ps = con.createStatement();
            ResultSet resultSet = ps.executeQuery(sb1.toString());
            while (resultSet.next()) {
                String comments = resultSet.getString("COMMENTS");
                String table_name = resultSet.getString("TABLE_NAME");
                TableInfo tableInfo = new TableInfo();
                tableInfo.setTableSource(table_name);
                tableInfo.setTableComment(comments);
                tableInfoList.add(tableInfo);
            }
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
        return tableInfoList;
    }

    @Override
    public long countTableListOnlyOracle(String tableNameLike, String owner, List<String> list, Integer taskFlag) throws Exception {
        if (StringUtils.isBlank(owner)) {
            return 0L;
        } else {
            owner = owner.toUpperCase();
        }
        StringBuilder sb = new StringBuilder("SELECT COUNT(1) AS COUNT FROM ALL_TABLES AT where AT.OWNER = '");
        sb.append(owner).append("'");
        if (StringUtils.isNotBlank(tableNameLike)) {
            sb.append(" AND AT.TABLE_NAME LIKE ").append("'").append("%").append(tableNameLike).append("%").append("'");
        }
        if (Objects.nonNull(taskFlag) && org.apache.commons.collections4.CollectionUtils.isNotEmpty(list)) {
//            String join = Joiner.on(",").skipNulls().join(list);
            StringBuilder join = new StringBuilder();
            list.stream().filter(Objects::nonNull).forEach(x->{
                join.append("'").append(x).append("'").append(",");
            });
            String tableNames = join.toString().substring(0, join.toString().length() - 1);
            if (YesTask.equals(taskFlag)) {
                sb.append(" AND AT.TABLE_NAME IN (").append(tableNames).append(")");
            } else if (NoTask.equals(taskFlag)) {
                sb.append(" AND AT.TABLE_NAME NOT IN (").append(tableNames).append(")");
            }
        }
        long count = 0L;
        LOG.info("【doSQL：】{}", sb.toString());
        try (Connection con = getConnection()) {
            Statement ps = con.createStatement();
            ResultSet resultSet = ps.executeQuery(sb.toString());
            while (resultSet.next()) {
                count = resultSet.getLong("COUNT");
            }
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
        return count;
    }

    @Override
    public List<TableInfo> getTableListOnlyOracleV2(String tableNameLike, String owner, List<String> list, Integer taskFlag, Pageable pageable) throws Exception {
        if (pageable == null || pageable.getPageSize() == 0 || pageable.getPageSize() > 1000) {
            pageable = PageRequest.of(0, 20);
        }
        List<TableInfo> tableInfoList = Lists.newArrayList();
        StringBuilder sb1 = new StringBuilder("SELECT ATC.TABLE_NAME, ATC.COMMENTS\n" +
                " FROM ALL_TAB_COMMENTS ATC\n" +
                " WHERE 1=1\n" +
                " AND ATC.OWNER NOT IN ('ANONYMOUS','APEX_030200','APEX_PUBLIC_USER',\n" +
                "                        'BI','DBSNMP','DIP','FLOW_FILES','HR','IX',\n" +
                "                        'MDDATA','MGMT_VIEW','OE','ORACLE_OCM','ORDDATA',\n" +
                "                        'ORDPLUGINS','OUTLN','PM','SCOTT','SH','SI_INFORMTN_SCHEMA','SPATIAL_CSW_ADMIN_USR',\n" +
                "                        'SPATIAL_WFS_ADMIN_USR','XDB','XS$NULL','WK_TEST','WKPROXY','FLOWS_FILES','DBSFWUSER',\n" +
                "                        'GSMADMIN_INTERNAL','MDSYS','CTXSYS','OLAPSYS','SYSTEM','DVSYS','AUDSYS',\n" +
                "                        'OJVMSYS','ORDSYS','APPQOSSYS','SYS','WMSYS','LBACSYS',\n" +
                "                        'OWBSYS','EXFSYS','SYSMAN')\n" +
                " AND ATC.TABLE_NAME IN (" +
                "   SELECT AT.TABLE_NAME " +
                "   FROM ALL_TABLES AT " +
                "   WHERE 1=1 " +
                "   AND AT.OWNER NOT IN ('ANONYMOUS','APEX_030200','APEX_PUBLIC_USER',\n" +
                "                        'BI','DBSNMP','DIP','FLOW_FILES','HR','IX',\n" +
                "                        'MDDATA','MGMT_VIEW','OE','ORACLE_OCM','ORDDATA',\n" +
                "                        'ORDPLUGINS','OUTLN','PM','SCOTT','SH','SI_INFORMTN_SCHEMA','SPATIAL_CSW_ADMIN_USR',\n" +
                "                        'SPATIAL_WFS_ADMIN_USR','XDB','XS$NULL','WK_TEST','WKPROXY','FLOWS_FILES','DBSFWUSER',\n" +
                "                        'GSMADMIN_INTERNAL','MDSYS','CTXSYS','OLAPSYS','SYSTEM','DVSYS','AUDSYS',\n" +
                "                        'OJVMSYS','ORDSYS','APPQOSSYS','SYS','WMSYS','LBACSYS',\n" +
                "                        'OWBSYS','EXFSYS','SYSMAN'))");

        //表的模糊查询
        if (StringUtils.isNotBlank(tableNameLike)) {
            sb1.append(" AND ATC.TABLE_NAME LIKE ").append("'").append("%").append(tableNameLike).append("%").append("'")
                    .append(" AND ").append("ATC.TABLE_NAME LIKE ").append("'").append("%").append(tableNameLike).append("%").append("'");
        }

        //同步状态查询
        if (Objects.nonNull(taskFlag) && org.apache.commons.collections4.CollectionUtils.isNotEmpty(list)) {
            StringBuilder join = new StringBuilder();
            list.stream().filter(Objects::nonNull).forEach(x -> {
                join.append("'").append(x).append("'").append(",");
            });
            String tableNames = join.toString().substring(0, join.toString().length() - 1);
            if (YesTask.equals(taskFlag)) {
                sb1.append(" AND ATC.TABLE_NAME IN (").append(tableNames).append(")");
            } else if (NoTask.equals(taskFlag)) {
                sb1.append(" AND ATC.TABLE_NAME NOT IN (").append(tableNames).append(")");
            }
        }

        //对Oracle的查询SQL进行分页
        StringBuilder sb2 = new StringBuilder("SELECT P.TABLE_NAME,P.COMMENTS\n" +
                " FROM (SELECT T.*, ROWNUM RN \n" +
                "        FROM (SELECT * \n" +
                "                FROM (");
        sb2.append(sb1.toString()).append(") A\n" +
                "               ORDER BY A.TABLE_NAME ASC) T\n" +
                "        WHERE ROWNUM <= ");
        int x = Math.max((pageable.getPageNumber()), 0);
        sb2.append((x * pageable.getPageSize()) + pageable.getPageSize());
        sb2.append(") P\n" +
                "WHERE RN >");
        sb2.append(x * pageable.getPageSize());

        // 上面这块获取SQL和执行SQL应该是要解耦的  , 这里就不做了
        LOG.info("【doSQL：】{}", sb2.toString());
        try (Connection con = getConnection()) {
            Statement ps = con.createStatement();
            ResultSet resultSet = ps.executeQuery(sb2.toString());
            while (resultSet.next()) {
                String comments = resultSet.getString("COMMENTS");
                String table_name = resultSet.getString("TABLE_NAME");
                TableInfo tableInfo = new TableInfo();
                tableInfo.setTableSource(table_name);
                tableInfo.setTableComment(comments);
                tableInfoList.add(tableInfo);
            }
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
        return tableInfoList;
    }

    @Override
    public long countTableListOnlyOracleV2(String tableNameLike, String owner, List<String> list, Integer taskFlag) throws Exception {
        StringBuilder sb1 = new StringBuilder("SELECT COUNT(1) AS COUNT\n" +
                " FROM (\n" +
                "     SELECT DISTINCT ATC.table_name, ATC.comments\n" +
                "        FROM ALL_TAB_COMMENTS ATC\n" +
                "        WHERE 1=1\n" +
                "        AND ATC.OWNER NOT IN ('ANONYMOUS','APEX_030200','APEX_PUBLIC_USER',\n" +
                "                        'BI','DBSNMP','DIP','FLOW_FILES','HR','IX',\n" +
                "                        'MDDATA','MGMT_VIEW','OE','ORACLE_OCM','ORDDATA',\n" +
                "                        'ORDPLUGINS','OUTLN','PM','SCOTT','SH','SI_INFORMTN_SCHEMA','SPATIAL_CSW_ADMIN_USR',\n" +
                "                        'SPATIAL_WFS_ADMIN_USR','XDB','XS$NULL','WK_TEST','WKPROXY','FLOWS_FILES','DBSFWUSER',\n" +
                "                        'GSMADMIN_INTERNAL','MDSYS','CTXSYS','OLAPSYS','SYSTEM','DVSYS','AUDSYS',\n" +
                "                        'OJVMSYS','ORDSYS','APPQOSSYS','SYS','WMSYS','LBACSYS',\n" +
                "                        'OWBSYS','EXFSYS','SYSMAN')\n" +
                "        AND ATC.TABLE_NAME IN (SELECT AT.TABLE_NAME FROM ALL_TABLES AT WHERE AT.OWNER NOT IN ('ANONYMOUS','APEX_030200','APEX_PUBLIC_USER',\n" +
                "                        'BI','DBSNMP','DIP','FLOW_FILES','HR','IX',\n" +
                "                        'MDDATA','MGMT_VIEW','OE','ORACLE_OCM','ORDDATA',\n" +
                "                        'ORDPLUGINS','OUTLN','PM','SCOTT','SH','SI_INFORMTN_SCHEMA','SPATIAL_CSW_ADMIN_USR',\n" +
                "                        'SPATIAL_WFS_ADMIN_USR','XDB','XS$NULL','WK_TEST','WKPROXY','FLOWS_FILES','DBSFWUSER',\n" +
                "                        'GSMADMIN_INTERNAL','MDSYS','CTXSYS','OLAPSYS','SYSTEM','DVSYS','AUDSYS',\n" +
                "                        'OJVMSYS','ORDSYS','APPQOSSYS','SYS','WMSYS','LBACSYS',\n" +
                "                        'OWBSYS','EXFSYS','SYSMAN'))");

        //表的模糊查询
        if (StringUtils.isNotBlank(tableNameLike)) {
            sb1.append(" AND ATC.TABLE_NAME LIKE ").append("'").append("%").append(tableNameLike).append("%").append("'")
                    .append(" AND ").append("ATC.TABLE_NAME LIKE ").append("'").append("%").append(tableNameLike).append("%").append("'");
        }

        //同步状态查询
        if (Objects.nonNull(taskFlag) && org.apache.commons.collections4.CollectionUtils.isNotEmpty(list)) {
            StringBuilder join = new StringBuilder();
            list.stream().filter(Objects::nonNull).forEach(x -> {
                join.append("'").append(x).append("'").append(",");
            });
            String tableNames = join.toString().substring(0, join.toString().length() - 1);
            if (YesTask.equals(taskFlag)) {
                sb1.append(" AND ATC.TABLE_NAME IN (").append(tableNames).append(")");
            } else if (NoTask.equals(taskFlag)) {
                sb1.append(" AND ATC.TABLE_NAME NOT IN (").append(tableNames).append(")");
            }
        }

        //统计语句收尾
        sb1.append(")");

        long count = 0L;
        LOG.info("【doSQL：】{}", sb1.toString());
        try (Connection con = getConnection()) {
            Statement ps = con.createStatement();
            ResultSet resultSet = ps.executeQuery(sb1.toString());
            while (resultSet.next()) {
                count = resultSet.getLong("COUNT");
            }
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
        return count;
    }

    @Override
    public List<String> getOwnerOnlyOracle() throws Exception {
        List<String> ownerList = Lists.newArrayList();
        StringBuilder sb = new StringBuilder("SELECT DISTINCT AT.OWNER AS OWNER\n" +
                " FROM ALL_TABLES AT\n" +
                " WHERE 1=1\n" +
                " AND AT.OWNER NOT IN ('ANONYMOUS','APEX_030200','APEX_PUBLIC_USER',\n" +
                "                        'BI','DBSNMP','DIP','FLOW_FILES','HR','IX',\n" +
                "                        'MDDATA','MGMT_VIEW','OE','ORACLE_OCM','ORDDATA',\n" +
                "                        'ORDPLUGINS','OUTLN','PM','SCOTT','SH','SI_INFORMTN_SCHEMA','SPATIAL_CSW_ADMIN_USR',\n" +
                "                        'SPATIAL_WFS_ADMIN_USR','XDB','XS$NULL','WK_TEST','WKPROXY','FLOWS_FILES','DBSFWUSER',\n" +
                "                        'GSMADMIN_INTERNAL','MDSYS','CTXSYS','OLAPSYS','SYSTEM','DVSYS','AUDSYS',\n" +
                "                        'OJVMSYS','ORDSYS','APPQOSSYS','SYS','WMSYS','LBACSYS',\n" +
                "                        'OWBSYS','EXFSYS','SYSMAN')");
        LOG.info("【doSQL：】{}", sb.toString());
        try (Connection con = getConnection()) {
            Statement ps = con.createStatement();
            ResultSet resultSet = ps.executeQuery(sb.toString());
            while (resultSet.next()) {
                String owner = resultSet.getString("OWNER");
                ownerList.add(owner);
            }
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
        return ownerList;
    }

    @Override
    public AggregateResultV2 queryTableDataOnlyOracle(List<String> columns, String tableName, String where, Pageable pageable, String dbName, List<String> ownerList) throws Exception {
        //获取表的字段信息
        List<ColumnInfo> columnList = Lists.newArrayList();
        if (org.apache.commons.collections4.CollectionUtils.isNotEmpty(ownerList)) {
            for (String owner : ownerList) {
                columnList = this.getColumnListOnlyOracle(tableName, owner);
                if (org.apache.commons.collections4.CollectionUtils.isNotEmpty(columnList)) {
                    break;
                }
            }
        } else {
            columnList = this.getColumnListFromView(tableName, null);
        }
        tableName = "\"" + tableName + "\"";
        LOG.info("字段信息：{}", columnList);
        //如果columns为空，则用查询出来的字段
        if (CollectionUtils.isEmpty(columns)) {
            columns = columnList.stream().map(ColumnInfo::getColumnSource).collect(Collectors.toList());
        }

        Map<@NotBlank String, ColumnInfo> columnInfoMap = columnList.stream().collect(Collectors.toMap(ColumnInfo::getColumnSource, (col) -> col));
        //根据columns，过滤，排序
        if (!CollectionUtils.isEmpty(columns)) {
            List<ColumnInfo> columnTempList = new ArrayList<>(columnList.size());
            for (String column : columns) {
                ColumnInfo columnInfo = columnInfoMap.get(column);
                if (columnInfo == null) {
                    continue;
                }

                columnTempList.add(columnInfo);
            }

            columnList = columnTempList;
        }

        List<ColumnIndex> colList = new ArrayList<>(columnList.size());
        for (ColumnInfo info : columnList) {
            ColumnIndex colIndex = new ColumnIndex();
            colIndex.setIndex(info.getColumnIndex());
            colIndex.setName(info.getColumnSource());
            colIndex.setColumnType(info.getColumnType());
            String comment = info.getColumnComment();
            //取真实的字段注释
          /*  if (StringUtils.isBlank(comment)) {
                comment = info.getColumnSource();
            }*/
            colIndex.setComment(comment);

            colList.add(colIndex);
        }

        //获取数据
        List<Map<String, String>> list = new LinkedList<>();
        if (org.apache.commons.collections4.CollectionUtils.isNotEmpty(ownerList)) {
            for (String owner : ownerList) {
                String exec = this.getQueryTableDataOnlyOracle(Joiner.on(",").skipNulls().join(columns), tableName, where, pageable, owner);
                try {
                    LOG.info(exec);
                    list = this.getDataOnlyOracle(exec, colList);
                } catch (APIException e) {
                    // 出现null，继续执行
                }
                if (org.apache.commons.collections4.CollectionUtils.isNotEmpty(list)) {
                    break;
                }
            }
        } else {
            String exec = this.getQueryTableDataSql(Joiner.on(",").skipNulls().join(columns), tableName, where, pageable);
            list = this.getDataOnlyOracle(exec, colList);
        }

        //完整结果（字段信息+表数据）
        AggregateResultV2 result = new AggregateResultV2();
        result.setData(list);
        result.setColumnList(colList);

        return result;
    }

    public List<Map<String, String>> getDataOnlyOracle(String exec, List<ColumnIndex> colList) throws APIException {
        List<Map<String, String>> list = new LinkedList<>();
        boolean isOracle = Objects.equals(this.getDatasource().getDatabaseType(), DtsConstants.DATABASE_TYPE_ORACLE);
        LOG.debug(exec);
        try (
                Connection connection = getConnection();
                Statement stat = connection.createStatement();
                ResultSet rs = stat.executeQuery(exec)
        ) {
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            while (rs.next()) {
                Map<String, String> row = new LinkedHashMap<>(columnCount);
                for (int j = 0; j < columnCount; j++) {
                    int columType = metaData.getColumnType(j + 1);
                    String value;
                    switch (columType) {
                        case Types.DATE:
                            Date date = rs.getDate(j + 1);
                            value = (date == null ? null : date.toString());
                            break;
                        default:
                            value = rs.getString(j + 1);
                            //去除ORACLE数据库TIMESTAMP的秒数据
                            if (isOracle && Objects.equals(columType, Types.TIMESTAMP) && StringUtils.isNotBlank(value)) {
                                value = value.replace(".0", "");
                            }
                            break;
                    }

                    if (j >= colList.size()) {
                        continue;
                    }
                    row.put(colList.get(j).getName(), value);
                }

                list.add(row);
            }
        } catch (Exception e) {
            LOG.error("\n[queryTableData]数据库连接或查询异常:" + e.getMessage(), e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常");
        }
        return list;
    }

}

