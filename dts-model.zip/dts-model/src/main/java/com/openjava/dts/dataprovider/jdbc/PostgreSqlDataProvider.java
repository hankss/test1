package com.openjava.dts.dataprovider.jdbc;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.openjava.dts.constants.DtsConstants;
import com.openjava.dts.constants.ExceptionConstants;
import com.openjava.dts.dataprovider.DataProvider;
import com.openjava.dts.dataprovider.DataProviderManager;
import com.openjava.dts.dataprovider.annotation.ProviderName;
import com.openjava.dts.dataprovider.result.AggregateResultV2;
import com.openjava.dts.dataprovider.result.ColumnIndex;
import com.openjava.dts.ddl.domain.DtsColumn;
import com.openjava.dts.ddl.dto.ColumnInfo;
import com.openjava.dts.ddl.dto.DatasourceInfo;
import com.openjava.dts.ddl.dto.TableInfo;
import com.openjava.dts.statistic.domain.DtsStatisticsDb;
import com.openjava.dts.statistic.domain.DtsStatisticsTable;
import com.openjava.dts.statistic.vo.PostGreSqlVo;
import com.openjava.dts.util.ColumnTypeTranslatorPostgreSql;
import com.openjava.dts.util.DtsMathUtil;
import com.openjava.dts.util.DtsStatisticsUtil;
import com.openjava.dts.util.JasyptUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.ljdp.component.exception.APIException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.sql.Types;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author: lsw
 * @Date: 2019/8/1 10:22
 */
@ProviderName(name = "postgreSql")
public class PostgreSqlDataProvider extends JdbcDataProvider {

    @Override
    public String getDriver() {
        return "org.postgresql.Driver";
    }

    private final Logger LOG = LoggerFactory.getLogger(this.getClass());


    @Override
    protected String getValidationQuery() {
        return "select 'Hello World' as hello";
    }

    @Override
    protected String getCheckTableExistSql(String tableName) {
//        tableName = StringUtils.lowerCase(tableName);
        tableName = tableName;
        return String.format("SELECT COUNT(1) FROM PG_CLASS WHERE RELNAME = '%s'", tableName);
    }

    @Override
    protected List<String> getCreateTableSqlList(String tableName, String tableComments, List<DtsColumn> columnList) {
        List<String> sqlList = new LinkedList<>();
        //表名转小写
//        tableName = StringUtils.lowerCase(tableName);
        tableName = tableName;
        for (DtsColumn column : columnList) {
//            String upperColumnSource = StringUtils.lowerCase(column.getColumnSource());
            String upperColumnSource = column.getColumnSource();
            column.setColumnSource(upperColumnSource);
        }

        //暂定都是同步到public模式下
        String schema = this.getDatasource().getSchemaName();
        if (StringUtils.isBlank(schema)) {
            schema = "public";
        }

        //建表语句
        StringBuilder createTableSql = new StringBuilder();
        createTableSql.append("CREATE TABLE \"");
        createTableSql.append(schema);
        createTableSql.append("\".");
        createTableSql.append("\"");
        createTableSql.append(tableName);
        createTableSql.append("\"");
        createTableSql.append(" ( ");

        String primary = "";
        for (DtsColumn column : columnList) {

            //给postgres中所有的字段长度为null的 字段赋一个初值
            ColumnTypeTranslatorPostgreSql.assignInitialValue(column);

            createTableSql.append("\"");
            createTableSql.append(column.getColumnSource());
            createTableSql.append("\" ");
            createTableSql.append(column.getColumnType());

            // 组装字段精确度
            Integer columnPrecision = column.getColumnPrecision();
            Integer columnScale = column.getColumnScale();
            if (columnPrecision != null && columnPrecision != 0) {
                String columnType = column.getColumnType().toLowerCase().trim();
                switch (columnType) {
                    case "bit":  // bit varbit char varchar 定义长度
                    case "varbit":
                    case "char":
                    case "varchar":
                        createTableSql.append(" (");
                        createTableSql.append(column.getColumnPrecision());
                        createTableSql.append(")");
                        break;
                    case "decimal":
                        createTableSql.append(" (");
                        createTableSql.append(column.getColumnPrecision());
                        if (columnScale != null && columnScale > 0) {
                            createTableSql.append(",");
                            createTableSql.append(columnScale);
                        }
                        createTableSql.append(")");
                        break;
                    default:
                }
            }

            createTableSql.append(",");

            if (column.getIsPrimaryKey()) {
                primary = column.getColumnSource();
            }
        }

        String tableSql0 = createTableSql.toString();
        tableSql0 = tableSql0.substring(0, tableSql0.length() - 1);
        tableSql0 += ")";

        //创建主键
        if (StringUtils.isNotBlank(primary)) {
            tableSql0 = String.format(tableSql0+ " distributed by (%s) ", primary);
        }

        sqlList.add(tableSql0);

        //表注释
        StringBuilder tableCommentsSqlSb = new StringBuilder();
        tableCommentsSqlSb.append("COMMENT ON TABLE \"");
        tableCommentsSqlSb.append(schema);
        tableCommentsSqlSb.append("\".\"");
        tableCommentsSqlSb.append(tableName);
        tableCommentsSqlSb.append("\" IS '");
        tableCommentsSqlSb.append(tableComments);
        tableCommentsSqlSb.append("'");
        sqlList.add(tableCommentsSqlSb.toString());

        //字段注释
        for (DtsColumn column : columnList) {
            StringBuilder commentSql = new StringBuilder();
            commentSql.append(" COMMENT ON COLUMN \"");
            commentSql.append(schema);
            commentSql.append("\".\"");
            commentSql.append(tableName);
            commentSql.append("\".\"");
            commentSql.append(column.getColumnSource());
            commentSql.append("\" IS '");
            commentSql.append(StringUtils.isNotEmpty(column.getColumnComment()) ? column.getColumnComment() : "");
            commentSql.append("'");

            sqlList.add(commentSql.toString());
        }

        //创建主键
        if (StringUtils.isNotBlank(primary)) {
            String createPrimaryKeySql = String.format("alter table \"%s\".\"%s\" add primary key (\"%s\")", schema, tableName, primary);
            sqlList.add(createPrimaryKeySql);
        }

        return sqlList;
    }

    @Override
    public List<String> getUpdateTableSqlList(String tableName, String tableComments, List<DtsColumn> columnList) {
        List<String> sqlList = new LinkedList<>();
        //表名转小写
//        tableName = StringUtils.lowerCase(tableName);
        tableName = tableName;
        for (DtsColumn column : columnList) {
//            String upperColumnSource = StringUtils.lowerCase(column.getColumnSource());
            String upperColumnSource = column.getColumnSource();
            column.setColumnSource(upperColumnSource);
        }
        //暂定都是同步到public模式下
        String schema = this.getDatasource().getSchemaName();
        if (StringUtils.isBlank(schema)) {
            schema = "public";
        }
        String primary = "";
        //表注释
        StringBuilder tableCommentsSqlSb = new StringBuilder();
        tableCommentsSqlSb.append("COMMENT ON TABLE \"");
        tableCommentsSqlSb.append(schema);
        tableCommentsSqlSb.append("\".\"");
        tableCommentsSqlSb.append(tableName);
        tableCommentsSqlSb.append("\" IS '");
        tableCommentsSqlSb.append(tableComments);
        tableCommentsSqlSb.append("'");
        sqlList.add(tableCommentsSqlSb.toString());

        //字段注释
        for (DtsColumn column : columnList) {
            StringBuilder commentSql = new StringBuilder();
            commentSql.append(" COMMENT ON COLUMN \"");
            commentSql.append(schema);
            commentSql.append("\".\"");
            commentSql.append(tableName);
            commentSql.append("\".\"");
            commentSql.append(column.getColumnSource());
            commentSql.append("\" IS '");
            commentSql.append(StringUtils.isNotEmpty(column.getColumnComment()) ? column.getColumnComment() : "");
            commentSql.append("'");
            sqlList.add(commentSql.toString());
        }
        return sqlList;
    }

    @Override
    public List<String> addTableColumnSqlList(String tableName, String tableComments, List<DtsColumn> columnList) {
        //这里走一条语句,就执行一次SQL
        if (CollectionUtils.isEmpty(columnList)) {
            return Collections.emptyList();
        }
        List<String> addTableSqlList = Lists.newArrayList();
        for (DtsColumn c : columnList) {
            StringBuilder sb = new StringBuilder("ALTER TABLE "); //注意空格
            sb.append("\""+tableName+"\"");
            sb.append(" add COLUMN ");
            sb.append(c.getColumnSource());
            sb.append(" ");
            sb.append(c.getColumnType());
            addTableSqlList.add(sb.toString());
        }
        return addTableSqlList;
    }

    @Override
    public List<String> deleteTableColumnSqlList(String tableName, String tableComments, List<DtsColumn> columnList) {
        //这里走一条语句,就执行一次SQL
        if (CollectionUtils.isEmpty(columnList)) {
            return Collections.emptyList();
        }
        List<String> deleteTableSqlList = Lists.newArrayList();
        for (DtsColumn c : columnList) {
            StringBuilder sb = new StringBuilder("ALTER TABLE "); //注意空格
            sb.append("\""+tableName+"\"");
            sb.append(" drop COLUMN ");
            sb.append(c.getColumnSource());
            deleteTableSqlList.add(sb.toString());
        }
        return deleteTableSqlList;
    }

    @Override
    public String getTotalNumberByTableNameSql(String tableName) throws Exception {
        StringBuilder sb = new StringBuilder("SELECT COUNT(*) record FROM ");//注意空格
        //pg的表名加上双引号，如果表名是数字开头，不加双引号就会有问题
        sb.append("\"");
        sb.append(tableName);
        sb.append("\"");
        return sb.toString();
    }

    @Override
    public String getQueryTableDataSql(String columns, String tableName, String where, Pageable pageable) {

        if (pageable == null || pageable.getPageSize() == 0 || pageable.getPageSize() > 1000)
            pageable = PageRequest.of(0, 30);

        StringBuilder sb = new StringBuilder();
        sb.append("select ");
        if (StringUtils.isNotBlank(columns)) {
            String noSpaceColumns = columns.replace(" ", "");
            String[] columnArray = noSpaceColumns.split(",");
            List<String> colList = new ArrayList<>(columnArray.length);
            for (String col : columnArray) {
                colList.add("\"" + col + "\"");
            }
            sb.append(StringUtils.join(colList, ","));
        } else {
            sb.append("*");
        }
        sb.append(" from \"");
        sb.append(tableName);
        sb.append("\"");
        if (StringUtils.isNotBlank(where)) {
            sb.append(" where ");
            sb.append(where);
        }
        //添加一个排序
        if (StringUtils.isNotBlank(columns)) {
            if (columns.contains(",")) {
                StringBuilder sb2 = new StringBuilder();
                Arrays.stream(columns.split(",")).filter(Objects::nonNull).forEach(x -> {
                    sb2.append("\"").append(x).append("\"").append(",");
                });
                columns = sb2.toString().substring(0, sb2.toString().length() - 1);
            }
            sb.append(" order by ")
                    .append(columns)
                    .append(" asc ");
        }
        if (pageable != null && pageable.getPageSize() != 0) {
            sb.append(" limit ");
            sb.append(pageable.getPageSize());
            sb.append(" offset ");
            sb.append(pageable.getOffset());
        } else {
            sb.append(" limit 30 ");
        }

        return sb.toString();
    }

    @Override
    public String getPrimaryKeyOfSql(String tableNameS) {
        //1.tableNameS进来之后，将每一个表名加上单引号
        String[] split = tableNameS.split(",");
        StringBuilder sb1 = new StringBuilder("(");
        for (String s : split) {
            sb1.append("'");
            sb1.append(s);
            sb1.append("'");
            sb1.append(",");
        }
        //会多一个逗号 ('tableName1','tableName2',
        String substring = sb1.toString().substring(0, sb1.toString().length() - 1);
        StringBuilder sb2 = new StringBuilder(substring);
        sb2.append(")");

        StringBuilder sb = new StringBuilder("select pg_constraint.conname as pk_name,\n" +
                "pg_attribute.attname as colname,\n" +
                "pg_type.typname as typename \n" +
                "from pg_constraint \n" +
                "inner join pg_class on pg_constraint.conrelid = pg_class.oid \n" +
                "inner join pg_attribute on pg_attribute.attrelid = pg_class.oid \n" +
                "and pg_attribute.attnum = pg_constraint.conkey[1]\n" +
                "inner join pg_type on pg_type.oid = pg_attribute.atttypid\n" +
                "and pg_constraint.contype='p'\n" +
                "where pg_class.relname IN ");
        return sb.append(sb2.toString()).toString();
    }

    @Override
    public List<ColumnInfo> getPrimaryKey(String tableNameS) throws Exception {
        String doSql = this.getPrimaryKeyOfSql(tableNameS);

        List<ColumnInfo> list = Lists.newArrayList();
        try (Connection con = getConnection()) {
            Statement ps = con.createStatement();
            LOG.debug("\n[doExecuteBatch]Execute sql: " + doSql);
            ResultSet resultSet = ps.executeQuery(doSql);
            while (resultSet.next()) {
                //字段名字
                String column_name = resultSet.getString("colname");
                //表名字
                String table_name = resultSet.getString("pk_name");
                //字典类型
                String typename = resultSet.getString("typename");
                ColumnInfo column = new ColumnInfo();
                column.setColumnSource(column_name);
                column.setColumnType(typename);
                column.setBelongTableName(table_name);
                list.add(column);
            }
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
        return list;
    }

    @Override
    public String getBatchTableColumnListSql(String tableNameS) throws Exception {
        //mysql中可以直接从INFORMATION_SCHEMA.COLUMNS一次获取到多张表的字段信息，走一次IO操作
        //1.tableNameS进来之后，将每一个表名加上单引号
        String[] split = tableNameS.split(",");
        StringBuilder sb1 = new StringBuilder("(");
        for (String s : split) {
            sb1.append("'");
            sb1.append(s);
            sb1.append("'");
            sb1.append(",");
        }
        //会多一个逗号 ('tableName1','tableName2',
        String substring = sb1.toString().substring(0, sb1.toString().length() - 1);
        StringBuilder sb2 = new StringBuilder(substring);
        sb2.append(")");

        StringBuilder sb = new StringBuilder("SELECT col_description(a.attrelid,a.attnum) \n" +
                "as comment,\n" +
                "pg_type.typname as typename,\n" +
                "a.attname as name, \n" +
                "a.attnotnull as notnull,\n" +
                "relname as tablename\n" +
                "FROM pg_class as c,pg_attribute as a \n" +
                "inner join pg_type on pg_type.oid = a.atttypid\n" +
                "where a.attrelid = c.oid and a.attnum>0 and c.relname in ");
        sb.append(sb2.toString());
        return sb.toString();
    }

    @Override
    public List<ColumnInfo> getBatchTableColumnList(String tableNameS) throws Exception {
        //获取表的字段信息,从视图获取
        String doSql = getPrimaryKeyOfSql(tableNameS);
        List<ColumnInfo> list = Lists.newArrayList();
        try (Connection con = getConnection()) {
            Statement ps = con.createStatement();
            LOG.debug("\n[doExecuteBatch]Execute sql: " + doSql);
            ResultSet resultSet = ps.executeQuery(doSql);
            while (resultSet.next()) {
                //字段名字
                String column_name = resultSet.getString("name");
                //字段类型
                String data_type = resultSet.getString("typename");
                //字段是否为null
                String is_nullable = resultSet.getString("notnull");
                //字段备注
                String column_comment = resultSet.getString("comment");
                //表名字
                String table_name = resultSet.getString("tablename");

                ColumnInfo column = new ColumnInfo();
                column.setColumnSource(column_name);
                column.setColumnType(data_type);
                //f字段是null,t字段不能为null
                column.setNullable(Objects.equals(is_nullable, "f"));
                column.setColumnComment(column_comment);
                column.setBelongTableName(table_name);
                list.add(column);
            }
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
        return list;
    }

    @Override
    public String getBatchTableCommentListSql(String tableNameS) throws Exception {
        //mysql中可以直接从INFORMATION_SCHEMA.COLUMNS一次获取到多张表的字段信息，走一次IO操作
        //1.tableNameS进来之后，将每一个表名加上单引号
        String[] split = tableNameS.split(",");
        StringBuilder sb1 = new StringBuilder("(");
        for (String s : split) {
            sb1.append("'");
            sb1.append(s);
            sb1.append("'");
            sb1.append(",");
        }
        //会多一个逗号 ('tableName1','tableName2',
        String substring = sb1.toString().substring(0, sb1.toString().length() - 1);
        StringBuilder sb2 = new StringBuilder(substring);
        sb2.append(")");

        StringBuilder sb = new StringBuilder("select relname as tablename,\n" +
                "cast(obj_description(relfilenode,'pg_class') as varchar) as comment \n" +
                "from pg_class c \n" +
                "where relname in ");
        sb.append(sb2.toString());
        return sb.toString();
    }

    @Override
    public List<TableInfo> getBatchTableCommentList(String tableNameS) throws Exception {
        //获取表的字段信息,从视图获取
        String doSql = getPrimaryKeyOfSql(tableNameS);
        List<TableInfo> list = Lists.newArrayList();
        try (Connection con = getConnection()) {
            Statement ps = con.createStatement();
            LOG.debug("\n[doExecuteBatch]Execute sql: " + doSql);
            ResultSet resultSet = ps.executeQuery(doSql);
            while (resultSet.next()) {
                //表注释TABLE_COMMENT
                String table_comment = resultSet.getString("comment");
                //表名字
                String table_name = resultSet.getString("tablename");

                TableInfo tableInfo = new TableInfo();
                tableInfo.setTableSource(table_name);
                tableInfo.setTableComment(table_comment);
                list.add(tableInfo);
            }
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
        return list;
    }

    @Override
    public List<String> getAllTableName() throws Exception {
        String sql = "select relname as tablename from pg_class c where  relkind = 'r' and relname not like 'pg_%' and relname not like 'sql_%' order by relname";
        //获取表的字段信息,从视图获取
        List<String> list = Lists.newArrayList();
        try (Connection con = getConnection()) {
            Statement ps = con.createStatement();
            LOG.debug("\n[doExecuteBatch]Execute sql: " + sql);
            ResultSet resultSet = ps.executeQuery(sql);
            while (resultSet.next()) {
                //表注释TABLE_COMMENT
                String tableName = resultSet.getString("tablename");
                list.add(tableName);
            }
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
        return list;
    }


    @Override
    protected String getQueryAllColumnSql() {
        return " SELECT C.relname,A.attname AS NAME " +
                " FROM pg_class AS C,pg_attribute AS A " +
                " WHERE A.attrelid = C.oid AND A.attnum >0 AND C.relkind='r'";
    }

    @Override
    protected String getDropTableSql(String tableName) {
        return "DROP TABLE IF EXISTS \"" + tableName + "\"";
    }

    /**
     * 复制表结构
     *
     * @param tarTableName
     * @param srcTableName
     * @return
     */
    @Override
    public boolean copyTableStructure(String tarTableName, String srcTableName) throws Exception {
        String sql = "create table \"" + tarTableName + "\" (like \"" + srcTableName + "\")";
        return doExecute(sql);
    }

    /**
     * 重命名表
     *
     * @param newTableName
     * @param srcTableName
     * @return
     */
    @Override
    public boolean renameTable(String newTableName, String srcTableName) throws Exception {
        String sql = "alter table " + srcTableName + " rename to " + newTableName;
        return doExecute(sql);
    }

    @Override
    public void dealCreateTableColumn(DtsColumn column) {
        if (column == null || StringUtils.isBlank(column.getColumnType())) {
            return;
        }

        //处理oracle默认nubmer时的情况，字段精度为0，小数位为-127
        if (Objects.equals(ColumnTypeTranslatorPostgreSql.PG_NUMBERIC, column.getColumnType())) {
            if (column.getColumnPrecision() != null && column.getColumnScale() != null) {
                if (column.getColumnPrecision() == 0 && column.getColumnScale() == -127) {
                    //对应MPP的精度跟小数位，多少合适
//                    column.setColumnPrecision(38);
//                    column.setColumnScale(127);
                    //PG的decimal是变长的，先注释掉精度跟小数位试下
                }
            }
        }
    }

    /**
     * 根据表名取得单个表表信息,数据行数,占用空间等 --hl
     * @param tableName
     * @return
     */
    @Override
    public DtsStatisticsTable getDtsStatisticsTable(String tableName) throws Exception {
        try {
            DtsStatisticsTable dtsStatisticsTable = new DtsStatisticsTable();
            dtsStatisticsTable.setTableName(tableName);Double rows = 0.0;
            String sql_count = "select relname,reltuples from pg_class where relkind = 'r' and relname='" + tableName + "'";
            Map<String, Object> sqlCountRe = queryForMap(sql_count);
            if (sqlCountRe != null) {
                double rowcounts = Double.parseDouble(sqlCountRe.get("reltuples").toString());
                if (rowcounts == 0)
                    dtsStatisticsTable.setRows(0.0);
                else
                    dtsStatisticsTable.setRows(DtsMathUtil.getRoundHalfUpDouble(rowcounts / 10000));
            } else {
                LOG.error("--------->pg没此表记录,表:{},查询sql:{}", tableName,sql_count);
                return null;
            }
            rows = dtsStatisticsTable.getRows();
            Double allSpace = 0.00;
            if (rows.doubleValue() > 0.1) {
                String allSpaceSql = "SELECT table_schema || '.' || table_name AS table_full_name,table_name,pg_size_pretty(pg_total_relation_size('\"' || table_schema || '\".\"' || table_name || '\"')) AS size " +
                        "FROM information_schema.tables where table_name = '" + tableName + "'";
                Map<String, Object> allSpaceSqlRe = queryForMap(allSpaceSql);
                if (allSpaceSqlRe != null) {
                    double d = DtsMathUtil.getGBfromPgSize((String) allSpaceSqlRe.get("size"));
                    dtsStatisticsTable.setAllSpace(d);
                }else
                    LOG.error("--------->pg没此表空间大小等记录,表:{},查询sql:{}", tableName,allSpaceSql);
            } else if (rows.doubleValue() == 0) {
                allSpace = 0.00;
                dtsStatisticsTable.setAllSpace(DtsMathUtil.getRoundHalfUpDouble(allSpace));
            } else {
                allSpace = 0.01;
                dtsStatisticsTable.setAllSpace(DtsMathUtil.getRoundHalfUpDouble(allSpace));
            }
            return dtsStatisticsTable;
        }catch (Exception e){
            LOG.error("PG取得表:{}信息异常",tableName,e);
            return null;
        }
    }

    /**
     * 取得所有表的信息返回
     * @return
     */
    @Override
    public List<DtsStatisticsTable> getDtsStatisticsTableList() throws Exception {
        try {
            DatasourceInfo datasourceInfo = this.getDatasource();
            PostGreSqlVo db = DtsStatisticsUtil.getPgShema(JasyptUtil.decyptText(datasourceInfo.getJdbcUrl()));
            List<DtsStatisticsTable> dtsStatisticsTableList = new LinkedList<>();
            String sql = "SELECT pg_class.reltuples,table_schema,table_schema || '.' || table_name AS table_full_name,table_name,pg_size_pretty(pg_total_relation_size('\"' || table_schema || '\".\"' || table_name || '\"')) AS size";
            sql += " FROM information_schema.tables left join pg_class on information_schema.tables.TABLE_NAME = pg_class.relname where pg_class.relkind ='r' ";
            sql += " and table_schema != 'pg_catalog' and table_schema != 'information_schema' ";//测出来的细节
            if(db !=null && StringUtils.isNotBlank(db.getDbName()))
                sql += " and table_catalog = '"+db.getDbName()+"'";
            if(db !=null && StringUtils.isNotBlank(db.getSchema()))
                sql += " and table_schema = '"+db.getSchema()+"'";
            List<Map<String,Object>> list = this.queryForList(sql);
            if (!list.isEmpty() && list.size() > 0) {
                for(Map map:list){
                    DtsStatisticsTable table = DtsStatisticsUtil.getPostgresqlStatisticsTable(map);
                    if(table != null)
                        dtsStatisticsTableList.add(table);
                }
            }
            return dtsStatisticsTableList;
        }catch (Exception e) {
            LOG.error("\n[PGSQL getDtsStatisticsTableList]数据库连接或查询异常:" + e.getMessage(), e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, ExceptionConstants.EXCEPTION_ERROR_MSG + "数据库连接或查询异常:" + e.getMessage());
        }
    }

    /**
     * 取得整个数据源的信息
     *
     * @param DtsStatisticsTableList
     * @return
     */
    @Override
    public DtsStatisticsDb getDtsStatisticsDb(List<DtsStatisticsTable> DtsStatisticsTableList) {
        //子类重写
        return null;
    }

    /**
     * 取得整个数据源的信息
     *
     * @return
     */
    @Override
    public DtsStatisticsDb getDtsStatisticsDb() throws Exception {
        //子类重写
        DataProvider dataProvider = DataProviderManager.getDataProvider(datasource, true);
        return dataProvider.getDtsStatisticsDb();
    }

    @Override
    public String getConnectUrl() {
        // jdbc:postgresql://19.104.59.17:25308/ioc_resourcedirect
        StringBuilder sb = new StringBuilder();
        String ip = datasource.getHostIp();
        String port = String.valueOf(datasource.getPort());
        String dataBaseName = datasource.getDatabaseName();
        String schema = StringUtils.isNotBlank(datasource.getSchemaName()) ? datasource.getSchemaName() : "public";

        sb.append("jdbc:postgresql://");
        sb.append(ip);
        sb.append(":");
        sb.append(port);
        sb.append("/");
        sb.append(dataBaseName);
        sb.append("?searchpath=");//?currentSchema=
        sb.append(schema);

        return sb.toString();
    }

    /**
     * 归集库中的表,增加表字段
     *
     * @param tableName
     * @param columnList
     */
    @Override
    public boolean addTableColumn(String tableName, List<ColumnInfo> columnList) throws APIException{
        StringBuilder sb = new StringBuilder("ALTER TABLE "+tableName+" ADD COLUMN "); //注意空格
        columnList.forEach(c ->{
            sb.append(c.getColumnSource());
            try {
                doExecute(sb.toString());
                System.out.println(sb.toString());
            } catch (Exception e) {
                LOG.error("\n[PGSQL addTableColumn]SQL执行异常:" + e.getMessage(), e);
                e.printStackTrace();
            }
        });
        return true;
    }

    @Override
    public boolean truncateTable(String tableName) throws Exception {
        if(checkTableExist(tableName))
            return doExecute("truncate table " + "\"" + tableName + "\"");
        return true;
    }

    @Override
    public AggregateResultV2 queryTableDataV2FromView(List<String> columns, String tableName, String where, Pageable pageable, String dbName) throws Exception {
        //获取表的字段信息
        List<ColumnInfo> columnList = this.getColumnListFromView(tableName, null);
        //如果columns为空，则用查询出来的字段
        if (org.springframework.util.CollectionUtils.isEmpty(columns)) {
            columns = columnList.stream().map(ColumnInfo::getColumnSource).collect(Collectors.toList());
        }
        Map<String, ColumnInfo> columnInfoMap = Maps.newHashMap();
        for (ColumnInfo c : columnList) {
            columnInfoMap.put(c.getColumnSource(), c);
        }
        //根据columns，过滤，排序
        if (!org.springframework.util.CollectionUtils.isEmpty(columns)) {
            List<ColumnInfo> columnTempList = new ArrayList<>(columnList.size());
            for (String column : columns) {
                ColumnInfo columnInfo = columnInfoMap.get(column);
                if (columnInfo == null) {
                    continue;
                }
                columnTempList.add(columnInfo);
            }
            columnList = columnTempList;
        }
        List<ColumnIndex> colList = new ArrayList<>(columnList.size());
        for (ColumnInfo info : columnList) {
            ColumnIndex colIndex = new ColumnIndex();
            colIndex.setIndex(info.getColumnIndex());
            colIndex.setName(info.getColumnSource());
            String comment = info.getColumnComment();
            //取真实注释
//            if (StringUtils.isBlank(comment)) {
//                comment = info.getColumnComment();
//            }
            colIndex.setComment(comment);
            colIndex.setColumnType(info.getColumnType());
            colList.add(colIndex);
        }

        //获取数据
        String exec = this.getQueryTableDataSql(Joiner.on(",").skipNulls().join(columns), tableName, where, pageable);
        List<Map<String, String>> list = new LinkedList<>();
        boolean isOracle = Objects.equals(this.getDatasource().getDatabaseType(), DtsConstants.DATABASE_TYPE_ORACLE);
        LOG.debug(exec);
        try (
                Connection connection = getConnection();
                Statement stat = connection.createStatement();
                ResultSet rs = stat.executeQuery(exec)
        ) {
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            while (rs.next()) {
                Map<String, String> row = new LinkedHashMap<>(columnCount);
                for (int j = 0; j < columnCount; j++) {
                    int columType = metaData.getColumnType(j + 1);
                    String value;
                    switch (columType) {
                        case Types.DATE:
                            Date date = rs.getDate(j + 1);
                            value = (date == null? null : date.toString());
                            break;
                        default:
                            value = rs.getString(j + 1);
                            //去除ORACLE数据库TIMESTAMP的秒数据
                            if (isOracle && Objects.equals(columType, Types.TIMESTAMP) && StringUtils.isNotBlank(value)) {
                                value = value.replace(".0", "");
                            }
                            break;
                    }

                    if (j >= colList.size()) {
                        continue;
                    }
                    row.put(colList.get(j).getName(), value);
                }

                list.add(row);
            }
        } catch (Exception e) {
            LOG.error("\n[queryTableData]数据库连接或查询异常:" + e.getMessage(),e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常");
        }

        //完整结果（字段信息+表数据）
        AggregateResultV2 result = new AggregateResultV2();
        result.setData(list);
        result.setColumnList(colList);

        return result;
    }

    /**
     * 获取字段信息，从视图中获取,这个是按照 pg做的
     * 对 gp ,可能存在兼容性问题
     *
     * @param tableName
     * @return
     * @throws Exception
     */
    @Override
    public List<ColumnInfo> getColumnListFromView(String tableName, String db_name) throws Exception {
        //字段名字，字段注释，字段类型，长度，精度，是否为null，字段位置，所属表名，是否是主键(这个另外的一条io做)
        StringBuilder sb = new StringBuilder("SELECT col_description(a.attrelid,a.attnum) as comment,\n" +
                "format_type(a.atttypid,a.atttypmod) as type,\n" +
                "a.attname as name, \n" +
                "a.attnotnull as notnull,\n" +
                "c.relname as table_name,\n" +
                "a.attnotnull as is_null,\n" +
                "a.attnum as position,\n" +
                "c.relhaspkey as primaryKey\n" +
                "FROM pg_class as c,pg_attribute as a\n" +
                "where a.attrelid = c.oid and a.attnum>0 and c.relname = ' ");
        sb.append(tableName).append("'");

        //执行的sql
        String doSql = sb.toString();
        List<ColumnInfo> list = Lists.newArrayList();
        try (Connection con = getConnection()) {
            Statement ps = con.createStatement();
            LOG.debug("\n[doExecuteBatch]Execute sql: " + doSql);
            ResultSet resultSet = ps.executeQuery(doSql);
            while (resultSet.next()) {
                //所属数据表名
                String belongTableName = resultSet.getString("table_name");
                //字段名
                String columnName = resultSet.getString("name");
                //字段注释
                String columnComment = resultSet.getString("comment");
                //对应typesSql的值
                String columnType = resultSet.getString("type");
                //字段长度
//                int precision = resultSet.getInt("CHARACTER_OCTET_LENGTH");
//                //精度
//                int scale = resultSet.getInt("NUMERIC_SCALE");
                //是否为空：N就表示Not Null，Y表示可以是Null
                String nullable = resultSet.getString("is_null");
                //字段索引定位：从1开始
                int position = resultSet.getInt("position");
                //是否是主键
                String isPrimary = resultSet.getString("primaryKey");

                ColumnInfo column = new ColumnInfo();
                column.setColumnSource(columnName);
                column.setColumnComment(columnComment);
                column.setColumnType(columnType);
//                column.setColumnPrecision(precision);
//                column.setColumnScale(scale);
                column.setColumnIndex(position);
                column.setNullable("YES".equals(nullable));
                column.setBelongTableName(belongTableName);
                column.setIsPrimaryKey("PRI".equals(isPrimary));
                list.add(column);
            }
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
        return list;
    }

}