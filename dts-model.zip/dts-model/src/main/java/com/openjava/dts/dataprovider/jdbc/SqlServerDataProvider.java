package com.openjava.dts.dataprovider.jdbc;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.openjava.dts.constants.DtsConstants;
import com.openjava.dts.constants.ExceptionConstants;
import com.openjava.dts.dataprovider.annotation.ProviderName;
import com.openjava.dts.dataprovider.result.AggregateResultV2;
import com.openjava.dts.dataprovider.result.ColumnIndex;
import com.openjava.dts.ddl.domain.DtsColumn;
import com.openjava.dts.ddl.dto.ColumnInfo;
import com.openjava.dts.ddl.dto.TableInfo;
import com.openjava.dts.util.EnumUtil;
import com.openjava.dts.util.column.JavaSqlTypeEnum;
import org.apache.commons.lang3.StringUtils;
import org.ljdp.component.exception.APIException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.util.CollectionUtils;

import javax.validation.constraints.NotBlank;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author: lsw
 * @Date: 2019/9/18 9:18
 */
@ProviderName(name = "sqlserver")
public class SqlServerDataProvider extends JdbcDataProvider {
    private static final Logger LOG = LoggerFactory.getLogger(SqlServerDataProvider.class);

    @Override
    public String getDriver() {
        return "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    }

    @Override
    protected String getValidationQuery() {
        return "select 1";
    }

    @Override
    protected List<String> getCreateTableSqlList(String tableName, String tableComments, List<DtsColumn> columnList) {
        //TODO ...
        return Collections.emptyList();
    }

    @Override
    protected String getCheckTableExistSql(String tableName) {
        return String.format("IF objectproperty(object_id('%s'), 'IsUserTable') = 1 SELECT 1 ELSE SELECT 0", tableName);
    }

    /**
     * 复制表结构
     *
     * @param tarTableName
     * @param srcTableName
     * @return
     */
    @Override
    public boolean copyTableStructure(String tarTableName, String srcTableName) {
        //TODO 目前没有对接SqlServer
        return false;
    }

    /**
     * 重命名表
     *
     * @param newTableName
     * @param srcTableName
     * @return
     */
    @Override
    public boolean renameTable(String newTableName, String srcTableName) {
        //TODO 目前没有对接SqlServer
        return false;
    }

    @Override
    protected String getQueryTableDataSql(String columns, String tableName, String where, Pageable pageable) {

        if(pageable ==null || pageable.getPageSize() == 0 || pageable.getPageSize() > 1000)
            pageable = PageRequest.of(0, 30);

        //Sqlserver 1.如果表名中出现了 "-" 表名要加 ""
        //2. SQLserver的行排序是从0开始的

        if(StringUtils.isBlank(columns))
            return null;
        String[] fArr = columns.split(",");
        String whereCon = "";
        if (StringUtils.isNotBlank(where)) {
            whereCon = " and "+ where;
        }
        String sql = "select top "+pageable.getPageSize()+" "+columns+" from (select row_number() over(order by "+fArr[0]+" asc) as rownumber,* from \""+tableName+"\") t where 1=1 "+whereCon+" and rownumber>(("+pageable.getPageNumber()+"-1)*"+pageable.getPageSize()+");";
        return sql;


        /**
        StringBuilder sb = new StringBuilder();
        sb.append(" select ");
        if (StringUtils.isNotBlank(columns)) {
            sb.append(columns);
        } else {
            sb.append(" * ");
        }
        //这里给表名加上双引号
        sb.append(" from ").append("\"");
        sb.append(tableName).append("\"");
//        sb.append(") t_n) t_n2 where t_n2.rowno between ");
        sb.append(" t ");
        if (StringUtils.isNotBlank(where)) {
            sb.append(" where ");
            sb.append(where);
        }
        sb.append(" order by ").append(columns);
        sb.append(" Offset  ");
        //这里从 0 开始
//        sb.append(pageable.getOffset() + 1);
        sb.append(pageable.getOffset());
        sb.append(" Row Fetch Next ");
        sb.append(pageable.getOffset() + pageable.getPageSize());
        sb.append(" Rows Only ");
        return sb.toString();
         **/
    }

    protected String getQueryTableDataSqlV2(List<String> columns ,Integer position, String tableName, String where, Pageable pageable) {
        //Sqlserver 1.如果表名中出现了 "-" 表名要加 ""
        //2. SQLserver的行排序是从0开始的
        //3. SQLserver 这里还有一个查询的问题是 字段中如果出现无效的 字段, 例如: weight 加上[] 也没有用 ,就很奇怪
        //4. 将查询字段换成 * , order by 换成一个字段, columns必须是有值的
        if (CollectionUtils.isEmpty(columns)) {
            return null;
        }
        String whereCon = "";
        if (StringUtils.isNotBlank(where)) {
            whereCon = " and "+ where;
        }
        String sql = "select top "+pageable.getPageSize()+" * from (select row_number() over(order by "+columns.get(0)+" asc) as rownumber,* from "+tableName+") t where 1=1 "+whereCon+" and rownumber>(("+pageable.getPageNumber()+"-1)*"+pageable.getPageSize()+");";
        return sql;
        /**
        sb.append(" select ");
        sb.append(" * ");
        //这里给表名加上双引号
        sb.append(" from ").append("\"");
        sb.append(tableName).append("\"");
        sb.append(" t ");
        if (StringUtils.isNotBlank(where)) {
            sb.append(" where ");
            sb.append(where);
        }
        sb.append(" order by ").append(columns.get(null == position ? 0 : position));
        sb.append(" Offset  ");
        //这里从 0 开始
        sb.append(pageable.getOffset());
        sb.append(" Row Fetch Next ");
        sb.append(pageable.getOffset() + pageable.getPageSize()-1);
        sb.append(" Rows Only ");
         return sb.toString();
         **/

        /**
         select top pageSize *
          from (select row_number()
          over(order by sno asc) as rownumber,*
          from student) temp_row
          where rownumber>((pageIndex-1)*pageSize);
         */
    }

    @Override
    public AggregateResultV2 queryTableDataV2(List<String> columns, String tableName, String where, Pageable pageable) throws Exception {
        //获取表的字段信息
        List<ColumnInfo> columnList = this.getColumnList(tableName);
        //如果columns为空，则用查询出来的字段
        if (CollectionUtils.isEmpty(columns)) {
            columns = columnList.stream().map(ColumnInfo::getColumnSource).collect(Collectors.toList());
        }

        Map<@NotBlank String, ColumnInfo> columnInfoMap = columnList.stream().collect(Collectors.toMap(ColumnInfo::getColumnSource, (col) -> col));
        //根据columns，过滤，排序
        if (!CollectionUtils.isEmpty(columns)) {
            List<ColumnInfo> columnTempList = new ArrayList<>(columnList.size());
            for (String column : columns) {
                ColumnInfo columnInfo = columnInfoMap.get(column);
                if (columnInfo == null) {
                    continue;
                }

                columnTempList.add(columnInfo);
            }

            columnList = columnTempList;
        }

        List<ColumnIndex> colList = new ArrayList<>(columnList.size());
        for (ColumnInfo info : columnList) {
            ColumnIndex colIndex = new ColumnIndex();
            colIndex.setIndex(info.getColumnIndex());
            colIndex.setName(this.removeN(info.getColumnSource()));
            String comment = info.getColumnComment();
            if (StringUtils.isBlank(comment)) {
                comment = this.removeN(info.getColumnSource());
            }
            colIndex.setComment(comment);
            colIndex.setColumnType(info.getColumnType());
            colList.add(colIndex);
        }

        //获取数据
       /* String exec = this.getQueryTableDataSql(Joiner.on(",").skipNulls().join(columns), tableName, where, pageable);
        LOG.info("[doSql :]{}", exec);
        List<Map<String, String>> list = new LinkedList<>();
        boolean isOracle = Objects.equals(this.getDatasource().getDatabaseType(), DtsConstants.DATABASE_TYPE_ORACLE);
        LOG.debug(exec);
        try (
                Connection connection = getConnection();
                PreparedStatement stat = connection.prepareStatement(exec);
                ResultSet rs = stat.executeQuery()
        ) {
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            while (rs.next()) {
                Map<String, String> row = new LinkedHashMap<>(columnCount);
                for (int j = 0; j < columnCount; j++) {
                    int columType = metaData.getColumnType(j + 1);
                    String value;
                    switch (columType) {
                        case Types.DATE:
                            java.sql.Date date = rs.getDate(j + 1);
                            value = (date == null ? null : date.toString());
                            break;
                        default:
                            value = rs.getString(j + 1);
                            //去除ORACLE数据库TIMESTAMP的秒数据
                            if (isOracle && Objects.equals(columType, Types.TIMESTAMP) && StringUtils.isNotBlank(value)) {
                                value = value.replace(".0", "");
                            }
                            break;
                    }

                    if (j >= colList.size()) {
                        continue;
                    }
                    row.put(colList.get(j).getName(), value);
                }

                list.add(row);
            }
        } catch (Exception e) {
            LOG.error("\n[queryTableData]数据库连接或查询异常:" + e.getMessage(), e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常");
        }*/
        List<Map<String, String>> list = this.obtainDataV1(columns, tableName, where, pageable, colList, 0);
        //完整结果（字段信息+表数据）
        AggregateResultV2 result = new AggregateResultV2();
        result.setData(list);
        result.setColumnList(colList);

        return result;
    }

    public String removeN(String columnSource) {
        if (StringUtils.isBlank(columnSource)) {
            return columnSource;
        }
        // \n 是在字段名字的第一个位置
        if (columnSource.contains("\n")) {
            columnSource = columnSource.substring(columnSource.indexOf("\n") + 1, columnSource.length());
        }
        return columnSource;
    }

    public List<Map<String, String>> obtainDataV1(List<String> columns, String tableName, String where, Pageable pageable, List<ColumnIndex> colList, Integer position) throws APIException {
        List<Map<String, String>> list = null;
        columns.stream().filter(Objects::nonNull).forEach(this::removeN);
        //这里是从0开始,
        for (int i = 0; i <= columns.size(); i++) {
            try {
                Integer flag = 0;
                if (i != 0) {
                    flag = 1;
                }
                list = this.obtainDataV2(columns, tableName, where, pageable, colList, i - 1, flag);
            } catch (Exception e) {
                //如果是因为列名无效的,则继续循环,其他的往上抛
                if ((e.getMessage().contains("列名") && e.getMessage().contains("无效"))
                        || e.getMessage().contains("不能比较或排序 text、ntext 和 image 数据类型，除非使用 IS NULL 或 LIKE 运算符")) {
                    continue;
                } else {
                    LOG.error("\n[queryTableData]数据库连接或查询异常:" + e.getMessage(), e);
                    throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常");
                }
            }
            if (!CollectionUtils.isEmpty(list)) {
                //正常的SQLserver表
                break;
            }
        }
        return list;
    }

    public List<Map<String, String>> obtainDataV2(List<String> columns, String tableName, String where, Pageable pageable, List<ColumnIndex> colList, Integer position, Integer flag) throws Exception {
        //获取数据
        String exec = null;
        if (0 == flag) {
            exec = this.getQueryTableDataSql(Joiner.on(",").skipNulls().join(columns), tableName, where, pageable);
        } else {
            exec = this.getQueryTableDataSqlV2(columns, position, tableName, where, pageable);
        }
        LOG.info("[doSql :]{}", exec);
        List<Map<String, String>> list = new LinkedList<>();
        boolean isOracle = Objects.equals(this.getDatasource().getDatabaseType(), DtsConstants.DATABASE_TYPE_ORACLE);
        LOG.debug(exec);
        try (
                Connection connection = getConnection();
                PreparedStatement stat = connection.prepareStatement(exec);
                ResultSet rs = stat.executeQuery()
        ) {
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            while (rs.next()) {
                Map<String, String> row = new LinkedHashMap<>(columnCount);
                for (int j = 0; j < columnCount; j++) {
                    int columType = metaData.getColumnType(j + 1);
                    String value;
                    switch (columType) {
                        case Types.DATE:
                            java.sql.Date date = rs.getDate(j + 1);
                            value = (date == null ? null : date.toString());
                            break;
                        default:
                            value = rs.getString(j + 1);
                            //去除ORACLE数据库TIMESTAMP的秒数据
                            if (isOracle && Objects.equals(columType, Types.TIMESTAMP) && StringUtils.isNotBlank(value)) {
                                value = value.replace(".0", "");
                            }
                            break;
                    }

                    if (j >= colList.size()) {
                        continue;
                    }
                    row.put(colList.get(j).getName(), value);
                }

                list.add(row);
            }
        }
        return list;
    }

    @Override
    public String getPrimaryKeyOfSql(String tableNameS) {
        //1.tableNameS进来之后，将每一个表名加上单引号
        String[] split = tableNameS.split(",");
        StringBuilder sb1 = new StringBuilder("(");
        for (String s : split) {
            sb1.append("'");
            sb1.append(s);
            sb1.append("'");
            sb1.append(",");
        }
        //会多一个逗号 ('tableName1','tableName2',
        String substring = sb1.toString().substring(0, sb1.toString().length() - 1);
        StringBuilder sb2 = new StringBuilder(substring);
        sb2.append(")");

        StringBuilder sb = new StringBuilder("SELECT TABLE_NAME,COLUMN_NAME " +
                "FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE " +
                "WHERE TABLE_NAME IN ");
        return sb.append(sb2.toString()).toString();
    }

    @Override
    public List<ColumnInfo> getPrimaryKey(String tableNameS) throws Exception {
        String doSql = this.getPrimaryKeyOfSql(tableNameS);

        List<ColumnInfo> list = Lists.newArrayList();
        try (Connection con = getConnection()) {
            Statement ps = con.createStatement();
            LOG.debug("\n[doExecuteBatch]Execute sql: " + doSql);
            ResultSet resultSet = ps.executeQuery(doSql);
            while (resultSet.next()) {
                //字段名字
                String column_name = resultSet.getString("COLUMN_NAME");
                //表名字
                String table_name = resultSet.getString("TABLE_NAME");

                ColumnInfo column = new ColumnInfo();
                column.setColumnSource(column_name);
                column.setBelongTableName(table_name);
                list.add(column);
            }
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
        return list;
    }

    @Override
    public String getBatchTableColumnListSql(String tableNameS) throws Exception {
        //mysql中可以直接从INFORMATION_SCHEMA.COLUMNS一次获取到多张表的字段信息，走一次IO操作
        //1.tableNameS进来之后，将每一个表名加上单引号
        String[] split = tableNameS.split(",");
        StringBuilder sb1 = new StringBuilder("(");
        for (String s : split) {
            sb1.append("'");
            sb1.append(s);
            sb1.append("'");
            sb1.append(",");
        }
        //会多一个逗号 ('tableName1','tableName2',
        String substring = sb1.toString().substring(0, sb1.toString().length() - 1);
        StringBuilder sb2 = new StringBuilder(substring);
        sb2.append(")");

        StringBuilder sb = new StringBuilder("SELECT  c.TABLE_NAME ,\n" +
                "c.COLUMN_NAME ,\n" +
                "c.DATA_TYPE ,\n" +
                "c.COLUMN_DEFAULT ,\n" +
                "c.IS_NULLABLE ,\n" +
                "c.NUMERIC_PRECISION ,\n" +
                "c.NUMERIC_SCALE\n" +
                "FROM [INFORMATION_SCHEMA].[COLUMNS] c\n" +
                "WHERE TABLE_NAME IN ");
        sb.append(sb2.toString());
        return sb.toString();
    }

    @Override
    public List<ColumnInfo> getBatchTableColumnList(String tableNameS) throws Exception {
        //获取表的字段信息,从视图获取
        String doSql = getPrimaryKeyOfSql(tableNameS);
        List<ColumnInfo> list = Lists.newArrayList();
        try (Connection con = getConnection()) {
            Statement ps = con.createStatement();
            LOG.debug("\n[doExecuteBatch]Execute sql: " + doSql);
            ResultSet resultSet = ps.executeQuery(doSql);
            while (resultSet.next()) {
                //字段名字
                String column_name = resultSet.getString("COLUMN_NAME");
                //字段类型
                String data_type = resultSet.getString("DATA_TYPE");
                //字段默认值
                String column_default = resultSet.getString("COLUMN_DEFAULT");
                //字段是否为null
                String is_nullable = resultSet.getString("IS_NULLABLE");
                //表名字
                String table_name = resultSet.getString("TABLE_NAME");

                ColumnInfo column = new ColumnInfo();
                column.setColumnSource(column_name);
                column.setColumnType(data_type);
                column.setDefaultValue(column_default);
                column.setNullable(Objects.equals(is_nullable, "YES"));
                column.setBelongTableName(table_name);
                list.add(column);
            }
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
        return list;
    }

    @Override
    public String getBatchTableCommentListSql(String tableNameS) throws Exception {
        //mysql中可以直接从INFORMATION_SCHEMA.COLUMNS一次获取到多张表的字段信息，走一次IO操作
        //1.tableNameS进来之后，将每一个表名加上单引号
        String[] split = tableNameS.split(",");
        StringBuilder sb1 = new StringBuilder("(");
        for (String s : split) {
            sb1.append("'");
            sb1.append(s);
            sb1.append("'");
            sb1.append(",");
        }
        //会多一个逗号 ('tableName1','tableName2',
        String substring = sb1.toString().substring(0, sb1.toString().length() - 1);
        StringBuilder sb2 = new StringBuilder(substring);
        sb2.append(")");

        StringBuilder sb = new StringBuilder("SELECT DISTINCT\n" +
                "d.name,\n" +
                "f.value \n" +
                "FROM\n" +
                "syscolumns a\n" +
                "LEFT JOIN systypes b ON a.xusertype= b.xusertype\n" +
                "INNER JOIN sysobjects d ON a.id= d.id \n" +
                "AND d.xtype= 'U' \n" +
                "AND d.name IN ");
        sb.append(sb2.toString());
        sb.append(" LEFT JOIN syscomments e ON a.cdefault= e.id\n" +
                "LEFT JOIN sys.extended_properties g ON a.id= G.major_id \n" +
                "AND a.colid= g.minor_id\n" +
                "LEFT JOIN sys.extended_properties f ON d.id= f.major_id \n" +
                "AND f.minor_id= 0");
        return sb.toString();
    }

    @Override
    public List<TableInfo> getBatchTableCommentList(String tableNameS) throws Exception {
        //获取表的字段信息,从视图获取
        String doSql = getPrimaryKeyOfSql(tableNameS);
        List<TableInfo> list = Lists.newArrayList();
        try (Connection con = getConnection()) {
            Statement ps = con.createStatement();
            LOG.debug("\n[doExecuteBatch]Execute sql: " + doSql);
            ResultSet resultSet = ps.executeQuery(doSql);
            while (resultSet.next()) {
                //表注释TABLE_COMMENT
                String table_comment = resultSet.getString("value");
                //表名字
                String table_name = resultSet.getString("name");

                TableInfo tableInfo = new TableInfo();
                tableInfo.setTableSource(table_name);
                tableInfo.setTableComment(table_comment);
                list.add(tableInfo);
            }
        } catch (Exception e) {
            LOG.error("\n[doExecuteBatch]数据库连接或查询异常,sql:{}", e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常:" + "\n" + e.getMessage());
        }
        return list;
    }

    @Override
    public List<ColumnInfo> getColumnList(String tableName) throws Exception {

        List<ColumnInfo> list = null;
        Map<Integer, ColumnInfo> map = new HashMap<>();
        try (Connection connection = getConnection()) {
            DatabaseMetaData metaData = connection.getMetaData();
            //精准匹配表，获取主键信息
//            ResultSet primaryKeys = metaData.getPrimaryKeys(connection.getCatalog(), connection.getSchema(), tableName);
            String primaryKeyName = null;
//            if (primaryKeys.next()) {
//                primaryKeyName = primaryKeys.getString("COLUMN_NAME");
//            }
            //sqlservre 的主键信息从视图中获取
            List<ColumnInfo> primaryL = this.getPrimaryKey(tableName);
            if (primaryL != null && primaryL.size() > 0)
                primaryKeyName = primaryL.get(0).getColumnSource();

            //精准匹配表，获取表字段信息q
            ResultSet colRet = metaData.getColumns(connection.getCatalog(), connection.getSchema(), tableName, null);
            //取字段注释
            Map<String, String> mapcol = new HashMap<String, String>();
            mapcol=getColumnRemarks(tableName);

            while (colRet.next()) {
                //字段名
                String columnName = colRet.getString("COLUMN_NAME");
                //字段注释
                String remarks = mapcol.get(columnName);
                //对应typesSql的值
                int javaTypesSql = colRet.getInt("DATA_TYPE");
                //字段长度
                int precision = colRet.getInt("COLUMN_SIZE");
                //精度
                int scale = colRet.getInt("DECIMAL_DIGITS");
                //是否为空：0就表示Not Null，1表示可以是Null
                int nullable = colRet.getInt("NULLABLE");
                //字段索引定位：从1开始
                int position = colRet.getInt("ORDINAL_POSITION");
                //默认值 TODO oracle获取会报错
//                String defaultValue = colRet.getString("COLUMN_DEF");
                //所属数据表名
                String belongTableName = colRet.getString("TABLE_NAME");

                JavaSqlTypeEnum typeEnum = EnumUtil.getByCode(javaTypesSql, JavaSqlTypeEnum.class);
                String columnTypeName = String.valueOf(typeEnum.getName());

                ColumnInfo column = new ColumnInfo();
                column.setColumnIndex(position);
                column.setColumnSource(columnName);
                column.setColumnType(StringUtils.upperCase(columnTypeName));
                column.setColumnPrecision(precision);
                column.setColumnScale(scale);
                column.setNullable(nullable == 1);
                column.setColumnComment(remarks);
//                column.setDefaultValue(defaultValue);
                column.setBelongTableName(belongTableName);
                column.setIsPrimaryKey(Objects.equals(primaryKeyName, columnName));
                map.put(position, column);
            }
            list = new LinkedList<>(map.values());
        } catch (Exception e) {
            LOG.error("\n[getColumnList]数据库连接或查询异常:" + e.getMessage(), e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, ExceptionConstants.EXCEPTION_ERROR_MSG + "数据库连接或查询异常:" + e.getMessage());
        }

        return list;

    }
    //取表字段注释
    public Map<String,String> getColumnRemarks(String tableName) throws Exception {

        HashMap<String, String> map = new HashMap<String, String>();

        try (Connection connection = getConnection()) {

            String sql = "SELECT D.name AS TABLE_NAME, A.name AS COLUMN_NAME, CAST( isnull( G.[value], '') AS VARCHAR ( 5000 )) AS REMARKS FROM syscolumns A INNER JOIN sysobjects D ON A.id= D.id AND D.xtype= 'U' AND D.name<> 'dtproperties' LEFT JOIN sys.extended_properties G ON A.id= G.major_id AND A.colid= G.minor_id WHERE d.name=?";
            PreparedStatement pstmt= null;
            pstmt=connection.prepareStatement(sql);
            pstmt.setString(1, tableName);
            ResultSet colRet = pstmt.executeQuery();
            while (colRet.next()) {
                //字段名
                String columnName = colRet.getString("COLUMN_NAME");
                //字段注释
                String remarks = colRet.getString("REMARKS");
                map.put(columnName,remarks);

            }
        } catch (Exception e) {
            LOG.error("\n[getColumnRemarks]数据库连接或查询异常:" + e.getMessage(), e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常");
        }

        return map;
    }

    @Override
    public Long getTableDataRowsFromView(List<String> tableNameList) throws APIException {
        //获取到当前表的记录数
        StringBuilder sb = new StringBuilder(" SELECT OBJECT_NAME(object_id) AS Object_Name, \n" +
                " i.name AS Index_Name,\n" +
                " p.rows AS Table_Rows\n" +
                " FROM sys.partitions  p\n" +
                " LEFT JOIN sys.sysindexes i ON p.object_id = i.id AND  p.index_id = i.indid  \n" +
                " WHERE object_id in ( ");
        tableNameList.stream().filter(Objects::nonNull).forEach(x -> sb.append(" OBJECT_ID( ' ").append(x).append(" ' ) ").append(","));
        String execSql = sb.toString().substring(0, sb.toString().length() - 1).concat(" )");
        try (
                Connection con = getConnection();
                Statement ps = con.createStatement();
        ) {
            ResultSet rs = ps.executeQuery(execSql);
            List<Long> rowsList = Lists.newArrayList();
            while (rs.next()) {
                Long rows = rs.getLong("Table_Rows");
                rowsList.add(rows);
            }
            return rowsList.parallelStream().filter(Objects::nonNull).reduce(0L, Long::sum);
        } catch (Exception e) {
            LOG.error("\n[doExecute]数据库连接或查询异常,sql:{}", execSql, e);
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "数据库连接或查询异常");
        }
    }

}
