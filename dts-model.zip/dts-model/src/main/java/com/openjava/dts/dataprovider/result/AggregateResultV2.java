package com.openjava.dts.dataprovider.result;

import com.openjava.dts.util.PageUtil;
import com.sun.org.apache.bcel.internal.generic.NEW;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.ljdp.ui.bootstrap.TablePageImpl;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Map;

/**
 * @author: lsw
 * @Date: 2019/10/18 10:01
 */
@ApiModel("查询结果信息V2")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class AggregateResultV2 {
    @ApiModelProperty("列信息")
    private List<ColumnIndex> columnList;

    @ApiModelProperty("数据")
    private List<Map<String, String>> data;

    @ApiModelProperty("对数据进行分页")
    private TablePageImpl<Map<String, String>> tablePage;

    public AggregateResultV2(List<ColumnIndex> columnList, List<Map<String, String>> data) {
        this.columnList = columnList;
        this.data = data;
    }

    public void setPageFromData(Pageable pageable, Integer total) {
        Page<Map<String, String>> page = new PageImpl<>(this.data, pageable, total);
        this.tablePage = new TablePageImpl<>(page);
    }

}
