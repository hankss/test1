package com.openjava.dts.dataprovider.result;

import com.openjava.dts.ddl.request.ColumnIndexRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.List;
import java.util.Map;

/**
 * @author: jianli
 */
@ApiModel("查询结果信息V3")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class AggregateResultV3 {

    @ApiModelProperty("列信息")
    private List<ColumnIndexRequest> columnIndexRequestList;

    @ApiModelProperty("数据")
    private List<Map<String, String>> data;

    @ApiModelProperty("表数据总数")
    private String tableDataSize;

    @ApiModelProperty("总记录数 == tableDataSize")
    private Long total;

    @ApiModelProperty("字段数据总数")
    private String tableColumnSize;

    @ApiModelProperty("当前页")
    private Integer number;

    @ApiModelProperty("每页大小")
    private Integer size;

    @ApiModelProperty("总页数")
    private Integer totalPage;

    /** ------ 这个列信息和数据data,是兼容以前  前端调用的数据接口 ------ **/
    @ApiModelProperty("列信息")
    private List<ColumnIndex> columnList;

    public AggregateResultV3(List<ColumnIndexRequest> columnIndexRequestList, List<Map<String, String>> data, List<ColumnIndex> columnList) {
        this.columnIndexRequestList = columnIndexRequestList;
        this.data = data;
        this.columnList = columnList;
    }

}
