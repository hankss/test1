package com.openjava.dts.ddl.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Persistable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import java.io.Serializable;

/**
 * 实体
 * @author 子右
 *
 */
@ApiModel("数据表字段配置")
@Data
@EqualsAndHashCode(callSuper = false)
//@Accessors(chain = true)
@Entity
@Table(name = "DTS_COLUMN")
public class DtsColumn implements Persistable<Long>,Serializable {
	
	@ApiModelProperty("表字段ID")
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "column_id")
	private Long columnId;
	
	@ApiModelProperty("数据表ID")
	@Max(999999999999999999L)
	@Column(name = "table_id")
	private Long tableId;
	
	@ApiModelProperty("字段列名")
	@Length(min=0, max=256)
	@Column(name = "column_source")
	private String columnSource;
	
	@ApiModelProperty("是否更新字段")
	@Column(name = "is_update_column")
	private Boolean isUpdateColumn;

	/*@ApiModelProperty("是否创建时间字段")
	@Value("false")
	@Column(name = "is_create_time")
	private Boolean isCreateTime;

	@ApiModelProperty("是否更新时间字段")
	@Value("false")
	@Column(name = "is_update_time")
	private Boolean isUpdateTime;*/

	@ApiModelProperty("字段类型")
	@Length(min=0, max=128)
	@Column(name = "column_type")
	private String columnType;

	@ApiModelProperty("字段在文件中的位置")
	@Max(99999999L)
	@Column(name = "column_index")
	private Integer columnIndex;
	
	@ApiModelProperty("字段长度")
	@Max(99999999999L)
	@Column(name = "column_precision")
	private Integer columnPrecision;
	
	@ApiModelProperty("小数位数")
	@Max(99L)
	@Column(name = "column_scale")
	private Integer columnScale;
	
	@ApiModelProperty("默认值")
	@Length(min=0, max=256)
	@Column(name = "default_value")
	private String defaultValue;
	
	@ApiModelProperty("是否主键（0否，1是）")
	@Column(name = "is_primary_key")
	private Boolean isPrimaryKey;
	
	@ApiModelProperty("字段可否为空（0否，1是）")
	@Column(name = "nullable")
	private Boolean nullable;
	
	@ApiModelProperty("备注")
	@Length(min=0, max=512)
	@Column(name = "column_comment")
	private String columnComment;

	@ApiModelProperty("排序")
	@Max(99999999L)
	@Column(name = "sort")
	private Integer sort;
	
	@ApiModelProperty("是否新增")
	@Transient
    private Boolean isNew;
	
	@Transient
    @JsonIgnore
    @Override
    public Long getId() {
        return this.columnId;
	}
    
    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
    	if(isNew != null) {
    		return isNew;
    	}
    	if(this.columnId != null) {
    		return false;
    	}
    	return true;
    }
}