package com.openjava.dts.ddl.domain;

import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.openjava.dts.constants.DtsConstants;
import com.openjava.dts.util.DtsStatisticsUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import lombok.experimental.Accessors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.constraints.Length;
import org.ljdp.component.exception.BusinessException;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Date;

/**
 * 实体
 *
 * @author 子右
 */
@ApiModel("数据源")
@Data
@Slf4j
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "DTS_DATASOURCE")
public class DtsDatasource implements Persistable<String>, Serializable {

    @ApiModelProperty("数据源ID")
    @Id
    @Column(name = "datasource_id")
    private String datasourceId;

    @ApiModelProperty("数据库类型（ 0:Oracle,1:MySql高版本 2：Mysql低版本 3:PostgreSQL  4:hive  5:SQL Server ）")
    @Max(value = 99L, message = "数据库类型限制最大为99")
    @NotNull(message = "数据库类型不能为空")
    @Column(name = "database_type")
    private Integer databaseType;

    @ApiModelProperty("数据库类型（ 0:Oracle,1:MySql高版本 2:Mysql低版本 3:PostgreSql 4:hive 5:SQL Server ）名称")
    @Transient
    private String databaseTypeName;

    @ApiModelProperty("集群连接地址URL")
    @Length(min = 0, max = 512, message = "url地址限制长度512位")
    @Column(name = "url")
    private String url;

    @ApiModelProperty("主机IP")
    @Length(min = 0, max = 512, message = "主机IP限制长度512位")
    @Column(name = "host_ip")
    private String hostIp;

    @ApiModelProperty("服务名")
    @Length(min = 0, max = 32, message = "服务名限制32字")
    @Column(name = "service_name")
    private String serviceName;

    @ApiModelProperty("数据库名")
    @Length(min = 0, max = 32, message = "数据库名限制最长32字")
    @Column(name = "database_name")
    private String databaseName;

    @ApiModelProperty("模式名称")
    @Length(min = 0, max = 32, message = "模式名称限制32字")
    @Column(name = "schema_name")
    private String schemaName;

    @ApiModelProperty("端口号")
    @Max(value = 99999L, message = "端口号限制最大为99999")
    @Column(name = "port")
    private Long port;

    @ApiModelProperty("用户名")
    @Length(min = 0, max = 128, message = "用户名限制最长128字")
    @Column(name = "username")
    private String username;

    @ApiModelProperty("委托用户")
    @Length(min = 0, max = 128, message = "委托用户限制最长128字")
    @Column(name = "principal")
    private String principal;

    @ApiModelProperty("密码")
    @Length(min = 0, max = 128, message = "密码限制最长128字")
    @Column(name = "password")
    private String password;

    @ApiModelProperty("安全认证类型(USER-PWD，KERBEROS，KERBEROS-HW）")
    @Length(min = 0, max = 20, message = "安全认证类型限制最长20字")
    @Column(name = "security_type")
    private String securityType;

    @ApiModelProperty("keytab文件")
    @Length(min = 0, max = 255, message = "keytab文件限制最长255字")
    @Column(name = "keytab")
    private String keytab;

    @ApiModelProperty("krb5.conf文件")
    @Length(min = 0, max = 255, message = "krb5.conf文件限制最长255字")
    @Column(name = "krb5conf")
    private String krb5conf;

    @ApiModelProperty("hdfs连接地址")
    @Length(min = 0, max = 255, message = "hdfs连接地址限制最长255字")
    @Column(name = "hdfs_url")
    private String hdfsUrl;

    @ApiModelProperty("表关联的hdfs文件路径")
    @Length(min = 0, max = 512, message = "表关联的hdfs文件路径限制最长512字")
    @Column(name = "hdfs_path")
    private String hdfsPath;

    @ApiModelProperty("数据库描述")
    @Length(min = 0, max = 512, message = "数据库描述限制最长512字")
    @Column(name = "description")
    private String description;

    @ApiModelProperty("数据库用途（1、数据源；2、目标库）")
    @Max(value = 99L, message = "数据库用途限制最大99")
    @Column(name = "database_use")
    private Integer databaseUse;

    @ApiModelProperty("数据库用途名称（1、数据源；2、目标库）")
    @Transient
    private String databaseUseName;

    @ApiModelProperty("关联局系统id")
    @Length(min = 0, max = 512)
    @Column(name = "system_ids")
    private String systemIds;

    @ApiModelProperty("关联局系统名字")
    @Length(min = 0, max = 512)
    @Column(name = "system_names")
    private String systemNames;

    @ApiModelProperty("连通状态（1、连通；2、未连通）")
    @Max(value = 99L, message = "连通状态限制最大99")
    @Column(name = "link_status")
    private Integer linkStatus;

    @ApiModelProperty("连通状态名称（1、连通；2、未连通）")
    @Transient
    private String linkStatusName;

    @ApiModelProperty("变更提醒（0、不提醒；1、提醒）")
    @Max(value = 99L, message = "变更提醒限制最大99")
    @Column(name = "change_remind")
    private Integer changeRemind;

    @ApiModelProperty("数据库来源")
    @Length(min = 0, max = 128, message = "数据库来源限制最长128字")
    @Column(name = "database_source")
    private String databaseSource;

    @ApiModelProperty("数据库来源名称")
    @Length(min = 0, max = 128, message = "数据库来源名称限制最长128字")
    @Column(name = "database_source_name")
    private String databaseSourceName;

    @ApiModelProperty("创建人ID")
    @Length(min = 0, max = 64)
    @Column(name = "create_id")
    private String createId;

    @ApiModelProperty("创建人名称")
    @Length(min = 0, max = 64)
    @Column(name = "create_name")
    private String createName;

    @ApiModelProperty("创建时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "create_time")
    private Date createTime;

    @ApiModelProperty("修改人ID")
    @Length(min = 0, max = 64)
    @Column(name = "modify_id")
    private String modifyId;

    @ApiModelProperty("修改人名称")
    @Length(min = 0, max = 64)
    @Column(name = "modify_name")
    private String modifyName;

    @ApiModelProperty("修改时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifyTime;

    @ApiModelProperty("来源业务ID")
    @Length(min = 0, max = 64)
    @Column(name = "BUSINESS_ID")
    private String businessId;

    @ApiModelProperty("业务系统ID（DTS_INTEGRATION:数据汇聚平台）")
    @Length(min = 0, max = 64)
    @Column(name = "SYSTEM_ID")
    private String systemId = "DTS_INTEGRATION";

    @ApiModelProperty("项目id")
    @Max(999999999999999999L)
    @Column(name = "project_id")
    private Long projectId;

    @ApiModelProperty("项目名称")
    @Length(min = 0, max = 256)
    @Column(name = "project_name")
    private String projectName;

    @ApiModelProperty("变更提醒，默认为0不提醒，1提醒")
    @Max(value = 99L, message = "数据库类型限制最大为99")
    @Column(name = "modify_remind_enabled")
    private Integer modifyRemindEnabled;

    @ApiModelProperty("RAC是否开启，默认0不开启，1开启")
    @Max(value = 99L, message = "数据库类型限制最大为99")
    @Column(name = "rac_enabled")
    private Integer racEnabled;

    @ApiModelProperty("读写是否分离，默认0不开启，1开启")
    @Max(value = 99L, message = "数据库类型限制最大为99")
    @Column(name = "read_write_divide_enabled")
    private Integer readWriteDivideEnabled;

    @ApiModelProperty("主从分离，默认0不开启，1开启")
    @Max(value = 99L, message = "数据库类型限制最大为99")
    @Column(name = "master_slave_enabled")
    private Integer masterSlaveEnabled;

    @ApiModelProperty("是否集群，默认0不集群，1集群")
    @Max(value = 99L, message = "数据库类型限制最大为99")
    @Column(name = "cluster_enabled")
    private Integer clusterEnabled;

    @ApiModelProperty("备库类型，默认0热备，1冷备")
    @Max(value = 99L, message = "数据库类型限制最大为99")
    @Column(name = "backup_type")
    private Integer backupType;

    @ApiModelProperty("是否容灾备份，默认0不开启，1开启")
    @Max(value = 99L, message = "数据库类型限制最大为99")
    @Column(name = "disaster_backup_enabled")
    private Integer disasterBackupEnabled;

    @ApiModelProperty("当前数据源所拥有表的总数")
    @Max(999999999999999999L)
    @Column(name = "table_number")
    private Long tableNumber;

    @ApiModelProperty("是否新增")
    @Transient
    private Boolean isNew;

    @ApiModelProperty("URL上的数据库名")
    @Length(min = 0, max = 128, message = "数据库名最长128字")
    @Column(name = "db_name")
    private String dbName;

    @ApiModelProperty("是否已经删除，0:未删除，1:已删除")
    @Max(9223372036854775806L)
    @Column(name = "deleted")
    private Integer deleted;

    @Transient
    @JsonIgnore
    @Override
    public String getId() {
        return this.datasourceId;
    }

    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
        if (isNew != null) {
            return isNew;
        }
        if (this.datasourceId != null) {
            return false;
        }
        return true;
    }

    @Transient
    public String getJdbcDriverClass() {
        if (databaseType == null) {
            return null;
        }

        if (databaseType.equals(DtsConstants.DATABASE_TYPE_ORACLE)) {
            return "oracle.jdbc.OracleDriver";
        } else if (databaseType.equals(DtsConstants.DATABASE_TYPE_MYSQL_NEW)) {
            return "com.mysql.cj.jdbc.Driver";
        } else if (databaseType.equals(DtsConstants.DATABASE_TYPE_MYSQL_OLD)) {
            return "com.mysql.jdbc.Driver";
        } else if (databaseType.equals(DtsConstants.DATABASE_TYPE_POSTGRES)) {
            return "org.postgresql.Driver";
        } else if (databaseType.equals(DtsConstants.DATABASE_TYPE_HIVE)
                || databaseType.equals(DtsConstants.DATABASE_TYPE_HIVE_HUAWEI)) {
            return "org.apache.hive.jdbc.HiveDriver";
        }
        return null;
    }

    @Transient
    public String getJDBCUrl(String jdbcParams) throws BusinessException {
        StringBuilder urlDest = null;
        if (DtsConstants.DATABASE_TYPE_ORACLE.equals(this.getDatabaseType())) {
            urlDest = new StringBuilder("jdbc:oracle:thin:@//");
            urlDest.append(this.getHostIp()).append(":").append(this.getPort()).append("/").append(this.getDatabaseName());
        } else if (DtsConstants.DATABASE_TYPE_MYSQL_NEW.equals(this.getDatabaseType())
                || DtsConstants.DATABASE_TYPE_MYSQL_OLD.equals(this.getDatabaseType())) {
            urlDest = new StringBuilder("jdbc:mysql://");
            urlDest.append(this.getHostIp()).append(":").append(this.getPort()).append("/").append(this.getDatabaseName()).append("?useUnicode=true&characterEncoding=utf-8&useSSL=false");
        } else if (DtsConstants.DATABASE_TYPE_POSTGRES.equals(this.getDatabaseType())) {
            urlDest = new StringBuilder("jdbc:postgresql://");
            urlDest.append(this.getHostIp()).append(":").append(this.getPort()).append("/").append(this.getDatabaseName());
            if (StringUtils.isNotBlank(this.getSchemaName())) {
                //searchpath -> currentSchema
                urlDest.append("?currentSchema=").append(this.getSchemaName());
            }
        } else if (DtsConstants.DATABASE_TYPE_HIVE.equals(this.getDatabaseType())
                || DtsConstants.DATABASE_TYPE_HIVE_HUAWEI.equals(this.getDatabaseType())) {
            urlDest = new StringBuilder("jdbc:hive2://");
            urlDest.append(this.getHostIp());
            if (this.getPort() != null && this.getPort().intValue() > 0) {
                urlDest.append(":").append(this.getPort());
            }
            urlDest.append("/");
            if (this.getDatabaseName() != null) {
                urlDest.append(this.getDatabaseName());
            }
            if (jdbcParams != null) {
                urlDest.append(jdbcParams);
            }
        } else if (DtsConstants.DATABASE_TYPE_TXT.equals(this.getDatabaseType())) {
            urlDest = new StringBuilder();
        } else {
            throw new BusinessException(1001, "暂不支持此数据类型");
        }
        return urlDest.toString();
    }

    /**
     * 兼容以前的数据,将URL抽出前,返回给前端
     */
    public void setIPAndPortAndDbName() {

        if (StringUtils.isBlank(this.hostIp)) {
            this.hostIp = this.getIpFromUrl();
            if (StringUtils.isBlank(this.hostIp)) {
                this.hostIp = this.getIpAndPort(this.url);
            }
        }

        if (StringUtils.isBlank(String.valueOf(this.port)) || null == this.port) {
            try {
                this.port = (long) this.getPortFromUrl();
            } catch (Exception e) {
                // 不作处理
            }
            if (StringUtils.isBlank(String.valueOf(this.getPortFromUrl()))) {
                this.port = Long.parseLong(this.getIpAndPort(this.url, null));
            }
        }

        if (StringUtils.isBlank(this.dbName)) {
            this.dbName = this.getDbNameFromUrl();
        }

    }

    public Integer getPortFromUrl() {
        try {
            return DtsStatisticsUtil.getJdbcPort(url);
        } catch (Exception e) {
            return null;
        }
    }

    public String getIpFromUrl() {
        try {
            return DtsStatisticsUtil.getJdbcHost(url);
        } catch (Exception e) {
            return null;
        }
    }

    public String getDbNameFromUrl() {
        try {
            String db = null;
            if (DtsConstants.DATABASE_TYPE_SQL_SERVER.equals(databaseType)) {
                db = DtsStatisticsUtil.getSqlserverJdbcDatabaseName(url);
            } else {
                db = DtsStatisticsUtil.getJdbcDatabaseName(url);
            }
            return db;
        } catch (Exception e) {
            return null;
        }
    }

    public String getIpAndPort(String url, DtsDatasource body) {
        String port = null;
        try {
            url = addSlash(url);
            if (null == url || "".equals(url))
                return null;
            String ip = "";
            port = "";
            if (url.contains("jdbc:oracle:thin:@//") || url.contains("jdbc:mysql://")
                    || url.contains("jdbc:postgresql://") || url.contains("jdbc:hive2://")) {
                String subStr = subStr = url.substring(url.indexOf("//") + 2, url.length());
                ip = subStr.substring(0, subStr.indexOf(":")).replace(" ", "").trim();
                if (!subStr.contains("/")) {
                    String str1 = subStr.substring(subStr.indexOf(":") + 1, subStr.length());
                    port = str1.substring(0, str1.indexOf(":")).replace(" ", "").trim();
                } else {
                    port = subStr.substring(subStr.indexOf(":") + 1, subStr.indexOf("/")).replace(" ", "").trim();
                }
            }
            if (url.contains("jdbc:zenith:@") || url.contains("jdbc:gaussdb")) {
                String subStr = url.substring(url.indexOf("@") + 1, url.length());
                ip = subStr.substring(0, subStr.indexOf(":")).replace(" ", "").trim();
                port = subStr.substring(subStr.indexOf(":") + 1, subStr.length()).replace(" ", "").trim();
            }
        } catch (Exception e) {
            //报异常暂时不作处理
            log.error("port解析出现异常 : {}", JSONObject.toJSONString(e.getMessage()));
        }
        return port;
    }

    public String getIpAndPort(String url) {
        String ip = null;
        try {
            url = addSlash(url);
            if (null == url || "".equals(url))
                return null;
            ip = "";
            String port = "";
            if (url.contains("jdbc:oracle:thin:@//") || url.contains("jdbc:mysql://")
                    || url.contains("jdbc:postgresql://") || url.contains("jdbc:hive2://")) {
                String subStr = subStr = url.substring(url.indexOf("//") + 2, url.length());
                ip = subStr.substring(0, subStr.indexOf(":")).replace(" ", "").trim();
                if (!subStr.contains("/")) {
                    String str1 = subStr.substring(subStr.indexOf(":") + 1, subStr.length());
                    port = str1.substring(0, str1.indexOf(":")).replace(" ", "").trim();
                } else {
                    port = subStr.substring(subStr.indexOf(":") + 1, subStr.indexOf("/")).replace(" ", "").trim();
                }
            }
            if (url.contains("jdbc:zenith:@") || url.contains("jdbc:gaussdb")) {
                String subStr = url.substring(url.indexOf("@") + 1, url.length());
                ip = subStr.substring(0, subStr.indexOf(":")).replace(" ", "").trim();
                port = subStr.substring(subStr.indexOf(":") + 1, subStr.length()).replace(" ", "").trim();
            }
        } catch (Exception e) {
            //报异常暂时不作处理
            log.error("ip解析出现异常 : {}", JSONObject.toJSONString(e.getMessage()));
        }
        return ip;
    }

    public String addSlash(String url) {
        if (url.contains("//") || StringUtils.isBlank(url)) {
            return url;
        }
        StringBuilder s = new StringBuilder(url);
        s.insert(url.indexOf("@") + 1, "//");
        return s.toString();
    }

}