package com.openjava.dts.ddl.domain;

import java.util.Date;
import java.io.Serializable;

import javax.persistence.*;
import javax.validation.constraints.Max;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.data.domain.Persistable;
import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 实体
 * @author 子右
 *
 */
@ApiModel("数据表配置")
@Data
@EqualsAndHashCode(callSuper = false)
//@Accessors(chain = true)
@Entity
@Table(name = "DTS_TABLE")
public class DtsTable implements Persistable<Long>,Serializable {
	
	@ApiModelProperty("数据表ID")
	@Id
	@Column(name = "table_id")
	private Long tableId;
	
	@ApiModelProperty("数据源ID")
	@Length(min=0, max=64)
	@Column(name = "datasource_id")
	private String datasourceId;
	
	@ApiModelProperty("数据表来源")
	@Length(min=0, max=64)
	@Column(name = "table_source")
	private String tableSource;
	
	@ApiModelProperty("备注")
	@Length(min=0, max=128)
	@Column(name = "table_comment")
	private String tableComment;
	
	@ApiModelProperty("版本号")
	@Max(99999999L)
	@Column(name = "version")
	private Long version;
	
	@ApiModelProperty("MD5码")
	@Length(min=0, max=256)
	@Column(name = "ciphertext")
	private String ciphertext;
	
	@ApiModelProperty("查询SQL")
	@Length(min=0, max=10000)
	@Column(name = "query_sql")
	private String querySql;
	
	
	@ApiModelProperty("是否新增")
	@Transient
    private Boolean isNew;
	
	@Transient
    @JsonIgnore
    @Override
    public Long getId() {
        return this.tableId;
	}
    
    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
    	if(isNew != null) {
    		return isNew;
    	}
    	if(this.tableId != null) {
    		return false;
    	}
    	return true;
    }
    
}