package com.openjava.dts.ddl.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import javax.persistence.Column;
import javax.validation.constraints.Max;

/**
 * @author: lsw
 * @Date: 2019/10/30 9:26
 */
@ApiModel("数据库excel信息DTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DataSourceExcelDTO {
    @ApiModelProperty("序号")
    private Integer seq;

    @ApiModelProperty("数据库名")
    private String databaseName;

    @ApiModelProperty("数据库类型（ 0:Oracle 1:MySql高版本 2;Mysql低版本 3:PostgreSql 4:hive 5:SQL Server ）")
    private Integer databaseType;

    @ApiModelProperty("数据库类型（ 0:Oracle 1:MySql高版本 2;Mysql低版本 3:PostgreSql 4:hive 5:SQL Server ）名称")
    private String databaseTypeName;

    @ApiModelProperty("集群连接地址URL")
    private String url;

    @ApiModelProperty("用户名")
    private String username;

    @ApiModelProperty("密码")
    private String password;

    @ApiModelProperty("数据库用途（1、数据源；2、目标库）")
    private Integer databaseUse;

    @ApiModelProperty("数据库用途名称（1、数据源；2、目标库）")
    private String databaseUseName;

    @ApiModelProperty("数据库描述")
    private String description;

    @ApiModelProperty("数据库来源")
    private String databaseSource;

    @ApiModelProperty("数据库来源名称")
    private String databaseSourceName;

    @ApiModelProperty("关联局系统id")
    private String systemIds;

    @ApiModelProperty("关联局系统名字")
    private String systemNames;

    @ApiModelProperty("项目id")
    private Long projectId;

    @ApiModelProperty("项目名称")
    private String projectName;

}
