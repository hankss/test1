package com.openjava.dts.ddl.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.List;


@ApiModel("数据源详细结构")
@Data
@EqualsAndHashCode(callSuper = false)
//@Accessors(chain = true)
public class DataSourceStructInfo {

    @ApiModelProperty("数据源")
    private DatasourceInfo datasourceInfo;

    @ApiModelProperty("表结构")
    private List<TableInfo> ListTable;
}
