package com.openjava.dts.ddl.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import javax.persistence.Column;
import javax.validation.constraints.Max;


/**
 * @author: lsw
 * @Date: 2019/9/26 10:40
 */
@ApiModel("数据库更新来源信息参数")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DatabaseSourceParam {

    @ApiModelProperty("数据库ID")
    @Length(min=0, max=32)
    private String datasourceId;

    @ApiModelProperty("数据库来源")
    @Length(min=0, max=128)
    private String databaseSource;

    @ApiModelProperty("数据库来源名称")
    @Length(min=0, max=128)
    private String databaseSourceName;
}
