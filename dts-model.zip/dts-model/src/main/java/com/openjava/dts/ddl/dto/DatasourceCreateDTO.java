package com.openjava.dts.ddl.dto;

import com.openjava.dts.ddl.domain.DtsDatasource;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * @author: lsw
 * @Date: 2019/9/24 11:20
 */
@ApiModel("数据库EXCEL上传DTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DatasourceCreateDTO {
    @ApiModelProperty("数据源ID")
    private String datasourceId;

    @ApiModelProperty("数据库名")
    private String databaseName;

    /*@ApiModelProperty("用户名")
    private String username;*/

    /*@ApiModelProperty("密码")
    private String password;*/

    /*@ApiModelProperty("JDBC URL")
    private String url;*/

    /*@ApiModelProperty("数据库类型（ 0:Oracle 1:MySql高版本 2;Mysql低版本 3:PostgreSql 4:hive 5:SQL Server ）名称")
    private String databaseTypeName;*/

    /*@ApiModelProperty("数据库用途（1、数据源；2、目标库）")
    private Integer databaseUse;*/

    /*@ApiModelProperty("数据库描述")
    private String databaseDesc;*/

    @ApiModelProperty("创建状态")
    private Boolean isCreate;

    @ApiModelProperty("连通状态")
    private Boolean isLinkTest;

    public DatasourceCreateDTO(DtsDatasource dtsDatasource){
        this.datasourceId = dtsDatasource.getDatasourceId();
        this.databaseName = dtsDatasource.getDatabaseName();
        this.isCreate = true;
        this.isLinkTest = false;
    }
}
