package com.openjava.dts.ddl.dto;

import com.openjava.dts.ddl.domain.DtsDatasource;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;

@ApiModel("数据源")
@Data
@EqualsAndHashCode(callSuper = false)
//@Accessors(chain = true)
@NoArgsConstructor
@ToString
public class DatasourceInfo {
    @ApiModelProperty(value = "数据库类型（0:Oracle 1:MySql高版本 2:Mysql低版本 3:PostgreSql 4:hive 5:SQL Server ）",required = true)
    @Max(99L)
    @NotNull
    private Integer databaseType;

    @ApiModelProperty("jdbc连接参数")
    @Length(min=0, max=512)
    private String jdbcParams;

    @ApiModelProperty(value = "主机IP",required = true)
    @Length(min=0, max=512)
    @NotBlank
    private String hostIp;

    @ApiModelProperty(value = "数据库名",required = true)
    @Length(min=0, max=32)
    @NotBlank
    private String databaseName;

    @ApiModelProperty("模式名称(postgres)")
    @Length(min=0, max=32)
    private String schemaName;

    @ApiModelProperty(value = "端口号",required = true)
    @Max(99999L)
//    @NotNull
    private Long port;

    @ApiModelProperty(value = "用户名",required = true)
    @Length(min=0, max=128)
    @NotBlank
    private String username;

    @ApiModelProperty("委托用户")
    @Length(min=0, max=128)
    private String principal;

    @ApiModelProperty(value = "密码",required = true)
    @Length(min=0, max=128)
    private String password;

    @ApiModelProperty("安全认证类型(USER-PWD，KERBEROS，KERBEROS-HW）")
    @Length(min=0, max=20)
    private String securityType;

    @ApiModelProperty("keytab文件")
    @Length(min=0, max=255)
    private String keytab;

    @ApiModelProperty("krb5.conf文件")
    @Length(min=0, max=255)
    private String krb5conf;

    @ApiModelProperty(value = "是否持久连接")
    private Boolean pooled = false;

    @ApiModelProperty(value = "jdbc连接")
    private String jdbcUrl;

    @ApiModelProperty(value = "hdfs地址")
    private String hdfsUrl;
    @ApiModelProperty(value = "表关联的hdfs文件路径")
    private String hdfsPath;

    @ApiModelProperty(value = "关联局系统id")
    private String systemIds;

    @ApiModelProperty(value = "关联局系统名字")
    private String systemNames;

    @ApiModelProperty("业务系统ID（DTS_INTEGRATION:数据汇聚平台）")
    @Length(min=0, max=32)
    private String systemId = "DTS_INTEGRATION";

    @ApiModelProperty("来源业务ID")
    @Length(min=0, max=32)
    private String businessId;


    public DatasourceInfo(DtsDatasource dtsDatasource) {
        this(dtsDatasource, false);
    }

    public DatasourceInfo(DtsDatasource dtsDatasource, Boolean pooled) {
        this.databaseType = dtsDatasource.getDatabaseType();
        this.hostIp = dtsDatasource.getHostIp();
        this.databaseName = dtsDatasource.getDatabaseName();
        this.schemaName = dtsDatasource.getSchemaName();
        this.port = dtsDatasource.getPort();
        this.username = dtsDatasource.getUsername();
        this.password = dtsDatasource.getPassword();
        this.pooled = pooled;
        this.jdbcUrl = dtsDatasource.getUrl();
        this.systemIds = dtsDatasource.getSystemIds();
        this.systemNames = dtsDatasource.getSystemNames();
    }
}
