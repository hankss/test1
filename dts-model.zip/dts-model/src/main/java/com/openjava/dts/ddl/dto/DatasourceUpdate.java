package com.openjava.dts.ddl.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;

@ApiModel("数据源更新")
@Data
@EqualsAndHashCode(callSuper = false)
//@Accessors(chain = true)
public class DatasourceUpdate {

    @ApiModelProperty(value = "主机IP",required = false)
    @Length(min=0, max=512)
    private String hostIp;

    @ApiModelProperty(value = "端口号",required = false)
    @Max(99999L)
    private Long port;

    @ApiModelProperty(value = "用户名",required = false)
    @Length(min=0, max=128)
    private String username;

    @ApiModelProperty(value = "密码",required = false)
    @Length(min=0, max=128)
    private String password;
}
