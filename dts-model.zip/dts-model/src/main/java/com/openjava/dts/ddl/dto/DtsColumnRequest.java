package com.openjava.dts.ddl.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Length;

/**
 * 实体
 * @author
 *
 */
@ApiModel("数据表字段配置")
@Data
@EqualsAndHashCode(callSuper = false)
//@Accessors(chain = true)
public class DtsColumnRequest {
	
	@ApiModelProperty("字段列名")
	@Length(min=0, max=256)
	private String columnSource;

	@ApiModelProperty("字段类型")
	@Length(min=0, max=32)
	private String columnType;
	
	@ApiModelProperty("备注")
	@Length(min=0, max=512)
	private String columnComment;

	@ApiModelProperty("排序")
	private Integer order;
}