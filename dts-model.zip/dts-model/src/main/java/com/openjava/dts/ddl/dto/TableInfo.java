package com.openjava.dts.ddl.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Length;

import java.io.Serializable;
import java.util.List;

@ApiModel("数据表配置")
@Data
@EqualsAndHashCode(callSuper = false)
//@Accessors(chain = true)
@ToString
public class TableInfo implements Serializable {

    @ApiModelProperty("表名")
    @Length(min=0, max=64)
    private String tableSource;

    @ApiModelProperty("表备注")
    @Length(min=0, max=128)
    private String tableComment;

    @ApiModelProperty("查询SQL")
    @Length(min=0, max=3000)
    private String querySql;

    @ApiModelProperty("字段配置")
    private List<ColumnInfo> columns;

    @ApiModelProperty("是否重新建表")
    private Boolean ifCover=false;

    @ApiModelProperty("是否存在同步任务 2否 1存在同步任务")
    private Integer exsiteTask;
}
