package com.openjava.dts.ddl.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.util.List;

/**
 * @author 丘健里
 * @date 2020-04-15 17:56
 */
@ApiModel("数据表请求参数：Request")
@Data
@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class TableInfoRequest {

    @ApiModelProperty("数据源id")
    private String datasourceId;

    @ApiModelProperty("所选表的表信息")
    private List<TableInfo> list;

}
