package com.openjava.dts.ddl.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author: lsw
 * @Date: 2019/9/23 10:22
 */
@ApiModel("表同步信息")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TableSyncInfo {
    @ApiModelProperty("表名")
    private String tableSource;

    @ApiModelProperty("同步位置（1、资源目录；2、目标库）")
    private Integer syncPosition;
}
