package com.openjava.dts.ddl.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author: HL
 * @Date: 2019/10/10 14:13
 */
@ApiModel("指定数据表同步信息状况")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TableSyncStatusInfo {

    @ApiModelProperty(value = "1已同步 ,2未同步")
    private Integer syncStatus;

    @ApiModelProperty(value = "1同步到数据湖 ,2同步数据库源")
    private Integer syncPosition;

    @ApiModelProperty(value = "源表数据源")
    private String sourceDatasourceId;

    @ApiModelProperty(value = "源表名称")
    private String sourceTableName;

    @ApiModelProperty(value = "源表ID")
    private String sourceTableId;

    @ApiModelProperty(value = "目标数据源")
    private String targetDatasourceId;

    @ApiModelProperty(value = "目标表名字")
    private String targetTableName;

    @ApiModelProperty(value = "目标表ID")
    private String targetTableId;
}
