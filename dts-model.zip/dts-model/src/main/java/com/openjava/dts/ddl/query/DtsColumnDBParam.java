package com.openjava.dts.ddl.query;

import java.util.Date;

import org.ljdp.core.db.RoDBQueryParam;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * 查询对象
 * @author 子右
 *
 */
public class DtsColumnDBParam extends RoDBQueryParam {
	private Long eq_columnId;//表字段ID --主键查询
	
	private Long eq_tableId;//数据表ID = ?
	private String like_columnSource;//字段列名 like ?
	
	public Long getEq_columnId() {
		return eq_columnId;
	}
	public void setEq_columnId(Long columnId) {
		this.eq_columnId = columnId;
	}
	
	public Long getEq_tableId() {
		return eq_tableId;
	}
	public void setEq_tableId(Long tableId) {
		this.eq_tableId = tableId;
	}
	public String getLike_columnSource() {
		return like_columnSource;
	}
	public void setLike_columnSource(String columnSource) {
		this.like_columnSource = columnSource;
	}
}