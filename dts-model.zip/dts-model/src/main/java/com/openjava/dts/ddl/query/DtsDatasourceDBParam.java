package com.openjava.dts.ddl.query;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.ljdp.core.db.RoDBQueryParam;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * 查询对象
 * @author 子右
 *
 */
public class DtsDatasourceDBParam extends RoDBQueryParam {
	private String eq_datasourceId;//数据源ID --主键查询
	
	private Integer eq_databaseType;//数据库类型（ 0:Oracle 1:MySql高版本 2;Mysql低版本 3:PostgreSql 4:hive 5:SQL Server ） = ?
	private String eq_serviceName;//服务名 = ?
	private String like_databaseName;//数据库名 = ?
	private String eq_schemaName;//模式名称 = ?
	private String eq_createId;//创建人 = ?
	private Integer eq_databaseUse;//数据库用途（1、数据源；2、目标库） = ?
	private Integer eq_linkStatus;//连通状态（1、连通；2、未连通） = ?
	private String eq_businessId;//来源业务ID = ?
	private String eq_systemId;//业务系统ID（DTS_INTEGRATION:数据汇聚平台） = ?

	private Integer eq_deleted; //逻辑删除标志, 0未删除 1已删除
	public Integer getEq_deleted() {
		return eq_deleted;
	}
	public void setEq_deleted(Integer eq_deleted) {
		this.eq_deleted = eq_deleted;
	}

	private String flag; //去账号限制标志
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}


	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date gt_createTime;//开始时间

	public Date getGt_createTime() {
		return gt_createTime;
	}
	public void setGt_createTime(String gt_createTime) {
		if(StringUtils.isEmpty(gt_createTime)){
			this.gt_createTime = null;
		}else {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			try {
				this.gt_createTime = sdf.parse(gt_createTime);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
	}

	public String getEq_datasourceId() {
		return eq_datasourceId;
	}
	public void setEq_datasourceId(String datasourceId) {
		this.eq_datasourceId = datasourceId;
	}
	
	public Integer getEq_databaseType() {
		return eq_databaseType;
	}
	public void setEq_databaseType(Integer databaseType) {
		this.eq_databaseType = databaseType;
	}
	public String getEq_serviceName() {
		return eq_serviceName;
	}
	public void setEq_serviceName(String serviceName) {
		this.eq_serviceName = serviceName;
	}
	public String getLike_databaseName() {return like_databaseName;}
	public void setLike_databaseName(String databaseName) {
		this.like_databaseName = databaseName;
	}
	public String getEq_schemaName() {
		return eq_schemaName;
	}
	public void setEq_schemaName(String schemaName) {
		this.eq_schemaName = schemaName;
	}

	public String getEq_createId() {
		return eq_createId;
	}

	public void setEq_createId(String eq_createId) {
		this.eq_createId = eq_createId;
	}

	public Integer getEq_databaseUse() {
		return eq_databaseUse;
	}

	public void setEq_databaseUse(Integer eq_databaseUse) {
		this.eq_databaseUse = eq_databaseUse;
	}

	public Integer getEq_linkStatus() {
		return eq_linkStatus;
	}

	public void setEq_linkStatus(Integer eq_linkStatus) {
		this.eq_linkStatus = eq_linkStatus;
	}

	public String getEq_businessId() {
		return eq_businessId;
	}

	public void setEq_businessId(String eq_businessId) {
		this.eq_businessId = eq_businessId;
	}

	public String getEq_systemId() {
		return eq_systemId;
	}

	public void setEq_systemId(String eq_systemId) {
		this.eq_systemId = eq_systemId;
	}
}