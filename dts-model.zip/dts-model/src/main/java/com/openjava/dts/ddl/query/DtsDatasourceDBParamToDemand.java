package com.openjava.dts.ddl.query;

import lombok.Data;

/**
 * @author by 丘健里
 * @date 2020/2/13.
 */
@Data
public class DtsDatasourceDBParamToDemand extends DtsDatasourceDBParam {
    private String like_systemIds; //关联系统名字

    private Long eq_projectId;//项目id

    public String getLike_systemIds() {
        return like_systemIds;
    }

    public void setLike_systemIds(String like_systemIds) {
        this.like_systemIds = like_systemIds;
    }

}
