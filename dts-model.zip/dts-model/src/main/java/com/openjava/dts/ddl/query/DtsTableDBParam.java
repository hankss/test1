package com.openjava.dts.ddl.query;

import java.util.Date;

import org.ljdp.core.db.RoDBQueryParam;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * 查询对象
 * @author 子右
 *
 */
public class DtsTableDBParam extends RoDBQueryParam {
	private Long eq_tableId;//数据表ID --主键查询
	
	private String eq_tableSource;//数据表来源 = ?
	private String eq_datasourceId;//数据源ID = ?
	
	public Long getEq_tableId() {
		return eq_tableId;
	}
	public void setEq_tableId(Long tableId) {
		this.eq_tableId = tableId;
	}
	
	public String getEq_tableSource() {
		return eq_tableSource;
	}
	public void setEq_tableSource(String tableSource) {
		this.eq_tableSource = tableSource;
	}
	public String getEq_datasourceId() {
		return eq_datasourceId;
	}
	public void setEq_datasourceId(String datasourceId) {
		this.eq_datasourceId = datasourceId;
	}
}