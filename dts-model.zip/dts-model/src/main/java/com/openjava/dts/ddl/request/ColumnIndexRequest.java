package com.openjava.dts.ddl.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * @author jianli
 * @date 2020-06-12 11:24
 */
@ApiModel("列信息")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class ColumnIndexRequest {

    @ApiModelProperty("序号")
    private int index;

    @ApiModelProperty("列名")
    private String columnDefinition;

    @ApiModelProperty("类备注")
    private String columnName;

    @ApiModelProperty("字段类型")
    private String dataType;

}
