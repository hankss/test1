package com.openjava.dts.ddl.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * @author jianli
 * @date 2020-06-11 11:34
 * <p>
 * 如果有人看到了这个请求参数, 不要诧异,我自己都觉的很乱
 */

@ApiModel("列信息")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class ColumnRequest {

    @ApiModelProperty("序号")
    private int index;

    @ApiModelProperty("列名")
    private String columnDefinition;

    @ApiModelProperty("类备注")
    private String columnName;

    @ApiModelProperty("字段类型")
    private String dataType;

    @ApiModelProperty("where 条件内容(如果是时间类型话,这里放入time)")
    private String whereContent;

    @ApiModelProperty("开始时间")
    private String gtTime;

    @ApiModelProperty("结束时间")
    private String ltTime;

    @ApiModelProperty(value = "表名")
    private String tableName;

    @ApiModelProperty("每页显示数量")
    private Integer size;

    @ApiModelProperty("页码")
    private Integer page;

}
