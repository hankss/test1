package com.openjava.dts.ddl.request;

import com.google.common.collect.Lists;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 * @author jianli
 * @date 2020-06-12 9:30
 */
@ApiModel("列信息")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class ColumnRequestV1 implements Serializable {

    @ApiModelProperty("序号")
    private int index;

    @ApiModelProperty("列名")
    private String columnDefinition;

    @ApiModelProperty("类备注")
    private String columnName;

    @ApiModelProperty("字段类型")
    private String dataType;

    @ApiModelProperty("where 条件内容(如果是时间类型话,这里放入time)")
    private String whereContent;

    @ApiModelProperty("where 条件内容--时间类型的话,是string拼接的字符串")
    private Object columnValue;

    @ApiModelProperty("开始时间")
    private String gtTime;

    @ApiModelProperty("结束时间")
    private String ltTime;

    @ApiModelProperty("搜索时间,逗号隔开")
    private String gtTimeAndLtTime;

    public void setGtTimeAndLtTime() {
        //兼容前端的组件
        if (StringUtils.isBlank(this.gtTimeAndLtTime)) {
            return;
        }
        String[] split = this.gtTimeAndLtTime.split(",");
        this.setGtTime(split[0])
                .setLtTime(split[1]);
    }

    public void setWhereContent() {
        //获取到来自前端的信息,一开始就要执行
        if (Objects.isNull(columnValue)) {
            return;
        }
        //字段的值要过滤掉带有中文单引号
        if (String.valueOf(this.columnValue).contains("‘")
                || String.valueOf(this.columnValue).contains("’")
                || String.valueOf(this.columnValue).contains("'")) {
            return;
        }
        //设置where 兼容前端的组件
        if ("4".equals(dataType)) {
            //说明object是数组
            this.setGtTimeAndLtTime(this.getListFromObject());
        }
        if (StringUtils.isNotBlank(String.valueOf(this.columnValue)) && (!"null".equalsIgnoreCase(String.valueOf(this.columnValue)))) {
            this.setWhereContent(String.valueOf(this.columnValue));
        }
    }

    public String getListFromObject() {
        if (!"4".equals(this.dataType)) {
            return null;
        }
        //object 转数组
        Object obj = this.columnValue;
        //["2020-06-01 00:00:00","2020-07-01 23:59:59"]
        String str = String.valueOf(obj);
        if (!"null".equalsIgnoreCase(str)) {
            String substring = str.substring(1, str.length() - 1);
            //"2020-06-01 00:00:00","2020-07-01 23:59:59"
            return substring;
        }
        return null;
    }

}
