package com.openjava.dts.ddl.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author jianli
 * @date 2020-06-11 11:34
 */

@ApiModel("列信息")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ColumnRequestV2 {

    @ApiModelProperty("字段信息")
    private List<ColumnRequestV1> columnRequestV1List;

    @ApiModelProperty(value = "表名")
    private String tableName;

    @ApiModelProperty("每页显示数量")
    private Integer size;

    @ApiModelProperty("页码")
    private Integer page;

}
