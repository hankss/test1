package com.openjava.dts.ddl.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.openjava.dts.constants.DtsConstants;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Date;

/**
 * @author jianli
 * @date 2020-06-29 0029 11:00
 */
@ApiModel("数据源")
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@AllArgsConstructor
@NoArgsConstructor
@Slf4j
public class DtsDatasourceRequest implements Persistable<String>, Serializable {

    @ApiModelProperty("数据源ID")
    private String datasourceId;

    @ApiModelProperty("数据库类型（ 0:Oracle,1:MySql高版本 2：Mysql低版本 3:PostgreSQL  4:hive  5:SQL Server ）")
    @NotNull(message = "数据库类型不能为空")
    private Integer databaseType;

    @ApiModelProperty("数据库类型（ 0:Oracle,1:MySql高版本 2:Mysql低版本 3:PostgreSql 4:hive 5:SQL Server ）名称")
    private String databaseTypeName;

    @ApiModelProperty("集群连接地址URL")
    private String url;

    @ApiModelProperty("主机IP")
    private String hostIp;

    @ApiModelProperty("服务名")
    private String serviceName;

    @ApiModelProperty("数据库名")
    private String databaseName;

    @ApiModelProperty("模式名称")
    private String schemaName;

    @ApiModelProperty("端口号")
    private Long port;

    @ApiModelProperty("用户名")
    private String username;

    @ApiModelProperty("委托用户")
    private String principal;

    @ApiModelProperty("密码")
    private String password;

    @ApiModelProperty("安全认证类型(USER-PWD，KERBEROS，KERBEROS-HW）")
    private String securityType;

    @ApiModelProperty("keytab文件")
    private String keytab;

    @ApiModelProperty("krb5.conf文件")
    private String krb5conf;

    @ApiModelProperty("hdfs连接地址")
    private String hdfsUrl;

    @ApiModelProperty("表关联的hdfs文件路径")
    private String hdfsPath;

    @ApiModelProperty("数据库描述")
    private String description;

    @ApiModelProperty("数据库用途（1、数据源；2、目标库）")
    private Integer databaseUse;

    @ApiModelProperty("数据库用途名称（1、数据源；2、目标库）")
    private String databaseUseName;

    @ApiModelProperty("关联局系统id")
    private String systemIds;

    @ApiModelProperty("关联局系统名字")
    private String systemNames;

    @ApiModelProperty("连通状态（1、连通；2、未连通）")
    private Integer linkStatus;

    @ApiModelProperty("连通状态名称（1、连通；2、未连通）")
    private String linkStatusName;

    @ApiModelProperty("变更提醒（0、不提醒；1、提醒）")
    private Integer changeRemind;

    @ApiModelProperty("数据库来源")
    private String databaseSource;

    @ApiModelProperty("数据库来源名称")
    private String databaseSourceName;

    @ApiModelProperty("创建人ID")
    private String createId;

    @ApiModelProperty("创建人名称")
    private String createName;

    @ApiModelProperty("创建时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createTime;

    @ApiModelProperty("修改人ID")
    private String modifyId;

    @ApiModelProperty("修改人名称")
    private String modifyName;

    @ApiModelProperty("修改时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifyTime;

    @ApiModelProperty("来源业务ID")
    private String businessId;

    @ApiModelProperty("业务系统ID（DTS_INTEGRATION:数据汇聚平台）")
    private String systemId = "DTS_INTEGRATION";

    @ApiModelProperty("项目id")
    private Long projectId;

    @ApiModelProperty("项目名称")
    private String projectName;

    @ApiModelProperty("变更提醒，默认为0不提醒，1提醒")
    private Integer modifyRemindEnabled;

    @ApiModelProperty("RAC是否开启，默认0不开启，1开启")
    private Integer racEnabled;

    @ApiModelProperty("读写是否分离，默认0不开启，1开启")
    private Integer readWriteDivideEnabled;

    @ApiModelProperty("主从分离，默认0不开启，1开启")
    private Integer masterSlaveEnabled;

    @ApiModelProperty("是否集群，默认0不集群，1集群")
    private Integer clusterEnabled;

    @ApiModelProperty("备库类型，默认0热备，1冷备")
    private Integer backupType;

    @ApiModelProperty("是否容灾备份，默认0不开启，1开启")
    private Integer disasterBackupEnabled;

    @ApiModelProperty("当前数据源所拥有表的总数")
    private Long tableNumber;

    @ApiModelProperty("是否新增")
    private Boolean isNew;

    @ApiModelProperty("URL上的数据库名")
    private String dbName;

    @Override
    public String getId() {
        return this.datasourceId;
    }

    @Override
    public boolean isNew() {
        if (isNew != null) {
            return isNew;
        }
        if (this.datasourceId != null) {
            return false;
        }
        return true;
    }

    public String getJdbcDriverClass() {
        if (databaseType == null) {
            return null;
        }

        if (databaseType.equals(DtsConstants.DATABASE_TYPE_ORACLE)) {
            return "oracle.jdbc.OracleDriver";
        } else if (databaseType.equals(DtsConstants.DATABASE_TYPE_MYSQL_NEW)) {
            return "com.mysql.cj.jdbc.Driver";
        } else if (databaseType.equals(DtsConstants.DATABASE_TYPE_MYSQL_OLD)) {
            return "com.mysql.jdbc.Driver";
        } else if (databaseType.equals(DtsConstants.DATABASE_TYPE_POSTGRES)) {
            return "org.postgresql.Driver";
        } else if (databaseType.equals(DtsConstants.DATABASE_TYPE_HIVE)
                || databaseType.equals(DtsConstants.DATABASE_TYPE_HIVE_HUAWEI)) {
            return "org.apache.hive.jdbc.HiveDriver";
        }
        return null;
    }

    public void splicingUrl() {
        //拼接URL,不需要事务
        Integer databaseType = this.databaseType;
        boolean oracleFlag = DtsConstants.DATABASE_TYPE_ORACLE.equals(databaseType);
        boolean mysqlNewFlag = DtsConstants.DATABASE_TYPE_MYSQL_NEW.equals(databaseType);
        boolean mysqlOldFlag = DtsConstants.DATABASE_TYPE_MYSQL_OLD.equals(databaseType);
        boolean postgresFlag = DtsConstants.DATABASE_TYPE_POSTGRES.equals(databaseType);
        boolean hiveFlag = DtsConstants.DATABASE_TYPE_HIVE.equals(databaseType);
        boolean sqlServerFlag = DtsConstants.DATABASE_TYPE_SQL_SERVER.equals(databaseType);
        boolean hiveHuaWeiFlag = DtsConstants.DATABASE_TYPE_HIVE_HUAWEI.equals(databaseType);
        boolean gaussDBFlag = DtsConstants.DATABASE_TYPE_GAUSSDB.equals(databaseType);
        if (StringUtils.isNotBlank(this.url))
            return;
        if (oracleFlag)
            this.url = this.getOracleUrl();
        if (mysqlNewFlag)
            this.url = this.getMysqlNewUrl();
        if (mysqlOldFlag)
            this.url = this.getMysqlOldUrl();
        if (postgresFlag)
            this.url = this.getPostgresUrl();
        if (hiveFlag)
            this.url = this.getHiveUrl();
        if (sqlServerFlag)
            this.url = this.getSqlServerUrl();
        if (hiveHuaWeiFlag)
            this.url = this.getHiveHuaWeiUrl();
        if (gaussDBFlag)
            this.url = this.getGuassDBUrl();
        log.info("拼接后的URL: [{}]", this.url);
    }

    private String getOracleUrl() {
        StringBuilder urlDest = new StringBuilder("jdbc:oracle:thin:@//");
        urlDest.append(this.getHostIp()).append(":").append(this.getPort()).append("/").append(this.getDbName());
        return urlDest.toString();
    }

    private String getMysqlNewUrl() {
        StringBuilder urlDest = new StringBuilder("jdbc:mysql://");
//        urlDest.append(this.getHostIp()).append(":").append(this.getPort()).append("/").append(this.getDbName()).append("?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=UTC");
        urlDest.append(this.getHostIp()).append(":").append(this.getPort()).append("/").append(this.getDbName());
        return urlDest.toString();
    }

    private String getMysqlOldUrl() {
        StringBuilder urlDest = new StringBuilder("jdbc:mysql://");
//        urlDest.append(this.getHostIp()).append(":").append(this.getPort()).append("/").append(this.getDbName()).append("?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=UTC");
        urlDest.append(this.getHostIp()).append(":").append(this.getPort()).append("/").append(this.getDbName());
        return urlDest.toString();
    }

    private String getPostgresUrl() {
        StringBuilder urlDest = new StringBuilder("jdbc:postgresql://");
        urlDest.append(this.getHostIp()).append(":").append(this.getPort()).append("/").append(this.getDbName());
        if (StringUtils.isNotBlank(this.getSchemaName())) {
            urlDest.append("?currentSchema=").append(this.getSchemaName());
        }
        return urlDest.toString();
    }

    private String getHiveUrl() {
        StringBuilder urlDest = new StringBuilder("jdbc:hive2://");
        urlDest.append(this.getHostIp());
        if (this.getPort() != null && this.getPort().intValue() > 0) {
            urlDest.append(":").append(this.getPort());
        }
        urlDest.append("/");
        if (this.getDbName() != null) {
            urlDest.append(this.getDbName());
        }
        return urlDest.toString();
    }

    private String getSqlServerUrl() {
        StringBuilder urlDest = new StringBuilder("jdbc:sqlserver://");
        urlDest.append(this.getHostIp());
        if (this.getPort() != null && this.getPort().intValue() > 0) {
            urlDest.append(":").append(this.getPort());
        }
        urlDest.append(";").append("DatabaseName=");
        if (this.getDbName() != null) {
            urlDest.append(this.getDbName());
        }
        return urlDest.toString();
    }

    private String getHiveHuaWeiUrl() {
        StringBuilder urlDest = new StringBuilder("jdbc:hive2://");
        urlDest.append(this.getHostIp());
        if (this.getPort() != null && this.getPort().intValue() > 0) {
            urlDest.append(":").append(this.getPort());
        }
        urlDest.append("/");
        if (this.getDbName() != null) {
            urlDest.append(this.getDbName());
        }
        return urlDest.toString();
    }

    private String getGuassDBUrl() {
        StringBuilder urlDest = new StringBuilder("jdbc:zenith:@");
        urlDest.append(this.getHostIp());
        if (this.getPort() != null && this.getPort().intValue() > 0) {
            urlDest.append(":").append(this.getPort());
        }
        return urlDest.toString();
    }

}
