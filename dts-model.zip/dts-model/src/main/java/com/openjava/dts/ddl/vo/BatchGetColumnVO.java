package com.openjava.dts.ddl.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author 丘健里
 * @date 2020-04-24 14:51
 */
@ApiModel("批量获取列信息")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BatchGetColumnVO {

    @ApiModelProperty("数据源id")
    private String datasourceId;

    @ApiModelProperty("表名list")
    private List<String> tableSourceList;

}
