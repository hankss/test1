package com.openjava.dts.ddl.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author 丘健里
 * @date 2020-04-22 11:40
 */
@ApiModel("批量获取表信息")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BatchGetTableInfo {

    @ApiModelProperty("表名list")
    private List<String> tableNameList;

    @ApiModelProperty("数据源id")
    private String datasourceId;

    @ApiModelProperty("系统id")
    private String systemId;

}
