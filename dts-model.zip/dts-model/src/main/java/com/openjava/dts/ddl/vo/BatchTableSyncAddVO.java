package com.openjava.dts.ddl.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author 丘健里
 * @date 2020-04-22 13:58
 */
@ApiModel("批量更新表结构")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BatchTableSyncAddVO {

    @ApiModelProperty("数据源ID(源表)")
    private String datasourceId;

    @ApiModelProperty("关联系统id")
    private String systemId;

    @ApiModelProperty("关联系统名字")
    private String systemName;

    @ApiModelProperty("项目id")
    private Long projectId;

    @ApiModelProperty("项目名字")
    private String projectName;

    @ApiModelProperty("源表表名")
    private List<String> sourceTableNameList;

    @ApiModelProperty("目标表表名")
    private List<String> targetTableNameList;

}
