package com.openjava.dts.ddl.vo;

import com.openjava.dts.ddl.domain.DtsDatasource;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author: lsw
 * @Date: 2019/9/23 14:35
 */
@ApiModel("数据源VO")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DtsDatasourceVO {

    @ApiModelProperty("数据源ID")
    private String datasourceId;

    @ApiModelProperty("数据库名")
    private String databaseName;

    @ApiModelProperty("数据库类型（ 0:Oracle 1:MySql高版本 2;Mysql低版本 3:PostgreSql 4:hive 5:SQL Server ）")
    private Integer databaseType;

    @ApiModelProperty("数据库类型（ 0:Oracle 1:MySql高版本 2;Mysql低版本 3:PostgreSql 4:hive 5:SQL Server ）名称")
    private String databaseTypeName;

    @ApiModelProperty("数据库用途（1、数据源；2、目标库）")
    private Integer databaseUse;

    @ApiModelProperty("数据库用途名称（1、数据源；2、目标库）")
    private String databaseUseName;

    public DtsDatasourceVO(DtsDatasource dtsDatasource) {
        this.datasourceId = dtsDatasource.getDatasourceId();
        this.databaseName = dtsDatasource.getDatabaseName();
        this.databaseType = dtsDatasource.getDatabaseType();
        this.databaseTypeName = dtsDatasource.getDatabaseTypeName();
        this.databaseUse = dtsDatasource.getDatabaseUse();
        this.databaseUseName = dtsDatasource.getDatabaseUseName();
    }
}
