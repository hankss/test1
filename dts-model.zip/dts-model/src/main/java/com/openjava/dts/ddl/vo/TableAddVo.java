package com.openjava.dts.ddl.vo;

import com.openjava.dts.ddl.domain.DtsColumn;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author hl
 */
@ApiModel("表信息VO")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TableAddVo {

    @ApiModelProperty("数据源ID")
    private String datasourceId;

    @ApiModelProperty("表名")
    private String tableName;

    @ApiModelProperty("表描述")
    private String tableComments;

    @ApiModelProperty("表字段属性")
    private List<DtsColumn> columnList;
}
