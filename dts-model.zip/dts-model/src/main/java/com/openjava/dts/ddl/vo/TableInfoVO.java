package com.openjava.dts.ddl.vo;

import com.openjava.dts.ddl.dto.ColumnInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import org.hibernate.validator.constraints.Length;

import java.util.List;

/**
 * @author 丘健里
 * @date 2020-04-14 15:36
 */
@ApiModel("数据表返回信息VO")
@Data
@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class TableInfoVO {

    @ApiModelProperty("表名")
    @Length(min=0, max=64)
    private String tableSource;

    @ApiModelProperty("表主键")
    private ColumnInfo columnInfo;

    @ApiModelProperty("表备注")
    @Length(min=0, max=128)
    private String tableComment;

    @ApiModelProperty("查询SQL")
    @Length(min=0, max=3000)
    private String querySql;

    @ApiModelProperty("字段配置")
    private ColumnInfo columns;

    @ApiModelProperty("是否重新建表")
    private Boolean ifCover=false;

    @ApiModelProperty("是否存在同步任务 2否 1存在同步任务")
    private Integer exsiteTask;
}
