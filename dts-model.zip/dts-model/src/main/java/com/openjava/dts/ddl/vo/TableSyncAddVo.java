package com.openjava.dts.ddl.vo;

import com.openjava.dts.ddl.domain.DtsColumn;
import com.openjava.dts.ddl.dto.ColumnInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author 丘健里
 * @date 2020/3/10
 */
@ApiModel("sync表信息VO")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TableSyncAddVo {
    @ApiModelProperty("数据源ID(源表)")
    private String datasourceId;

    @ApiModelProperty("表名(目标表表名)")
    private String tableName;

    @ApiModelProperty("表描述(源表)")
    private String tableComments;

    @ApiModelProperty("表字段属性(源表)")
    private List<ColumnInfo> columnList;

}
