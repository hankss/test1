package com.openjava.dts.ddl.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author: lsw
 * @Date: 2019/9/23 11:04
 */
@ApiModel("表同步信息VO")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TableSyncInfoVO {

    @ApiModelProperty("表名")
    private String tableSource;

    @ApiModelProperty("是否同步到资源目录")
    private Boolean syncToResourceDirectory;

    @ApiModelProperty("是否同步到目标库")
    private Boolean syncToTargetSource;
}
