package com.openjava.dts.job.domain;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.openjava.dts.job.dto.DtsExchangeComponentParameter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 实体
 * @author hl
 *
 */
@ApiModel("DtsComponent")
@Data
@EqualsAndHashCode(of = {"id"},callSuper = false)
@Accessors(chain = true)
@Entity
@Table(name = "DTS_COMPONENT")
public class DtsComponent implements Persistable<Long>,Serializable {
    
    @ApiModelProperty("id")
    @Id
    @Column(name = "id")
    private Long id;
    
    @ApiModelProperty("组件名称")
    @Length(min=0, max=255)
    @Column(name = "name")
    private String name;
    
    @ApiModelProperty("1数据源输入 2归集库输入 3资源目录输入 4需求任务输入 5归集库输出 6资源目录输出 7.需求任务输出 8字段值转换 9表整合转换 10 数据过滤转换")
    @Column(name = "compent_type")
    private Integer compentType;
    
    @ApiModelProperty("所属科室系统")
    @Length(min=0, max=255)
    @Column(name = "system_name")
    private String systemName;
    
    @ApiModelProperty("所属科室ids")
    @Length(min=0, max=255)
    @Column(name = "system_ids")
    private String systemIds;
    
    @ApiModelProperty("数据源名字")
    @Length(min=0, max=128)
    @Column(name = "datasource_name")
    private String datasourceName;
    
    @ApiModelProperty("数据源id")
    @Length(min=0, max=128)
    @Column(name = "datasource_id")
    private String datasourceId;
    
    @ApiModelProperty("数据库名字")
    @Length(min=0, max=128)
    @Column(name = "datasource_dbname")
    private String datasourceDbname;
    
    @ApiModelProperty("同步表名")
    @Length(min=0, max=128)
    @Column(name = "table_name")
    private String tableName;
    
    @ApiModelProperty("切分键")
    @Length(min=0, max=256)
    @Column(name = "split_key")
    private String splitKey;

    @ApiModelProperty("任务id")
    @Max(9223372036854775806L)
    @Column(name = "job_id")
    private Long jobId;

    @ApiModelProperty("前端组件自带的cid")
    @JsonProperty("cId")
    @Column(name = "c_id")
    private String cId;

    @ApiModelProperty("该属性表示type=15|16的批量组件的cId，批量组件拆分多个子组件后，batchComponentId与cId代表父子关系")
    @Column(name = "batch_component_id")
    private String batchComponentId;

    @ApiModelProperty("前置关联组件的cid,json数组")
    @Column(name = "pre_")
    private String pre;

    @ApiModelProperty("后置关联组件的cid,json数组")
    @Column(name = "next_")
    private String next;

    @ApiModelProperty("调试器id")
    @Max(9223372036854775806L)
    @Column(name = "xxl_job_id")
    private Long xxlJobId;
    
    @ApiModelProperty("0全量1增量")
    @Max(9L)
    @Column(name = "sync_type")
    private Integer syncType;
    
    @ApiModelProperty("并发速率")
    @Max(99999999L)
    @Column(name = "concurrent_num")
    private Integer concurrentNum;
    
    @ApiModelProperty("是否限流（0、否；1、是）")
    @Max(9L)
    @Column(name = "is_limit_rate")
    private Integer isLimitRate;
    
    @ApiModelProperty("同步速率")
    @Max(99999L)
    @Column(name = "sync_rate")
    private Integer syncRate;
    
    @ApiModelProperty("清理规则（1、写入前保留已有数据；2、写入前删除已有数据）")
    @Max(9L)
    @Column(name = "clean_rule")
    private Integer cleanRule;
    
    @ApiModelProperty("启动状态（0、已停止；1、执行中）")
    @Max(9L)
    @Column(name = "launch_status")
    private Integer launchStatus;
    
    @ApiModelProperty("状态（1、可用，待启动；2、队列中待执行；3、运行中；4、任务执行成功；5、任务执行失败；6、暂停中）")
    @Max(9L)
    @Column(name = "status")
    private Integer status;


    @ApiModelProperty("是否生成表 0不 1是")
    @Max(9L)
    @Column(name = "create_table")
    private Integer createTable;
    
    @ApiModelProperty("增量时间字段")
    @Length(min=0, max=64)
    @Column(name = "increment_field")
    private String incrementField;
    
    @ApiModelProperty("上一次运行增量时间")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "last_increment_time")
    private Date lastIncrementTime;
    
    @ApiModelProperty("增量开始时间")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "increment_start_time")
    private Date incrementStartTime;

    @ApiModelProperty("增量开始时间是否重置，默认0，不重置，1为已重置")
    @Column(name = "increment_reset")
    private Integer incrementReset;
    
    @ApiModelProperty("组件参数json")
    @Column(name = "param")
    private String param;

    @ApiModelProperty("需求任务组件:任务名称")
    @Length(min=0, max=256)
    @Column(name = "task_name")
    private String taskName;

    @ApiModelProperty("需求任务组件:任务id，")
    @Max(9223372036854775806L)
    @Column(name = "task_id")
    private Long taskId;

    @ApiModelProperty("对应是需求任务接口的relevanceId,该属性用于数据同步过程中调用需求任务接口返回数据库连接信息")
    @Column(name = "relevance_id")
    private Long relevanceId;

    @ApiModelProperty("需求任务组件分类：组件类型：1：输入 2：输出，该属性用于数据同步过程中调用需求任务接口返回数据库连接信息,对应接口参数是componentType")
    @Column(name = "task_component_type")
    private Integer taskComponentType;

    @ApiModelProperty("代表是从哪里开始创建同步任务的，任务类型：0：数据集成 1：需求工单 2：协作工单；该属性用于数据同步过程中调用需求任务接口返回数据库连接信息,对应接口参数是taskType")
    @Column(name = "task_type")
    private Integer taskType;

    @ApiModelProperty("需求任务组件:FinalCommitId")
    @Max(9223372036854775806L)
    @Column(name = "task_final_commit_id")
    private Long taskFinalCommitId;

    @ApiModelProperty("表别名,通常对应是中文名")
    @Length(min=0, max=256)
    @Column(name = "table_alias")
    private String tableAlias;

    @Transient
    @JsonIgnore
    private DtsExchangeComponentParameter paramEntity;
    
    @ApiModelProperty("资源目录id")
    @Max(9223372036854775806L)
    @Column(name = "resource_id")
    private Long resourceId;
    
    @ApiModelProperty("资源目录名称")
    @Length(min=0, max=500)
    @Column(name = "resource_name")
    private String resourceName;
    
    @ApiModelProperty("资源目录编码")
    @Length(min=0, max=128)
    @Column(name = "resource_code")
    private String resourceCode;
    
    @ApiModelProperty("数据湖目录位置")
    @Length(min=0, max=255)
    @Column(name = "resource_path")
    private String resourcePath;
    
    @ApiModelProperty("数据湖目录位置code")
    @Length(min=0, max=255)
    @Column(name = "resource_path_code")
    private String resourcePathCode;
    
    @ApiModelProperty("创建人ID")
    @Column(name = "create_id")
    private Long createId;
    
    @ApiModelProperty("创建人名称")
    @Length(min=0, max=64)
    @Column(name = "create_name")
    private String createName;
    
    @ApiModelProperty("创建时间")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "create_time")
    private Date createTime;
    
    @ApiModelProperty("修改人ID")
    @Column(name = "modify_id")
    private Long modifyId;
    
    @ApiModelProperty("修改人名称")
    @Length(min=0, max=64)
    @Column(name = "modify_name")
    private String modifyName;
    
    @ApiModelProperty("修改时间")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modify_time")
    private Date modifyTime;
    
    @ApiModelProperty("来源业务ID")
    @Length(min=0, max=64)
    @Column(name = "business_id")
    private String businessId;
    
    @ApiModelProperty("业务系统ID（DTS_INTEGRATION:数据汇聚平台）")
    @Length(min=0, max=256)
    @Column(name = "system_id")
    private String systemId;

    @Transient
    private List<DtsComponentFieldMapping> selected;
    
    
    @ApiModelProperty("是否新增")
    @Transient
    private Boolean isNew;

    @Override
    public Long getId() {
        return this.id;
    }

    @ApiModelProperty("组成组件查询sql,通常是连表查询sql")
    @Length(min=0, max=5000)
    @Column(name = "query_sql")
    public String querySql;

    @ApiModelProperty("写入字段")
    @JsonIgnore
    @Transient
    public String writerColumn;

    @ApiModelProperty("写入字段")
    @JsonIgnore
    @Transient
    public Long mappingId;

    @ApiModelProperty("其它标识")
    @JsonIgnore
    @Transient
    public String otherFlag;

    @ApiModelProperty("项目id")
    @Max(999999999999999999L)
    @Column(name = "project_id")
    private Long projectId;

    @ApiModelProperty("项目名称")
    @Length(min = 0, max = 256)
    @Column(name = "project_name")
    private String projectName;

    @ApiModelProperty("组件类型分组,默认为null，取值：input-输入组件，output-输出组件，transfer-转换组件")
    @Column(name = "category_")
    @Length(min = 0, max = 64)
    private String category;

    @ApiModelProperty("默认为0，0代表不会选择整个库的表，1代表整个库的表都用到，当值为1时，tableNameList不用传")
    @Column(name = "entire_enable")
    private Integer entireEnable;

    @ApiModelProperty("批量组件多选表名集合")
    @Column(name = "table_names")
    private String tableNames;

    @ApiModelProperty("建表总数，与tableNames一致，在建表引擎启动时，过滤完已同步的表")
    @Column(name = "create_total")
    private Integer createTotal;

    @ApiModelProperty("批量组件切分键集合")
    @Column(name = "split_key_names")
    private String splitKeyNames;

    @ApiModelProperty("批量数据源输入组件增量集合")
    @Column(name = "increment_fields")
    private String incrementFields;

    @ApiModelProperty("表注释")
    @Column(name = "table_comment")
    private String tableComment;

    @ApiModelProperty("主题分类ID")
    @Length(min=0, max=64)
    @Column(name = "subject_type_id")
    private String subjectTypeId;

    @ApiModelProperty("主题分类名称")
    @Length(min=0, max=512)
    @Column(name = "subject_type_name")
    private String subjectTypeName;


    @Transient
    @ApiModelProperty("批量组件多选表名集合，接收参数时使用")
    private List<String> tableNameList;

    @Transient
    @ApiModelProperty("批量组件切分键集合，接收参数时使用")
    private List<JSONObject> splitKeyList;

    @Transient
    @ApiModelProperty("批量数据源输入组件增量集合，接收参数时使用")
    private  List<JSONObject> incrementFieldList;

    @Transient
    @ApiModelProperty("批量归集库输出组件字段映射集合，在处理json转换为对象时，临时使用")
    private List<DtsComponentFieldMapping> batchComponentUsing;

    public void setTableNameList(List<String> tableNameList) {
        this.tableNameList = tableNameList;
        this.tableNames = JSON.toJSONString(this.tableNameList);
    }

    public void setSplitKeyList(List<JSONObject> splitKeyList) {
        this.splitKeyList = splitKeyList;
        this.splitKeyNames = JSON.toJSONString(this.splitKeyList);
    }

    public void setIncrementFieldList(List<JSONObject> incrementFieldList) {
        this.incrementFieldList = incrementFieldList;
        this.incrementFields = JSON.toJSONString(this.incrementFieldList);
    }

    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
        if(isNew != null) {
            return isNew;
        }
        if(this.id != null) {
            return false;
        }
        return true;
    }


    public static final int DTS_COMPONENT_INPUT_TYPE_DATASOURCE = 1;//数据源输入组件
    public static final int DTS_COMPONENT_INPUT_TYPE_COLLECT = 2;//归集库输入组件
    public static final int DTS_COMPONENT_INPUT_TYPE_RESOURCE_FOLDER = 3;//资源目录输入组件
    public static final int DTS_COMPONENT_INPUT_TYPE_REQUIREMENT_TASK = 4;//需求任务输入组件
    public static final int DTS_COMPONENT_OUTPUT_TYPE_COLLECT = 5;//汇集库输出组件
    public static final int DTS_COMPONENT_OUTPUT_TYPE_RESOURCE_FOLDER = 6;//资源目录输出组件
    public static final int DTS_COMPONENT_OUTPUT_TYPE_REQUIREMENT_TASK = 7;//需求任务输出组件
    public static final int DTS_COMPONENT_EXCHANGE_TYPE_FIELD_VALUE = 8;//字段值转换组件
    public static final int DTS_COMPONENT_EXCHANGE_TYPE_TABLE_INTEGRATION = 9;//表整合转换组件
    public static final int DTS_COMPONENT_EXCHANGE_TYPE_DATA_FILTER = 10;//数据过滤转换组件
    public static final int DTS_COMPONENT_OUTPUT_TYPE_USER_DEFINED = 11;//自定义输出组件
    public static final int USER_DEFINED_QUERY_SQL = 12;//自定义sql ,兼容数据集及自定sql
    public static final int DTS_COMPONENT_MAIN_LAKE_INPUT_RESOURCE_FOLDER = 13; // 主湖资源目录输入组件
    public static final int DTS_COMPONENT_MAIN_LAKE_OUTPUT_RESOURCE_FOLDER = 14; // 主湖资源目录输出组件
    public static final int DTS_COMPONENT_INPUT_TYPE_BATCH_DATASOURCE = 15;//批量数据源输入组件
    public static final int DTS_COMPONENT_INPUT_TYPE_BATCH_DATASOURCE_CHILD = 150;//批量数据源输入组件拆分后的子组件
    public static final int DTS_COMPONENT_OUTPUT_TYPE_BATCH_COLLECT = 16;//批量归集库输出组件
    public static final int DTS_COMPONENT_OUTPUT_TYPE_BATCH_COLLECT_CHILD = 160;//批量归集库输出组件拆分后的子组件
    public static final int DTS_COMPONENT_EXCHANGE_TYPE_DUPLICATION_FILTER = 17;//数据去重转换组件
    public static final int DTS_COMPONENT_EXCHANGE_TYPE_NULL_REPLACEMENT = 18;//空值替换转换组件
    public static final int DTS_COMPONENT_EXCHANGE_TYPE_CONTENT_CLEANUP = 19;//字段内容清洗转换组件
    public static final int DTS_COMPONENT_EXCHANGE_TYPE_DATA_ORDER = 20;//数据排序转换组件
    public static final int DTS_COMPONENT_EXCHANGE_TYPE_EXPRESSION = 21;//表达式转换组件

    public static final int DTS_COMPONENT_INPUT_TYPE_STANDARD = 23;//标准库输入组件
    public static final int DTS_COMPONENT_OUTPUT_TYPE_STANDARD = 22;//标准库输出组件
    public static final int DTS_COMPONENT_INPUT_TYPE_BASE = 24;//基础库输入组件
    public static final int DTS_COMPONENT_OUTPUT_TYPE_BASE = 25;//基础库输出组件
    public static final int DTS_COMPONENT_INPUT_TYPE_SUBJECT = 26;//主题库输入组件
    public static final int DTS_COMPONENT_OUTPUT_TYPE_SUBJECT = 27;//主题库输出组件
    public static final int DTS_COMPONENT_OUTPUT_TYPE_SPECIAL_TOPIC = 28;//专题库输出组件

}