package com.openjava.dts.job.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Persistable;

import javax.persistence.*;
import javax.validation.constraints.Max;
import java.io.Serializable;

/**
 * 实体
 * @author hl
 *
 */
@ApiModel("DtsComponentFieldMapping")
@Data
@EqualsAndHashCode(of ={"columnId"},callSuper = false)
@Accessors(chain = true)
@Entity
@Table(name = "DTS_COMPONENT_FIELD_MAPPING")
public class DtsComponentFieldMapping implements Persistable<Long>,Serializable {
	
	@ApiModelProperty("表字段ID")
	@Id
	@Column(name = "column_id")
	private Long columnId;
	
	@ApiModelProperty("任务id")
	@Max(9223372036854775806L)
	@Column(name = "job_id")
	private Long jobId;
	
	@ApiModelProperty("字任务id")
	@Max(9223372036854775806L)
	@Column(name = "item_job_id")
	private Long itemJobId;

	@ApiModelProperty("组件id,字段所属组件")
	@Max(9223372036854775806L)
	@Column(name = "compent_id")
	private Long compentId;

	@Column(name = "group_id")
	@ApiModelProperty("分组id，仅用于前端分组展示字段映射列表")
	private String groupId;

	@ApiModelProperty("前端组件cId")
	@Column(name = "c_id")
	@JsonProperty("cId")
	private String cId;

	@ApiModelProperty("组件名称")
	@Column(name = "component_name")
	@JsonProperty("componentName")
    private String componentName;

	@ApiModelProperty("前端映射目标组件id")
	@Column(name = "c_tar_id")
	@JsonProperty("cTarId")
    private String cTarId;

	@ApiModelProperty("前端映射源组件id")
	@Column(name = "c_src_id")
	@JsonProperty("cSrcId")
    private String cSrcId;

    @ApiModelProperty("映射源组件id")
    @Max(9223372036854775806L)
    @Column(name = "compent_src_id")
    private Long compentSrcId;

	@ApiModelProperty("组件源名称")
	@Column(name = "component_src_name")
	@JsonProperty("componentSrcName")
	private String componentSrcName;

	@ApiModelProperty("映射目标组件id")
	@Max(9223372036854775806L)
	@Column(name = "compent_tar_id")
	private Long compentTarId;

	@ApiModelProperty("组件目标名称")
	@Column(name = "component_tar_name")
	@JsonProperty("componentTarName")
	private String componentTarName;
	
	@ApiModelProperty("字段列名")
	@Length(min=0, max=256)
	@Column(name = "column_source")
	private String columnSource;

	@ApiModelProperty("所属表名称")
	@Length(min=0, max=1024)
	@Column(name = "table_name")
	private String tableName;
	
	@ApiModelProperty("是否更新字段")
	@Max(9L)
	@Column(name = "is_update_column")
	private Integer isUpdateColumn;
	
	@ApiModelProperty("字段类型")
	@Length(min=0, max=64)
	@Column(name = "column_type")
	private String columnType;
	
	@ApiModelProperty("字段长度")
	@Max(9999999999999999L)
	@Column(name = "column_precision")
	private Integer columnPrecision;
	
	@ApiModelProperty("小数位数")
	@Max(99999999L)
	@Column(name = "column_scale")
	private Integer columnScale;
	
	@ApiModelProperty("默认值")
	@Length(min=0, max=256)
	@Column(name = "default_value")
	private String defaultValue;
	
	@ApiModelProperty("是否主键（0否，1是）")
	@Column(name = "is_primary_key")
	private Boolean isPrimaryKey;
	
	@ApiModelProperty("字段可否为空（0否，1是）")
	@Max(9L)
	@Column(name = "nullable")
	private Integer nullable;
	
	@ApiModelProperty("备注")
	@Length(min=0, max=512)
	@Column(name = "column_comment")
	private String columnComment;
	
	@ApiModelProperty("字段在文件中的位置")
	@Max(99999999999L)
	@Column(name = "column_index")
	private Integer columnIndex;
	
	@ApiModelProperty("排序")
	@Max(99999999999L)
	@Column(name = "sort")
	private Integer sort;

	@ApiModelProperty("前端映射源组件id")
	@Length(min=0, max=128)
	@Column(name = "belong_table_name")
	private String belongTableName;

	@ApiModelProperty("是否新增")
	@Transient
    private Boolean isNew;
	
	@Transient
    @JsonIgnore
    @Override
    public Long getId() {
        return this.columnId;
	}
    
    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
    	if(isNew != null) {
    		return isNew;
    	}
    	if(this.columnId != null) {
    		return false;
    	}
    	return true;
    }
    
}