package com.openjava.dts.job.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Date;

/**
 * 实体
 * @author 子右
 *
 */
@ApiModel("数据传输任务对象")
@Data
@EqualsAndHashCode(callSuper = false)
//@Accessors(chain = true)
@Entity
@Table(name = "DTS_JOB")
public class DtsJob implements Persistable<Long>,Serializable {
	
	@ApiModelProperty("任务ID")
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "dtsjobid")
//	@SequenceGenerator(name = "dtsjobid", sequenceName = "SEQ_COMMON_ID", allocationSize = 1)
	@Column(name = "JOB_ID")
	private Long jobId;
	
	@ApiModelProperty("来源业务ID")
	@Length(min=0, max=128)
	@Column(name = "BUSINESS_ID")
	private String businessId;

	@ApiModelProperty("业务系统ID（DTS_INTEGRATION:数据汇聚平台）")
	@Length(min=0, max=128)
	@Column(name = "SYSTEM_ID")
	private String systemId = "DTS_INTEGRATION";
	
	@ApiModelProperty(value = "任务名称",required = true)
	@Length(min=2, max=128,message = "任务名称需多于2字和少于64个字!")
	@Column(name = "JOB_NAME")
	private String jobName;

	@ApiModelProperty(value = "任务定时执行cron表达式,前端请传cronValue")
	@Length(min=0, max=128)
	@Column(name = "JOB_CRON")
	private String jobCron;
	
	@ApiModelProperty("来源系统名称")
	@Length(min=0, max=128)
	@Column(name = "SOURCE_SYSTEM")
	private String sourceSystem = "DTS_INTEGRATION";
	
	@ApiModelProperty("创建人账号")
	@Length(min=0, max=128)
	@Column(name = "CREATE_USER")
	private String createUser;
	
	@ApiModelProperty("创建时间")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	private Date createTime;
	
	@ApiModelProperty("更新时间")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;
	
	@ApiModelProperty("XXL_JOB_ID")
	@Max(999999999999999999L)
	@Column(name = "XXL_JOB_ID")
	private Long xxlJobId;
	
	@ApiModelProperty(value = "状态（1、可用，待启动；2、队列中待执行；3、运行中；4、任务执行成功；5、任务执行失败；6、暂停中）",required = true)
	@Max(99L)
	@Column(name = "STATUS")
	private Integer status;
	@ApiModelProperty("状态名称")
	@Transient
	private String statusName;

	@ApiModelProperty("启动状态")
	@Max(99L)
	@Column(name = "LAUNCH_STATUS")
	private Integer launchStatus;
	@ApiModelProperty("启动状态名称")
	@Transient
	private String launchStatusName;
	
	@ApiModelProperty("源数据表ID")
	@Max(999999999999999999L)
	@Column(name = "SOURCE_TABLE_ID")
	private Long sourceTableId;
	
	@ApiModelProperty("目标数据表ID")
	@Max(999999999999999999L)
	@Column(name = "TARGET_TABLE_ID")
	private Long targetTableId;

	@ApiModelProperty(value = "数据源表的数据源ID",required = true)
	@Length(min=0, max=128)
	@Column(name = "SOURCE_DATASOURCE_ID")
	private String sourceTableDatasourceId;

	@ApiModelProperty(value = "目标表的数据源ID",required = true)
	@Length(min=0, max=128)
	@Column(name = "TARGET_DATASOURCE_ID")
	private String targetTableDatasourceId;

	@ApiModelProperty(value = "同步类型（0:全量同步、1:增量同步）默认值:0",required = true)
	@Value("0")
	@Range(min=0, max=1,message = "请输入正确的同步类型!0:全量同步、1:增量同步.")
	@Column(name = "SYNC_TYPE")
	private Integer syncType;
    @ApiModelProperty("同步类型名称")
    @Transient
    private String syncTypeName;

	@ApiModelProperty("where条件值")
	@Length(min=0, max=255)
	@Column(name = "WHERE_VALUE")
	private String whereValue;

	@ApiModelProperty("reader的更新时间值")
	@Length(min=0, max=255)
	@Column(name = "READER_UPDATE_TIME")
	private String readerUpdateTime;

	@ApiModelProperty("切分键")
	@Length(min=0, max=128)
	@Column(name = "split_key")
	private String splitKey;

	@ApiModelProperty("增量时间字段")
	@Length(min=0, max=128)
	@Column(name = "increment_field")
	private String incrementField;

	@ApiModelProperty("任务描述")
	@Length(min=0, max=512)
	@Column(name = "description")
	private String description;

	@ApiModelProperty(value = "同步位置（1、资源目录；2、目标库）",required = true)
	@Max(99L)
	@Range(min=1, max=2,message = "请输入正确的同步位置!1:资源目录 2:目标库.")
	@Column(name = "sync_position")
	private Integer syncPosition;
    @ApiModelProperty("同步位置名称")
    @Transient
    private String syncPositionName;

	@ApiModelProperty(value = "任务类型（1、数据库任务；2、API任务）",required = true)
	@Max(99L)
	@Range(min=1, max=2,message = "请输入正确的同步任务! 1:数据库任务2:api任务.")
	@Column(name = "job_type")
	private Integer jobType;
    @ApiModelProperty("任务类型名称")
    @Transient
    private String jobTypeName;

	@ApiModelProperty("发布状态（1、未发布；2、已发布）")
	@Max(99L)
	@Column(name = "publish_status")
	private Integer publishStatus = 1;
    @ApiModelProperty("发布状态名称")
    @Transient
    private String publishStatusName;

	@ApiModelProperty("最后修改人账号")
	@Length(min=0, max=128)
	@Column(name = "modify_user")
	private String modifyUser;

	@ApiModelProperty("增量开始时间")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "increment_start_time")
	private Date incrementStartTime;

	@ApiModelProperty(value = "清理规则（1、写入前保留已有数据；2、写入前删除已有数据。 默认是1）",required = true)
	@Max(99L)
	@Column(name = "clean_rule")
	private Integer cleanRule = 1;

	@ApiModelProperty(value = "清理规则名称")
	@Transient
	private String cleanRuleName;

	@ApiModelProperty("资源目录id")
	@Max(9223372036854775806L)
	@Column(name = "resource_id")
	private Long resourceId;

	@ApiModelProperty("资源目录代码")
	@Length(min=0, max=5000)
	@Column(name = "resource_code")
	private String resourceCode;

	@ApiModelProperty("资源目录名称")
	@Length(min=0, max=5000)
	@Column(name = "resource_name")
	private String resourceName;

	@ApiModelProperty("资源目录路径")
	@Length(min=0, max=5000)
	@Column(name = "resource_path")
	private String resourcePath;

	@ApiModelProperty("资源目录路径-编码形式")
	@Length(min=0, max=5000)
	@Column(name = "resource_path_code")
	private String resourcePathCode;

	@ApiModelProperty(value = "并发数",required = true)
	@Max(99999999999L)
	@Column(name = "concurrent_num")
	private Integer concurrentNum;

	@ApiModelProperty(value = "是否限流（0、否；1、是）",required = true)
	@Max(9L)
	@Column(name = "is_limit_rate")
	private Integer isLimitRate;
    @ApiModelProperty("是否限流名称")
    @Transient
    private String isLimitRateName;

	@ApiModelProperty(value = "同步速率",required = true)
	@Max(99999999999L)
	@Column(name = "sync_rate")
	private Integer syncRate;

	@ApiModelProperty(value = "调度类型（1、周期调度；2、手动调度）",required = true)
	@Max(99L)
	@Column(name = "schedule_type")
	private Integer scheduleType;
    @ApiModelProperty("调度类型名称")
    @Transient
    private String scheduleTypeName;

	@ApiModelProperty(value = "是否失败重启（0、否；1、是）",required = true)
	@Max(9L)
	@Column(name = "is_failure_restart")
	private Integer isFailureRestart;

	@ApiModelProperty(value = "重启次数",required = false)
	@Max(99L)
	@Column(name = "retry_time")
	private Integer retryTime;

    @ApiModelProperty("是否失败重启名称")
    @Transient
    private String isFailureRestartName;

	@ApiModelProperty("通知提醒类型（1、成功提醒；2、失败提醒）逗号隔开")
	@Column(name = "notice_type")
	private String noticeType;

	@ApiModelProperty("提醒方式（1、邮件提醒；2、站内信；3、短信）逗号隔开")
	@Column(name = "notice_way")
	private String noticeWay;

	@ApiModelProperty("通知提醒邮箱（逗号分隔）")
	@Length(min=0, max=256)
	@Column(name = "notice_mails")
	private String noticeMails;

	@ApiModelProperty("通知提醒手机（逗号分隔）")
	@Length(min=0, max=256)
	@Column(name = "notice_phones")
	private String noticePhones;

	@ApiModelProperty("通知提醒接收人id(逗号分隔)")
	@Length(min=0, max=256)
	@Column(name = "notice_receiver_ids")
	private String noticeReceiverIds;

	@ApiModelProperty("通知提醒接收人姓名（逗号分隔）")
	@Length(min=0, max=1024)
	@Column(name = "notice_receiver_names")
	private String noticeReceiverNames;

	@ApiModelProperty("是否新增")
	@Transient
    private Boolean isNew;

	@ApiModelProperty(value = "数据源的数据库名称",required = true)
	@Length(min=0, max=256)
	@Column(name = "source_database_name")
	private String sourceDatabaseName;

	@ApiModelProperty(value = "数据源的表名",required = true)
	@Length(min=0, max=128)
	@Column(name = "source_table_name")
	private String sourceTableName;

	@ApiModelProperty("数据源的数据库类型名称")
	@Transient
	private String sourceDatabaseTypeName;

	@ApiModelProperty(value = "目标表的数据库名称",required = true)
	@Transient
	private String targetDatabaseName;

	@ApiModelProperty(value = "目标表的表名",required = true)
	@Column(name = "TARGET_TABLE_NAME")
	private String targetTableName;


	@NotNull(message = "来源数据库类型不能为空")
	@ApiModelProperty(value = "来源数据库类型3:资源目录 0:Oracle 1:MySql高版本 2;Mysql低版本 3:PostgreSql 4:hive 5:SQL Server 6：华为hive",required = true)
	@Column(name = "source_database_type")
	private Integer sourceDdatabaseType;

	//@NotNull(message = "目标数据库类型不能为空") 不强行判断
	@ApiModelProperty(value = "目标数据库类型 3:资源目录 0:Oracle 1:MySql高版本 2;Mysql低版本 3:PostgreSql 4:hive 5:SQL Server 6：华为hive",required = true)
	@Column(name = "target_database_type")
	private Integer targetDdatabaseType;

	@ApiModelProperty("目标表的数据库类型名称")
	@Transient
	private String targetDdatabaseTypeName;

	@ApiModelProperty("创建人id")
    @Length(min=0, max=32)
	@Column(name = "CREATER_ID")
	private String createrId;

//	@ApiModelProperty("接口名称")
//	@Length(min=0, max=256)
//	@Column(name = "api_name")
//	private String apiName;

	@Transient
    @JsonIgnore
    @Override
    public Long getId() {
        return this.jobId;
	}
    
    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
    	if(isNew != null) {
    		return isNew;
    	}
    	if(this.jobId != null) {
    		return false;
    	}
    	return true;
    }
    
}