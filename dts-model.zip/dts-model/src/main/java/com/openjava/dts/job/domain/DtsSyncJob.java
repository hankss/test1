package com.openjava.dts.job.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.openjava.dts.constants.DtsConstants;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;

/**
 * 实体
 * @author hl
 *
 */
@ApiModel("DtsSyncJob")
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@Entity
@Table(name = "DTS_SYNC_JOB")
public class DtsSyncJob implements Persistable<Long>,Serializable {

	@ApiModelProperty("id")
	@Id
	@Column(name = "id")
	private Long id;

	@ApiModelProperty("任务名称")
	@Length(min=0, max=128)
	@Column(name = "name_")
	private String name;

	@ApiModelProperty("任务描述")
	@Length(min = 0, max = 512)
	@Column(name = "job_desc")
	private String jobDesc;

	@ApiModelProperty("跳转来源，0：数据集成自身页面,1：需求任务,2:数据协作,3：资源目录")
	@Column(name = "redirect_type")
	private Integer redirectType;

	@ApiModelProperty("调试器id")
	@Max(9223372036854775806L)
	@Column(name = "xxl_job_id")
	private Long xxlJobId;

	@ApiModelProperty("来源系统名称")
	@Length(min=0, max=128)
	@Column(name = "source_system")
	private String sourceSystem;

	@ApiModelProperty("状态（1、可用，待启动；2、队列中待执行；3、运行中；4、任务执行成功；5、任务执行失败；6、暂停中）")
	@Max(99L)
	@Column(name = "status_")
	private Integer status;

	@ApiModelProperty("启动状态（0、已停止；1、执行中）")
	@Max(9L)
	@Column(name = "lauch_status")
	private Integer lauchStatus;

	@ApiModelProperty(value = "任务类型（1、数据库任务；2、API任务）",required = true)
	@Max(9L)
	@Column(name = "job_type")
	private Integer jobType;

	@ApiModelProperty("0全量1增量")
	@Max(9L)
	@Column(name = "sync_type")
	private Integer syncType;

	@ApiModelProperty(value = "月1周2日3时4",required = true)
	@Max(9L)
	@Column(name = "schedule_cycle")
	private Integer scheduleCycle;

	@ApiModelProperty("调度类型（1、周期调度；2、手动调度）")
	@Max(9L)
	@Column(name = "schedule_type")
	private Integer scheduleType;

	@ApiModelProperty(value = "执行时间12:00",required = true)
	@Length(min=0, max=10)
	@Column(name = "run_time")
	private String runTime;

	@ApiModelProperty("开始时间12:00")
	@Length(min=0, max=10)
	@Column(name = "start_time")
	private String startTime;
	
	@ApiModelProperty("结束时间12:00")
	@Length(min=0, max=10)
	@Column(name = "end_time")
	private String endTime;
	
	@ApiModelProperty(value = "每间隔?小时",required = true)
	@Max(99L)
	@Column(name = "interval_")
	private Integer interval;
	
	@ApiModelProperty("cron表达式")
	@Length(min=0, max=560)
	@Column(name = "job_cron")
	private String jobCron;
	
	@ApiModelProperty("失败重启是否失败重启（0、否；1、是）")
	@Max(9L)
	@Column(name = "is_failure_restart")
	private Integer isFailureRestart;
	
	@ApiModelProperty("重启次数")
	@Max(9L)
	@Column(name = "retry_time")
	private Integer retryTime;

	@ApiModelProperty("发布状态（1、未发布；2、已发布）")
	@Max(99L)
	@Column(name = "publish_status")
	private Integer publishStatus = DtsConstants.JOB_PUBLISH_STATUS_NO;

	@ApiModelProperty(value = "任务json结构，暂时不再存数据了")
	@Column(name = "job_flow")
	private String jobFlow;
	
	@ApiModelProperty("前端同步任务画布页面上显示组件html，不再设置长度的限制，除非有特殊要求")
	@Column(name = "job_html")
	private String jobHtml;
	
	@ApiModelProperty("通知提醒类型（1、成功提醒；2、失败提醒）逗号分隔")
	@Length(min=0, max=128)
	@Column(name = "notice_type")
	private String noticeType;
	
	@ApiModelProperty("提醒方式（1、邮件提醒；2、站内信；3、短信）逗号分隔")
	@Length(min=0, max=10)
	@Column(name = "notice_way")
	private String noticeWay;
	
	@ApiModelProperty("通知提醒邮箱（逗号分隔）")
	@Length(min=0, max=256)
	@Column(name = "notice_mails")
	private String noticeMails;
	
	@ApiModelProperty("通知提醒手机（逗号分隔）")
	@Length(min=0, max=256)
	@Column(name = "notice_phones")
	private String noticePhones;
	
	@ApiModelProperty("通知提醒接收人id(逗号分隔)")
	@Length(min=0, max=256)
	@Column(name = "notice_receiver_ids")
	private String noticeReceiverIds;
	
	@ApiModelProperty("通知提醒接收人姓名（逗号分隔）")
	@Length(min=0, max=1024)
	@Column(name = "notice_receiver_names")
	private String noticeReceiverNames;
	
	@ApiModelProperty("来源业务ID")
	@Length(min=0, max=128)
	@Column(name = "business_id")
	private String businessId;
	
	@ApiModelProperty("业务系统ID（DTS_INTEGRATION:数据汇聚平台）")
	@Length(min=0, max=128)
	@Column(name = "system_id")
	private String systemId = "DTS_INTEGRATION";
	
	@ApiModelProperty("创建人")
	@Column(name = "create_id")
	private Long createId;
	
	@ApiModelProperty("创建人名字")
	@Length(min=0, max=60)
	@Column(name = "create_name")
	private String createName;
	
	@ApiModelProperty("创建人id")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "create_time")
	private Date createTime;
	
	@ApiModelProperty("修改人")
	@Column(name = "modify_id")
	private Long modifyId;
	
	@ApiModelProperty("修改名字")
	@Length(min=0, max=60)
	@Column(name = "modify_name")
	private String modifyName;
	
	@ApiModelProperty("修改时间")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modify_time")
	private Date modifyTime;

	@Column(name = "parent_job_id")
	private Long parentJobId;

	@Column(name = "is_child")
	@ApiModelProperty("是否是子任务，默认0,0：主任务，1：子任务")
	private Integer isChild = 0;
	
	
	@ApiModelProperty("是否新增")
	@Transient
    private Boolean isNew;
	
    @Override
    public Long getId() {
        return this.id;
	}
    
    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
    	if(isNew != null) {
    		return isNew;
    	}
    	if(this.id != null) {
    		return false;
    	}
    	return true;
    }
    
}