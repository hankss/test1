package com.openjava.dts.job.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;

/**
 * @author linchuangang
 * @create 2020-02-27 18:06
 **/
@ApiModel("任务实例2.0")
@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "DTS_SYNC_JOB_INSTANCE")
public class DtsSyncJobInstance implements Persistable<Long>,Serializable {

    @ApiModelProperty("id")
    @Id
    @Column(name = "id")
    private Long id;

    @ApiModelProperty("实例执行参数")
    @Length(min=0, max=255)
    @Column(name = "param")
    private String param;

    @ApiModelProperty("实例类型（1、周期实例；2、手动实例；3、补数实例；4、测试实例）")
    @Max(99L)
    @Column(name = "job_instance_type")
    private Integer jobInstanceType;

    @ApiModelProperty("实例状态（1、等待中；2、运行中；3、运行成功；4、运行失败）")
    @Max(99L)
    @Column(name = "status")
    private Integer status;

    @ApiModelProperty("任务开始时间")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "job_start_time")
    private Date jobStartTime;

    @ApiModelProperty("任务结束时间")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "job_end_time")
    private Date jobEndTime;

    @ApiModelProperty("同步时间段的开始时间")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "sync_start_time")
    private Date syncStartTime;

    @ApiModelProperty("同步时间段的结束时间")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "sync_end_time")
    private Date syncEndTime;

    @ApiModelProperty("下次同步开始时间")//用于解决服务器间时间差
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "next_sync_start_time")
    private Date nextSyncStartTime;

//	@ApiModelProperty("执行时长(秒)")
//	@Max(9223372036854775806L)
//	@Column(name = "exec_time_length")
//	private Long execTimeLength;

    @ApiModelProperty("XXL_JOB的任务实例ID")
    @Max(9223372036854775806L)
    @Column(name = "xxl_job_instance_id")
    private Long xxlJobInstanceId;

    @ApiModelProperty("数据传输任务ID")
    @Max(9223372036854775806L)
    @Column(name = "job_id")
    private Long jobId;

    @ApiModelProperty("数据传输任务对应的组件ID")
    @Max(9223372036854775806L)
    @Column(name = "component_id")
    private Long componentId;

    @ApiModelProperty("数据传输任务对应的输出组件ID")
    @Max(9223372036854775806L)
    @Column(name = "component_tar_id")
    private Long componentTarId;

    @ApiModelProperty("运行时长(单位为秒)")
    @Max(9223372036854775806L)
    @Column(name = "execute_duration")
    private Long executeDuration;

    @ApiModelProperty("任务的实例：0，组件的实例:1")
    @Column(name = "instance_type")
    private Integer instanceType;


    @ApiModelProperty("是否新增")
    @Transient
    private Boolean isNew;

    //	@Transient
//    @JsonIgnore
    @Override
    public Long getId() {
        return this.id;
    }

    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
        if(isNew != null) {
            return isNew;
        }
        if(this.id != null) {
            return false;
        }
        return true;
    }
}
