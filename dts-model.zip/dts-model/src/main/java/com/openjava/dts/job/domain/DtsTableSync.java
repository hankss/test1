package com.openjava.dts.job.domain;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.Max;
import java.io.Serializable;

/**
 * 汇聚2.0-表关联同步任务记录表
 * @author linchuangang
 * @create 2020-03-31 16:03
 **/
@Table(name = "dts_table_sync")
@Entity
@Data
public class DtsTableSync implements Serializable{

    @Id
    @Column(name = "id_")
    private Long id;

    @Column(name = "job_id")
    private Long jobId;

    @Column(name = "table_name")
    private String tableName;

    @Column(name = "table_reference_id")
    @ApiModelProperty("数据源id，归集库的id默认为1")
    private String tableReferenceId;

    @Column(name = "table_reference_type")
    @ApiModelProperty("0：数据源类型，1：资源目录类型，2：需求任务类型，3：归集库类型 4: 标准库")
    private Integer tableReferenceType;

    @Column(name = "stream_type")
    @ApiModelProperty(name = "流类型，0：输入，1：输出")
    private Integer streamType;

    @Column(name = "unite_sync_id")
    @ApiModelProperty("通常用来表示数据源类型的表与资源目录、需求任务、归集库的关联关系")
    private Long uniteSyncId;

    @ApiModelProperty("仅当类型为数据源时，根据host,port,databaseName生成加密sha-1字符串")
    @Column(name = "sha_secret")
    private String shaSecret;

    @ApiModelProperty("表的记录数")
    @Max(999999999999999999L)
    @Column(name = "data_count")
    private Long dataCount;

    @Transient
    private String cId;

    /**
     * 该方法仅仅适用于更新时。
     * @param o
     * @return
     */
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        } else if (!(o instanceof DtsTableSync)) {
            return false;
        } else {
            DtsTableSync other = (DtsTableSync)o;
            label47: {
                Object this$jobId = this.getJobId();
                Object other$jobId = other.getJobId();
                if (this$jobId == null) {
                    if (other$jobId == null) {
                        break label47;
                    }
                } else if (this$jobId.equals(other$jobId)) {
                    break label47;
                }

                return false;
            }

            Object this$tableName = this.getTableName();
            Object other$tableName = other.getTableName();
            if (this$tableName == null) {
                if (other$tableName != null) {
                    return false;
                }
            } else if (!this$tableName.equals(other$tableName)) {
                return false;
            }

            Object this$tableReferenceType = this.getTableReferenceType();
            Object other$tableReferenceType = other.getTableReferenceType();
            if (this$tableReferenceType == null) {
                if (other$tableReferenceType != null) {
                    return false;
                }
            } else if (!this$tableReferenceType.equals(other$tableReferenceType)) {
                return false;
            }

            return true;
        }
    }
}
