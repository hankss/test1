package com.openjava.dts.job.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.ljdp.component.user.BaseUserInfo;

import javax.persistence.Column;
import javax.validation.constraints.Max;
import java.util.List;

/**
 * @author 丘健里
 * @date 2020-05-10 20:34
 */
@ApiModel("归集资产DTO")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AssetsDTO {

    @ApiModelProperty("数据源id")
    private String datasourceId;

    @ApiModelProperty("系统id")
    private String systemId;

    @ApiModelProperty("系统名称")
    private String systemName;

    @ApiModelProperty("项目id")
    private Long projectId;

    @ApiModelProperty("项目名称")
    private String projectName;

    @ApiModelProperty("数据库来源")
    private String databaseSource;

    @ApiModelProperty("数据库名称")
    private String databaseName;

    @ApiModelProperty("源表表名")
    private List<String> sourceTableNameList;

    @ApiModelProperty("归集资产--目标表表名")
    private List<String> targetTableNameList;

    @ApiModelProperty("0全量 or 1增量 ")
    private Integer SyncType;

    @ApiModelProperty("月1周2时3日4")
    private Integer scheduleCycle;

    private BaseUserInfo createUser;

}
