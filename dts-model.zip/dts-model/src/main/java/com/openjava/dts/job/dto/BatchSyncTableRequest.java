package com.openjava.dts.job.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.Length;

import javax.persistence.Column;
import javax.validation.constraints.Max;
import java.io.Serializable;

@ApiModel("数据汇聚批量任务提交表请求对象")
@Data
@EqualsAndHashCode(callSuper = false)
public class BatchSyncTableRequest implements Serializable {

   @ApiModelProperty("来源表id")
   private Long srcTableId;

   @ApiModelProperty(value = "来源表名称",required = true)
   private String srcTableName;

   @ApiModelProperty("数据源表备注")
   private String sourceTableComment;

   @ApiModelProperty("数据源表的md5加密码")
   private String sourceTableCiphertext;

   @ApiModelProperty("数据源表的查询sql")
   private String sourceQuerySql;

   @ApiModelProperty("切分键")
   private String splitKey;

   @ApiModelProperty("增量时间段")
   private String incrementField;

   @ApiModelProperty(value = "目标表id")
   private Long targetTableId;

   @ApiModelProperty(value = "目标表名称",required = true)
   private String targetTableName;

   @ApiModelProperty("目标源表备注")
   private String targetTableComment;

   @ApiModelProperty("目标表的md5加密码")
   private String targetTableCiphertext;

   @ApiModelProperty("目标表的查询sql")
   private String targetQuerySql;

   @ApiModelProperty("资源目录id")
   @Max(9223372036854775806L)
   private Long resourceId;

   @ApiModelProperty("资源目录代码")
   @Length(min=0, max=5000)
   @Column(name = "resource_code")
   private String resourceCode;

   @ApiModelProperty("资源目录名称")
   @Length(min=0, max=5000)
   private String resourceName;

   @ApiModelProperty(value = "任务名称",required = true)
   private String dtsJobName;
}
