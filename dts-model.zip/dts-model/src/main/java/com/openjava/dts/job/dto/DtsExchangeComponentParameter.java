package com.openjava.dts.job.dto;

import com.alibaba.fastjson.JSON;
import lombok.Data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 将转换组件的param属性转换为对象
 * @author linchuangang
 * @create 2020-02-20 18:12
 * @see com.openjava.dts.job.domain.DtsComponent 组件表的param属性
 **/
@Data
public class DtsExchangeComponentParameter implements Serializable {

    private List<DataFilters> dataFilters;

    private List<FieldValueExchange> fieldValueExchanges;

    private List<TableIntegration> tableIntegrations;

    private ComponentTask task;

    /**
     * DtsCompent实体类里的param属性转换为一个对象
     * @param paramJson
     * @return
     */
    public static DtsExchangeComponentParameter converter(String paramJson){
        return JSON.parseObject(paramJson,DtsExchangeComponentParameter.class);
    }

    @Data
    public static class ComponentTask{
        private String cId;
        private String taskId;
        private String taskName;
    }

    @Data
    public static class DataFilters{
        private String cId;
        private String fieldName;
        private String fieldType;
        private String filterRule;
        private String filterValue;
    }

    @Data
    public static class FieldValueExchange{
        private String cId;
        private String fieldName;
        private List<FieldValueRule> rules;
    }

    @Data
    public static class FieldValueRule{
        private String originalValue;
        private String replaceValue;
    }

    @Data
    public static class TableIntegration{

        private Integer integrationType;/** 1列整合,列整合joinType relation有效 2表整合**/
        private String joinType;/** 1左链接 默认,2右链接 3整合**/
         /**"rules": [[{"cId": "","tableName": "","fieldName": ""},{"cId": "","tableName": "","fieldName": ""}]]**/
        private List<List<TableIntegrationRules>> rules;
    }

    @Data
    public static class TableIntegrationRules{
        private String cId;
        private String tableName;
        private String fieldName;
    }
}
