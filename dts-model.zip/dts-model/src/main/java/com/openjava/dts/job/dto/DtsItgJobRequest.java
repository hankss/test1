package com.openjava.dts.job.dto;

import com.openjava.dts.ddl.dto.ColumnInfo;
import com.openjava.dts.job.domain.DtsJob;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

@ApiModel("数据汇聚任务提交请求对象")
@Data
@EqualsAndHashCode(callSuper = false)
//@Accessors(chain = true)
public class DtsItgJobRequest extends DtsJob implements Serializable {

    @ApiModelProperty(value = "目标是新增 0否 1增",required = true)
    @NotNull(message = "targetIsNew不能为空")
    @Range(min=0, max=1,message = "请输入正常的值,0目标不存成,1目标生成.")
    private Integer targetIsNew;

    @ApiModelProperty(value = "来源表结构")
    private List<ColumnInfo> sourceTableStruct;//DtsColumnRequest

    @ApiModelProperty(value = "目标表结构")
    private List<ColumnInfo> targetTableStruct;

    @ApiModelProperty(value = "是否改变目标表的字段描述 0否 1是",required = true)
    private Integer isChangeTargetTbComment;

    @ApiModelProperty("数据源表备注")
    private String sourceTableComment;

    @ApiModelProperty("数据源表的md5加密码")
    private String sourceTableCiphertext;

    @ApiModelProperty("数据源表的查询sql")
    private String sourceQuerySql;

    @ApiModelProperty("目标源表备注")
    private String targetTableComment;

    @ApiModelProperty("目标表的md5加密码")
    private String targetTableCiphertext;

    @ApiModelProperty("目标表的查询sql")
    private String targetQuerySql;

    @ApiModelProperty(value = "cron表达式传值,(类型:1月,2周,3日,4时),参数以,号隔开.例:每月1号0点执行->1,1,00:00 ",required = false)
    private String cronValue;

    @ApiModelProperty(hidden=true)
    public Long newSrcTableId;

    @ApiModelProperty(hidden=true)
    private Long newTargetTableId;

    @ApiModelProperty(value = "资源目标部门ID")
    private String provideDeptId;


}
