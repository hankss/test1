package com.openjava.dts.job.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.openjava.dts.ddl.dto.ColumnInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author by 丘健里
 * @date 2020/2/13.
 */
@ApiModel("数据汇聚任务提交请求对象----需求协同")
@Data
@EqualsAndHashCode(callSuper = false)
public class DtsItgJobRequestFromDemand implements Serializable {

    @ApiModelProperty("来源业务ID")
    @Length(min=0, max=32)
    @Column(name = "BUSINESS_ID")
    private String businessId;

    @ApiModelProperty(value = "数据源ID",required = true)
    @Id
    @Column(name = "datasource_id")
    private String datasourceId;

    /**
     * 以下是源表部分
     */
    @NotNull(message = "来源数据库类型不能为空")
    @ApiModelProperty(value = "来源数据库类型3:资源目录 0:Oracle 1:MySql高版本 2;Mysql低版本 3:PostgreSql 4:hive 5:SQL Server 6：华为hive",required = true)
    @Column(name = "source_database_type")
    private Integer sourceDdatabaseType;

    @ApiModelProperty(value = "数据源的表名",required = true)
    @Length(min=0, max=64)
    @Column(name = "source_table_name")
    private String sourceTableName;

    @ApiModelProperty(value = "数据源表的数据源ID",required = true)
    @Length(min=0, max=128)
    @Column(name = "SOURCE_DATASOURCE_ID")
    private String sourceTableDatasourceId;

    @ApiModelProperty("切分键")
    @Length(min=0, max=128)
    @Column(name = "split_key")
    private String splitKey;

    @ApiModelProperty(value = "同步类型（0:全量同步、1:增量同步）默认值:0",required = true)
    @Value("0")
    @Range(min=0, max=1,message = "请输入正确的同步类型!0:全量同步、1:增量同步.")
    @Column(name = "SYNC_TYPE")
    private Integer syncType;

    @ApiModelProperty("增量开始时间")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "increment_start_time")
    private Date incrementStartTime;

    @ApiModelProperty("增量时间字段")
    @Length(min=0, max=128)
    @Column(name = "increment_field")
    private String incrementField;

    @ApiModelProperty("where条件值")
    @Length(min=0, max=255)
    @Column(name = "WHERE_VALUE")
    private String whereValue;

    /**
     * 以下是目标表部分
     * syncPosition 默认是2
     */
    @ApiModelProperty(value = "目标数据库类型 3:资源目录 0:Oracle 1:MySql高版本 2;Mysql低版本 3:PostgreSql 4:hive 5:SQL Server 6：华为hive",required = true)
    @Column(name = "target_database_type")
    private Integer targetDdatabaseType;

    @ApiModelProperty(value = "目标表的表名",required = true)
    @Column(name = "TARGET_TABLE_NAME")
    private String targetTableName;

    @ApiModelProperty(value = "清理规则（1、写入前保留已有数据；2、写入前删除已有数据。 默认是1）",required = true)
    @Max(99L)
    @Column(name = "clean_rule")
    private Integer cleanRule = 1;

    /**
     * 目标表的连接信息，由数据集加密后传给前端，再传到汇聚
     */
    @ApiModelProperty("用户名")
    @Length(min=0, max=128, message = "用户名限制最长128字")
    @Column(name = "username")
    private String username;

    @ApiModelProperty("密码")
    @Length(min=0, max=128, message = "密码限制最长128字")
    @Column(name = "password")
    private String password;

    @ApiModelProperty("主机IP")
    @Length(min=0, max=512, message = "主机IP限制长度512位")
    @Column(name = "host_ip")
    private String hostIp;

    @ApiModelProperty("端口号")
    @Length(min=0, max=99999, message = "端口号限制最大为99999")
    @Column(name = "port")
    private String port;

    @ApiModelProperty("数据库名")
    @Length(min=0, max=32, message = "数据库名限制最长32字")
    @Column(name = "database_name")
    private String databaseName;

    @ApiModelProperty("模式名称")
    @Length(min=0, max=32, message = "模式名称限制32字")
    @Column(name = "schema_name")
    private String schemaName;

    /**
     * 以下是字段映射
     */
    @ApiModelProperty(value = "来源表结构")
    private List<ColumnInfo> sourceTableStruct;//DtsColumnRequest

    @ApiModelProperty(value = "任务名称",required = true)
    @Length(min=2, max=64,message = "任务名称需多于2字和少于64个字!")
    @Column(name = "JOB_NAME")
    private String jobName;

    @ApiModelProperty(value = "是否改变目标表的字段描述 0否 1是",required = true)
    private Integer isChangeTargetTbComment;

    @ApiModelProperty(value = "状态（1、可用，待启动；2、队列中待执行；3、运行中；4、任务执行成功；5、任务执行失败；6、暂停中）",required = true)
    @Max(99L)
    @Column(name = "STATUS")
    private Integer status;

    @ApiModelProperty(value = "任务类型（1、数据库任务；2、API任务）",required = true)
    @Max(99L)
    @Range(min=1, max=2,message = "请输入正确的同步任务! 1:数据库任务2:api任务.")
    @Column(name = "job_type")
    private Integer jobType;

    @ApiModelProperty("是否新增")
    @Transient
    private Boolean isNew;

    @ApiModelProperty(value = "数据源的数据库名称",required = true)
    @Length(min=0, max=256)
    @Column(name = "source_database_name")
    private String sourceDatabaseName;

    @ApiModelProperty("任务描述")
    @Length(min=0, max=512)
    @Column(name = "description")
    private String description;

    @ApiModelProperty(value = "目标表的数据库名称",required = true)
    @Transient
    private String targetDatabaseName;

    @ApiModelProperty(value = "目标是新增 0否 1增",required = true)
    @NotNull(message = "targetIsNew不能为空")
    @Range(min=0, max=1,message = "请输入正常的值,0目标不存成,1目标生成.")
    private Integer targetIsNew;

    @ApiModelProperty(value = "目标表结构")
    private List<ColumnInfo> targetTableStruct;

}
