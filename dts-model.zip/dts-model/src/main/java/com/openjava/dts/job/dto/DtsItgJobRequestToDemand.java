package com.openjava.dts.job.dto;

import com.openjava.dts.ddl.domain.DtsColumn;
import com.openjava.dts.ddl.domain.DtsDatasource;
import com.openjava.dts.job.domain.DtsJob;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author by 丘健里
 * @date 2020/2/18.
 */
@ApiModel("同步任务详情--ToDemand")
@Data
public class DtsItgJobRequestToDemand {
    //dts_job 里面的同步任务的基本数据
    @ApiModelProperty("同步任务基本数据")
    private List<DtsJob> dtsJobList ;
    //数据源的信息
    @ApiModelProperty("数据源信息")
    private List<DtsDatasource> dtsDatasourceList ;
    //字段映射的信息
    @ApiModelProperty("源字段映射数据")
    private List<DtsColumn> sourceTableList ;
    @ApiModelProperty("目标字段映射数据")
    private List<DtsColumn> targetTableList ;
}
