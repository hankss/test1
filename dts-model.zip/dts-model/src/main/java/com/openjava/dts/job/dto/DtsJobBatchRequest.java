package com.openjava.dts.job.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.Length;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import java.io.Serializable;
import java.util.Date;

/**
 * 实体
 * @author
 *
 */
@ApiModel("数据传输批量添加任务对象")
@Data
@EqualsAndHashCode(callSuper = false)
//@Accessors(chain = true)
public class DtsJobBatchRequest implements Serializable {

	@ApiModelProperty("来源业务ID")
	@Length(min=0, max=32)
	private String businessId;

	@ApiModelProperty(value = "任务定时执行cron表达式,前端请传cronValue")
	@Length(min=0, max=64)
	private String jobCron;
	
	@ApiModelProperty("来源系统名称")
	@Length(min=0, max=64)
	private String sourceSystem;
	
	@ApiModelProperty("创建人账号")
	@Length(min=0, max=32)
	private String createUser;
	
	@ApiModelProperty("创建时间")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createTime;
	
	@ApiModelProperty("更新时间")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	private Date updateTime;
	
	@ApiModelProperty("XXL_JOB_ID")
	@Max(999999999999999999L)
	private Long xxlJobId;
	
	@ApiModelProperty(value = "状态（1、可用，待启动；2、队列中待执行；3、运行中；4、任务执行成功；5、任务执行失败；6、暂停中）",required = true)
	@Max(99L)
	private Integer status;
	@ApiModelProperty("状态名称")
	@Transient
	private String statusName;

	@ApiModelProperty("启动状态")
	@Max(99L)
	private Integer launchStatus;
	@ApiModelProperty("状态名称")
	@Transient
	private String launchStatusName;

	@ApiModelProperty(value = "同步类型（0:全量同步、1:增量同步）默认值:0",required = true)
	@Value("0")
	@Min(0)
	@Max(1)
	private Integer syncType;

	@ApiModelProperty("where条件值")
	@Length(min=0, max=255)
	private String whereValue;

	@ApiModelProperty("reader的更新时间值")
	@Length(min=0, max=255)
	private String readerUpdateTime;

	@ApiModelProperty("任务描述")
	@Length(min=0, max=512)
	private String description;

	@ApiModelProperty(value = "同步位置（1、资源目录；2、目标库）",required = true)
	@Max(99L)
	private Integer syncPosition;

	@ApiModelProperty(value = "任务类型（1、数据库任务；2、API任务）",required = true)
	@Max(99L)
	private Integer jobType;

	@ApiModelProperty("发布状态（1、未发布；2、已发布）")
	@Max(99L)
	private Integer publishStatus;

	@ApiModelProperty("最后修改人账号")
	@Length(min=0, max=32)
	private String modifyUser;

	@ApiModelProperty("增量开始时间")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	private Date incrementStartTime;

	@ApiModelProperty(value = "清理规则（1、首次同步删除已有数据；2、写入前保留已有数据；3、每次写入前删除已有数据）",required = true)
	@Max(99L)
	@Column(name = "clean_rule")
	private Integer cleanRule;

	@ApiModelProperty("资源目标部门ID")
	private String provideDeptId;

//	@ApiModelProperty("资源目录id")
//	@Max(9223372036854775806L)
//	private Long resourceId;
//
//	@ApiModelProperty("资源目录名称")
//	@Length(min=0, max=5000)
//	private String resourceName;

	@ApiModelProperty("资源目录路径")
	@Length(min=0, max=5000)
	@Column(name = "resource_path")
	private String resourcePath;

	@ApiModelProperty("资源目录路径-编码形式")
	@Length(min=0, max=5000)
	@Column(name = "resource_path_code")
	private String resourcePathCode;

	@ApiModelProperty(value = "并发数",required = true)
	@Max(99999999999L)
	private Integer concurrentNum;

	@ApiModelProperty(value = "是否限流（0、否；1、是）",required = true)
	@Max(9L)
	private Integer isLimitRate;

	@ApiModelProperty(value = "同步速率",required = true)
	@Max(99999999999L)
	private Integer syncRate;

	@ApiModelProperty(value = "调度类型（1、周期调度；2、手动调度）",required = true)
	@Max(99L)
	private Integer scheduleType;

	@ApiModelProperty(value = "是否失败重启（0、否；1、是）",required = true)
	@Max(9L)
	private Integer isFailureRestart;

	@ApiModelProperty("通知提醒类型（1、成功提醒；2、失败提醒）")
	private String noticeType;

	@ApiModelProperty("提醒方式（1、邮件提醒；2、站内信）")
	@Column(name = "notice_way")
	private String noticeWay;

	@ApiModelProperty("通知提醒邮箱（逗号分隔）")
	@Length(min=0, max=256)
	private String noticeMails;

	@ApiModelProperty("通知提醒手机（逗号分隔）")
	@Length(min=0, max=256)
	private String noticePhones;

	@ApiModelProperty("通知提醒接收人id(逗号分隔)")
	@Length(min=0, max=256)
	private String noticeReceiverIds;

	@ApiModelProperty("通知提醒接收人姓名（逗号分隔）")
	@Length(min=0, max=1024)
	private String noticeReceiverNames;

//	@ApiModelProperty("是否新增")
//	@Transient
//    private Boolean isNew;

	@ApiModelProperty(value = "数据源的数据库名称",required = true)
	@Length(min=0, max=256)
	private String sourceDatabaseName;

	@ApiModelProperty(value = "数据源表的数据源ID",required = true)
	@Length(min=0, max=128)
	private String sourceTableDatasourceId;

	@ApiModelProperty(value = "目标表的数据源ID",required = true)
	@Length(min=0, max=128)
	private String targetTableDatasourceId;

	@ApiModelProperty(value = "目标的数据库名称",required = true)
	@Length(min=0, max=256)
	private String targetDatabaseName;

	@ApiModelProperty(value = "来源数据库类型 -1:资源目录 0:Oracle 1:MySql高版本 2;Mysql低版本 3:PostgreSql 4:hive 5:SQL Server 6：华为hive",required = true)
	private Integer sourceDatabaseType;

	@ApiModelProperty(value = "目标数据库类型 -1:资源目录 0:Oracle 1:MySql高版本 2;Mysql低版本 3:PostgreSql 4:hive 5:SQL Server 6：华为hive",required = true)
	private Integer targetDatabaseType;

	@ApiModelProperty("创建人id")
	@Max(999999999999999999L)
	private Long createrId;

	@ApiModelProperty(value = "cron表达式传值,(类型:1月,2周,3日,4时),参数以,号隔开.例:每月1号0点执行->1,1,00:00 ",required = false)
	private String cronValue;

//    @JsonIgnore
//    @Transient
//    public boolean isNew() {
//    	if(isNew != null) {
//    		return isNew;
//    	}
//    	return true;
//    }
    
}