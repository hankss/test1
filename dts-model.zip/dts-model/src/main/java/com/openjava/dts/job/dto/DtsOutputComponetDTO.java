package com.openjava.dts.job.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 输出组件
 *
 * @author: lsw
 * @Date: 2020/2/29 14:58
 */
@ApiModel("输出组件")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DtsOutputComponetDTO {

    @ApiModelProperty("编号（任务序号）")
    private Integer id;

    @ApiModelProperty("组件名称")
    private String name;

    @ApiModelProperty("组件类型：1、输入组件")
    private Integer compentType;

    @ApiModelProperty("上一步任务）")
    private List<Integer> prev;

    @ApiModelProperty("下一步任务")
    private List<Integer> next;

    @ApiModelProperty("系统名称")
    private String systemName;

    @ApiModelProperty("部门ID")
    private String deparmentId;

    @ApiModelProperty("数据源表ID")
    private String datasourceId;

    @ApiModelProperty("数据源名称")
    private String datasourceName;

    @ApiModelProperty("表名")
    private String tableName;

    @ApiModelProperty("切分键（字段名）")
    private String splitKey;

    @ApiModelProperty("同步方式（0、全量同步；1、增量同步）")
    private Integer syncType;

    @ApiModelProperty("并发数")
    private Integer concurrentNum;

    @ApiModelProperty("是否限流（0、否；1、是）")
    private Integer isLimitRate;

    @ApiModelProperty("同步速率(MB/S)")
    private Integer syncRate;

    @ApiModelProperty("字段映射表")
    private List<Object> mapping;

    @ApiModelProperty("输出目标（0、归集库；1、资源目录；2、需求任务）")
    private Integer outputTo;
}
