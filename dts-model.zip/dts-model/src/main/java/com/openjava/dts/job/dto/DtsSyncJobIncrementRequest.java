package com.openjava.dts.job.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * @author linchuangang
 * @create 2020-04-27 9:55
 **/
@Getter
@Setter
@ApiModel("同步任务2.0-增量时间重置参数体")
public class DtsSyncJobIncrementRequest {

    @ApiModelProperty(name = "jobId",value = "同步任务主键id",required = true)
    Long jobId;

    @ApiModelProperty(name = "componentId",value = "输入组件的主键id",required = true)
    Long componentId;

    @ApiModelProperty(name = "tableNameList",value = "需要重置增量时间的表名,如果componentId是批量数据源输入组件，则tableNameList必须传")
    List<String> tableNameList;
}
