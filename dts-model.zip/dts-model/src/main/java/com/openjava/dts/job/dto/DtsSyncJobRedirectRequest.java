package com.openjava.dts.job.dto;

import com.openjava.dts.constants.DtsRedirectTypeEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.ljdp.component.exception.APIException;

import javax.annotation.PostConstruct;


/**
 * @author linchuangang
 * @create 2020-03-10 10:09
 **/
@ApiModel("从外部跳转到同步任务新增或编辑页面时的参数体")
@Data
public class DtsSyncJobRedirectRequest {

    @ApiModelProperty("跳转来源，0：数据集成自身页面,1：需求任务,2:数据协作,3：资源目录,4：数据集")
    private Integer redirectType;

    @ApiModelProperty("资源目录code")
    private String resourceCode;

    @ApiModelProperty("需求任务id或协作任务id")
    private String taskId;

    public void check()throws Exception{
        if (this.getRedirectType() == null){
            throw new APIException(400,"跳转来源类型不能为空");
        }
        if (this.getRedirectType() != DtsRedirectTypeEnum.assistance_task.ordinal()
            && this.getRedirectType() != DtsRedirectTypeEnum.requirement_task.ordinal()
            && this.getRedirectType() != DtsRedirectTypeEnum.resource_folder.ordinal()
            && this.getRedirectType() != DtsRedirectTypeEnum.data_integration.ordinal()
            && this.getRedirectType() != DtsRedirectTypeEnum.data_set.ordinal()
        ){
            throw new APIException(400,"跳转类型参数值不合法，取值范围[0-4]");
        }
    }

}
