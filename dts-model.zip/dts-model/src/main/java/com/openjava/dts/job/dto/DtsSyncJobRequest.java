package com.openjava.dts.job.dto;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.parser.Feature;
import com.openjava.dts.constants.DtsConstants;
import com.openjava.dts.constants.DtsRedirectTypeEnum;
import com.openjava.dts.job.domain.DtsComponent;
import com.openjava.dts.job.domain.DtsComponentFieldMapping;
import com.openjava.dts.job.domain.DtsSyncJob;
import com.openjava.dts.util.HandleTableNameUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.ljdp.component.exception.APIException;
import org.ljdp.component.sequence.ConcurrentSequence;
import org.springframework.beans.BeanUtils;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author linchuangang
 * @create 2020-02-20 17:06
 **/
@ApiModel("数据同步任务接口")
@Data
@Slf4j
public class DtsSyncJobRequest extends DtsSyncJob{

    @ApiModelProperty(hidden = true)
    private List<DtsComponent> components;
    /**只有输出组件才会有字段映射**/
    @ApiModelProperty(hidden = true)
    private List<DtsComponentFieldMapping> fieldMapping;

    private String cronValue;

    @ApiModelProperty("默认不执行发布操作，true则表示执行发布操作")
    private boolean onPublish;

    public DtsSyncJobRequest() {
        this.components = new LinkedList<>();
        this.fieldMapping = new ArrayList<>();
    }

    /**
     * 转换为组件，提取组件里的mapping参数
     * @throws Exception
     */
    public void componentsConvert()throws Exception{
        this.before();
        if (this.getScheduleType() == DtsConstants.JOB_SCHEDULE_TYPE_CRON.intValue()) {
            this.setCronValue(this.cronValueConvert());
        }
        if (StringUtils.isNotBlank(this.getJobFlow())){
            JSONObject jsonObject = JSON.parseObject(this.getJobFlow());
            for (Map.Entry<String,Object>entry : jsonObject.entrySet()){
                JSONObject item = (JSONObject) entry.getValue();
                DtsComponent component = JSON.parseObject(item.toJSONString(),DtsComponent.class, Feature.OrderedField);
                if (component.getCompentType() == DtsComponent.DTS_COMPONENT_INPUT_TYPE_BATCH_DATASOURCE
                || component.getCompentType() == DtsComponent.DTS_COMPONENT_INPUT_TYPE_DATASOURCE
                || component.getCompentType() == DtsComponent.DTS_COMPONENT_OUTPUT_TYPE_BATCH_COLLECT
                || component.getCompentType() == DtsComponent.DTS_COMPONENT_OUTPUT_TYPE_COLLECT
                ){
                    if (component.getProjectId() == null){
                        throw new APIException(400,"组件的项目id不能为空");
                    }
                    if (component.getSystemId() == null){
                        throw new APIException(400,"组件的系统id不能为空");
                    }
                }
                this.fieldsMappingConvert(component,item);
                component.setIncrementReset(0);
                components.add(component);
            }
        }
//        this.separateFromBatchComponent();
        this.after();
    }

    private void before()throws Exception{
        if (this.getRedirectType() == null){
            throw new APIException(400,"跳转来源类型不能为空");
        }
        //如果是该同步任务是从本身数据集成的页面新增的，则系统自动设置一个businessId
        if (this.getRedirectType() == DtsRedirectTypeEnum.data_integration.ordinal()){
            this.setBusinessId(String.valueOf(ConcurrentSequence.getInstance().getSequence()));
        }
        if (StringUtils.isBlank(this.getJobFlow())){
            throw new APIException(400,"组件json字符串不能为空");
        }
        if (this.getScheduleType() == null){
            throw new APIException(400,"同步任务周期类型不能为空");
        }
    }

    private void after()throws Exception{
        if (this.components.isEmpty()){
            log.warn("同步任务组件列表为空，jobFlow:{}",this.getJobFlow());
            throw new APIException(400,"同步任务组件列表为空，请检查参数合法性");
        }
    }

    private String cronValueConvert()throws Exception{
        String cron = "";
        if (this.getScheduleType() ==  DtsConstants.JOB_SCHEDULE_TYPE_MANUAL.intValue()){
            return cron;
        }
        if (this.getScheduleCycle() == null){
            throw new APIException(400,"调度周期参数不能为空");
        }

        switch (this.getScheduleCycle()){
            case 1://按月
                if (this.getInterval() == null){
                    throw new APIException(400,"间隔参数不能为空");
                }
                if (this.getRunTime() == null){
                    throw new APIException(400,"执行时间参数不能为空");
                }
                cron += this.getScheduleCycle()+","+this.getInterval()+","+this.getRunTime();
                break;
            case 2://按周
                if (this.getInterval() == null){
                    throw new APIException(400,"需要指定星期几");
                }
                if (this.getRunTime() == null){
                    throw new APIException(400,"执行时间参数不能为空");
                }
                cron += this.getScheduleCycle()+","+this.getInterval()+","+this.getRunTime();
                break;
            case 3://按日
                if (this.getRunTime() == null){
                    throw new APIException(400,"执行时间参数不能为空");
                }
                cron += this.getScheduleCycle()+","+this.getRunTime();
                break;
            case 4://按时
                if (this.getInterval() == null){
                    throw new APIException(400,"时间间隔参数不能为空");
                }
                if (this.getStartTime() == null){
                    throw new APIException(400,"开始时间参数不能为空");
                }
                if (this.getEndTime() == null){
                    throw new APIException(400,"结束时间参数不能为空");
                }
                cron += this.getScheduleCycle()+","+this.getStartTime()+","+this.getInterval()+","+this.getEndTime();
                break;
        }
        if (cron.equals("")){
            throw new APIException(400,"cron表达式解析失败，请检查调度周期相关参数的完整性");
        }
        return cron;
    }

    public void fieldsMappingConvert(DtsComponent component, JSONObject item)throws Exception{
        if (component.getCompentType()==DtsComponent.DTS_COMPONENT_OUTPUT_TYPE_COLLECT
            || component.getCompentType()==DtsComponent.DTS_COMPONENT_OUTPUT_TYPE_REQUIREMENT_TASK
            || component.getCompentType()==DtsComponent.DTS_COMPONENT_OUTPUT_TYPE_RESOURCE_FOLDER
            || component.getCompentType() == DtsComponent.DTS_COMPONENT_OUTPUT_TYPE_STANDARD
            || component.getCompentType() == DtsComponent.DTS_COMPONENT_OUTPUT_TYPE_BASE
            || component.getCompentType() == DtsComponent.DTS_COMPONENT_OUTPUT_TYPE_SUBJECT
            || component.getCompentType() == DtsComponent.DTS_COMPONENT_OUTPUT_TYPE_SPECIAL_TOPIC
        ){
            if (!item.containsKey("mapping") || item.get("mapping") == null){
                throw new APIException(400, "字段映射mapping属性不能为空");
            }
            String fieldMappingString = item.getJSONArray("mapping").toJSONString();
            List<DtsComponentFieldMapping> mapping = JSON.parseArray(fieldMappingString,DtsComponentFieldMapping.class);
            fieldMapping.addAll(mapping);
        }
    }

    /**
     * 批量组件拆分子组件
     * @throws APIException
     */
    public void separateFromBatchComponent()throws APIException{
        List<DtsComponent> temp = new ArrayList<>();
        for (DtsComponent s : this.components) {
            //只提取批量数据源输入组件
            if (s.getCompentType() == DtsComponent.DTS_COMPONENT_INPUT_TYPE_BATCH_DATASOURCE) {
                JSONArray array = JSON.parseArray(s.getNext());
                DtsComponent output = this.components.stream().filter(x->x.getCId().equals(array.get(0))).findFirst().orElse(null);
                if (output == null){
                    throw new APIException(400,"批量输入组件必须对应一个批量输出组件");
                }
                if (s.getSyncType() == 1) {
                    if (s.getIncrementFieldList() != null && s.getIncrementStartTime() == null) {
                        throw new APIException(400, "批量输入组件增量字段时间必须设置");
                    }
                }
                // 按照批量输入组件的tableNameList来循环拆分
                //list假如有2个源表表名，那么每次循环都会生成两个子组件，一共是4个子组件+2个父组件
                //其中，字段映射fieldMapping，里面包含的对象=源表1字段数*2+源表2字段数*2
                for (String tableName : s.getTableNameList()){//批量输入组件的拆分
                    //这里生成一个批量数据库输入子组件
                    DtsComponent item = new DtsComponent();
                    BeanUtils.copyProperties(s,item);
                    item.setTableNameList(null);
                    item.setSplitKeyList(null);
                    item.setIncrementFieldList(null);
                    //子组件存储增量开始时间
                    item.setIncrementStartTime(s.getIncrementStartTime());
                    item.setIncrementReset(0);
                    //子组件拆分后，设置好其本来的父组件cId
                    item.setBatchComponentId(s.getCId());
                    item.setCompentType(DtsComponent.DTS_COMPONENT_INPUT_TYPE_BATCH_DATASOURCE_CHILD);
                    JSONObject splitKey = s.getSplitKeyList().stream().filter(a->a.getString("tableName").equalsIgnoreCase(tableName)).findFirst().orElse(null);
                    item.setSplitKey(splitKey==null?null:splitKey.getString("splitKey"));
                    item.setTableName(tableName);
                    JSONObject incrementField = s.getIncrementFieldList().stream().filter(a->a.getString("tableName").equalsIgnoreCase(tableName)).findFirst().orElse(null);
                    item.setIncrementField(incrementField == null?null:incrementField.getString("fieldName"));

                    //这里生成一个批量归集库输出子组件
                    DtsComponent next = new DtsComponent();
                    //复制批量组件对象的基础属性
                    BeanUtils.copyProperties(output,next);
                    //批量归集库输出子组件，设置其父组件的cId
                    next.setBatchComponentId(output.getCId());
                    next.setCompentType(DtsComponent.DTS_COMPONENT_OUTPUT_TYPE_BATCH_COLLECT_CHILD);
                    next.setBatchComponentUsing(null);
                    String createdTableName = output.getTableNameList().stream().filter(x-> HandleTableNameUtil.removeTableNameSign(x).equalsIgnoreCase(tableName)).findFirst().orElse(null);
                    if (createdTableName == null){
                        throw new APIException(400,"批量输出组件找不到与输入组件表名匹配的值");
                    }
                    next.setTableName(createdTableName);
                    JSONObject splitKeyOutput = output.getSplitKeyList().stream().filter(x-> HandleTableNameUtil.removeTableNameSign(x.getString("tableName")).equalsIgnoreCase(tableName))
                        .findFirst().orElse(null);
                    next.setSplitKey(splitKeyOutput==null?null:splitKeyOutput.getString("splitKey"));

                    //绑定组件的层级关联关系
                    String preString = RandomStringUtils.randomAlphabetic(8);
                    String nextString = RandomStringUtils.randomAlphabetic(8);
                    item.setCId(preString);
                    item.setNext(JSON.toJSONString(Arrays.asList(nextString)));
                    item.setPre(JSON.toJSONString(Collections.emptyList()));
                    next.setCId(nextString);
                    next.setPre(JSON.toJSONString(Arrays.asList(preString)));
                    next.setNext(JSON.toJSONString(Collections.emptyList()));


                    // 按照表名来分组
                    Map<String,List<DtsComponentFieldMapping>> group = output.getBatchComponentUsing().stream()
                        .collect(Collectors.groupingBy(DtsComponentFieldMapping::getTableName));
                    if (group.containsKey(tableName)){
                        // 使用新的pre, next来配置字段映射类里的cId,cSrcId,cTarId
                        group.get(tableName).forEach(x->{
                            x.setCId(preString);
                            x.setCSrcId(preString);
                            x.setCTarId(nextString);
                        });
                    }else {
                        throw new APIException(400,"批量数据源输入组件表字段映射数据结构不正确");
                    }
                    if (group.containsKey(createdTableName)){
                        group.get(createdTableName).forEach(x->{
                            x.setCId(nextString);
                            x.setCSrcId(preString);
                            x.setCTarId(nextString);
                        });
                    }else {
                        throw new APIException(400,"批量归集库输出组件表字段映射数据结构不正确");
                    }
                    temp.add(item);
                    temp.add(next);
                    group.forEach((key, value) -> {
                        if (key.equals(tableName) || key.equals(createdTableName)){
                            fieldMapping.addAll(value);
                        }
                    });
                }
                output.setBatchComponentUsing(null);
            }

        }
        components.addAll(temp);
    }


}
