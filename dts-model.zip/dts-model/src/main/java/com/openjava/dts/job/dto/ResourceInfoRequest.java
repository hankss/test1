package com.openjava.dts.job.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.openjava.dts.ddl.dto.ColumnInfo;
import com.openjava.dts.ddl.dto.DatasourceInfo;
import com.openjava.dts.ddl.dto.TableInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.Range;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;

@ApiModel("资源目录信息")
@Data
@EqualsAndHashCode(callSuper = false)
//@Accessors(chain = true)
public class ResourceInfoRequest {

    @ApiModelProperty("来源业务ID")
    private String businessId;

    @ApiModelProperty(value = "任务名称", required = true)
    private String jobName;

//    @ApiModelProperty(value = "任务定时执行cron表达式,前端请传cronValue")
//    private String jobCron;

    @ApiModelProperty(value = "创建人账号", required = true)
    private String createUser;

    @ApiModelProperty(value = "资源目录id", required = true)
    private Long resourceId;

    @ApiModelProperty(value = "资源目录代码", required = true)
    private String resourceCode;

    @ApiModelProperty(value = "资源目录名称", required = true)
    private String resourceName;

    //@NotNull(message = "目标数据库类型不能为空") 不强行判断
    @ApiModelProperty(value = "目标数据库类型 3:资源目录 0:Oracle 1:MySql高版本 2;Mysql低版本 3:PostgreSql 4:hive 5:SQL Server 6：华为hive",required = true)
    private Integer databaseType;

    @ApiModelProperty(value = "表名", required = true)
    private String tableName;

    @ApiModelProperty(value = "表结构", required = true)
    private List<ColumnInfo> tableStruct;

    @ApiModelProperty(value = "数据同步任务信息", required = true)
    private String syncInfo;

}
