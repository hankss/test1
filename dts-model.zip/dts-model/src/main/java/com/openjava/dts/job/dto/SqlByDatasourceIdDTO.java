package com.openjava.dts.job.dto;

import com.openjava.dts.ddl.dto.ColumnInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;

import javax.validation.constraints.NotBlank;
import java.util.List;

/**
 * @author: lsw
 * @Date: 2020/3/5 15:03
 */
@ApiModel("根据SQL获取数据源信息DTO")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SqlByDatasourceIdDTO {

//    @ApiModelProperty("数据源ID")
//    @NotBlank
//    private String datasourceId;

    @ApiModelProperty("表名")
    private String tableName;

    @ApiModelProperty("表注释")
    private String tableComments;

    @ApiModelProperty("列信息")
    private List<ColumnInfo> columnInfoList;

}
