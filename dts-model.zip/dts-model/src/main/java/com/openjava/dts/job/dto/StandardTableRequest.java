package com.openjava.dts.job.dto;

import com.alibaba.fastjson.JSON;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.openjava.dts.job.domain.DtsComponentFieldMapping;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.List;

/**
 * created by Annie since 2020/5/27 15:38
 * intro: Annie
 */
@Data
@Accessors(chain = true)
@ApiModel("标准库输出组件建表接口参数体")
public class StandardTableRequest implements Serializable {

    @ApiModelProperty(value = "标准库输出组件前端cId",required = true)
    @JsonProperty("cTarId")
    private String cTarId;

    @ApiModelProperty(value = "源表名(上游节点的表名),新增同步任务时传进来")
    private String sourceTableName;

    @ApiModelProperty(value = "建表的表名，新增同步任务时不用传，编辑同步任务时如果请求了该接口，需要传表名，用于更新表结构")
    private String tableName;

    @ApiModelProperty(value = "表中文注释，非必传，如果用户没填，则可以不传")
    private String tableComment;

    private String fieldsJson;

    @ApiModelProperty(value = "用户勾选的源表字段信息集合",hidden = true)
    private List<DtsComponentFieldMapping> fields;

    @ApiModelProperty(value = "本次接口请求是否是新建表，默认为false，false：更新表，true：新建表")
    private boolean create;

    public void setFieldsJson(String fieldsJson) {
        this.fieldsJson = fieldsJson;
        fields = JSON.parseArray(fieldsJson,DtsComponentFieldMapping.class);
    }
}
