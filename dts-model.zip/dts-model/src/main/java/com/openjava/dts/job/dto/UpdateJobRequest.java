package com.openjava.dts.job.dto;

import com.openjava.dts.ddl.dto.DatasourceUpdate;
import com.openjava.dts.ddl.dto.TableInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.beans.factory.annotation.Value;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@ApiModel("任务对象更新请求")
@Data
@EqualsAndHashCode(callSuper = false)
//@Accessors(chain = true)
public class UpdateJobRequest {

    @ApiModelProperty(value = "任务名称",required = false)
    @Length(min=0, max=64)
    private String jobName;

    @ApiModelProperty(value = "任务定时执行cron表达式",required = true)
    @Length(min=0, max=64)
    @NotBlank
    private String jobCron;

    @ApiModelProperty("来源系统编码（可空，将作为目标表名的前缀。目标表命名规则：系统编码_源表名_v版本号）")
    @Length(min=0, max=64)
    private String sourceSystem;

    @ApiModelProperty(value = "读数据库配置（来源）",required = false)
    private DatasourceUpdate readDatasource;

    @ApiModelProperty(value = "写数据库配置（目标）", required = false)
    private DatasourceUpdate writeDatasource;

    @ApiModelProperty(value = "读表配置（来源）",required = false)
    private TableInfo readTable;

    @ApiModelProperty(value = "写表配置（目标）",required = false)
    private TableInfo writeTable;

    @ApiModelProperty(value = "同步类型（0:全量同步、1:增量同步）默认值:0")
    @Value("0")
    @Min(0)
    @Max(1)
    private Integer syncType;

    @ApiModelProperty("where条件值")
    @Length(min=0, max=255)
    private String whereValue;
}
