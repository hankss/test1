package com.openjava.dts.job.query;

import org.ljdp.core.db.RoDBQueryParam;

/**
 * 查询对象
 * @author hl
 *
 */
public class DtsComponentDBParam extends RoDBQueryParam {
	private Long eq_id;//id --主键查询
	
	private Integer eq_compentType;//1数据源输入 2归集库输入 3资源目录输入 4需求任务输入 5归集库输出 6资源目录输出 7.需求任务输出 = ?
	private String like_name;//组件名称 like ?
	private String like_systemName;//所属科室系统 like ?
	private String like_systemIds;//所属科室ids like ?
	private String like_datasourceName;//数据源名字 like ?
	private String eq_datasourceId;//数据源id = ?
	private String eq_tableName;//同步表名 = ?
	private Long eq_resourceId;//资源目录id = ?
	private String eq_resourceName;//资源目录名称 = ?
	private String eq_resourceCode;//资源目录编码 = ?
	private String eq_createId;//创建人ID = ?
	
	public Long getEq_id() {
		return eq_id;
	}
	public void setEq_id(Long id) {
		this.eq_id = id;
	}
	
	public Integer getEq_compentType() {
		return eq_compentType;
	}
	public void setEq_compentType(Integer compentType) {
		this.eq_compentType = compentType;
	}
	public String getLike_name() {
		return like_name;
	}
	public void setLike_name(String name) {
		this.like_name = name;
	}
	public String getLike_systemName() {
		return like_systemName;
	}
	public void setLike_systemName(String systemName) {
		this.like_systemName = systemName;
	}
	public String getLike_systemIds() {
		return like_systemIds;
	}
	public void setLike_systemIds(String systemIds) {
		this.like_systemIds = systemIds;
	}
	public String getLike_datasourceName() {
		return like_datasourceName;
	}
	public void setLike_datasourceName(String datasourceName) {
		this.like_datasourceName = datasourceName;
	}
	public String getEq_datasourceId() {
		return eq_datasourceId;
	}
	public void setEq_datasourceId(String datasourceId) {
		this.eq_datasourceId = datasourceId;
	}
	public String getEq_tableName() {
		return eq_tableName;
	}
	public void setEq_tableName(String tableName) {
		this.eq_tableName = tableName;
	}
	public Long getEq_resourceId() {
		return eq_resourceId;
	}
	public void setEq_resourceId(Long resourceId) {
		this.eq_resourceId = resourceId;
	}
	public String getEq_resourceName() {
		return eq_resourceName;
	}
	public void setEq_resourceName(String resourceName) {
		this.eq_resourceName = resourceName;
	}
	public String getEq_resourceCode() {
		return eq_resourceCode;
	}
	public void setEq_resourceCode(String resourceCode) {
		this.eq_resourceCode = resourceCode;
	}
	public String getEq_createId() {
		return eq_createId;
	}
	public void setEq_createId(String createId) {
		this.eq_createId = createId;
	}
}