package com.openjava.dts.job.query;

import org.ljdp.core.db.RoDBQueryParam;

/**
 * 查询对象
 * @author hl
 *
 */
public class DtsComponentFieldMappingDBParam extends RoDBQueryParam {
	private Long eq_columnId;//表字段ID --主键查询
	
	private Long eq_jobId;//任务id = ?
	private Long eq_itemJobId;//字任务id = ?
	private Long eq_compentId;//组件id = ?
	private String eq_columnSource;//字段列名 = ?
	
	public Long getEq_columnId() {
		return eq_columnId;
	}
	public void setEq_columnId(Long columnId) {
		this.eq_columnId = columnId;
	}
	
	public Long getEq_jobId() {
		return eq_jobId;
	}
	public void setEq_jobId(Long jobId) {
		this.eq_jobId = jobId;
	}
	public Long getEq_itemJobId() {
		return eq_itemJobId;
	}
	public void setEq_itemJobId(Long itemJobId) {
		this.eq_itemJobId = itemJobId;
	}
	public Long getEq_compentId() {
		return eq_compentId;
	}
	public void setEq_compentId(Long compentId) {
		this.eq_compentId = compentId;
	}
	public String getEq_columnSource() {
		return eq_columnSource;
	}
	public void setEq_columnSource(String columnSource) {
		this.eq_columnSource = columnSource;
	}
}