package com.openjava.dts.job.query;

import org.apache.commons.lang3.StringUtils;
import org.ljdp.core.db.RoDBQueryParam;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * 查询对象
 * @author 子右
 *
 */
public class DtsJobDBParam extends RoDBQueryParam {
	private Long eq_jobId;//任务ID --主键查询
	
	private String like_jobName;//任务名称 like ?
	private Long eq_xxlJobId;//XXL_JOB_ID = ?
	private String eq_businessId;//来源业务ID = ?
	private String eq_systemId;//业务系统ID（DTS_INTEGRATION:数据汇聚平台） = ?
	private Integer eq_status;//状态 = ?
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date le_createTime;//创建时间 <= ?
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date ge_createTime;//创建时间 >= ?
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date le_updateTime;//更新时间 <= ?
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date ge_updateTime;//更新时间 >= ?

	private String like_createUser;//创建人账号 like ?
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private String like_sourceDatabaseName;//数据源的数据库名称 like ?
	private Integer eq_syncType;//同步方式（0、全量同步；1、增量同步） = ?
	private String like_apiName;//接口名称 like ?
	private Integer eq_jobType;//任务类型（1、数据库任务；2、API任务） = ?
	private Integer eq_publishStatus;//发布状态（1、未发布；2、已发布） = ?
	private String like_modifyUser;//最后修改人账号 like ?
	private String like_jobCron;//调度周期cron like ?
	private Integer eq_scheduleType;//调度类型（1、周期调度；2、手动调度)
	private String eq_createrId;//创建人 = ?

	private String eq_resourceCode;//同步到资源目录code

	public String getEq_systemId() {
		return eq_systemId;
	}

	public void setEq_systemId(String eq_systemId) {
		this.eq_systemId = eq_systemId;
	}

	public String getEq_createrId() {
		return eq_createrId;
	}

	public void setEq_createrId(String eq_createrId) {
		this.eq_createrId = eq_createrId;
	}

	public Long getEq_jobId() {
		return eq_jobId;
	}
	public void setEq_jobId(Long jobId) {
		this.eq_jobId = jobId;
	}
	
	public String getLike_jobName() {
		return like_jobName;
	}
	public void setLike_jobName(String jobName) {
		if(StringUtils.isNotBlank(jobName)){
			jobName  = "%"+jobName+"%";
		}
		this.like_jobName = jobName;
	}
	public Long getEq_xxlJobId() {
		return eq_xxlJobId;
	}
	public void setEq_xxlJobId(Long xxlJobId) {
		this.eq_xxlJobId = xxlJobId;
	}
	public String getEq_businessId() {
		return eq_businessId;
	}
	public void setEq_businessId(String businessId) {
		this.eq_businessId = businessId;
	}
	public Integer getEq_status() {
		return eq_status;
	}
	public void setEq_status(Integer status) {
		this.eq_status = status;
	}
	public Date getLe_createTime() {
		return le_createTime;
	}
	public void setLe_createTime(Date createTime) {
		this.le_createTime = createTime;
	}
	public Date getGe_createTime() {
		return ge_createTime;
	}
	public void setGe_createTime(Date createTime) {
		this.ge_createTime = createTime;
	}
	public Date getLe_updateTime() {
		return le_updateTime;
	}
	public void setLe_updateTime(Date updateTime) {
		this.le_updateTime = updateTime;
	}
	public Date getGe_updateTime() {
		return ge_updateTime;
	}
	public void setGe_updateTime(Date updateTime) {
		this.ge_updateTime = updateTime;
	}

	public String getLike_createUser() {
		return like_createUser;
	}
	public void setLike_createUser(String createUser) {
		if(StringUtils.isNotBlank(createUser)){
			createUser  = "%"+createUser+"%";
		}
		this.like_createUser = createUser;
	}
	public String getLike_sourceDatabaseName() {
		return like_sourceDatabaseName;
	}
	public void setLike_sourceDatabaseName(String sourceDatabaseName) {
		if(StringUtils.isNotBlank(sourceDatabaseName)){
			sourceDatabaseName  = "%"+sourceDatabaseName+"%";
		}
		this.like_sourceDatabaseName = sourceDatabaseName;
	}
	public Integer getEq_syncType() {
		return eq_syncType;
	}
	public void setEq_syncType(Integer syncType) {
		this.eq_syncType = syncType;
	}
	public String getLike_apiName() {
		return like_apiName;
	}
	public void setLike_apiName(String apiName) {
		if(StringUtils.isNotBlank(apiName)){
			apiName  = "%"+apiName+"%";
		}
		this.like_apiName = apiName;
	}
	public Integer getEq_jobType() {
		return eq_jobType;
	}
	public void setEq_jobType(Integer jobType) {
		this.eq_jobType = jobType;
	}
	public Integer getEq_publishStatus() {
		return eq_publishStatus;
	}
	public void setEq_publishStatus(Integer publishStatus) {
		this.eq_publishStatus = publishStatus;
	}
	public String getLike_modifyUser() {
		return like_modifyUser;
	}
	public void setLike_modifyUser(String modifyUser) {
		if(StringUtils.isNotBlank(modifyUser)){
			modifyUser  = "%"+modifyUser+"%";
		}
		this.like_modifyUser = modifyUser;
	}
	public String getLike_jobCron() {
		return like_jobCron;
	}
	public void setLike_jobCron(String jobCron) {
		if(StringUtils.isNotBlank(jobCron)){
			jobCron  = "%"+jobCron+"%";
		}
		this.like_jobCron = jobCron;
	}

	public Integer getEq_scheduleType() {
		return eq_scheduleType;
	}

	public void setEq_scheduleType(Integer eq_scheduleType) {
		this.eq_scheduleType = eq_scheduleType;
	}

	public String getEq_resourceCode() {
		return eq_resourceCode;
	}

	public void setEq_resourceCode(String eq_resourceCode) {
		this.eq_resourceCode = eq_resourceCode;
	}
}