package com.openjava.dts.job.query;

import lombok.Getter;
import lombok.Setter;
import org.ljdp.core.db.RoDBQueryParam;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * 查询对象
 * @author hhr
 *
 */
@Getter
@Setter
public class DtsJobInstanceDBParam extends RoDBQueryParam {

	private Long jobId;//任务ID
	private Integer scheduleType;//调度类型（1、周期调度；2、手动调度）
	private String jobName;//任务名称
	private Long jobInstanceId;//实例ID
	private Integer jobInstanceType;//实例类型（1、周期实例；2、手动实例；3、补数实例；4、测试实例）
	private Integer status;//实例状态（1、等待中；2、运行中；3、运行成功；4、运行失败）
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date jobStartTimeGt;//任务开始时间 >=
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date jobStartTimeLt;//任务开始时间 <=
	private Integer jobType;//任务类型（1、数据库任务；2、API任务）
	private String createrId;//创建人ID
	private String systemId;//业务系统ID（DTS_INTEGRATION:数据汇聚平台） = ?
	private Integer scheduleCycle;//调度周期（月1周2时3日4）
	private int instanceType;//任务实例:0，组件实例:1

	private Integer isChild;
}