package com.openjava.dts.job.query;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.ljdp.core.db.RoDBQueryParam;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * 查询对象
 * @author hl
 *
 */
public class DtsSyncJobDBParam extends RoDBQueryParam {
	private Long eq_id;//id --主键查询

	private String like_name;//任务名称 like ?
	private Long eq_xxlJobId;//调试器id = ?
	private Integer eq_status;//状态（1、可用，待启动；2、队列中待执行；3、运行中；4、任务执行成功；5、任务执行失败；6、暂停中） = ?
	private Integer eq_lauchStatus;//启动状态（0、已停止；1、执行中） = ?
	private Integer eq_jobType;//任务类型（1、数据库任务；2、API任务） = ?
	private Integer eq_syncType;//0全量1增量 = ?
	private Long eq_createId;//创建人 = ?
	private Integer eq_scheduleType;//调度类型（1、周期调度；2、手动调度）
	private Integer eq_scheduleCycle;//调度周期(月1周2时3日4)
	private Integer eq_isFailureRestart;//失败重启是否失败重启（0、否；1、是）
	private Long eq_modifyId;//修改人 = ?
	private String like_createName;//创建人名字
	private String like_modifyName;//修改人名字

	private Integer eq_isChild;

	//这个字段是为了区分是否是标准库的
	private Integer compentType;

	//发布状态
	private Integer eq_publishStatus;
	public Integer getEq_publishStatus() {
		return eq_publishStatus;
	}
	public void setEq_publishStatus(Integer eq_publishStatus) {
		this.eq_publishStatus = eq_publishStatus;
	}

	public Integer getCompentType() {
		return compentType;
	}
	public void setCompentType(Integer compentType) {
		this.compentType = compentType;
	}

	//运维中心标志
	private String eq_flag;
	public String getEq_flag() {
		return eq_flag;
	}
	public void setEq_flag(String eq_flag) {
		this.eq_flag = eq_flag;
	}

	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date lt_createTime;//结束时间
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date gt_createTime;//开始时间

	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date lt_modifyTime;//结束时间
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date gt_modifyTime;//开始时间

	public Date getLt_createTime() {
		return lt_createTime;
	}
	public void setLt_createTime(String lt_createTime) {
		if (StringUtils.isEmpty(lt_createTime)) {
			this.lt_createTime = null;
		} else {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			try {
				this.lt_createTime = sdf.parse(lt_createTime);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
	}
	public Date getGt_createTime() {
		return gt_createTime;
	}
	public void setGt_createTime(String gt_createTime) {
		if(StringUtils.isEmpty(gt_createTime)){
			this.gt_createTime = null;
		}else {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			try {
				this.gt_createTime = sdf.parse(gt_createTime);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
	}

	public Date getLt_modifyTime() {
		return lt_modifyTime;
	}
	public void setLt_modifyTime(String lt_modifyTime) {
		if (StringUtils.isEmpty(lt_modifyTime)) {
			this.lt_modifyTime = null;
		}else{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			try {
				this.lt_modifyTime = sdf.parse(lt_modifyTime);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
	}
	public Date getGt_modifyTime() {
		return gt_modifyTime;
	}
	public void setGt_modifyTime(String gt_modifyTime) {
		if(StringUtils.isEmpty(gt_modifyTime)){
			this.gt_modifyTime = null;
		}else {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			try {
				this.gt_modifyTime = sdf.parse(gt_modifyTime);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
	}

	public Long getEq_modifyId() {
		return eq_modifyId;
	}
	public void setEq_modifyId(Long eq_modifyId) {
		this.eq_modifyId = eq_modifyId;
	}
	public Integer getEq_isFailureRestart() {
		return eq_isFailureRestart;
	}
	public void setEq_isFailureRestart(Integer eq_isFailureRestart) {
		this.eq_isFailureRestart = eq_isFailureRestart;
	}
	public Integer getEq_scheduleCycle() {
		return eq_scheduleCycle;
	}
	public void setEq_scheduleCycle(Integer eq_scheduleCycle) {
		this.eq_scheduleCycle = eq_scheduleCycle;
	}
	public Integer getEq_scheduleType() {
		return eq_scheduleType;
	}
	public void setEq_scheduleType(Integer eq_scheduleType) {
		this.eq_scheduleType = eq_scheduleType;
	}

	public Long getEq_id() {
		return eq_id;
	}
	public void setEq_id(Long id) {
		this.eq_id = id;
	}

	public String getLike_name() {
		return like_name;
	}
	public void setLike_name(String name) {
		this.like_name = name;
	}
	public Long getEq_xxlJobId() {
		return eq_xxlJobId;
	}
	public void setEq_xxlJobId(Long xxlJobId) {
		this.eq_xxlJobId = xxlJobId;
	}
	public Integer getEq_status() {
		return eq_status;
	}
	public void setEq_status(Integer status) {
		this.eq_status = status;
	}
	public Integer getEq_lauchStatus() {
		return eq_lauchStatus;
	}
	public void setEq_lauchStatus(Integer lauchStatus) {
		this.eq_lauchStatus = lauchStatus;
	}
	public Integer getEq_jobType() {
		return eq_jobType;
	}
	public void setEq_jobType(Integer jobType) {
		this.eq_jobType = jobType;
	}
	public Integer getEq_syncType() {
		return eq_syncType;
	}
	public void setEq_syncType(Integer syncType) {
		this.eq_syncType = syncType;
	}
	public Long getEq_createId() {
		return eq_createId;
	}
	public void setEq_createId(Long createId) {
		this.eq_createId = createId;
	}

	public String getLike_createName() {
		return like_createName;
	}
	public void setLike_createName(String like_createName) {
		this.like_createName = like_createName;
	}

	public String getLike_modifyName() {
		return like_modifyName;
	}
	public void setLike_modifyName(String like_modifyName) {
		this.like_modifyName = like_modifyName;
	}

	public Integer getEq_isChild() {
		return eq_isChild;
	}

	public void setEq_isChild(Integer eq_isChild) {
		this.eq_isChild = eq_isChild;
	}
}