package com.openjava.dts.job.query;

import java.util.Date;

import org.ljdp.core.db.RoDBQueryParam;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * 查询对象
 * @author hailang
 *
 */
public class DtsTableSeqDBParam extends RoDBQueryParam {
	private Long eq_id;//id --主键查询
	
	private String eq_tableName;//表的名称 = ?
	private String like_tableName;//表的名称 like ?
	private Long eq_seq;//seq = ?
	private Long eq_createId;//创建人id = ?
	
	public Long getEq_id() {
		return eq_id;
	}
	public void setEq_id(Long id) {
		this.eq_id = id;
	}
	
	public String getEq_tableName() {
		return eq_tableName;
	}
	public void setEq_tableName(String tableName) {
		this.eq_tableName = tableName;
	}
	public String getLike_tableName() {
		return like_tableName;
	}
	public void setLike_tableName(String tableName) {
		this.like_tableName = tableName;
	}
	public Long getEq_seq() {
		return eq_seq;
	}
	public void setEq_seq(Long seq) {
		this.eq_seq = seq;
	}
	public Long getEq_createId() {
		return eq_createId;
	}
	public void setEq_createId(Long createId) {
		this.eq_createId = createId;
	}
}