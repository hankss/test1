package com.openjava.dts.job.vo;


import lombok.Data;

@Data
public class DtsComponentRelatFieldVO {

    private String cid;
    private String tableName;
    private String fieldName;

}
