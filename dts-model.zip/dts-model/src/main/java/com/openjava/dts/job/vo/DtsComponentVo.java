package com.openjava.dts.job.vo;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.openjava.dts.job.domain.DtsComponentFieldMapping;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.persistence.Column;
import java.util.Date;
import java.util.List;

/**
 * @author linchuangang
 * @create 2020-03-06 17:43
 **/
@Data
@ApiModel("组件2.0详情信息")
public class DtsComponentVo {
    @ApiModelProperty("id")
    private Long id;

    @ApiModelProperty("组件名称")
    private String name;

    @ApiModelProperty("1数据源输入 2归集库输入 3资源目录输入 4需求任务输入 5归集库输出 6资源目录输出 7.需求任务输出 8字段值转换 9表整合转换 10 数据过滤转换")
    private Integer compentType;

    @ApiModelProperty("所属科室系统")
    private String systemName;

    @ApiModelProperty("所属科室ids")
    private String systemIds;

    @ApiModelProperty("数据源名字")
    private String datasourceName;

    @ApiModelProperty("数据源id")
    private String datasourceId;

    @ApiModelProperty("数据库名字")
    private String datasourceDbname;

    @ApiModelProperty("同步表名")
    private String tableName;

    @ApiModelProperty("切分键")
    private String splitKey;

    @ApiModelProperty("任务id")
    private Long jobId;

    @ApiModelProperty("前端组件自带的cid")
    private String cId;

    @ApiModelProperty(value = "该属性表示type=15|16的批量组件的cId，批量组件拆分多个子组件后，batchComponentId与cId代表父子关系",hidden = true)
    @JsonIgnore
    private String batchComponentId;

    @ApiModelProperty("前置关联组件的cid,json数组")
    private String pre;

    @ApiModelProperty("后置关联组件的cid,json数组")
    private String next;

    @ApiModelProperty("调试器id")
    private Long xxlJobId;

    @ApiModelProperty("0全量1增量")
    private Integer syncType;

    @ApiModelProperty("并发速率")
    private Integer concurrentNum;

    @ApiModelProperty("是否限流（0、否；1、是）")
    private Integer isLimitRate;

    @ApiModelProperty("同步速率")
    private Integer syncRate;

    @ApiModelProperty("清理规则（1、写入前保留已有数据；2、写入前删除已有数据）")
    private Integer cleanRule;

    @ApiModelProperty("启动状态（0、已停止；1、执行中）")
    private Integer launchStatus;

    @ApiModelProperty("状态（1、可用，待启动；2、队列中待执行；3、运行中；4、任务执行成功；5、任务执行失败；6、暂停中）")
    private Integer status;


    @ApiModelProperty("是否生成表 0不 1是")
    private Integer createTable;

    @ApiModelProperty("增量时间字段")
    private String incrementField;

    @ApiModelProperty("上一次运行增量时间")
    private Date lastIncrementTime;

    @ApiModelProperty("增量开始时间")
    private Date incrementStartTime;

    @ApiModelProperty("组件参数json")
    private String param;

    @ApiModelProperty("需求任务组件:任务名称")
    private String taskName;

    @ApiModelProperty("需求任务组件:任务id")
    private Long taskId;

    @ApiModelProperty("需求任务组件:FinalCommitId")
    private Long taskFinalCommitId;
    @ApiModelProperty("对应是需求任务接口的relevanceId,该属性用于数据同步过程中调用需求任务接口返回数据库连接信息")
    private Long relevanceId;

    @ApiModelProperty("表别名,通常对应是中文名")
    private String tableAlias;
    @ApiModelProperty("需求任务组件分类：组件类型：1：输入 2：输出，该属性用于数据同步过程中调用需求任务接口返回数据库连接信息,对应接口参数是componentType")
    private Integer taskComponentType;

    @ApiModelProperty("代表是从哪里开始创建同步任务的，任务类型：0：数据集成 1：需求工单 2：协作工单；该属性用于数据同步过程中调用需求任务接口返回数据库连接信息,对应接口参数是taskType")
    private Integer taskType;

    @ApiModelProperty("资源目录id")
    private Long resourceId;

    @ApiModelProperty("资源目录名称")
    private String resourceName;

    @ApiModelProperty("资源目录编码")
    private String resourceCode;

    @ApiModelProperty("数据湖目录位置")
    private String resourcePath;

    @ApiModelProperty("数据湖目录位置code")
    private String resourcePathCode;

    @ApiModelProperty("创建人ID")
    private Long createId;

    @ApiModelProperty("创建人名称")
    private String createName;

    @ApiModelProperty("创建时间")
    private Date createTime;

    @ApiModelProperty("修改人ID")
    private Long modifyId;

    @ApiModelProperty("修改人名称")
    private String modifyName;

    @ApiModelProperty("修改时间")
    private Date modifyTime;

    @ApiModelProperty("来源业务ID")
    private String businessId;

    @ApiModelProperty("项目id")
    private Long projectId;

    @ApiModelProperty("表注释")
    private String tableComment;

    @ApiModelProperty("项目名称")
    private String projectName;

    @ApiModelProperty("业务系统ID（DTS_INTEGRATION:数据汇聚平台）")
    private String systemId;

    @ApiModelProperty("组件类型分组,默认为null，取值：input-输入组件，output-输出组件，transfer-转换组件")
    private String category;

    @ApiModelProperty("批量组件多选表名集合")
    private List<String> tableNameList;

    @ApiModelProperty("批量组件切分键集合")
    private List<JSONObject> splitKeyList;

    @ApiModelProperty("批量数据源输入组件增量集合")
    private  List<JSONObject> incrementFieldList;


    private List<DtsComponentFieldMapping> mapping;

    @ApiModelProperty(value = "默认为0，0代表不会选择整个库的表，1代表整个库的表都用到，当值为1时，tableNameList不用传")
    private Integer entireEnable;

    @ApiModelProperty(value = "批量组件多选表名集合",hidden = true)
    @JsonIgnore
    private String tableNames;

    @ApiModelProperty(value = "批量组件切分键集合",hidden = true)
    @JsonIgnore
    private String splitKeyNames;

    @ApiModelProperty(value = "批量数据源输入组件增量集合",hidden = true)
    @JsonIgnore
    private String incrementFields;

    @ApiModelProperty("主题分类ID")
    private String subjectTypeId;

    @ApiModelProperty("主题分类名称")
    private String subjectTypeName;

    public void setTableNames(String tableNames) {
        this.tableNames = tableNames;
        this.setTableNameList(JSON.parseArray(this.tableNames,String.class));
    }

    public void setSplitKeyNames(String splitKeyNames) {
        this.splitKeyNames = splitKeyNames;
        this.setSplitKeyList(JSON.parseArray(this.splitKeyNames,JSONObject.class));
    }

    public void setIncrementFields(String incrementFields) {
        this.incrementFields = incrementFields;
        this.setIncrementFieldList(JSON.parseArray(this.incrementFields,JSONObject.class));
    }
}
