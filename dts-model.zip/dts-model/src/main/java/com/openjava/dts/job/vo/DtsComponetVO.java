package com.openjava.dts.job.vo;

import com.openjava.dts.dataprovider.DataProvider;
import com.openjava.dts.ddl.domain.DtsDatasource;
import com.openjava.dts.job.domain.DtsComponent;
import com.openjava.dts.job.domain.DtsSyncJob;
import lombok.Data;

@Data
public class DtsComponetVO {

    private DtsComponent dtsCompent;
    private DtsDatasource dtsDatasource;
    private DtsSyncJob dtsSyncJob;
    private DataProvider dataProvider;

}
