package com.openjava.dts.job.vo;

import com.openjava.dts.ddl.domain.DtsColumn;
import com.openjava.dts.ddl.domain.DtsTable;
import com.openjava.dts.job.domain.DtsJob;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.ljdp.component.result.SuccessMessage;

import java.util.List;

@ApiModel("数据汇聚批量任务实体")
@Data
@EqualsAndHashCode(callSuper = false)
//@Accessors(chain = true)
public class DtsJobBatchVo {
    @ApiModelProperty(value = "创建任务属性")
    private DtsJob dtsJob;
    @ApiModelProperty(value = "创建任务表属性")
    private List<DtsTable> dtsTables;
    @ApiModelProperty(value = "创建任务字段属性")
    private List<DtsColumn> dtsColumns;
    @ApiModelProperty(value = "0成功创建 ,其它失败创建 ")
    private Integer createStatus;//0成功 其它失败
    @ApiModelProperty(value = "返回的信息 ")
    private String message;

/*    @ApiModelProperty("批量保存资源目录是否同步成功")
    private List<SuccessMessage> synSignMessage;*/
}
