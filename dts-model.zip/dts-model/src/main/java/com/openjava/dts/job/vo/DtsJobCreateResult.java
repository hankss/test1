package com.openjava.dts.job.vo;

import com.openjava.dts.ddl.domain.DtsColumn;
import com.openjava.dts.ddl.domain.DtsDatasource;
import com.openjava.dts.ddl.domain.DtsTable;
import com.openjava.dts.job.domain.DtsJob;
import lombok.Data;

import java.util.List;

@Data
public class DtsJobCreateResult {

    private DtsJob job;
    private DtsDatasource readerDatasource;
    private DtsDatasource writerDatasource;
    private DtsTable readerTable;
    private List<DtsColumn> readerColumns;
    private DtsTable writerTable;
    private List<DtsColumn> writerColumns;


}
