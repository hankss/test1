package com.openjava.dts.job.vo;

import com.openjava.dts.job.domain.DtsJob;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;


@ApiModel("返回详细的任务实体")
@Data
@EqualsAndHashCode(callSuper = false)
//@Accessors(chain = true)
public class DtsJobDetailResponse implements Serializable {

    @ApiModelProperty(value = "任务实体")
    private DtsJob dtsJob;

    @ApiModelProperty(value = "数据表及字段详细列表")
    private List<DtsTableResponse> dtsTableResponseList = Collections.emptyList();;
}
