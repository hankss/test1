package com.openjava.dts.job.vo;

import com.openjava.dts.ddl.domain.DtsDatasource;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author: lsw
 * @Date: 2020/3/10 9:34
 */
@ApiModel("任务结果（兼容同步任务）")
@Data
public class DtsJobForSyncJobResponse {

    @ApiModelProperty("目标表名（自动生成）")
    private String writerTableName;

    @ApiModelProperty("reader数据源")
    private DtsDatasource readerDatasource;

    @ApiModelProperty("writer数据源")
    private DtsDatasource writerDatasource;
}
