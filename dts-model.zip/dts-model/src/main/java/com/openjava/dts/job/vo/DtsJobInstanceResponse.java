package com.openjava.dts.job.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;

/**
 * 任务实例查询结果
 * @author hhr
 *
 */
@ApiModel("任务实例查询结果")
@Data
public class DtsJobInstanceResponse {

	public DtsJobInstanceResponse() {

	}

	public DtsJobInstanceResponse(Integer scheduleType, String jobName, Long jobInstanceId, Integer jobInstanceType, Integer status,
								  Date jobStartTime, Date jobEndTime, Date syncStartTime, Date syncEndTime, Integer jobType, Integer cleanRule, Long xxlJobInstanceId) {
		this.scheduleType = scheduleType;
		this.jobName = jobName;
		this.jobInstanceId = jobInstanceId;
		this.jobInstanceType = jobInstanceType;
		this.status = status;
		this.jobStartTime = jobStartTime;
		this.jobEndTime = jobEndTime;
		this.syncStartTime = syncStartTime;
		this.syncEndTime = syncEndTime;
		this.jobType = jobType;
		this.cleanRule = cleanRule;
		this.xxlJobInstanceId = xxlJobInstanceId;
	}

	@ApiModelProperty("调度类型（1、周期调度；2、手动调度）")
	private Integer scheduleType;

	@ApiModelProperty("任务名称")
	private String jobName;

	@ApiModelProperty("实例ID")
	private Long jobInstanceId;
	
	@ApiModelProperty("实例类型（1、周期实例；2、手动实例；3、补数实例；4、测试实例）")
	private Integer jobInstanceType;
	@ApiModelProperty("实例类型名称")
	private String jobInstanceTypeName;
	
	@ApiModelProperty("实例状态（1、等待中；2、运行中；3、运行成功；4、运行失败）")
	private Integer status;
	@ApiModelProperty("实例状态名称")
	private String statusName;
	
	@ApiModelProperty("任务开始时间")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	private Date jobStartTime;
	
	@ApiModelProperty("任务结束时间")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	private Date jobEndTime;
	
	@ApiModelProperty("同步开始时间")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	private Date syncStartTime;
	
	@ApiModelProperty("同步结束时间")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	private Date syncEndTime;

	@ApiModelProperty("任务类型（1、数据库任务；2、API任务）")
	private Integer jobType;
	@ApiModelProperty("任务类型名称")
	private String jobTypeName;

	@ApiModelProperty("XXL_JOB的任务实例ID")
	private Long xxlJobInstanceId;

	@ApiModelProperty("任务耗时(秒)")
	private Long execTimeLength;

	@ApiModelProperty("同步方式（0、全量同步；1、增量同步）")
	private Integer syncType;
	@ApiModelProperty("同步方式名称")
	private String syncTypeName;

	@ApiModelProperty("并发数")
	private Integer concurrentNum;

	@ApiModelProperty("同步速率")
	private Integer syncRate;

	@ApiModelProperty("调度周期")
	private String jobCron;

	@ApiModelProperty("是否失败重启（0、否；1、是）")
	private Integer isFailureRestart;
	@ApiModelProperty("是否失败重启名称")
	private String isFailureRestartName;

	@ApiModelProperty("清理规则（1、写入前保留已有数据；2、写入前删除已有数据。）")
	private Integer cleanRule;
	@ApiModelProperty("清理规则名称")
	private String cleanRuleName;

}