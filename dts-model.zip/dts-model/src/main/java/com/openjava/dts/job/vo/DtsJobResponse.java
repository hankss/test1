package com.openjava.dts.job.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel("任务结果")
@Data
public class DtsJobResponse {
    @ApiModelProperty("任务ID")
    private Long jobId;

    @ApiModelProperty("目标表名（自动生成）")
    private String writerTableName;
}
