package com.openjava.dts.job.vo;

import lombok.Data;

@Data
public class DtsJobResult {
    private Integer code;
    private String msg;
    private String content;
}
