package com.openjava.dts.job.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.Date;

/**
 * @author by 丘健里
 * @date 2020/3/5.
 */
@ApiModel("数据挂载管理--数据归集数据")
@Data
@EqualsAndHashCode(callSuper = false)
@ToString
public class DtsJobToDataMountVO {

    @ApiModelProperty("序号")
    private Long id;

    @ApiModelProperty("任务名")
    private String jobName;

    @ApiModelProperty("任务描述")
    private String jobDesc;

    @ApiModelProperty("任务类型")
    private Integer jobType;

    @ApiModelProperty("数据库名")
    private String databaseName;

    @ApiModelProperty("接口名称")
    private String interfaceName;

    @ApiModelProperty("操作人")
    private String operatorName;

    @ApiModelProperty("操作时间")
    private Date operationTime;

}
