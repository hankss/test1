package com.openjava.dts.job.vo;

import com.openjava.dts.job.domain.DtsComponent;
import com.openjava.dts.job.domain.DtsSyncJob;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author by 丘健里
 * @date 2020/2/26.
 */
@ApiModel("返回详细的任务实体")
@Data
@EqualsAndHashCode(callSuper = false)
public class DtsSyncJobDetailResponse {
    @ApiModelProperty(value = "任务实体")
    private DtsSyncJob dtsSyncJob;

    @ApiModelProperty(value = "组件实体")
    private DtsComponent dtsCompent;
}
