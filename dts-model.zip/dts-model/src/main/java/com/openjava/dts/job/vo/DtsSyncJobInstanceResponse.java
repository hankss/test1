package com.openjava.dts.job.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.persistence.Column;
import javax.validation.constraints.Max;
import java.util.Date;

/**
 * 任务实例查询结果
 * @author hhr
 *
 */
@ApiModel("任务实例查询结果2.0")
@Data
@EqualsAndHashCode(callSuper = true)
@ToString
public class DtsSyncJobInstanceResponse extends DtsJobInstanceResponse{

	private Long jobId;

	@ApiModelProperty("运行时长")
	private String executeTime;

	@ApiModelProperty("调度周期")
	private Integer scheduleCycle;

	@ApiModelProperty("调度周期名称")
	private String scheduleCycleName;

	@ApiModelProperty("通知提醒类型（1、成功提醒；2、失败提醒）逗号分隔")
	private String noticeType;

	@ApiModelProperty("XXL_JOB的任务实例ID")
	private Long xxlJobInstanceId;

	@ApiModelProperty(hidden = true)
	@JsonIgnore
	private Long executeDuration;

	public DtsSyncJobInstanceResponse() {
	}

	public DtsSyncJobInstanceResponse(Long jobId,Integer scheduleType, String jobName, Long jobInstanceId, Integer jobInstanceType, Integer status,
									  Date jobStartTime, Date jobEndTime, Integer scheduleCycle, Long executeDuration ,Long xxlJobInstanceId) {
		this.jobId = jobId;
		this.setScheduleType(scheduleType);
		this.setJobName(jobName);
		this.setJobInstanceId(jobInstanceId);
		this.setJobInstanceType(jobInstanceType);
		this.setStatus(status);
		this.setJobStartTime(jobStartTime);
		this.setJobEndTime(jobEndTime);
		this.scheduleCycle = scheduleCycle;
		this.executeDuration = executeDuration;
		this.xxlJobInstanceId = xxlJobInstanceId;
	}

	public String getScheduleCycleName() {
		String str = "未知";
		if (this.getScheduleCycle() == null){
			return str;
		}
		switch (this.getScheduleCycle()){
			case 1:
				str = "月";
				break;
			case 2:
				str = "周";
				break;
			case 3:
				str = "日";
				break;
			case 4:
				str = "时";
				break;
		}
		return str;
	}

	public String getExecuteTime() {
		String str = "未知";
		if (executeDuration == null){
			return str;
		}
		str = "%sh%sm%ss";
		int hour = (int) (executeDuration/3600);
		int minus = (int) (executeDuration/60 %60);
		int sec = (int) (executeDuration % 60);
		return String.format(str,hour,minus,sec);
	}
}