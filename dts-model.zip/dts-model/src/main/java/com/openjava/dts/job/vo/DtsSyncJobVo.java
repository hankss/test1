package com.openjava.dts.job.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author linchuangang
 * @create 2020-02-24 18:34
 **/
@Data
public class DtsSyncJobVo implements Serializable {

    @ApiModelProperty("id")
    private Long id;

    @ApiModelProperty("任务名称")
    private String name;

    @ApiModelProperty("任务描述")
    private String jobDesc;

    @ApiModelProperty("调试器id")
    private Long xxlJobId;

    @ApiModelProperty("来源系统名称")
    private String sourceSystem;

    @ApiModelProperty("状态（1、可用，待启动；2、队列中待执行；3、运行中；4、任务执行成功；5、任务执行失败；6、暂停中）")
    private Integer status;

    @ApiModelProperty("启动状态（0、已停止；1、执行中）")
    private Integer lauchStatus;

    @ApiModelProperty("任务类型（1、数据库任务；2、API任务）")
    private Integer jobType;

    @ApiModelProperty("0全量1增量")
    private Integer syncType;

    @ApiModelProperty("月1周2时3日4")
    private Integer scheduleCycle;

    @ApiModelProperty("调度类型（1、周期调度；2、手动调度）")
    private Integer scheduleType;

    @ApiModelProperty("执行时间12:00")
    private String runTime;

    @ApiModelProperty("开始时间12:00")
    private String startTime;

    @ApiModelProperty("结束时间12:00")
    private String endTime;

    @ApiModelProperty("每间隔?小时")
    private Integer interval;

    @ApiModelProperty("cron表达式")
    private String jobCron;

    @ApiModelProperty("失败重启是否失败重启（0、否；1、是）")
    private Integer isFailureRestart;

    @ApiModelProperty("重启次数")
    private Integer retryTime;

    @ApiModelProperty("任务前端显示html")
    private String jobHtml;

    @ApiModelProperty("通知提醒类型（1、成功提醒；2、失败提醒）逗号分隔")
    private String noticeType;

    @ApiModelProperty("提醒方式（1、邮件提醒；2、站内信；3、短信）逗号分隔")
    private String noticeWay;

    @ApiModelProperty("通知提醒邮箱（逗号分隔）")
    private String noticeMails;

    @ApiModelProperty("通知提醒手机（逗号分隔）")
    private String noticePhones;

    @ApiModelProperty("通知提醒接收人id(逗号分隔)")
    private String noticeReceiverIds;

    @ApiModelProperty("通知提醒接收人姓名（逗号分隔）")
    private String noticeReceiverNames;

    @ApiModelProperty("来源业务ID")
    private String businessId;

    @ApiModelProperty("业务系统ID（DTS_INTEGRATION:数据汇聚平台）")
    private String systemId;

    @ApiModelProperty("创建人")
    private Long createId;

    @ApiModelProperty("创建人名字")
    private String createName;

    @ApiModelProperty("创建人id")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    private Date createTime;

    @ApiModelProperty("修改人")
    private Long modifyId;

    @ApiModelProperty("修改名字")
    private String modifyName;

    @ApiModelProperty("修改时间")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    private Date modifyTime;

    @ApiModelProperty("跳转来源，0：数据集成自身页面,1：需求任务,2:数据协作,3：资源目录")
    private Integer redirectType;

    @ApiModelProperty("是否新增")
    private Boolean isNew;

    @ApiModelProperty("发布状态（1、未发布；2、已发布）")
    private Integer publishStatus;

    private List<DtsComponentVo> components;

}
