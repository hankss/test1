package com.openjava.dts.job.vo;

import lombok.Data;

@Data
public class DtsTableJoinParamVO {

    private String cid;
    private Integer integrationType; /** 1列整合,列整合joinType relation有效 2表整合**/
    private Integer joinType; /** 1左链接 默认,2右链接 3整合**/
    private String relation; /** "componentId@tableName@fieldName=componentId@tableName@fieldName,componentId@tableName@fieldName=componentId@tableName@fieldName**/
    private String rules;
}
