package com.openjava.dts.job.vo;

import com.openjava.dts.ddl.domain.DtsColumn;
import com.openjava.dts.ddl.domain.DtsTable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Collections;
import java.util.List;


@ApiModel("数据汇聚批量任务实体")
@Data
@EqualsAndHashCode(callSuper = false)
//@Accessors(chain = true)
public class DtsTableResponse {

    @ApiModelProperty(value = "表详细")
    private DtsTable dtsTable;

    @ApiModelProperty(value = "表对应字段详细")
    private List<DtsColumn> dtsColumnList = Collections.emptyList();;
}
