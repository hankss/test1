package com.openjava.dts.job.vo;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;

import java.io.Serializable;

/**
 * created by Annie since 2020/5/27 10:56
 * intro: Annie
 */
@Data
public class StandardDatabaseInfo implements Serializable {
    private String driverClassName;
    private String url;
    private String username;
    private String password;
    private String dbName;
    private String schema;
}
