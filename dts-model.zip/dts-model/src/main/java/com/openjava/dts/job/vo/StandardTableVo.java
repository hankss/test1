package com.openjava.dts.job.vo;

import com.openjava.dts.job.domain.DtsComponentFieldMapping;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.List;

/**
 * created by Annie since 2020/5/27 15:38
 * intro: Annie
 */
@Data
@Accessors(chain = true)
@ApiModel("标准库输出组件建表接口返回体")
public class StandardTableVo implements Serializable {


    @ApiModelProperty(value = "标准库里的表名")
    private String tableName;


    @ApiModelProperty(value = "字段映射集合")
    private List<DtsComponentFieldMapping> mapping;
}
