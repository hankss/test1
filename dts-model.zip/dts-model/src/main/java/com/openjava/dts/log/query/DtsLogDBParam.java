package com.openjava.dts.log.query;

import org.ljdp.core.db.RoDBQueryParam;

/**
 * 查询对象
 * @author hl
 *
 */
public class DtsLogDBParam extends RoDBQueryParam {
	private Long eq_id;//id --主键查询
	
	private String like_title;//title like ?
	private String like_keyword;//keyword like ?
	private String eq_lever;//lever = ?
	private String like_content;//content like ?
	private Long eq_createUid;//create_uid = ?
	
	public Long getEq_id() {
		return eq_id;
	}
	public void setEq_id(Long id) {
		this.eq_id = id;
	}
	
	public String getLike_title() {
		return like_title;
	}
	public void setLike_title(String title) {
		this.like_title = title;
	}
	public String getLike_keyword() {
		return like_keyword;
	}
	public void setLike_keyword(String keyword) {
		this.like_keyword = keyword;
	}
	public String getEq_lever() {
		return eq_lever;
	}
	public void setEq_lever(String lever) {
		this.eq_lever = lever;
	}
	public String getLike_content() {
		return like_content;
	}
	public void setLike_content(String content) {
		this.like_content = content;
	}
	public Long getEq_createUid() {
		return eq_createUid;
	}
	public void setEq_createUid(Long createUid) {
		this.eq_createUid = createUid;
	}
}