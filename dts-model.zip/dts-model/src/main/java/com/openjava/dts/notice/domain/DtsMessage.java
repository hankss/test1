package com.openjava.dts.notice.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;

/**
 * 实体
 * @author hhr
 *
 */
@ApiModel("站内信")
@Data
@EqualsAndHashCode(callSuper = false)
//@Accessors(chain = true)
@Entity
@Table(name = "DTS_MESSAGE")
public class DtsMessage implements Persistable<Long>,Serializable {
	
	@ApiModelProperty("id")
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@ApiModelProperty("发送人id")
	@Length(min=0, max=64)
	@Column(name = "sender_id")
	private String senderId;

	@ApiModelProperty("发送人姓名")
	@Length(min=0, max=64)
	@Column(name = "sender_name")
	private String senderName;

	@ApiModelProperty("发送时间")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "send_time")
	private Date sendTime;

	@ApiModelProperty("标题")
	@Length(min=0, max=512)
	@Column(name = "title")
	private String title;

	@ApiModelProperty("消息类型(数据同步,数据集,数据湖,资源目录)")
	@Length(min = 0,max = 32)
	@Column(name = "message_type")
	private String messageType;
	
	@ApiModelProperty("内容")
	@Length(min=0, max=1024)
	@Column(name = "content")
	private String content;

	@ApiModelProperty("接收人id")
	@Length(min=0, max=64)
	@Column(name = "receiver_id")
	private String receiverId;

	@ApiModelProperty("接收人姓名")
	@Length(min=0, max=64)
	@Column(name = "receiver_name")
	private String receiverName;

	@ApiModelProperty("消息状态（1、已读；0、未读）")
	@Max(99L)
	@Column(name = "status")
	private Integer status;
	
	@ApiModelProperty("创建时间")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "create_time")
	private Date createTime;
	
	
	@ApiModelProperty("是否新增")
	@Transient
    private Boolean isNew;
	
//	@Transient
//    @JsonIgnore
    @Override
    public Long getId() {
        return this.id;
	}
    
    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
    	if(isNew != null) {
    		return isNew;
    	}
    	if(this.id != null) {
    		return false;
    	}
    	return true;
    }
    
}