package com.openjava.dts.notice.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;

/**
 * 实体
 * @author 何子佑
 *
 */
@ApiModel("DtsSms")
@Data
@EqualsAndHashCode(callSuper = false)
//@Accessors(chain = true)
@Entity
@Table(name = "DTS_SMS")
public class DtsSms implements Persistable<Long>,Serializable {
	
	@ApiModelProperty("短信id")
	@Id
	@Column(name = "sms_id")
	private Long smsId;
	
	@ApiModelProperty("发送源")
	@Length(min=0, max=128)
	@Column(name = "send_user")
	private String sendUser;
	
	@ApiModelProperty("接收人")
	@Length(min=0, max=128)
	@Column(name = "receive_user")
	private String receiveUser;
	
	@ApiModelProperty("接收手机号码")
	@Length(min=0, max=16)
	@Column(name = "phone")
	private String phone;
	
	@ApiModelProperty("短信内容")
	@Length(min=0, max=2048)
	@Column(name = "msg")
	private String msg;
	
	@ApiModelProperty("发送时间")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "send_time")
	private Date sendTime;
	
	@ApiModelProperty("提交状态1成功2失败")
	@Max(9L)
	@Column(name = "send_status")
	private Integer sendStatus;
	
	@ApiModelProperty("发送次数")
	@Max(999L)
	@Column(name = "send_times")
	private Integer sendTimes;
	
	@ApiModelProperty("标志:记录短信备注")
	@Length(min=0, max=255)
	@Column(name = "remark")
	private String remark;
	
	@ApiModelProperty("短信状态码")
	@Length(min=0, max=64)
	@Column(name = "receive_code")
	private String receiveCode;
	
	@ApiModelProperty("短信接收时间")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "receive_time")
	private Date receiveTime;
	
	@ApiModelProperty("运营商代码 yd lt dx")
	@Length(min=0, max=64)
	@Column(name = "sp_code")
	private String spCode;
	
	@ApiModelProperty("短信序列号")
	@Max(99999999L)
	@Column(name = "sq_num")
	private Integer sqNum;
	
	@ApiModelProperty("优先级别")
	@Max(9L)
	@Column(name = "priority")
	private Integer priority;
	
	
	@ApiModelProperty("是否新增")
	@Transient
    private Boolean isNew;
	
	@Transient
    @JsonIgnore
    @Override
    public Long getId() {
        return this.smsId;
	}
    
    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
    	if(isNew != null) {
    		return isNew;
    	}
    	if(this.smsId != null) {
    		return false;
    	}
    	return true;
    }
    
}