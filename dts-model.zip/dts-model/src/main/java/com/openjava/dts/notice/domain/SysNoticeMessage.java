package com.openjava.dts.notice.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.openjava.admin.user.vo.OaOrgVO;
import com.openjava.admin.user.vo.OaUserVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.constraints.Length;
import org.ljdp.secure.valid.AddGroup;
import org.ljdp.secure.valid.UpdateGroup;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;

/**
 * @author JianLi
 */
@ApiModel("站内信")
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class SysNoticeMessage implements Serializable {

    @ApiModelProperty("id")
    private Long id;

    @ApiModelProperty("标题")
    private String title;

    @ApiModelProperty("消息类型id,对应枚举中的code")
    private Long messageTypeId;

    @ApiModelProperty("消息类型(数据同步,数据集,数据湖,资源目录)")
    private String messageType;

    @ApiModelProperty("内容")
    private String content;

    @ApiModelProperty("发送人id")
    private String senderId;

    @ApiModelProperty("发送人姓名")
    private String senderName;

    @ApiModelProperty("发送时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    private Date sendTime;

    @ApiModelProperty("发送人账号")
    private String senderAccount;

    @ApiModelProperty("发送人部门code")
    private String senderDeptCode;

    @ApiModelProperty("发送人部门名称")
    private String senderDeptName;

    @ApiModelProperty("发送人科室code")
    private String senderSectionCode;

    @ApiModelProperty("发送人科室名字")
    private String senderSectionName;

    @ApiModelProperty("发送人角色别名")
    private String senderRoleAlias;

    @ApiModelProperty("接收人id")
    private String receiverId;

    @ApiModelProperty("接收人姓名")
    private String receiverName;

    @ApiModelProperty("接收时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    private Date receiverTime;

    @ApiModelProperty("接收人账号")
    @Length(min = 0, max = 100)
    @Column(name = "RECEIVER_ACCOUNT")
    private String receiverAccount;

    @ApiModelProperty("接收人部门code")
    private String receiverDeptCode;

    @ApiModelProperty("接收人部门名称")
    private String receiverDeptName;

    @ApiModelProperty("接收人科室code")
    private String receiverSectionCode;

    @ApiModelProperty("接收人科室名字")
    private String receiverSectionName;

    @ApiModelProperty("接收人角色别名")
    private String receiverRoleAlias;

    @ApiModelProperty("关联表id")
    private Long bid;

    @ApiModelProperty("发送类型(0:全部 1：部门 2：科室 3：角色  4：个人 5:部门+角色 6：科室+角色 7：部门+个人)")
    private Long sendType;

    /**
     * 填充发送人信息
     *
     * @param user 用户信息
     */
    public void fillUpSenderInfo(OaUserVO user) {
        String userId = user.getUserId();
        if (StringUtils.isNumeric(userId)) {
            //用户ID
            this.setSenderId(userId);
        }
        //获取用户所属的机构信息
        OaOrgVO topOrg = user.getTopOrg();
        if (topOrg != null) {
            //部门CODE
            String orgCode = topOrg.getDeptcode();
            this.setSenderDeptCode(orgCode);
            //部门名称
            String orgName = topOrg.getOrgname();
            this.setSenderDeptName(orgName);

        }
        //科室CODE
        this.setSenderSectionCode(user.getDeptcode())
                //科室名称
                .setSenderSectionName(user.getOrgname())
                .setSenderAccount(user.getUserAccount())
                .setSenderName(user.getUserName())
                .setSendTime(new Date())
                .setSenderRoleAlias(user.getRoleAlias().toString());
    }

    public SysNoticeMessage() {

    }

    public SysNoticeMessage(OaUserVO sendUser) {
        OaOrgVO dept = sendUser.getTopOrg();
        this.senderAccount = sendUser.getUserAccount();
        if (dept != null) {
            this.senderDeptCode = dept.getDeptcode();
            this.senderDeptName = dept.getOrgname();
        }
        this.senderId = sendUser.getUserId();
        this.senderName = sendUser.getUserName();
        if (sendUser.getRoleAlias().size() > 0) {
            this.senderRoleAlias = String.join(",", sendUser.getRoleAlias());
        }
        this.senderSectionCode = sendUser.getOrgcode();
        this.senderSectionName = sendUser.getOrgname();
        this.sendTime = new Date();
    }
}
