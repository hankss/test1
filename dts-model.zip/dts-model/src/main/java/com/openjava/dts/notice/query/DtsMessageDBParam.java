package com.openjava.dts.notice.query;

import org.ljdp.core.db.RoDBQueryParam;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * 查询对象
 * @author hhr
 *
 */
public class DtsMessageDBParam extends RoDBQueryParam {
	private Long eq_id;//id --主键查询
	
	private String like_title;//标题 like ?
	private Integer eq_status;//消息状态 = ?
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date le_sendTime;//发送时间 <= ?
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date ge_sendTime;//发送时间 >= ?
	private String eq_receiverId;//接收人 = ?
	private String like_content;//内容
	private String like_messageType; //消息类型

	public Long getEq_id() {
		return eq_id;
	}
	public void setEq_id(Long id) {
		this.eq_id = id;
	}
	
	public String getLike_title() {
		return like_title;
	}
	public void setLike_title(String title) {
		this.like_title = title;
	}
	public Integer getEq_status() {
		return eq_status;
	}
	public void setEq_status(Integer status) {
		this.eq_status = status;
	}
	public Date getLe_sendTime() {
		return le_sendTime;
	}
	public void setLe_sendTime(Date sendTime) {
		this.le_sendTime = sendTime;
	}
	public Date getGe_sendTime() {
		return ge_sendTime;
	}
	public void setGe_sendTime(Date sendTime) {
		this.ge_sendTime = sendTime;
	}

	public String getEq_receiverId() {
		return eq_receiverId;
	}

	public void setEq_receiverId(String eq_receiverId) {
		this.eq_receiverId = eq_receiverId;
	}

	public String getLike_content() {
		return like_content;
	}
	public void setLike_content(String like_content) {
		this.like_content = like_content;
	}

	public String getLike_messageType() {
		return like_messageType;
	}
	public void setLike_messageType(String like_messageType) {
		this.like_messageType = like_messageType;
	}
}