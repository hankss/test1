package com.openjava.dts.notice.query;

import org.ljdp.core.db.RoDBQueryParam;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * 查询对象
 * @author 何子佑
 *
 */
public class DtsSmsDBParam extends RoDBQueryParam {
	private Long eq_smsId;//短信id --主键查询
	
	private String eq_sendUser;//发送源 = ?
	private String eq_receiveUser;//接收人 = ?
	private String eq_phone;//接收手机号码 = ?
	private String like_msg;//短信内容 like ?
	private Integer eq_sendStatus;//提交状态1成功2失败 = ?
	private Integer ge_sendTimes;//发送次数 >= ?
	private String like_remark;//标志:记录短信备注 like ?
	private String eq_receiveCode;//短信状态码 = ?
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date ge_receiveTime;//短信接收时间 >= ?
	private String eq_spCode;//运营商代码 yd lt dx = ?
	
	public Long getEq_smsId() {
		return eq_smsId;
	}
	public void setEq_smsId(Long smsId) {
		this.eq_smsId = smsId;
	}
	
	public String getEq_sendUser() {
		return eq_sendUser;
	}
	public void setEq_sendUser(String sendUser) {
		this.eq_sendUser = sendUser;
	}
	public String getEq_receiveUser() {
		return eq_receiveUser;
	}
	public void setEq_receiveUser(String receiveUser) {
		this.eq_receiveUser = receiveUser;
	}
	public String getEq_phone() {
		return eq_phone;
	}
	public void setEq_phone(String phone) {
		this.eq_phone = phone;
	}
	public String getLike_msg() {
		return like_msg;
	}
	public void setLike_msg(String msg) {
		this.like_msg = msg;
	}
	public Integer getEq_sendStatus() {
		return eq_sendStatus;
	}
	public void setEq_sendStatus(Integer sendStatus) {
		this.eq_sendStatus = sendStatus;
	}
	public Integer getGe_sendTimes() {
		return ge_sendTimes;
	}
	public void setGe_sendTimes(Integer sendTimes) {
		this.ge_sendTimes = sendTimes;
	}
	public String getLike_remark() {
		return like_remark;
	}
	public void setLike_remark(String remark) {
		this.like_remark = remark;
	}
	public String getEq_receiveCode() {
		return eq_receiveCode;
	}
	public void setEq_receiveCode(String receiveCode) {
		this.eq_receiveCode = receiveCode;
	}
	public Date getGe_receiveTime() {
		return ge_receiveTime;
	}
	public void setGe_receiveTime(Date receiveTime) {
		this.ge_receiveTime = receiveTime;
	}
	public String getEq_spCode() {
		return eq_spCode;
	}
	public void setEq_spCode(String spCode) {
		this.eq_spCode = spCode;
	}
}