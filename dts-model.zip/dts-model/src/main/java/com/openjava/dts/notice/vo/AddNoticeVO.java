package com.openjava.dts.notice.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;

/**
 * 实体
 * @author 子右
 *
 */
@ApiModel("添加提醒VO")
@Data
public class AddNoticeVO {
	
	@ApiModelProperty("任务ID")
	private Long jobId;

	@ApiModelProperty("通知提醒类型（1、成功提醒；2、失败提醒）逗号隔开")
	private String noticeType;

	@ApiModelProperty("提醒方式（1、邮件提醒；2、站内信；3、短信）逗号隔开")
	private String noticeWay;

	@ApiModelProperty("通知提醒邮箱（逗号分隔）")
	private String noticeMails;

	@ApiModelProperty("通知提醒手机（逗号分隔）")
	private String noticePhones;

	@ApiModelProperty("通知提醒接收人id(逗号分隔)")
	private String noticeReceiverIds;

	@ApiModelProperty("通知提醒接收人姓名（逗号分隔）")
	private String noticeReceiverNames;
    
}