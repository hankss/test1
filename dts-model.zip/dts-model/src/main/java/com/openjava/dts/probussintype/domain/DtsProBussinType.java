package com.openjava.dts.probussintype.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;

/**
 * 实体
 * @author hl
 *
 */
@ApiModel("DtsProBussinType")
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@Entity
@Table(name = "DTS_PRO_BUSSIN_TYPE")
public class DtsProBussinType implements Persistable<Long>,Serializable {
	
	@ApiModelProperty("id")
	@Id
	@Column(name = "id")
	private Long id;
	
	@ApiModelProperty("名称")
	@Length(min=0, max=128)
	@Column(name = "name")
	private String name;
	
	@ApiModelProperty("父id")
	@Max(9223372036854775806L)
	@Column(name = "parent_id")
	private Long parentId;
	
	@ApiModelProperty("机构id")
	@Length(min=0, max=128)
	@Column(name = "org_id")
	private String orgId;
	
	@ApiModelProperty("机构名字")
	@Length(min=0, max=128)
	@Column(name = "org_name")
	private String orgName;
	
	@ApiModelProperty("添加时间")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "create_time")
	private Date createTime;
	
	@ApiModelProperty("添加用户id")
	@Max(9223372036854775806L)
	@Column(name = "create_uid")
	private Long createUid;
	
	@ApiModelProperty("更新时间")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "update_time")
	private Date updateTime;
	
	@ApiModelProperty("更新用户id")
	@Max(9223372036854775806L)
	@Column(name = "update_uid")
	private Long updateUid;
	
	@ApiModelProperty("1正常2删除")
	@Max(9L)
	@Column(name = "del_status")
	private Integer delStatus;
	
	
	@ApiModelProperty("是否新增")
	@Transient
    private Boolean isNew;
	
	@Transient
    @JsonIgnore
    @Override
    public Long getId() {
        return this.id;
	}
    
    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
    	if(isNew != null) {
    		return isNew;
    	}
    	if(this.id != null) {
    		return false;
    	}
    	return true;
    }
    
}