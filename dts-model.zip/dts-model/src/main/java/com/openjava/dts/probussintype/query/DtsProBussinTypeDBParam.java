package com.openjava.dts.probussintype.query;

import org.ljdp.core.db.RoDBQueryParam;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * 查询对象
 * @author hl
 *
 */
public class DtsProBussinTypeDBParam extends RoDBQueryParam {
	private Long eq_id;//id --主键查询
	
	private String like_name;//名称 like ?
	private Long eq_parentId;//父id = ?
	private String eq_orgId;//机构id = ?
	private String like_orgName;//机构名字 like ?
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date eq_createTime;//添加时间 = ?
	
	public Long getEq_id() {
		return eq_id;
	}
	public void setEq_id(Long id) {
		this.eq_id = id;
	}
	
	public String getLike_name() {
		return like_name;
	}
	public void setLike_name(String name) {
		this.like_name = name;
	}
	public Long getEq_parentId() {
		return eq_parentId;
	}
	public void setEq_parentId(Long parentId) {
		this.eq_parentId = parentId;
	}
	public String getEq_orgId() {
		return eq_orgId;
	}
	public void setEq_orgId(String orgId) {
		this.eq_orgId = orgId;
	}
	public String getLike_orgName() {
		return like_orgName;
	}
	public void setLike_orgName(String orgName) {
		this.like_orgName = orgName;
	}
	public Date getEq_createTime() {
		return eq_createTime;
	}
	public void setEq_createTime(Date createTime) {
		this.eq_createTime = createTime;
	}
}