package com.openjava.dts.provider.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.openjava.dts.provider.dto.ProviderCompanyFile;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 实体
 * @author hl
 *
 */
@ApiModel("DtsProviderCompany")
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@Entity
@Table(name = "DTS_PROVIDER_COMPANY")
public class DtsProviderCompany implements Persistable<Long>,Serializable {
	
	@ApiModelProperty("开发——维护商管理id")
	@Id
	@Column(name = "id")
	private Long id;
	
	@ApiModelProperty("公司名称")
	@Length(min=0, max=128)
	@Column(name = "company_name")
	private String companyName;
	
	@ApiModelProperty("公司介绍")
	@Length(min=0, max=5000)
	@Column(name = "company_desc")
	private String companyDesc;
	
	@ApiModelProperty("社会信用代码")
	@Length(min=0, max=128)
	@Column(name = "social_credit_code")
	private String socialCreditCode;
	
	@ApiModelProperty(" 联系人")
	@Length(min=0, max=100)
	@Column(name = "contact")
	private String contact;
	
	@ApiModelProperty("联系电话")
	@Length(min=0, max=32)
	@Column(name = "contact_phone")
	private String contactPhone;
	
	@ApiModelProperty("公司类型：1、开发 2、维护")
	@Max(99L)
	@Column(name = "type")
	private Integer type;
	
	@ApiModelProperty("公司类型：开发-维护")
	@Length(min=0, max=64)
	@Column(name = "type_name")
	private String typeName;
	
	@ApiModelProperty("状态：1、有效、其它无效")
	@Max(99L)
	@Column(name = "status")
	private Integer status;
	
	@ApiModelProperty("营业执照号")
	@Length(min=0, max=128)
	@Column(name = "business_number")
	private String businessNumber;
	
	@ApiModelProperty("创建时间")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "create_time")
	private Date createTime;
	
	@ApiModelProperty("修改时间")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "update_time")
	private Date updateTime;
	
	@ApiModelProperty("创建人")
	@Max(9223372036854775806L)
	@Column(name = "create_uid")
	private Long createUid;
	
	@ApiModelProperty("create_name")
	@Length(min=0, max=64)
	@Column(name = "create_name")
	private String createName;
	
	@ApiModelProperty("update_uid")
	@Max(9223372036854775806L)
	@Column(name = "update_uid")
	private Long updateUid;
	
	@ApiModelProperty("update_name")
	@Length(min=0, max=64)
	@Column(name = "update_name")
	private String updateName;
	
	@ApiModelProperty("1正常 2删除")
	@Max(9L)
	@Column(name = "del_status")
	private Integer delStatus;


	@ApiModelProperty("关联系统ID")
	@Transient
	private List<Long> systemList;

	@ApiModelProperty("公司附件")
	@Transient
	private List<ProviderCompanyFile> files;
	
	
	@ApiModelProperty("是否新增")
	@Transient
    private Boolean isNew;


	/**
	@Transient
    @JsonIgnore
    @Override
    public Long getId() {
        return this.id;
	}
	 **/
    
    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
    	if(isNew != null) {
    		return isNew;
    	}
    	if(this.id != null) {
    		return false;
    	}
    	return true;
    }
    
}