package com.openjava.dts.provider.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ProviderCompanyFile {

    public ProviderCompanyFile(String fileId, String fileName, String fileType, String downloadPath, String viewPath) {
        this.fileId = fileId;
        this.fileName = fileName;
        this.fileType = fileType;
        this.downloadPath = downloadPath;
        this.viewPath = viewPath;
    }

    @ApiModelProperty("文件ID")
    private String fileId;

    @ApiModelProperty("文件名")
    private String fileName;

    @ApiModelProperty("文件类型")
    private String fileType;

    @ApiModelProperty("文件下载路径")
    private String downloadPath;

    @ApiModelProperty("文件预览路径")
    private String viewPath;

}
