package com.openjava.dts.provider.dto;


import com.openjava.dts.provider.domain.DtsProviderCompany;
import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class ProviderCompanyListVO {

     private Map<String,List<DtsProviderCompany>> dtsProivederCompanyMap;
     private Map<String,String> typeMap;
}
