package com.openjava.dts.provider.query;

import lombok.Data;
import org.ljdp.core.db.RoDBQueryParam;

/**
 * 查询对象
 * @author hl
 *
 */
@Data
public class DtsProviderCompanyDBParam extends RoDBQueryParam {
	private Integer eq_id;//开发\维护商管理id --主键查询
	
	private String like_companyName;//公司名称 like ?
	private String like_companyDesc;//公司介绍 like ?
	private String like_socialCreditCode;//社会信用代码 like ?
	private String like_contact;// 联系人 like ?
	private String like_contactPhone;// 联系电话 like ?
	private Integer eq_type;//公司类型：1、开发 2、维护 = ?
	private String eq_typeName;//公司类型：开发\维护 = ?
	private Integer eq_status;
	private Long eq_createUid;//创建人 = ?
	private Integer eq_delStatus;//1正常 2删除

}
