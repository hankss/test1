package com.openjava.dts.statistic.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.ljdp.secure.valid.AddGroup;
import org.ljdp.secure.valid.UpdateGroup;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;

/**
 * 实体
 * @author hzy
 *
 */
@ApiModel("数据源统计日志")
@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "dts_statistics_log")
public class DtsStatisticsLog implements Persistable<Long>,Serializable {

    @ApiModelProperty("主键")
    @Id
    @Column(name = "lid")
    private Long lid;

    @ApiModelProperty("批次id")
    @Max(value=9223372036854775806L, groups= {AddGroup.class, UpdateGroup.class})
    @Column(name = "batch_id")
    private String batchId;

    @ApiModelProperty("标题描述")
    @Column(name = "title")
    private String title;

    @ApiModelProperty("日志内容")
    @Column(name = "content")
    private String content;

    @ApiModelProperty("日志等级")
    @Column(name = "lever")
    private String lever;

    @ApiModelProperty("添加时间")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @Column(name = "create_time")
    private Date createTime;

    @ApiModelProperty("是否新增")
    @JsonIgnore
    @Transient
    private Boolean isNew;

    @Transient
    @JsonIgnore
    @Override
    public Long getId() {
        return this.lid;
    }

    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
        if(isNew != null) {
            return isNew;
        }
        if(this.lid != null) {
            return false;
        }
        return true;
    }

}
