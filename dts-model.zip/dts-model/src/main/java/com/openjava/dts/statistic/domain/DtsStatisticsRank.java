package com.openjava.dts.statistic.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;

/**
 * 实体
 * @author chl
 *
 */
@ApiModel("DtsStatisticsRank")
@Data
@EqualsAndHashCode(callSuper = false)
//@Accessors(chain = true)
@Entity
@Table(name = "DTS_STATISTICS_RANK")
public class DtsStatisticsRank implements Persistable<Long>,Serializable {
	
	@ApiModelProperty("id")
	@Id
	@Column(name = "id")
	private Long id;
	
	@ApiModelProperty("1数据统计划 2数据记录 3空间占用")
	@Max(9L)
	@Column(name = "type")
	private Integer type;
	
	@ApiModelProperty("数据源id")
	@Length(min=0, max=64)
	@Column(name = "datasource_id")
	private String datasourceId;
	
	@ApiModelProperty("数据源名字")
	@Length(min=0, max=128)
	@Column(name = "datasource_name")
	private String datasourceName;
	
	@ApiModelProperty("参照对比批次id")
	@Length(min=0, max=32)
	@Column(name = "src_batch_id")
	private String srcBatchId;
	
	@ApiModelProperty("对比id")
	@Length(min=0, max=32)
	@Column(name = "batch_id")
	private String batchId;
	
	@ApiModelProperty("目录数量")
	@Max(9999999999L)
	@Column(name = "table_count")
	private Integer tableCount;
	
	@ApiModelProperty("原目录数量")
	@Max(9999999999L)
	@Column(name = "table_count_src")
	private Integer tableCountSrc;
	
	@ApiModelProperty("增加数量")
	@Max(9999999999L)
	@Column(name = "table_count_cre")
	private Integer tableCountCre;
	
	@ApiModelProperty("增加比例")
	@Max(99999999999L)
	@Column(name = "table_count_cre_pre")
	private Double tableCountCrePre;
	
	@ApiModelProperty("数据记录量")
	@Max(9223372036854775806L)
	@Column(name = "data_count")
	private Double dataCount;
	
	@ApiModelProperty("原数据记录量")
	@Max(9223372036854775806L)
	@Column(name = "data_count_src")
	private Double dataCountSrc;
	
	@ApiModelProperty("增加数据量")
	@Max(9223372036854775806L)
	@Column(name = "data_count_cre")
	private Double dataCountCre;
	
	@ApiModelProperty("数据记录数增加比例")
	@Max(99999999999L)
	@Column(name = "data_count_cre_pre")
	private Double dataCountCrePre;
	
	@ApiModelProperty("空间占用")
	@Max(9223372036854775806L)
	@Column(name = "space")
	private Double space;
	
	@ApiModelProperty("原空间占用")
	@Max(9223372036854775806L)
	@Column(name = "space_src")
	private Double spaceSrc;
	
	@ApiModelProperty("空间添加数")
	@Max(9223372036854775806L)
	@Column(name = "space_cre")
	private Double spaceCre;
	
	@ApiModelProperty("空间增加比例")
	@Max(9999999999L)
	@Column(name = "space_cre_pre")
	private Double spaceCrePre;
	
	@ApiModelProperty("create_time")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "create_time")
	private Date createTime;
	
	@ApiModelProperty("update_time")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "update_time")
	private Date updateTime;
	
	
	@ApiModelProperty("是否新增")
	@Transient
    private Boolean isNew;
	
	@Transient
    @JsonIgnore
    @Override
    public Long getId() {
        return this.id;
	}
    
    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
    	if(isNew != null) {
    		return isNew;
    	}
    	if(this.id != null) {
    		return false;
    	}
    	return true;
    }
    
}