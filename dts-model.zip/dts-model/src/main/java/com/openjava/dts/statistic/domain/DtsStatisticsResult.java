package com.openjava.dts.statistic.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.Length;
import org.ljdp.component.sequence.ConcurrentSequence;
import org.ljdp.secure.valid.AddGroup;
import org.ljdp.secure.valid.UpdateGroup;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 实体
 *
 * @author hzy
 */
@ApiModel("所有数据源统计结果")
@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "dts_statistics_result")
public class DtsStatisticsResult implements Persistable<Long>, Serializable {

    @ApiModelProperty("主键")
    @Id
    @Column(name = "id")
    private Long id;

    @ApiModelProperty("批次id")
    @Max(value = 9223372036854775806L, groups = {AddGroup.class, UpdateGroup.class})
    @Column(name = "batch_id")
    private String batchId;

    @ApiModelProperty("1数源总数 2.数据目录 3.数据行数 4.空间占用")
    @Max(value = 9L, groups = {AddGroup.class, UpdateGroup.class})
    @Column(name = "type")
    private Integer type;

    @ApiModelProperty("前当值")
    @Max(value = 9223372036854775806L, groups = {AddGroup.class, UpdateGroup.class})
    @Column(name = "current_val")
    private Double currentVal;

    @ApiModelProperty("历史值")
    @Max(value = 9223372036854775806L, groups = {AddGroup.class, UpdateGroup.class})
    @Column(name = "history_val")
    private Double historyVal;

    @ApiModelProperty("浮动百分比")
    @Max(value = 99999L, groups = {AddGroup.class, UpdateGroup.class})
    @Column(name = "float_percent")
    private Double floatPercent;

    @ApiModelProperty("统计日期")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    @Column(name = "statistics_date")
    private Date statisticsDate;

    @ApiModelProperty("添加时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Column(name = "create_time")
    private Date createTime;

    @ApiModelProperty("更新时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Column(name = "update_time")
    private Date updateTime;

    @ApiModelProperty("更新人id")
    @Max(value = 9223372036854775806L, groups = {AddGroup.class, UpdateGroup.class})
    @Column(name = "update_uid")
    private Long updateUid;

    @ApiModelProperty("更新人名字-主要是可以手动触发统计")
    @Length(min = 0, max = 64, groups = {AddGroup.class, UpdateGroup.class})
    @Column(name = "update_name")
    private String updateName;

    @ApiModelProperty("统计类型 1:数据源 2:归集库 3:中心库")
    @Column(name = "statistics_type")
    private Integer statisticsType = 1;


    @ApiModelProperty("是否新增")
    @JsonIgnore
    @Transient
    private Boolean isNew;

    @Transient
    @JsonIgnore
    @Override
    public Long getId() {
        return this.id;
    }

    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
        if (isNew != null) {
            return isNew;
        }
        if (this.id != null) {
            return false;
        }
        return true;
    }

    public DtsStatisticsResult() {

    }

    public DtsStatisticsResult(String batchId, Integer type, Integer statisticsType, Double currentVal, List<DtsStatisticsResult> historyResults) {
        this.batchId = batchId;
        this.type = type;
        this.statisticsType = statisticsType;
        this.id = ConcurrentSequence.getInstance().getSequence();
        this.createTime = new Date();
        this.currentVal = currentVal;
        this.isNew = true;
        this.historyVal = 0.0;
        if (historyResults != null && historyResults.size() > 0) {
            List<DtsStatisticsResult> filters = historyResults.stream().filter(p -> p.getType() == type && p.getStatisticsType() == statisticsType).collect(Collectors.toList());
            if (filters.size() > 0) {
                this.historyVal = filters.get(0).getCurrentVal();
            }
        }
    }

}
