package com.openjava.dts.statistic.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.Length;
import org.ljdp.secure.valid.AddGroup;
import org.ljdp.secure.valid.UpdateGroup;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;

/**
 * 实体
 * @author hzy
 *
 */
@ApiModel("数据源目录信息")
@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "dts_statistics_table")
public class DtsStatisticsTable implements Persistable<Long>,Serializable {
	
	@ApiModelProperty("主键")
	@Id
	@Column(name = "tbid")
	private Long tbid;
	
	@ApiModelProperty("批次id")
	@Max(value=9223372036854775806L, groups= {AddGroup.class, UpdateGroup.class})
	@Column(name = "batch_id")
	private String batchId;
	
	@ApiModelProperty("数据源id")
	@Length(min=0, max=64, groups= {AddGroup.class, UpdateGroup.class})
	@Column(name = "datasource_id")
	private String datasourceId;
	
	@ApiModelProperty("数据源名字")
	@Length(min=0, max=128, groups= {AddGroup.class, UpdateGroup.class})
	@Column(name = "datasource_name")
	private String datasourceName;
	
	@ApiModelProperty("所属系统id")
	@Length(min=0, max=128, groups= {AddGroup.class, UpdateGroup.class})
	@Column(name = "system_ids")
	private String systemIds;
	
	@ApiModelProperty("所属系统名字")
	@Length(min=0, max=128, groups= {AddGroup.class, UpdateGroup.class})
	@Column(name = "system_names")
	private String systemNames;
	
	@ApiModelProperty("表名")
	@Length(min=0, max=128, groups= {AddGroup.class, UpdateGroup.class})
	@Column(name = "table_name")
	private String tableName;
	
	@ApiModelProperty("记录数/万条,进1取整")
	@Max(value=9223372036854775806L, groups= {AddGroup.class, UpdateGroup.class})
	@Column(name = "rows")
	private Double rows;
	
	@ApiModelProperty("总空间gb")
	@Max(value=9999999999L, groups= {AddGroup.class, UpdateGroup.class})
	@Column(name = "all_space")
	private Double allSpace;
	
	@ApiModelProperty("数据空间")
	@Max(value=9999999999L, groups= {AddGroup.class, UpdateGroup.class})
	@Column(name = "data_space")
	private Double dataSpace;
	
	@ApiModelProperty("索引空间")
	@Max(value=9999999999L, groups= {AddGroup.class, UpdateGroup.class})
	@Column(name = "index_space")
	private Double indexSpace;
	
	@ApiModelProperty("1.已同步 2未同步")
	@Max(value=9L, groups= {AddGroup.class, UpdateGroup.class})
	@Column(name = "sync_status")
	private Integer syncStatus;
	
	@ApiModelProperty("统计日期")
	@DateTimeFormat(pattern="yyyy-MM-dd")
	@JsonFormat(pattern="yyyy-MM-dd", timezone="GMT+8")
	@Column(name = "statistics_date")
	private Date statisticsDate;
	
	@ApiModelProperty("添加时间")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Column(name = "create_time")
	private Date createTime;
	
	@ApiModelProperty("修改时间")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Column(name = "update_time")
	private Date updateTime;
	
	@ApiModelProperty("修改人id")
	@Max(value=9223372036854775806L, groups= {AddGroup.class, UpdateGroup.class})
	@Column(name = "update_uid")
	private Long updateUid;
	
	@ApiModelProperty("修改人名")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Column(name = "update_uname")
	private String updateUname;
	
	
	@ApiModelProperty("是否新增")
	@JsonIgnore
	@Transient
    private Boolean isNew;
	
	@Transient
    @JsonIgnore
    @Override
    public Long getId() {
        return this.tbid;
	}
    
    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
    	if(isNew != null) {
    		return isNew;
    	}
    	if(this.tbid != null) {
    		return false;
    	}
    	return true;
    }
    
}