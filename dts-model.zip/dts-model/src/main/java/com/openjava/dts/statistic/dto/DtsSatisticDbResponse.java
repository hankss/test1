package com.openjava.dts.statistic.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.ljdp.secure.valid.AddGroup;
import org.ljdp.secure.valid.UpdateGroup;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import java.time.LocalDateTime;
import java.util.Date;

@Data
public class DtsSatisticDbResponse {

    private Long systemId;

    public DtsSatisticDbResponse(String datasourceName,Integer tableCount, Double tableSyncPercent,Double dataCount,
                                 Double dataSyncPercent,Double space,String datasourceId,String batchId){
       this.setDatasourceName(datasourceName);
       this.setTableCount(tableCount);
       this.setTableSyncPercent(tableSyncPercent);
       this.setDataCount(dataCount);
       this.setDataSyncPercent(dataSyncPercent);
       this.setSpace(space);
       this.setDatasourceId(datasourceId);
       this.setBatchId(batchId);
    }

    @ApiModelProperty("主键")
    @Id
    @Column(name = "dbid")
    private Long dbid;

    @ApiModelProperty("批次id")
    @Max(value=9223372036854775806L, groups= {AddGroup.class, UpdateGroup.class})
    @Column(name = "batch_id")
    private String batchId;

    @ApiModelProperty("数据源id")
    @Length(min=0, max=64, groups= {AddGroup.class, UpdateGroup.class})
    @Column(name = "datasource_id")
    private String datasourceId;

    @ApiModelProperty("数据源名字")
    @Length(min=0, max=32, groups= {AddGroup.class, UpdateGroup.class})
    @Column(name = "datasource_name")
    private String datasourceName;

    @ApiModelProperty("所属系统id")
    @Length(min=0, max=64, groups= {AddGroup.class, UpdateGroup.class})
    @Column(name = "system_ids")
    private String systemIds;

    @ApiModelProperty("所属系统名字")
    @Length(min=0, max=128, groups= {AddGroup.class, UpdateGroup.class})
    @Column(name = "sytem_names")
    private String sytemNames;

    @ApiModelProperty("资源目录数")
    @Max(value=9999999999L, groups= {AddGroup.class, UpdateGroup.class})
    @Column(name = "table_count")
    private Integer tableCount;

    @ApiModelProperty("已同步资源目录数")
    @Max(value=9999999999L, groups= {AddGroup.class, UpdateGroup.class})
    @Column(name = "table_sync_count")
    private Integer tableSyncCount;

    @ApiModelProperty("同步目录数百分表")
    @Max(value=99999L, groups= {AddGroup.class, UpdateGroup.class})
    @Column(name = "table_sync_percent")
    private Double tableSyncPercent;

    @ApiModelProperty("数据记录数")
    @Max(value=9223372036854775806L, groups= {AddGroup.class, UpdateGroup.class})
    @Column(name = "data_count")
    private Double dataCount;

    @ApiModelProperty("同步数据记录数")
    @Max(value=9223372036854775806L, groups= {AddGroup.class, UpdateGroup.class})
    @Column(name = "data_sync_count")
    private Double dataSyncCount;

    @ApiModelProperty("同步数据百分表")
    @Max(value=99999L, groups= {AddGroup.class, UpdateGroup.class})
    @Column(name = "data_sync_percent")
    private Double dataSyncPercent;

    @ApiModelProperty("占用空间数")
    @Max(value=9223372036854775806L, groups= {AddGroup.class, UpdateGroup.class})
    @Column(name = "space")
    private Double space;

    @ApiModelProperty("统计日期")
    @DateTimeFormat(pattern="yyyy-MM-dd")
    @JsonFormat(pattern="yyyy-MM-dd", timezone="GMT+8")
    @Column(name = "statistics_date")
    private Date statisticsDate;

    @ApiModelProperty("添加时间")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @Column(name = "create_time")
    private Date createTime;

    @ApiModelProperty("更新时间")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @Column(name = "update_time")
    private LocalDateTime updateTime;

    @ApiModelProperty("更新用户id")
    @Max(value=99999999999L, groups= {AddGroup.class, UpdateGroup.class})
    @Column(name = "update_uid")
    private Integer updateUid;

    @ApiModelProperty("更新用户名字-主要记录可以手动触发统计")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @Column(name = "update_name")
    private String updateName;



}
