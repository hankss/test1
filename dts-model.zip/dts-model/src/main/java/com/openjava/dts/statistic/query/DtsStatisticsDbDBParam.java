package com.openjava.dts.statistic.query;

import lombok.Data;
import org.ljdp.core.db.RoDBQueryParam;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

/**
 * 查询对象
 * @author hzy
 *
 */
@Data
public class DtsStatisticsDbDBParam extends RoDBQueryParam {

	private Long eq_id;//主键 --主键查询
	private String eq_batchId;//批次id = ?
	private String eq_datasourceId;//数据源id = ?
	private String like_datasourceName;//数据源名字 like ?
	private String order_by;
	private String eq_systemId;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private LocalDateTime eq_statisticsDate;//统计日期 = ?

}