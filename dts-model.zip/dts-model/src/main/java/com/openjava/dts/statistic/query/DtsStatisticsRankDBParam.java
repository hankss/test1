package com.openjava.dts.statistic.query;

import lombok.Data;
import org.ljdp.core.db.RoDBQueryParam;

/**
 * 查询对象
 * @author chl
 *
 */
@Data
public class DtsStatisticsRankDBParam extends RoDBQueryParam {
	private Long eq_id;//id --主键查询
	private Integer eq_type;//1数据统计划 2数据记录 3空间占用 = ?
	private String eq_datasourceId;//数据源id = ?
	private String like_datasourceName;//数据源名字 like ?
	private String eq_srcBatchId;//参照对比批次id = ?
	private String eq_batchId;//对比id = ?
	private String order_by;
}