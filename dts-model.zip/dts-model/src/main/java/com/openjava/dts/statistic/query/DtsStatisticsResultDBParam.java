package com.openjava.dts.statistic.query;

import lombok.Data;
import org.ljdp.core.db.RoDBQueryParam;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * 查询对象
 * @author hzy
 *
 */
@Data
public class DtsStatisticsResultDBParam extends RoDBQueryParam {

	private Long eq_id;//主键 --主键查询
	private String eq_batchId;//批次id = ?
	private Integer eq_type;//类型 = ?
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date le_statisticsDate;//统计时间 <= ?
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date ge_statisticsDate;//统计时间 >= ?

}