package com.openjava.dts.statistic.query;

import lombok.Data;
import org.ljdp.core.db.RoDBQueryParam;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

/**
 * 查询对象
 * @author hzy
 *
 */
@Data
public class DtsStatisticsTableDBParam extends RoDBQueryParam {

	private Long eq_tbid;//主键 --主键查询
	private String eq_batchId;//批次id = ?
	private String eq_datasourceId;//数据源id = ?
	private String eq_datasourceName;//数据源名字 = ?
	private String like_datasourceName;//数据源名字 like ?
	private String like_systemIds;//所属系统id like ?
	private String like_systemNames;//所属系统名字 like ?
	private String eq_tableName;//表名 = ?
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private LocalDateTime eq_statisticsDate;//统计日期 = ?

}