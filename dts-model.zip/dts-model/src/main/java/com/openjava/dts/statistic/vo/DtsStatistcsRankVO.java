package com.openjava.dts.statistic.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.Length;
import org.ljdp.secure.valid.AddGroup;
import org.ljdp.secure.valid.UpdateGroup;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.validation.constraints.Max;
import java.time.LocalDateTime;
import java.util.Date;

public class DtsStatistcsRankVO {

    @ApiModelProperty("主键")
    private Long dbid;

    @ApiModelProperty("批次id")
    private String batchId;

    @ApiModelProperty("数据源id")
    @Column(name = "datasource_id")
    private String datasourceId;

    @ApiModelProperty("对照数据源id")
    private String srcDatasourceId;

    @ApiModelProperty("数据源名字")
    @Length(min=0, max=32, groups= {AddGroup.class, UpdateGroup.class})
    private String datasourceName;

    @ApiModelProperty("所属系统id")
    @Length(min=0, max=64, groups= {AddGroup.class, UpdateGroup.class})
    private String systemIds;

    @ApiModelProperty("所属系统名字")
    @Length(min=0, max=128, groups= {AddGroup.class, UpdateGroup.class})
    private String sytemNames;

    @ApiModelProperty("资源目录数")
    @Max(value=9999999999L, groups= {AddGroup.class, UpdateGroup.class})
    private Integer tableCount;

    @ApiModelProperty("对照资源目录数")
    private Integer srcTableCount;

    @ApiModelProperty("已同步资源目录数")
    @Max(value=9999999999L, groups= {AddGroup.class, UpdateGroup.class})
    private Integer tableSyncCount;

    private Integer srcTableSyncCount;

    @ApiModelProperty("同步目录数百分表")
    @Max(value=99999L, groups= {AddGroup.class, UpdateGroup.class})
    private Double tableSyncPercent;

    @ApiModelProperty("数据记录数")
    @Max(value=9223372036854775806L, groups= {AddGroup.class, UpdateGroup.class})
    private Double dataCount;

    @ApiModelProperty("对照数据记录数")
    private Double srcDataCount;

    @ApiModelProperty("同步数据记录数")
    @Max(value=9223372036854775806L, groups= {AddGroup.class, UpdateGroup.class})
    private Double dataSyncCount;

    @ApiModelProperty("同步数据百分表")
    @Max(value=99999L, groups= {AddGroup.class, UpdateGroup.class})
    private Double dataSyncPercent;

    @ApiModelProperty("占用空间数")
    @Max(value=9223372036854775806L, groups= {AddGroup.class, UpdateGroup.class})
    private Double space;

    @ApiModelProperty("对照占用空间数")
    private Double srcSpace;

    @ApiModelProperty("统计日期")
    @DateTimeFormat(pattern="yyyy-MM-dd")
    @JsonFormat(pattern="yyyy-MM-dd", timezone="GMT+8")
    private Date statisticsDate;

    @ApiModelProperty("添加时间")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    private Date createTime;

    @ApiModelProperty("更新时间")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    private LocalDateTime updateTime;

    @ApiModelProperty("更新用户id")
    @Max(value=99999999999L, groups= {AddGroup.class, UpdateGroup.class})
    private Integer updateUid;

    @ApiModelProperty("更新用户名字-主要记录可以手动触发统计")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    private String updateName;
}
