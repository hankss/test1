package com.openjava.dts.statistic.vo;

import com.openjava.dts.statistic.domain.DtsStatisticsDb;
import com.openjava.dts.statistic.domain.DtsStatisticsTable;
import lombok.Data;

import java.util.List;

@Data
public class DtsStatisticsDbVO{
    private List<DtsStatisticsTable> dtsStatisticsTableList;
    private DtsStatisticsDb dtsStatisticsDb;
}
