package com.openjava.dts.statistic.vo;

import com.openjava.dts.statistic.domain.DtsStatisticsTable;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.ljdp.ui.bootstrap.TablePage;
import org.springframework.data.domain.Persistable;

import java.io.Serializable;
import java.util.HashSet;
import java.util.List;

/**
 * @author 丘健里
 */
@Data
public class DtsStatisticsTableQyVO {
    //关联系统名字
    @ApiModelProperty("关联系统名字")
    private HashSet<String> systemNamesSet;
    //总数据记录(万条)
    @ApiModelProperty("总数据记录(万条)")
    private Double allRows = 0.0;
    //总占用存储空间(GB)
    @ApiModelProperty("总占用存储空间(GB)")
    private Double allSpace = 0.0;
    //获取目录数量
    @ApiModelProperty("目录数量")
    private Integer tableCount;
    //分页数据
    @ApiModelProperty("分页数据")
    private TablePage<DtsStatisticsTable> tablePage;
}

