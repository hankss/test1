package com.openjava.dts.statistic.vo;

import lombok.Data;

@Data
public class PostGreSqlVo {
   private String dbName;
   private String schema;
}
