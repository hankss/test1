package com.openjava.dts.system.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;

/**
 * 实体
 * @author 丘健里
 *
 */

@ApiModel("科室或局系统关联表")
@Data
@Entity
@Table(name = "dts_department")
public class DtsDepartment implements Persistable<Long>, Serializable {
    @ApiModelProperty("主键")
    @Id
    @Column(name = "id")
    private Long id;

    @ApiModelProperty("科室或局id")
    @Length(min=0, max=30)
    @Column(name = "department_id")
    private String departmentId;

    @ApiModelProperty("科室或局的名字")
    @Length(min=0, max=128)
    @Column(name = "department_name")
    private String departmentName;

    @ApiModelProperty("系统id,拼接科室或局id")
    @Length(min=0, max=256)
    @Column(name = "system_id")
    private String systemId;

    @ApiModelProperty("系统名字")
    @Length(min=0, max=256)
    @Column(name = "system_name")
    private String systemName;

    @ApiModelProperty("描述备注")
    @Length(min=0, max=1024)
    @Column(name = "des")
    private String des;

    @ApiModelProperty("机构id")
    @Max(9223372036854775806L)
    @Column(name = "orgid")
    private Long orgid;

    @ApiModelProperty("机构名字")
    @Length(min=0, max=64)
    @Column(name = "orgname")
    private String orgname;

    @ApiModelProperty("状态1正常2停用")
    @Max(9L)
    @Column(name = "status")
    private Integer status;

    @ApiModelProperty("create_time")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "create_time")
    private Date createTime;

    @ApiModelProperty("添加用户id")
    @Max(9223372036854775806L)
    @Column(name = "create_uid")
    private Long createUid;

    @ApiModelProperty("添加用户名字")
    @Length(min=0, max=128)
    @Column(name = "create_uname")
    private String createUname;

    @ApiModelProperty("update_time")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "update_time")
    private Date updateTime;

    @ApiModelProperty("update_uid")
    @Max(9223372036854775806L)
    @Column(name = "update_uid")
    private Long updateUid;

    @ApiModelProperty("update_uname")
    @Length(min=0, max=128)
    @Column(name = "update_uname")
    private String updateUname;


    @ApiModelProperty("是否新增")
    @Transient
    private Boolean isNew;

    @Transient
    @JsonIgnore
    @Override
    public Long getId() {
        return this.id;
    }

    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
        if(isNew != null) {
            return isNew;
        }
        if(this.id != null) {
            return false;
        }
        return true;
    }

}
