package com.openjava.dts.system.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;

/**
 * 实体
 * @author hzy
 *
 */
@ApiModel("数据源系统关联表")
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "dts_ds_system_relation")
public class DtsDsSystemRelation implements Persistable<Long>,Serializable {
	
	@ApiModelProperty("id")
	@Id
	@Column(name = "dsrid")
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long dsrid;
	
	@ApiModelProperty("数据源id")
	@Length(min=0, max=64)
	@Column(name = "datasource_id")
	private String datasourceId;
	
	@ApiModelProperty("系统id")
	@Max(9223372036854775806L)
	@Column(name = "system_id")
	private Long systemId;
	
	@ApiModelProperty("create_time")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "create_time")
	private Date createTime;
	
	@ApiModelProperty("create_uid")
	@Max(9223372036854775806L)
	@Column(name = "create_uid")
	private Long createUid;

	@ApiModelProperty("是否已经删除，0:未删除，1:已删除")
	@Max(9223372036854775806L)
	@Column(name = "deleted")
	private Integer deleted;
	
	@ApiModelProperty("是否新增")
	@Transient
    private Boolean isNew;
	
	@Transient
    @JsonIgnore
    @Override
    public Long getId() {
        return this.dsrid;
	}
    
    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
    	if(isNew != null) {
    		return isNew;
    	}
    	if(this.dsrid != null) {
    		return false;
    	}
    	return true;
    }

}