package com.openjava.dts.system.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;

/**
 * @author 丘健里
 * @date 2020-04-16 16:57
 */
@ApiModel("项目表")
@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Table(name = "dts_project")
public class DtsProject implements Persistable<Long>, Serializable {

    @ApiModelProperty("项目id")
    @Id
    @Column(name = "project_id")
    private Long projectId;

    @ApiModelProperty("项目名称")
    @Length(min = 0, max = 256)
    @Column(name = "project_name")
    private String projectName;

    @ApiModelProperty("机构id以@分隔")
    @Length(min = 0, max = 256)
    @Column(name = "org_id")
    private String orgId;

    @ApiModelProperty("机构code")
    @Length(min = 0, max = 256)
    @Column(name = "org_code")
    private String orgCode;

    @ApiModelProperty("机构名字以@分隔")
    @Length(min = 0, max = 256)
    @Column(name = "org_name")
    private String orgName;

    @ApiModelProperty("项目代码")
    @Length(min = 0, max = 256)
    @Column(name = "project_code")
    private String projectCode;

    @ApiModelProperty("项目描述")
    @Length(min = 0, max = 1024)
    @Column(name = "project_desc")
    private String projectDesc;

    @ApiModelProperty("业务分类以@分隔")
    @Length(min = 0, max = 256)
    @Column(name = "business_ids")
    private String busisnessIds;

    @ApiModelProperty("业务名称以@分隔")
    @Length(min = 0, max = 256)
    @Column(name = "business_name")
    private String businessName;

    @ApiModelProperty("创建方式 1-导入，2-手工录入")
    @Max(9223372036854775806L)
    @Column(name = "is_import")
    private Integer isImport;

    @ApiModelProperty("是否已经删除，0:未删除，1:已删除")
    @Max(9223372036854775806L)
    @Column(name = "deleted")
    private Integer deleted;

    @ApiModelProperty("创建人")
    @Max(9223372036854775806L)
    @Column(name = "create_id")
    private Long createId;

    @ApiModelProperty("创建人名字")
    @Length(min = 0, max = 128)
    @Column(name = "create_name")
    private String createName;

    @ApiModelProperty("创建人id")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "create_time")
    private Date createTime;

    @ApiModelProperty("修改人")
    @Max(9223372036854775806L)
    @Column(name = "modify_id")
    private Long modifyId;

    @ApiModelProperty("修改名字")
    @Length(min = 0, max = 128)
    @Column(name = "modify_name")
    private String modifyName;

    @ApiModelProperty("修改时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modify_time")
    private Date modifyTime;

    @ApiModelProperty("是否新增")
    @Transient
    private Boolean isNew;

    @Transient
    @JsonIgnore
    @Override
    public Long getId() {
        return this.projectId;
    }

    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
        if (isNew != null) {
            return isNew;
        }
        if (this.projectId != null) {
            return false;
        }
        return true;
    }
}
