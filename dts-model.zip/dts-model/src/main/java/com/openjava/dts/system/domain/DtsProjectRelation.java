package com.openjava.dts.system.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;

/**
 * @author 丘健里
 * @date 2020-04-16 16:58
 */
@ApiModel("项目关系表")
@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Table(name = "dts_project_relation")
public class DtsProjectRelation implements Persistable<Long>, Serializable {

    @ApiModelProperty("主键id")
    @Id
    @Column(name = "id_")
    private Long id_;

    @ApiModelProperty("项目id")
    @Max(9223372036854775806L)
    @Column(name = "project_id")
    private long projectId;

    @ApiModelProperty("系统id")
    @Max(9223372036854775806L)
    @Column(name = "system_id")
    private Long systemId;

    @ApiModelProperty("项目关系分类，0：项目与系统关联")
    @Max(9223372036854775806L)
    @Column(name = "relation_type")
    private Long relationType;

    @ApiModelProperty("是否已经删除，0:未删除，1:已删除")
    @Max(9223372036854775806L)
    @Column(name = "deleted")
    private Integer deleted;

    @ApiModelProperty("创建人")
    @Max(9223372036854775806L)
    @Column(name = "create_id")
    private Long createId;

    @ApiModelProperty("创建人名字")
    @Length(min = 0, max = 128)
    @Column(name = "create_name")
    private String createName;

    @ApiModelProperty("创建人id")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "create_time")
    private Date createTime;

    @ApiModelProperty("修改人")
    @Max(9223372036854775806L)
    @Column(name = "modify_id")
    private Long modifyId;

    @ApiModelProperty("修改名字")
    @Length(min = 0, max = 128)
    @Column(name = "modify_name")
    private String modifyName;

    @ApiModelProperty("修改时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modify_time")
    private Date modifyTime;

    @ApiModelProperty("是否新增")
    @Transient
    private Boolean isNew;

    @Transient
    @JsonIgnore
    @Override
    public Long getId() {
        return this.id_;
    }

    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
        if (isNew != null) {
            return isNew;
        }
        if (this.id_ != null) {
            return false;
        }
        return true;
    }
}
