package com.openjava.dts.system.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;

/**
 * 实体
 * @author hzy
 *
 */
@ApiModel("局系统表")
@Data
@EqualsAndHashCode(callSuper = false)
//@Accessors(chain = true)
@Entity
@Table(name = "dts_system")
public class DtsSystem implements Persistable<Long>,Serializable {
	
	@ApiModelProperty("主键")
	@Id
	@Column(name = "sid")
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long sid;
	
	@ApiModelProperty("系统名字")
	@Length(min=0, max=256)
	@Column(name = "name")
	private String name;
	
	@ApiModelProperty("描述备注")
	@Length(min=0, max=250)
	@Column(name = "des")
	private String des;
	
	@ApiModelProperty("原系统id")
	@Max(9223372036854775806L)
	@Column(name = "src_system_id")
	private Long srcSystemId;
	
	@ApiModelProperty("原系统名字")
	@Length(min=0, max=256)
	@Column(name = "src_system_name")
	private String srcSystemName;
	
	@ApiModelProperty("机构id")
	@Length(min=0, max=128)
	@Column(name = "orgid")
	private String orgid;
	
	@ApiModelProperty("机构名字")
	@Length(min=0, max=128)
	@Column(name = "orgname")
	private String orgname;

	@ApiModelProperty("开发公司id@隔开")
	@Length(min=0, max=128)
	@Column(name = "dev_company_id")
	private String devCompanyId;

	@ApiModelProperty("开发公司名字@隔开")
	@Length(min=0, max=128)
	@Column(name = "dev_company_name")
	private String devCompanyName;

	@ApiModelProperty("运维公司id@隔开")
	@Length(min=0, max=128)
	@Column(name = "mol_company_id")
	private String molCompanyId;

	@ApiModelProperty("运维公司名字@隔开")
	@Length(min=0, max=128)
	@Column(name = "mol_company_name")
	private String molCompanyName;

	@ApiModelProperty("状态1正常2停用3拟建")
	@Max(9L)
	@Column(name = "status")
	private Integer status;
	
	@ApiModelProperty("create_time")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "create_time")
	private Date createTime;
	
	@ApiModelProperty("添加用户id")
	@Max(9223372036854775806L)
	@Column(name = "create_uid")
	private Long createUid;
	
	@ApiModelProperty("添加用户名字")
	@Length(min=0, max=128)
	@Column(name = "create_uname")
	private String createUname;
	
	@ApiModelProperty("update_time")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "update_time")
	private Date updateTime;
	
	@ApiModelProperty("update_uid")
	@Max(9223372036854775806L)
	@Column(name = "update_uid")
	private Long updateUid;
	
	@ApiModelProperty("update_uname")
	@Length(min=0, max=128)
	@Column(name = "update_uname")
	private String updateUname;

	@ApiModelProperty("是否已经删除，0:未删除，1:已删除")
	@Max(9223372036854775806L)
	@Column(name = "deleted")
	private Integer deleted;

	@ApiModelProperty("创建方式 1-导入，2-手工录入")
	@Max(9223372036854775806L)
	@Column(name = "is_import")
	private Integer isImport;

	@ApiModelProperty("是否新增")
	@Transient
    private Boolean isNew;
	
	@Transient
    @JsonIgnore
    @Override
    public Long getId() {
        return this.sid;
	}
    
    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
    	if(isNew != null) {
    		return isNew;
    	}
    	if(this.sid != null) {
    		return false;
    	}
    	return true;
    }
    
}