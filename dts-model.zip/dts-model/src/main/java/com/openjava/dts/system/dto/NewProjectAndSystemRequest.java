package com.openjava.dts.system.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author 丘健里
 * @date 2020-04-17 9:21
 */
@ApiModel("新增项目与系统请求参数")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class NewProjectAndSystemRequest {

    @ApiModelProperty("系统id")
    private Long systemId;

    @ApiModelProperty("系统名称")
    private String systemName;

    @ApiModelProperty("项目id")
    private Long projectId;

    @ApiModelProperty("项目名称")
    private String projectName;

    @ApiModelProperty("是否是新增项目")
    private String addNew;

    @ApiModelProperty("改变类型: system(只是系统改变),project(只是项目改变),all(系统和项目都改变)")
    private String changeType;

    @ApiModelProperty("项目系统关系id")
    private Long relationId;

}
