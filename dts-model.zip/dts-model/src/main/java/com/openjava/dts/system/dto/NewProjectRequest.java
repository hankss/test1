package com.openjava.dts.system.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@ApiModel("新增项目请求参数")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class NewProjectRequest {

    @ApiModelProperty("项目id")
    private Long projectId;

    @ApiModelProperty("项目名称")
    private String projectName;

    @ApiModelProperty("是否新增项目")
    private Boolean addNew;

    @ApiModelProperty("创建方式 1-导入，2-手工录入")
    private Integer isImport;

    @ApiModelProperty("机构id")
    private String orgId;

    @ApiModelProperty("机构名称")
    private String orgName;

    @ApiModelProperty("项目代码")
    private String projectCode;

    @ApiModelProperty("业务分类id@隔开")
    private String businessIds;

    @ApiModelProperty("业务分类名称中文@隔开")
    private String businessName;

    @ApiModelProperty("项目简介")
    private String desc;

    @ApiModelProperty("要关联的系统id")
    private List<Long> systemIds;

//    @ApiModelProperty("要移除的关联系统id")
//    private List<Long> delSystemIds;
}
