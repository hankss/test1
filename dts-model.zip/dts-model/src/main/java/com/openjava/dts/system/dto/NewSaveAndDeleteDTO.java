package com.openjava.dts.system.dto;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by 曾庆淼 on 2020/3/14.
 */
@ApiModel("新增和删除关联系统参数DTO")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class NewSaveAndDeleteDTO {

    @ApiModelProperty("科室/部门/局名")
    private String depName;

    @ApiModelProperty("系统名")
    private String system_name;

    @ApiModelProperty("科室id")
    private Long dep_id;

    @ApiModelProperty("科室id批量")
    private String dep_ids;

    @ApiModelProperty("局系统id")
    private Long sid;

    @ApiModelProperty("局系统id批量")
    private String sids;

    @ApiModelProperty("系统id(科室或局id加上dts_system的系统id)")
    private String system_id;

    @ApiModelProperty("系统id(科室或局id加上dts_system的系统id)批量")
    private String system_ids;

}
