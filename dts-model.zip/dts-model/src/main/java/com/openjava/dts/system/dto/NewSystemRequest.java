package com.openjava.dts.system.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@ApiModel("新增系统请求参数")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class NewSystemRequest {

    @ApiModelProperty("系统id")
    private Long systemId;

    @ApiModelProperty("系统名称")
    private String systemName;

    @ApiModelProperty("是否新增系统")
    private Boolean addNew;

    @ApiModelProperty("创建方式 1-导入，2-手工录入")
    private Integer isImport;

    @ApiModelProperty("在用状态：状态1正常2停用")
    private Integer status;

    @ApiModelProperty("系统简介")
    private String desc;

    @ApiModelProperty("开发商id 以@隔开")
    private String devCompanyIds;

    @ApiModelProperty("开发商名字 以@隔开")
    private String devCompanyNames;

    @ApiModelProperty("维护商id 以@隔开")
    private String molCompanyIds;

    @ApiModelProperty("维护商名字 以@隔开")
    private String molCompanyNames;

    @ApiModelProperty("要关联的项目id")
    private List<Long> projectIds;

//    @ApiModelProperty("要移除的项目id")
//    private List<Long> delProjectIds;
}
