package com.openjava.dts.system.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * @author jianli
 * @date 2020-07-02 0002 12:45
 */
@ApiModel("新增系统请求参数")
@Data
@NoArgsConstructor
@Accessors(chain = true)
public class ProjectNameAndSystemNameDTO {

    @ApiModelProperty("项目id")
    private Long projectId;

    @ApiModelProperty("项目名字")
    private String projectName;

    @ApiModelProperty("项目创建时间")
    private Date projectCreateTime;

    @ApiModelProperty("关联系统的id")
    private Long systemId;

    @ApiModelProperty("关联系统的名字")
    private String systemName;

    @ApiModelProperty("关联系统创建时间")
    private Date systemCreateTime;

    @ApiModelProperty("项目系统关系id")
    private Long relationId;

    public ProjectNameAndSystemNameDTO(Long projectId, String projectName, Date projectCreateTime, Long systemId, String systemName, Date systemCreateTime, Long relationId) {
        this.projectId = projectId;
        this.projectName = projectName;
        this.projectCreateTime = projectCreateTime;
        this.systemId = systemId;
        this.systemName = systemName;
        this.systemCreateTime = systemCreateTime;
        this.relationId = relationId;
    }

}
