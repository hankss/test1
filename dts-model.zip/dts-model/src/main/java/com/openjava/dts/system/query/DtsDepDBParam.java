package com.openjava.dts.system.query;

import org.ljdp.core.db.RoDBQueryParam;

/**
 * 查询对象
 * @author hl
 *
 */
public class DtsDepDBParam extends RoDBQueryParam {
	private Long eq_id;//id --主键查询
	
	private String like_depName;//dep_name like ?
	private Integer eq_statue;//1启用2停用 = ?
	
	public Long getEq_id() {
		return eq_id;
	}
	public void setEq_id(Long id) {
		this.eq_id = id;
	}
	
	public String getLike_depName() {
		return like_depName;
	}
	public void setLike_depName(String depName) {
		this.like_depName = depName;
	}
	public Integer getEq_statue() {
		return eq_statue;
	}
	public void setEq_statue(Integer statue) {
		this.eq_statue = statue;
	}
}