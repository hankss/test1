package com.openjava.dts.system.query;

import lombok.Data;
import org.ljdp.core.db.RoDBQueryParam;

/**
 * 查询对象
 * @author hzy
 *
 */
@Data
public class DtsDsSystemRelationDBParam extends RoDBQueryParam {

	private Long eq_id;//id --主键查询
	private String eq_datasourceId;//数据源id = ?
	private Long eq_systemId;//系统id = ?

}