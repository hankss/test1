package com.openjava.dts.system.query;

import lombok.Data;
import org.ljdp.core.db.RoDBQueryParam;

/**
 * @author 丘健里
 * @date 2020-04-16 17:21
 */
@Data
public class DtsProjectDBParam extends RoDBQueryParam {

    private Long eq_projectId;

    private String like_projectName;

    private Integer eq_deleted;

    private Long eq_createId;
}
