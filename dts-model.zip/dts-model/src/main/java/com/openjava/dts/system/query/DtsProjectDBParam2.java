package com.openjava.dts.system.query;


import lombok.Data;
import org.ljdp.core.db.RoDBQueryParam;

@Data
public class DtsProjectDBParam2 extends RoDBQueryParam {
    private String like_projectName;
    private String like_projectCode;
}
