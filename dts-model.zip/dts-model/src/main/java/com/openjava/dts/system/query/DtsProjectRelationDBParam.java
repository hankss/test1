package com.openjava.dts.system.query;

import lombok.Data;
import org.ljdp.core.db.RoDBQueryParam;

/**
 * @author 丘健里
 * @date 2020-04-16 17:23
 */
@Data
public class DtsProjectRelationDBParam extends RoDBQueryParam {

    private Long eq_id_;

    private Long eq_projectId;

    private Long eq_systemId;

    private Long eq_relationType;

    private Integer eq_deleted;

}
