package com.openjava.dts.system.query;

import lombok.Data;
import org.ljdp.core.db.RoDBQueryParam;



@Data
public class DtsSystemDBParam extends RoDBQueryParam {

    private Long eq_sid;//id --主键查询
    private String eq_datasourceId;//数据源id = ?
    private Long eq_systemId;//系统id = ?
    private Integer eq_status;//系统id = ?
}