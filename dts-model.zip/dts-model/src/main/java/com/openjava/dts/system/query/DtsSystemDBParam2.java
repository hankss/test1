package com.openjava.dts.system.query;

import lombok.Data;
import org.ljdp.core.db.RoDBQueryParam;

@Data
public class DtsSystemDBParam2 extends RoDBQueryParam {

    private String like_systemName;

    private Long eq_systemId;

    private Integer eq_status;
}
