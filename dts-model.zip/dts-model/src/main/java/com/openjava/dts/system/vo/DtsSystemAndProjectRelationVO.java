package com.openjava.dts.system.vo;

import com.openjava.dts.system.domain.DtsProject;
import com.openjava.dts.system.domain.DtsSystem;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * @author jianli
 * @date 2020-06-15 17:52
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
@ApiModel("项目系统关系--返回到新增数据源页面")
public class DtsSystemAndProjectRelationVO {

    @ApiModelProperty("所属的项目")
    private List<DtsProject> dtsProjectList;

    @ApiModelProperty("所属的系统--唯一")
    private DtsSystem dtsSystem;

}
