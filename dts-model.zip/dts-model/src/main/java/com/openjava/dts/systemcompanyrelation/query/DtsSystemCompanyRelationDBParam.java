package com.openjava.dts.systemcompanyrelation.query;

import lombok.Data;
import org.ljdp.core.db.RoDBQueryParam;

/**
 * 查询对象
 * @author hl
 *
 */
@Data
public class DtsSystemCompanyRelationDBParam extends RoDBQueryParam {
	private Long eq_id;//id --主键查询

	private Long eq_sysId;//系统id = ?
	private Long eq_companyId;//开发商id = ?
	private String eq_companyName;//开发商name = ?
	private Long eq_createUid;//create_uid = ?
	private Integer eq_companyType;//公司类型：1、开发 2、维护 = ?
	private Integer delStatus; //状态 1为有效


}