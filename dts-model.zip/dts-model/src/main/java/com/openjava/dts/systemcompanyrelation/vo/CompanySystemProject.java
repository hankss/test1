package com.openjava.dts.systemcompanyrelation.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel("公司系统项目信息list")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CompanySystemProject {



    @ApiModelProperty("开发-维护商id ")
    private Long CompanyId;

    @ApiModelProperty("开发商名字")
    private String CompanyNames;

    @ApiModelProperty("开发-维护商类型")
    private Integer companyType;

    @ApiModelProperty("系统id")
    private Long systemId;

    @ApiModelProperty("系统名称")
    private String systemName;

    @ApiModelProperty("项目id")
    private Long projectId;

    @ApiModelProperty("项目名字")
    private String projectName;

}
