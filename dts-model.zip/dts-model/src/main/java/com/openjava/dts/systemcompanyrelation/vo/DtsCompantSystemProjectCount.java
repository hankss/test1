package com.openjava.dts.systemcompanyrelation.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel("公司项目总量与关联系统总数")
@Data
public class DtsCompantSystemProjectCount {


        @ApiModelProperty("状态码")
        private Integer code;

        @ApiModelProperty("信息")
        private String mesg;

        @ApiModelProperty("关联项目总量")
        private Integer projectCount;

        @ApiModelProperty("关联系统数")
        private Integer systemCount;

        @ApiModelProperty("公司总数")
        private Integer CompantCount;

        @ApiModelProperty("开发公司总数")
        private Integer DeveloperCompantCount;

        @ApiModelProperty("维护公司总数")
        private Integer MaintainCompantCount;

}
