package com.openjava.dts.systemcompanyrelation.vo;

import com.openjava.dts.provider.dto.ProviderCompanyFile;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@ApiModel("公司统计信息")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DtsProviderCompanySpcount {
    @ApiModelProperty("开发——维护商管理id")
    private Long id;

    @ApiModelProperty("公司名称")
    private String companyName;

    @ApiModelProperty("公司介绍")
    private String companyDesc;

    @ApiModelProperty("社会信用代码")
    private String socialCreditCode;

    @ApiModelProperty(" 联系人")
    private String contact;

    @ApiModelProperty("联系电话")
    private String contactPhone;

    @ApiModelProperty("公司类型：1、开发 2、维护")
    private Integer type;

    @ApiModelProperty("公司类型：开发-维护")
    private String typeName;

    @ApiModelProperty("状态：1、有效、其它无效")
    private Integer status;

    @ApiModelProperty("营业执照号")
    private String businessNumber;

    @ApiModelProperty("创建时间")
    private Date createTime;

    @ApiModelProperty("修改时间")
    private Date updateTime;

    @ApiModelProperty("创建人")
    private Long createUid;

    @ApiModelProperty("create_name")
    private String createName;

    @ApiModelProperty("update_uid")
    private Long updateUid;

    @ApiModelProperty("update_name")
    private String updateName;

    @ApiModelProperty("1正常 2删除")
    private Integer delStatus;

    @ApiModelProperty("关联系统数")
    Long sysCount;

    @ApiModelProperty("关联项目数")
    Long projectCount;

    @ApiModelProperty("公司文件列表")
    List<ProviderCompanyFile> file;

}
