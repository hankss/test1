package com.openjava.dts.uploadfile.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;

/**
 * 实体
 * @author hl
 *
 */
@ApiModel("DtsUploadFile")
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@Entity
@Table(name = "DTS_UPLOAD_FILE")
public class DtsUploadFile implements Persistable<Long>,Serializable {
	
	@ApiModelProperty("id")
	@Id
	@Column(name = "id")
	private Long id;
	
	@ApiModelProperty("文件名中文")
	@Length(min=0, max=120)
	@Column(name = "name")
	private String name;
	
	@ApiModelProperty("描述")
	@Length(min=0, max=255)
	@Column(name = "des")
	private String desc;
	
	@ApiModelProperty("关键字")
	@Length(min=0, max=255)
	@Column(name = "keyword")
	private String keyword;
	
	@ApiModelProperty("原来文件名")
	@Length(min=0, max=255)
	@Column(name = "src_name")
	private String srcName;
	
	@ApiModelProperty("现在文件名")
	@Length(min=0, max=255)
	@Column(name = "file_name")
	private String fileName;
	
	@ApiModelProperty("保存文件夹")
	@Length(min=0, max=255)
	@Column(name = "bucket_name")
	private String bucketName;
	
	@ApiModelProperty("短路径")
	@Length(min=0, max=255)
	@Column(name = "short_path")
	private String shortPath;
	
	@ApiModelProperty("完整访问路径")
	@Length(min=0, max=500)
	@Column(name = "full_path")
	private String fullPath;
	
	@ApiModelProperty("大小kb")
	@Max(9223372036854775806L)
	@Column(name = "size")
	private Long size;
	
	@ApiModelProperty("文件类型")
	@Length(min=0, max=256)
	@Column(name = "file_type")
	private String fileType;
	
	@ApiModelProperty("文件后缀")
	@Length(min=0, max=32)
	@Column(name = "file_suffix")
	private String fileSuffix;
	
	@ApiModelProperty("业务id")
	@Max(9223372036854775806L)
	@Column(name = "biz_id")
	private Long bizId;
	
	@ApiModelProperty("业务类型  accessory附件")
	@Length(min=0, max=128)
	@Column(name = "biz_type")
	private String bizType;
	
	@ApiModelProperty("create_time")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "create_time")
	private Date createTime;
	
	@ApiModelProperty("create_uid")
	@Max(9223372036854775806L)
	@Column(name = "create_uid")
	private Long createUid;
	
	@ApiModelProperty("update_time")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "update_time")
	private Date updateTime;
	
	@ApiModelProperty("update_uid")
	@Max(9223372036854775806L)
	@Column(name = "update_uid")
	private Long updateUid;
	
	@ApiModelProperty("1正常2删除")
	@Max(9L)
	@Column(name = "del_status")
	private Integer delStatus;
	
	
	@ApiModelProperty("是否新增")
	@Transient
    private Boolean isNew;
	
	@Transient
    @JsonIgnore
    @Override
    public Long getId() {
        return this.id;
	}
    
    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
    	if(isNew != null) {
    		return isNew;
    	}
    	if(this.id != null) {
    		return false;
    	}
    	return true;
    }
    
}