package com.openjava.dts.uploadfile.query;

import org.ljdp.core.db.RoDBQueryParam;

/**
 * 查询对象
 * @author hl
 *
 */
public class DtsUploadFileDBParam extends RoDBQueryParam {
	private Long eq_id;//id --主键查询
	
	private String like_name;//文件名中文 like ?
	private String like_keyword;//关键字 like ?
	private String eq_srcName;//原来文件名 = ?
	private Long eq_bizId;//业务id = ?
	private String eq_bizType;//业务类型  accessory附件 = ?
	private Long eq_createUid;//create_uid = ?
	
	public Long getEq_id() {
		return eq_id;
	}
	public void setEq_id(Long id) {
		this.eq_id = id;
	}
	
	public String getLike_name() {
		return like_name;
	}
	public void setLike_name(String name) {
		this.like_name = name;
	}
	public String getLike_keyword() {
		return like_keyword;
	}
	public void setLike_keyword(String keyword) {
		this.like_keyword = keyword;
	}
	public String getEq_srcName() {
		return eq_srcName;
	}
	public void setEq_srcName(String srcName) {
		this.eq_srcName = srcName;
	}
	public Long getEq_bizId() {
		return eq_bizId;
	}
	public void setEq_bizId(Long bizId) {
		this.eq_bizId = bizId;
	}
	public String getEq_bizType() {
		return eq_bizType;
	}
	public void setEq_bizType(String bizType) {
		this.eq_bizType = bizType;
	}
	public Long getEq_createUid() {
		return eq_createUid;
	}
	public void setEq_createUid(Long createUid) {
		this.eq_createUid = createUid;
	}
}