package com.openjava.dts.util;

import com.openjava.dts.constants.RegexConstant;
import net.sourceforge.pinyin4j.PinyinHelper;
import net.sourceforge.pinyin4j.format.HanyuPinyinCaseType;
import net.sourceforge.pinyin4j.format.HanyuPinyinOutputFormat;
import net.sourceforge.pinyin4j.format.HanyuPinyinToneType;
import net.sourceforge.pinyin4j.format.HanyuPinyinVCharType;
import net.sourceforge.pinyin4j.format.exception.BadHanyuPinyinOutputFormatCombination;
import org.apache.commons.lang3.StringUtils;

/**
 * @Author JiaHai
 * @Description 中文转拼音工具类
 */
public class ChineseToPinYinUtils {
    /**
     * 转为大写字母, 如：中国人民银行 =====> ZHONGGUORENMINYINHAN
     */
    public static String convertUpper(String text) {
        return convert(text, HanyuPinyinCaseType.UPPERCASE, false);
    }

    /**
     * 转为小写字母, 如：中国人民银行 =====> zhongguorenminyinhang
     */
    public static String convertLower(String text) {
        return convert(text, HanyuPinyinCaseType.LOWERCASE, false);
    }

    /**
     * 首字母大写, 如：中国人民银行 =====> ZhongGuoRenMinYinHang
     */
    public static String converCapitalize(String text) {
        return convert(text, null, true);
    }

    /**
     * 所有中文的第一个字母大写, 如：中国人民银行 =====> ZGRMYH
     */
    public static String capitalizeLetter(String text) {
        String firstUpperString = converCapitalize(text);
        if (StringUtils.isBlank(firstUpperString)) {
            return "";
        }
//        String s = StringUtils.replacePattern(c, "[a-z]", "");
        // 只保留大写字母
        StringBuffer stringBuffer = new StringBuffer();
        for (char c : firstUpperString.toCharArray()) {
            if (c >= 'A' && c <= 'Z') {
                stringBuffer.append(c);
            }
        }
        return stringBuffer.toString();
    }

    /**
     * 获取首字母, 如：中国人民银行 =====> Z
     */
    public static String firstLetter(String text) {
        String c = converCapitalize(text);
        if (StringUtils.isBlank(c)) {
            return "";
        }
        return StringUtils.substring(c, 0, 1);
    }

    /**
     * 转为拼音
     *
     * @param text         待转化的中文字符
     * @param caseType     转化类型, 即大写小写
     * @param isCapitalize 是否首字母大写
     */
    public static String convert(String text, HanyuPinyinCaseType caseType, boolean isCapitalize) {
        if (StringUtils.isBlank(text)) {
            return "";
        }
        HanyuPinyinOutputFormat format = new HanyuPinyinOutputFormat();
        if (caseType != null) {
            format.setCaseType(caseType);
            isCapitalize = false;
        }

        format.setToneType(HanyuPinyinToneType.WITHOUT_TONE);
        format.setVCharType(HanyuPinyinVCharType.WITH_V);
        char[] input = StringUtils.trimToEmpty(text).toCharArray();
        StringBuilder builder = new StringBuilder();
        try {
            for (char c : input) {
                if (Character.toString(c).matches(RegexConstant.ONLY_CHINESE)) {
                    String[] temp = PinyinHelper.toHanyuPinyinStringArray(c, format);
                    if (isCapitalize) {
                        builder.append(StringUtils.capitalize(temp[0]));
                    } else {
                        builder.append(temp[0]);
                    }
                } else {
                    if (isCapitalize) {
                        builder.append(StringUtils.capitalize(Character.toString(c)));
                    } else {
                        builder.append(c);
                    }
                }
            }
        } catch (BadHanyuPinyinOutputFormatCombination ex) {
            ex.printStackTrace();
        }

        return builder.toString();
    }

//    public static void main(String[] args) {
//        String s = capitalizeLetter("中国788hjh人啊【】、、（（））是吧d的");
//        System.out.println(s);
//    }
}
