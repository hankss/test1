package com.openjava.dts.util;

import com.openjava.dts.util.column.JavaSqlTypeEnum;
import org.apache.commons.lang3.Validate;
import org.ljdp.component.exception.APIException;

import java.sql.Types;

/**
 * @author: lsw
 * @Date: 2019/8/21 9:59
 */
public class ColumnTypeTranslatorMysql {
    /*----数字类----*/
    /** 有符号整型 1字节 */
    private static String MYSQL_TINYINT = "TINYINT";
    /** 有符号整型 2字节 */
    private static String MYSQL_SMALLINT = "SMALLINT";
    /** 有符号整型 4字节 */
    private static String MYSQL_INT = "INT";
    /** 有符号整型 8字节 */
    private static String MYSQL_BIGINT = "BIGINT";
    /** 有符号单精度浮点数 */
    private static String MYSQL_FLOAT = "FLOAT";
    /** 有符号双精度浮点数 */
    private static String MYSQL_DOUBLE = "DOUBLE";
    /** 可带小数的精确数字字符串 */
    private static String MYSQL_DECIMAL = "DECIMAL";

    /*----日期时间类----*/
    /** 时间戳，内容格式：yyyy-mm-dd hh:mm:ss[.f...] */
    private static String MYSQL_TIMESTAMP = "TIMESTAMP";
    /** 日期，内容格式：YYYY­MM­DD */
    private static String MYSQL_DATE = "DATE";
    /** -- */
    private static String MYSQL_INTERVAL = "INTERVAL";

    private static String MYSQL_DATE_TIME = "DATETIME";

    /*----字符串类----*/
    /** 字符串 */
    private static String MYSQL_STRING = "STRING";
    /** 长度不定字符串 字符数范围1 - 65535 */
    private static String MYSQL_VARCHAR = "VARCHAR";
    /** 长度固定字符串 最大的字符数：255 */
    private static String MYSQL_CHAR = "CHAR";

    private static String MYSQL_TEXT = "TEXT";

    /*----Misc类----*/
    /** 布尔类型 TRUE/FALSE */
    private static String MYSQL_BOOLEAN = "BOOLEAN";
    /** 字节序列 */
    private static String MYSQL_BINARY = "BINARY";

    /*----复合类----*/
    /** 包含同类型元素的数组，索引从0开始 ARRAY */
    private static String MYSQL_ARRAY = "ARRAY";
    /** 字典 MAP<primitive_type, data_type> */
    private static String MYSQL_MAP = "MAP";
    /** 结构体 STRUCT<col_name : data_type [COMMENT col_comment], ...> */
    private static String MYSQL_STRUCT = "STRUCT";
    /** 联合体 UNIONTYPE<data_type, data_type, ...> */
    private static String MYSQL_UNIONTYPE = "UNIONTYPE";

    /**
     * 根据type的名称获取对应的postgresql类型
     * @param sqlTypeEnum
     * @return
     * @throws APIException
     */
    public static String getTranslateType(final JavaSqlTypeEnum sqlTypeEnum, Integer columnPrecision, Integer columnScale) throws APIException {
        Validate.notNull(sqlTypeEnum, "sqlTypeEnum不能为空");
        switch (sqlTypeEnum) {
            case CHAR:
            case NCHAR:
            case VARCHAR:
            case NVARCHAR:
                return MYSQL_VARCHAR;
            case LONGVARCHAR:
            case LONGNVARCHAR:
            case CLOB:
            case NCLOB:
                return MYSQL_TEXT;
            case SMALLINT:
                return MYSQL_SMALLINT;
            case TINYINT:
                return MYSQL_TINYINT;
            case INTEGER:
                return MYSQL_INT;
            case BIGINT:
                return MYSQL_BIGINT;
            case NUMERIC:
            case DECIMAL:
                if(columnScale>0){
                    return MYSQL_DOUBLE;
                }else{
                    return MYSQL_BIGINT;
                }
            case FLOAT:
                return MYSQL_FLOAT;
            case REAL:
            case DOUBLE:
                return MYSQL_DOUBLE;

            case TIME:
//                return MYSQL_TIMESTAMP;
            case DATE:
                return MYSQL_DATE;

            case TIMESTAMP:
                return MYSQL_TIMESTAMP;

            case BINARY:
            case VARBINARY:
            case BLOB:
            case LONGVARBINARY:
                return MYSQL_BINARY;

            case BOOLEAN:
            case BIT:
                return MYSQL_BOOLEAN;

            case NULL:
            case TIME_WITH_TIMEZONE:
            case TIMESTAMP_WITH_TIMEZONE:
            default:
                throw new APIException(500, "无法识别字段类型:" + sqlTypeEnum);
        }
    }

    /**
     * 根据type的int值获取对应的postgresql类型
     * @param javaSqlType
     * @return
     * @throws APIException
     */
    public static String getTranslateType(final int javaSqlType) throws APIException {
        switch (javaSqlType) {
            case Types.CHAR:
            case Types.NCHAR:
            case Types.VARCHAR:
            case Types.NVARCHAR:
                return MYSQL_VARCHAR;

            case Types.LONGVARCHAR:
            case Types.LONGNVARCHAR:
            case Types.CLOB:
            case Types.NCLOB:
                return MYSQL_TEXT;

            case Types.SMALLINT:
                return MYSQL_SMALLINT;
            case Types.TINYINT:
                return MYSQL_TINYINT;
            case Types.INTEGER:
                return MYSQL_INT;
            case Types.BIGINT:
                return MYSQL_BIGINT;

            case Types.NUMERIC:
            case Types.DECIMAL:
                return MYSQL_DECIMAL;

            case Types.FLOAT:
                return MYSQL_FLOAT;
            case Types.REAL:
            case Types.DOUBLE:
                return MYSQL_DOUBLE;

            case Types.TIME:
//                return MYSQL_TIMESTAMP;
            case Types.DATE:
                return MYSQL_DATE;

            case Types.TIMESTAMP:
                return MYSQL_TIMESTAMP;

            case Types.BINARY:
            case Types.VARBINARY:
            case Types.BLOB:
            case Types.LONGVARBINARY:
                return MYSQL_BINARY;

            case Types.BOOLEAN:
            case Types.BIT:
                return MYSQL_BOOLEAN;

            case Types.NULL:
            case Types.TIME_WITH_TIMEZONE:
            case Types.TIMESTAMP_WITH_TIMEZONE:
            default:
                throw new APIException(500, "无法识别字段类型:" + javaSqlType);
        }
    }
}
