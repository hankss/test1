package com.openjava.dts.util;

import com.openjava.dts.ddl.domain.DtsColumn;
import com.openjava.dts.util.column.JavaSqlTypeEnum;
import org.apache.commons.lang3.Validate;
import org.ljdp.component.exception.APIException;

import javax.validation.constraints.Max;
import java.sql.Types;

import static com.openjava.dts.util.column.JavaSqlTypeEnum.*;

/**
 * 字段类型翻译工具
 * java.sql->postgresql对应类型
 * @author: lsw
 * @Date: 2019/8/16 11:37
 */
public class ColumnTypeTranslatorPostgreSql {

    /*----数字类型----*/
    /** 2 字节, 小范围整数 */
    public static String PG_SMALLINT = "int2";
    /** 4 字节, 整数类型 */
    public static String PG_INTGER = "int4";
    /** 8 字节, 长整形 */
    public static String PG_BIGINT = "int8";
    /** 可变长度, 用户制定精度 */
    public static String PG_NUMBERIC = "decimal";
    /** 可变长度, 用户制定精度 */
    public static String PG_FLOAT = "float";
    /** 4 字节，6 位十进制精度 */
    public static String PG_REAL = "real";

    /*----字符类型----*/
    /** 变长, n 大小没有限制 */
    public static String PG_STRING = "varchar";
    /** 定长, n 大小没有限制 */
    public static String PG_CHAR= "char";
    /** 变长, 任意长度字符串 */
    public static String PG_TEXT = "text";

    /*----布尔类型----*/
    /** true / false */
    private static String PG_BOOLEAN = "boolean";

    /*----时间类型----*/
    /** 4 字节, 日期格式(无时间) */
    public static String PG_DATE = "date";
    /** 8 字节, 日期 +时间格式 */
    public static String PG_TIMESTAMP = "timestamp";
    /** 8 字节, 时间格式(无日期) */
    public static String PG_TIME = "time";



    /**
     * 根据type的名称获取对应的postgresql类型
     * @param sqlTypeEnum
     * @return
     * @throws APIException
     */
    public static String getTranslateType(final JavaSqlTypeEnum sqlTypeEnum) throws APIException {
        Validate.notNull(sqlTypeEnum, "sqlTypeEnum不能为空");
        switch (sqlTypeEnum) {
            case CHAR:
            case NCHAR:
            case VARCHAR:
//统一用varchar，因为char会填充空格
//                return PG_CHAR;
            case LONGVARCHAR:
            case NVARCHAR:
            case LONGNVARCHAR:
                return PG_STRING;

            case BIT:
            case SMALLINT:
            case TINYINT:
//                return PG_SMALLINT;
            case INTEGER:
                return PG_INTGER;
            case BIGINT:
                return PG_BIGINT;
            case FLOAT:
            case REAL:
            case DOUBLE:
//                return PG_FLOAT;
            case NUMERIC:
            case DECIMAL:
                //数值类型统一用decimal
                return PG_NUMBERIC;

            case TIME:
                return PG_TIME;

            case DATE:
                return PG_DATE;

            case TIMESTAMP:
                return PG_TIMESTAMP;

            case BINARY:
            case VARBINARY:
            case BLOB:
            case LONGVARBINARY:
            case CLOB:
            case NCLOB:
                return PG_TEXT;

            case BOOLEAN:
                return PG_BOOLEAN;

            case NULL:
            case TIME_WITH_TIMEZONE:
            case TIMESTAMP_WITH_TIMEZONE:
            default:
                throw new APIException(500, "无法识别字段类型:" + sqlTypeEnum);
        }
    }

    /**
     * 根据type的int值获取对应的postgresql类型
     * @param javaSqlType
     * @return
     * @throws APIException
     */
    public static String getTranslateType(final int javaSqlType) throws APIException {
        switch (javaSqlType) {
            case Types.CHAR:
            case Types.NCHAR:
            case Types.VARCHAR:
                return PG_CHAR;

            case Types.LONGVARCHAR:
            case Types.NVARCHAR:
            case Types.LONGNVARCHAR:
            case Types.CLOB:
            case Types.NCLOB:
                return PG_STRING;

            case Types.BIT:
            case Types.SMALLINT:
            case Types.TINYINT:
                return PG_SMALLINT;

            case Types.INTEGER:
                return PG_INTGER;

            case Types.BIGINT:
                return PG_BIGINT;

            case Types.NUMERIC:
            case Types.DECIMAL:
                return PG_NUMBERIC;

            case Types.FLOAT:
            case Types.REAL:
            case Types.DOUBLE:
                return PG_FLOAT;

            case Types.TIME:
                return PG_TIME;

            case Types.DATE:
                return PG_DATE;

            case Types.TIMESTAMP:
                return PG_TIMESTAMP;

            case Types.BINARY:
            case Types.VARBINARY:
            case Types.BLOB:
            case Types.LONGVARBINARY:
                return PG_TEXT;

            case Types.BOOLEAN:
                return PG_BOOLEAN;

            case Types.NULL:
            case Types.TIME_WITH_TIMEZONE:
            case Types.TIMESTAMP_WITH_TIMEZONE:
            default:
                throw new APIException(500, "无法识别字段类型:" + javaSqlType);
        }
    }

    /**
     * 给没有字段长度的 字段 赋初值
     *
     * @param column
     * @return
     */
    public static void assignInitialValue(DtsColumn column) {
        if (column.getColumnType().equalsIgnoreCase(PG_BOOLEAN)) {
            return;
        }
        String columnName = column.getColumnType();
        Integer columnPrecision = column.getColumnPrecision();
        // 字段长度是null或者是0,给初始长度
        if (null == columnPrecision || 0 == columnPrecision) {
            switch (columnName.toLowerCase()) {
                case "char":
                    column.setColumnPrecision(1000);
                    break;
                case "varchar":
                    column.setColumnPrecision(10485750);
                    break;
                case "int2":
                    break;
                case "int4":
                    break;
                case "int8":
                    break;
                case "decimal":
                case "float":
                case "real":
                    column.setColumnPrecision(999);
//                    column.setColumnScale(null != column.getColumnScale() ? column.getColumnScale() : 100);
                    break;
//                case "text":
//                    column.setColumnPrecision(100000);
//                    break;
                default:
                    break;
            }
        }
        // postgrep 数据库的数值类型的长度是1到1000
        Integer columnScale = column.getColumnScale();
        if (columnName.equalsIgnoreCase("int2") || columnName.equalsIgnoreCase("int4")
                || columnName.equalsIgnoreCase("int8") || columnName.equalsIgnoreCase("decimal")
                || columnName.equalsIgnoreCase("float") || columnName.equalsIgnoreCase("real")) {
            if (null == columnPrecision || 0 == columnPrecision || columnPrecision > 1000 || columnScale > 1000) {
                column.setColumnPrecision(999);
//                column.setColumnScale(100);
            }
        }

        //这里单独对 varchar类型 进行处理 10485760
        if ("varchar".equalsIgnoreCase(column.getColumnType())) {
            if (column.getColumnPrecision() >= 10485760) {
                column.setColumnPrecision(10485750);
            }
        }
    }

}
