package com.openjava.dts.util;

import com.openjava.dts.util.column.JavaSqlTypeEnum;
import org.apache.commons.lang3.Validate;
import org.ljdp.component.exception.APIException;

import java.sql.Types;

/**
 * @author: lsw
 * @Date: 2019/8/21 9:59
 */
public class ColumnTypeTranslatorSql {
    /*----数字类----*/
    /** 有符号整型 1字节 */
    private static String SQL_TINYINT = "TINYINT";
    /** 有符号整型 2字节 */
    private static String SQL_SMALLINT = "SMALLINT";
    /** 有符号整型 4字节 */
    private static String SQL_INTEGER = "INTEGER";
    /** 有符号整型 8字节 */
    private static String SQL_BIGINT = "BIGINT";
    /** 有符号单精度浮点数 */
    private static String SQL_FLOAT = "FLOAT";
    /** 有符号双精度浮点数 */
    private static String SQL_DOUBLE = "DOUBLE";
    /** 可带小数的精确数字字符串 */
    private static String SQL_DECIMAL = "DECIMAL";

    /*----日期时间类----*/
    /** 时间戳，内容格式：yyyy-mm-dd hh:mm:ss[.f...] */
    private static String SQL_TIMESTAMP = "TIMESTAMP";
    /** 日期，内容格式：YYYY­MM­DD */
    private static String SQL_DATE = "DATE";

    private static String SQL_TIME = "TIME";
    /** -- */
    private static String SQL_INTERVAL = "INTERVAL";

    private static String SQL_DATE_TIME = "DATETIME";

    /*----字符串类----*/
    /** 字符串 */
    private static String SQL_STRING = "STRING";
    /** 长度不定字符串 字符数范围1 - 65535 */
    private static String SQL_VARCHAR = "VARCHAR";
    /** 长度固定字符串 最大的字符数：255 */
    private static String SQL_CHAR = "CHAR";

    private static String SQL_TEXT = "TEXT";

    /*----Misc类----*/
    /** 布尔类型 TRUE/FALSE */
    private static String SQL_BOOLEAN = "BOOLEAN";
    /** 字节序列 */
    private static String SQL_BINARY = "BINARY";

    /*----复合类----*/
    /** 包含同类型元素的数组，索引从0开始 ARRAY */
    private static String SQL_ARRAY = "ARRAY";
    /** 字典 MAP<primitive_type, data_type> */
    private static String SQL_MAP = "MAP";
    /** 结构体 STRUCT<col_name : data_type [COMMENT col_comment], ...> */
    private static String SQL_STRUCT = "STRUCT";
    /** 联合体 UNIONTYPE<data_type, data_type, ...> */
    private static String SQL_UNIONTYPE = "UNIONTYPE";

    /**
     * 根据type的名称获取对应的postgresql类型
     * @param sqlTypeEnum
     * @return
     * @throws APIException
     */
    public static String getTranslateType(final JavaSqlTypeEnum sqlTypeEnum, Integer columnPrecision, Integer columnScale) throws APIException {
        Validate.notNull(sqlTypeEnum, "sqlTypeEnum不能为空");
        switch (sqlTypeEnum) {
            case CHAR:
            case NCHAR:
            case VARCHAR:
            case NVARCHAR:
                return SQL_VARCHAR;

            case LONGVARCHAR:
            case LONGNVARCHAR:
            case CLOB:
            case NCLOB:
                return SQL_TEXT;

            case SMALLINT:
                return SQL_SMALLINT;
            case TINYINT:
                return SQL_TINYINT;

            case INTEGER:
                return SQL_INTEGER;
            case BIGINT:
                return SQL_BIGINT;
            case NUMERIC:
            case DECIMAL:
                if(columnScale>0){
                    return SQL_DOUBLE;
                }else{
                    return SQL_BIGINT;
                }
            case FLOAT:
                return SQL_FLOAT;
            case REAL:
            case DOUBLE:
                return SQL_DOUBLE;

            case TIME:
                return SQL_TIME;
            case DATE:
                return SQL_DATE;

            case TIMESTAMP:
                return SQL_DATE_TIME;

            case BINARY:
            case VARBINARY:
            case BLOB:
            case LONGVARBINARY:
                return SQL_BINARY;

            case BOOLEAN:
            case BIT:
                return SQL_BOOLEAN;

            case NULL:
            case TIME_WITH_TIMEZONE:
            case TIMESTAMP_WITH_TIMEZONE:
            default:
                throw new APIException(500, "无法识别字段类型:" + sqlTypeEnum);
        }
    }

    /**
     * 根据type的int值获取对应的postgresql类型
     * @param javaSqlType
     * @return
     * @throws APIException
     */
    public static String getTranslateType(final int javaSqlType) throws APIException {
        switch (javaSqlType) {
            case Types.CHAR:
            case Types.NCHAR:
            case Types.VARCHAR:
                return SQL_VARCHAR;

            case Types.LONGVARCHAR:
            case Types.NVARCHAR:
            case Types.LONGNVARCHAR:
            case Types.CLOB:
            case Types.NCLOB:
                return SQL_TEXT;

            case Types.SMALLINT:
                return SQL_SMALLINT;

            case Types.TINYINT:
                return SQL_TINYINT;

            case Types.INTEGER:
                return SQL_INTEGER;

            case Types.BIGINT:
                return SQL_BIGINT;

            case Types.NUMERIC:
            case Types.DECIMAL:
                return SQL_DECIMAL;

            case Types.FLOAT:
                return SQL_FLOAT;
            case Types.REAL:
            case Types.DOUBLE:
                return SQL_DOUBLE;

            case Types.TIME:
                return SQL_TIME;
            case Types.DATE:
                return SQL_DATE;

            case Types.TIMESTAMP:
                return SQL_DATE_TIME;

            case Types.BINARY:
            case Types.VARBINARY:
            case Types.BLOB:
            case Types.LONGVARBINARY:
                return SQL_BINARY;

            case Types.BOOLEAN:
            case Types.BIT:
                return SQL_BOOLEAN;

            case Types.NULL:
            case Types.TIME_WITH_TIMEZONE:
            case Types.TIMESTAMP_WITH_TIMEZONE:
            default:
                throw new APIException(500, "无法识别字段类型:" + javaSqlType);
        }
    }
}
