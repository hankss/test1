package com.openjava.dts.util;

import java.util.ArrayList;
import java.util.List;

import com.openjava.dts.constants.DtsConstants;
import com.openjava.dts.ddl.domain.DtsColumn;
import org.apache.commons.lang3.StringUtils;


/**
 * SQL创建工具
 * 
 * @author Jiahai
 *
 */
public class CreateSqlUtil {

	/**
	 * 字符类型
	 */
	static List<String> stringTypeList = new ArrayList<>();
	static {
		stringTypeList.add("CHAR");
		stringTypeList.add("NVARCHAR2");
		stringTypeList.add("VARCHAR2");
	}

	/**
	 * 数字类型
	 */
	static List<String> numberTypeList = new ArrayList<>();
	static {
		numberTypeList.add("NUMBER");
		numberTypeList.add("FLOAT");
		numberTypeList.add("DOUBLE");
	}

	/**
	 * 创建“建立表SQL”（Oracle）
	 * 
	 * @param tableName     表名
	 * @param dcColumnRules 表对应的列信息
	 * @return
	 */
	public static String createOracleTableSQL(String tableName, List<DtsColumn> dcColumnRules) {
		StringBuilder sb = new StringBuilder("CREATE TABLE " + tableName + "( ");
		for (int i = 0, length = dcColumnRules.size(); i < length; i++) {
			// TODO 获取字段编码
			String columnSource = dcColumnRules.get(i).getColumnSource();
			// TODO 获取字段类型
			String columnType = dcColumnRules.get(i).getColumnType();
			// TODO 获取字段精度
			Integer columnPrecision = dcColumnRules.get(i).getColumnPrecision();
			if (null == columnPrecision) {
				columnPrecision = 0;
			}
			// TODO 获取字段小数位数
			Integer columnScale = dcColumnRules.get(i).getColumnScale();
			if (null == columnScale) {
				columnScale = 0;
			}
			if (i != length - 1) {
				// TODO 不是最后的字段
				sb.append(columnSource + " ");
				if (stringTypeList.contains(columnType.toUpperCase())) {
					if(columnPrecision == 0L) {
						sb.append(columnType + "(512), ");
					} else {
						sb.append(columnType + "(" + columnPrecision + "), ");
					}
				} else if ("VARCHAR".equalsIgnoreCase(columnType)) {
					if(columnPrecision == 0L) {
						sb.append("VARCHAR2" + "(512), ");
					} else {
						sb.append("VARCHAR2" + "(" + columnPrecision + "), ");
					}
				} else if ("INT".equalsIgnoreCase(columnType) || "bigint".equalsIgnoreCase(columnType) || "tinyint".equalsIgnoreCase(columnType)) {
					sb.append("NUMBER" + "(" + columnPrecision + "), ");
				} else if ("DATETIME".equalsIgnoreCase(columnType) || "DATE".equalsIgnoreCase(columnType)) {
					sb.append("DATE" + ", ");
				} else if ("TINYTEXT".equalsIgnoreCase(columnType) || "TEXT".equalsIgnoreCase(columnType) || "MEDIUMTEXT".equalsIgnoreCase(columnType) || "LONGTEXT".equalsIgnoreCase(columnType)) {
					sb.append("CLOB" + ", ");
				} else if (numberTypeList.contains(columnType.toUpperCase())) {
					if (columnPrecision == 0) {
						sb.append(columnType + ", ");
					} else {
						sb.append(columnType + "(" + columnPrecision + ", " + columnScale + "), ");
					}
				} else {
					sb.append(columnType + ", ");
				}
			} else {
				// TODO 是最后的字段
				sb.append(columnSource + " ");
				if (stringTypeList.contains(columnType.toUpperCase())) {
					if(columnPrecision == 0L) {
						sb.append(columnType + "(512) )");
					} else {
						sb.append(columnType + "(" + columnPrecision + ") )");
					}
				} else if ("VARCHAR".equalsIgnoreCase(columnType)) {
					if(columnPrecision == 0L) {
						sb.append("VARCHAR2" + "(512) )");
					} else {
						sb.append("VARCHAR2" + "(" + columnPrecision + ") )");
					}
				} else if ("INT".equalsIgnoreCase(columnType) || "bigint".equalsIgnoreCase(columnType) || "tinyint".equalsIgnoreCase(columnType)) {
					sb.append("NUMBER" + "(" + columnPrecision + ") )");
				} else if ("DATETIME".equalsIgnoreCase(columnType) || "DATE".equalsIgnoreCase(columnType)) {
					sb.append("DATE" + " )");
				}  else if ("TINYTEXT".equalsIgnoreCase(columnType) || "TEXT".equalsIgnoreCase(columnType) || "MEDIUMTEXT".equalsIgnoreCase(columnType) || "LONGTEXT".equalsIgnoreCase(columnType)) {
					sb.append("CLOB" + " )");
				} else if (numberTypeList.contains(columnType.toUpperCase())) {
					if (columnPrecision == 0) {
						sb.append(columnType + " )");
					} else {
						sb.append(columnType + "(" + columnPrecision + ", " + columnScale + ") )");
					}
				} else {
					sb.append(columnType + " )");
				}
			}
		}
		return sb.toString();
	}
	
	/**
	 * 创建“建立表SQL”（MySQL）
	 * 
	 * @param tableName     表名
	 * @param dcColumnRules 表对应的列信息
	 * @return
	 */
	public static String createMysqlTableSQL(String tableName, List<DtsColumn> dcColumnRules) {
		StringBuilder sb = new StringBuilder("CREATE TABLE " + tableName + "( ");
		for (int i = 0, length = dcColumnRules.size(); i < length; i++) {
			//获取字段编码
			String columnSource = dcColumnRules.get(i).getColumnSource();
			//获取字段类型
			String columnType = dcColumnRules.get(i).getColumnType();
			//获取字段精度
			Integer columnPrecision = dcColumnRules.get(i).getColumnPrecision();
			if (null == columnPrecision) {
				columnPrecision = 0;
			}
			//获取字段小数位数
			Integer columnScale = dcColumnRules.get(i).getColumnScale();
			if (null == columnScale) {
				columnScale = 0;
			}
			//TODO 保存时做了类型转换后，这里不需要再做类型转换，只做精度控制就好了
			if (i != length - 1) {
				// TODO 不是最后的字段
				sb.append(columnSource + " ");
				if ("VARCHAR".equalsIgnoreCase(columnType)) {
					sb.append("VARCHAR" + "(" + columnPrecision + "), ");
				} else if ("CHAR".equalsIgnoreCase(columnType)) {
					sb.append("CHAR" + "(" + columnPrecision + "), ");
				} else if ("NUMBER".equalsIgnoreCase(columnType)) {
					if (columnScale == 0L && columnPrecision == 0L) {
						sb.append("INT" + ", ");
					} else if (columnScale == 0L && columnPrecision > 0L) {
						sb.append("INT" + "(" + columnPrecision + "), ");
					} else if (columnScale > 0L && columnPrecision > 0L) {
						sb.append("DOUBLE" + "(" + columnPrecision + ", " + columnScale + "), ");
					}
				} else {
					sb.append(columnType + ", ");
				}
			} else {
				// TODO 是最后的字段
				sb.append(columnSource + " ");
				if ("VARCHAR".equalsIgnoreCase(columnType) || "VARCHAR".equalsIgnoreCase(columnType)) {
					sb.append("VARCHAR" + "(" + columnPrecision + ") )");
				} else if ("CHAR".equalsIgnoreCase(columnType)) {
					sb.append("CHAR" + "(" + columnPrecision + ") )");
				} else if ("NUMBER".equalsIgnoreCase(columnType)) {
					if (columnScale == 0L && columnPrecision == 0L) {
						sb.append("INT" + " )");
					} else if (columnScale == 0L && columnPrecision > 0L) {
						sb.append("INT" + "(" + columnPrecision + ") )");
					} else if (columnScale > 0L && columnPrecision > 0L) {
						sb.append("DOUBLE" + "(" + columnPrecision + ", " + columnScale + ") )");
					}
				} else {
					sb.append(columnType + " )");
				}
			}
		}
		return sb.toString();
	}

	/**
	 * 创建“建立表SQL”（SQL Server）
	 * 
	 * @param tableName     表名
	 * @param dcColumnRules 表对应的列信息
	 * @return
	 */
	public static String createSqlServerTableSQL(String tableName, List<DtsColumn> dcColumnRules) {
		StringBuilder sb = new StringBuilder("CREATE TABLE " + tableName + "( ");
		for (int i = 0, length = dcColumnRules.size(); i < length; i++) {
			// TODO 获取字段编码
			String columnSource = dcColumnRules.get(i).getColumnSource();
			// TODO 获取字段类型
			String columnType = dcColumnRules.get(i).getColumnType();
			// TODO 获取字段精度
			Integer columnPrecision = dcColumnRules.get(i).getColumnPrecision();
			if (null == columnPrecision) {
				columnPrecision = 0;
			}
			// TODO 获取字段小数位数
			Integer columnScale = dcColumnRules.get(i).getColumnScale();
			if (null == columnScale) {
				columnScale = 0;
			}
			if (i != length - 1) {
				// TODO 不是最后的字段
				sb.append(columnSource + " ");
				if ("NVARCHAR2".equalsIgnoreCase(columnType) || "VARCHAR2".equalsIgnoreCase(columnType)) {
					sb.append("VARCHAR" + "(" + columnPrecision + "), ");
				} else if ("CHAR".equalsIgnoreCase(columnType)) {
					sb.append("CHAR" + "(" + columnPrecision + "), ");
				} else if ("NUMBER".equalsIgnoreCase(columnType)) {
					if (columnScale == 0L && columnPrecision == 0L) {
						sb.append("INT" + ", ");
					} else if (columnScale == 0L && columnPrecision > 0L) {
						sb.append("INT" + "(" + columnPrecision + "), ");
					} else if (columnScale > 0L && columnPrecision > 0L) {
						sb.append("FLOAT" + "(" + columnPrecision + ", " + columnScale + "), ");
					}
				} else {
					sb.append(columnType + ", ");
				}
			} else {
				// TODO 是最后的字段
				sb.append(columnSource + " ");
				if ("NVARCHAR2".equalsIgnoreCase(columnType) || "VARCHAR2".equalsIgnoreCase(columnType)) {
					sb.append("VARCHAR" + "(" + columnPrecision + ") )");
				} else if ("CHAR".equalsIgnoreCase(columnType)) {
					sb.append("CHAR" + "(" + columnPrecision + ") )");
				} else if ("NUMBER".equalsIgnoreCase(columnType)) {
					if (columnScale == 0L && columnPrecision == 0L) {
						sb.append("INT" + " )");
					} else if (columnScale == 0L && columnPrecision > 0L) {
						sb.append("INT" + "(" + columnPrecision + ") )");
					} else if (columnScale > 0L && columnPrecision > 0L) {
						sb.append("FLOAT" + "(" + columnPrecision + ", " + columnScale + ") )");
					}
				} else {
					sb.append(columnType + " )");
				}
			}
		}
		return sb.toString();
	}

	/**
	 * PostgreSql建表语句
	 * @param tableName
	 * @param dcColumnRules
	 * @return
	 */
	public static String createPostgreSqlTableSQL(String tableName, List<DtsColumn> dcColumnRules) {

		return "";
	}
	
	/**
	 * 创建“建立表SQL”
	 * 
	 * @param databaseType
	 * @param tableName
	 * @param dcColumnRules
	 * @return
	 */
	public static String createTableSQL(Integer databaseType, String tableName, List<DtsColumn> dcColumnRules) {
		if (StringUtils.isNoneBlank(tableName) && null != dcColumnRules && dcColumnRules.size() > 0) {
			if (databaseType.equals(DtsConstants.DATABASE_TYPE_ORACLE)) {
				return CreateSqlUtil.createOracleTableSQL(tableName, dcColumnRules);
			} else if (databaseType.equals(DtsConstants.DATABASE_TYPE_MYSQL_NEW) || databaseType.equals(DtsConstants.DATABASE_TYPE_MYSQL_OLD)) {
				return CreateSqlUtil.createMysqlTableSQL(tableName, dcColumnRules);
			} else if (DtsConstants.DATABASE_TYPE_POSTGRES.equals(databaseType)) {
				return CreateSqlUtil.createPostgreSqlTableSQL(tableName, dcColumnRules);
			} else if (databaseType.equals(DtsConstants.DATABASE_TYPE_SQL_SERVER)) {
				// TODO 待开发
			}
		}
		return null;
	}
	
	/**
	 * 创建“添加表注释SQL”
	 * 
	 * @param databaseType
	 * @param tableName
	 * @param tableComment
	 * @return
	 */
	public static String addCommentOnTable(Integer databaseType, String tableName, String tableComment) {
		StringBuilder sb = null;
		if (databaseType.equals(DtsConstants.DATABASE_TYPE_ORACLE)) {
			sb = new StringBuilder("COMMENT ON TABLE " + tableName + " IS '" + tableComment + "'");
		} else if (databaseType.equals(DtsConstants.DATABASE_TYPE_MYSQL_NEW) || databaseType.equals(DtsConstants.DATABASE_TYPE_MYSQL_OLD)) {
			sb = new StringBuilder("ALTER TABLE " + tableName + " COMMENT '" + tableComment + "'");
		}else if(databaseType.equals(DtsConstants.DATABASE_TYPE_SQL_SERVER)) {
			// TODO 待开发 ---> 复杂
		}
		return sb.toString();
	}

	/**
	 * 创建“添加字段注释SQL”
	 * 
	 * @param databaseType
	 * @param tableName     表名
	 * @param dcColumnRules 表对应的列信息
	 * @return
	 */
	public static List<String> addCommentOnColumn(Integer databaseType, String tableName, List<DtsColumn> dcColumnRules) {
		List<String> commentSqlList = new ArrayList<>();
		if(dcColumnRules.size() <= 0) {
			return null;
		}
		if (databaseType.equals(DtsConstants.DATABASE_TYPE_ORACLE)) {
			for (DtsColumn dcColumnRule : dcColumnRules) {
				commentSqlList.add("COMMENT ON COLUMN " + tableName + "." + dcColumnRule.getColumnSource() + " IS '" + dcColumnRule.getColumnComment() + "'");
			}
		} else if (databaseType.equals(DtsConstants.DATABASE_TYPE_MYSQL_NEW) || databaseType.equals(DtsConstants.DATABASE_TYPE_MYSQL_OLD)) {
			for (DtsColumn dcColumnRule : dcColumnRules) {
				commentSqlList.add("ALTER TABLE " + tableName + " MODIFY COLUMN " + dcColumnRule.getColumnSource() + " " + dcColumnRule.getColumnType() + " COMMENT '" + dcColumnRule.getColumnComment() + "'");
			}
		} else if (databaseType.equals(DtsConstants.DATABASE_TYPE_SQL_SERVER)) {
			// TODO 待开发 ---> 复杂
		}
		return commentSqlList;
	}

	/**
	 * 创建“设置表的主键SQL”
	 * 
	 * @param tableName     表名
	 * @param dcColumnRules 表对应的列信息
	 * @return
	 */
	public static String setPrimaryKeySQL(Integer databaseType, String tableName, List<DtsColumn> dcColumnRules) {
		StringBuilder sb = new StringBuilder();
		for (DtsColumn dcColumnRule : dcColumnRules) {
			if (dcColumnRule.getIsPrimaryKey()) {
				if(databaseType.equals(DtsConstants.DATABASE_TYPE_ORACLE)) {
					sb.append("ALTER TABLE " + tableName + " ADD constraint " + "pk_" + tableName + "_"	+ dcColumnRule.getColumnSource() + " primary key (" + dcColumnRule.getColumnSource() + ")");
					return sb.toString();
				} else if(databaseType.equals(DtsConstants.DATABASE_TYPE_MYSQL_NEW) || databaseType.equals(DtsConstants.DATABASE_TYPE_MYSQL_OLD)){
					sb.append("ALTER TABLE " + tableName + " ADD PRIMARY KEY( " + dcColumnRule.getColumnSource() + " )");
					return sb.toString();
				} else if(databaseType.equals(DtsConstants.DATABASE_TYPE_SQL_SERVER)) {
					sb.append("ALTER TABLE " + tableName + " ADD constraint " + "pk_" + tableName + "_"	+ dcColumnRule.getColumnSource() + " primary key (" + dcColumnRule.getColumnSource() + ")");
					return sb.toString();
				}
			}
		}
		return null;
	}

	/**
	 * 完整创建表（建表、表注释、主键、字段注释）
	 * 
	 * @param databaseType
	 * @param tableName
	 * @param tableComment
	 * @param dcColumnRules
	 * @param jdbcConnectUtil
	 * @throws Exception 
	 */
	public static void createWholeTable(Integer databaseType, String tableName, String tableComment, List<DtsColumn> dcColumnRules, JdbcMetaExecutor jdbcConnectUtil) throws Exception {
		if (StringUtils.isNotBlank(tableName) && null != dcColumnRules && dcColumnRules.size() > 0 && null != jdbcConnectUtil) {
			String createTableSQL = CreateSqlUtil.createTableSQL(databaseType, tableName, dcColumnRules);
			String tableCommentSQL = CreateSqlUtil.addCommentOnTable(databaseType, tableName, tableComment);
			String setPrimaryKeySQL = CreateSqlUtil.setPrimaryKeySQL(databaseType, tableName, dcColumnRules);
			List<String> columnCommentList = CreateSqlUtil.addCommentOnColumn(databaseType, tableName, dcColumnRules);
			jdbcConnectUtil.customExecuteSQL(createTableSQL, tableCommentSQL, setPrimaryKeySQL, columnCommentList);
		}
	}

	/**
	 * 创建“建立表SQL”（hive）
	 *
	 * @param tableName     表名
	 * @param dcColumnRules 表对应的列信息
	 * @return
	 */
	public static String createHiveTableSQL(String tableName, List<DtsColumn> dcColumnRules) {
		StringBuilder sb = new StringBuilder("CREATE TABLE " + tableName + "( ");
		for (int i = 0, length = dcColumnRules.size(); i < length; i++) {
			//获取字段编码
			String columnSource = dcColumnRules.get(i).getColumnSource();
			//获取字段类型
			String columnType = dcColumnRules.get(i).getColumnType();
			//获取字段精度
			Integer columnPrecision = dcColumnRules.get(i).getColumnPrecision();
			if (null == columnPrecision) {
				columnPrecision = 0;
			}
			//获取字段小数位数
			Integer columnScale = dcColumnRules.get(i).getColumnScale();
			if (null == columnScale) {
				columnScale = 0;
			}
			//字段注释
			String comment = dcColumnRules.get(i).getColumnComment();

			sb.append(columnSource + " ");
			//前面保存写表信息时已转换为对应写数据库的类型
			sb.append(columnType);
			//TODO hive建表是否有精度控制
			if("VARCHAR".equalsIgnoreCase(columnType)){//varchar必须指定长度
				sb.append("(").append(columnPrecision).append(")");
			}
//			if(columnPrecision>0){
//				sb.append("(").append(columnPrecision);
//				if(columnScale>0){
//					sb.append(",").append(columnPrecision);
//				}
//				sb.append(")");
//			}
			//字段注释
			sb.append(" COMMENT '").append(comment).append("'");
			sb.append(",");
		}

		String ddl = sb.toString();
		ddl = ddl.substring(0,ddl.length()-1);
		ddl += ") STORED AS ORC";

		return ddl;
	}
}
