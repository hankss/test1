package com.openjava.dts.util;

import com.openjava.dts.constants.ExceptionConstants;
import com.openjava.dts.dataLake.domain.DatabaseInfoVo;
import com.openjava.dts.ddl.domain.DtsDatasource;
import com.openjava.dts.ddl.dto.DatasourceInfo;
import com.openjava.dts.job.domain.DtsComponent;
import org.ljdp.component.exception.APIException;

import java.util.regex.Pattern;


public class DataSourceUtil {


    public static DtsDatasource getDtsDatasourceByDatabaseInfoVo(DatabaseInfoVo databaseInfoVo){
        if(null ==databaseInfoVo)
            return null;
        DtsDatasource DtsDatasource = new DtsDatasource();
        //DtsDatasource.setUrl(databaseInfoVo.);
        return DtsDatasource;
    }


    public static Integer getDbType(DtsComponent dtsCompent, DtsDatasource dtsDatasource){
       //0:Oracle,1:MySql高版本 2：Mysql低版本 3:PostgreSQL  4:hive  5:SQL Server ）
        if (dtsCompent.getCompentType().intValue() == 1) {
            return dtsDatasource.getDatabaseType();
        } else if (dtsCompent.getCompentType().intValue() == 2 || dtsCompent.getCompentType().intValue() == 5) {
            return Integer.valueOf(3);
        }else if (dtsCompent.getCompentType().intValue() == 4 || dtsCompent.getCompentType().intValue() == 7) {
            return null;//这里要补上 HLTODO
        }else if (dtsCompent.getCompentType().intValue() == 3 || dtsCompent.getCompentType().intValue() == 6) {
            return Integer.valueOf(3);
        }
        return null;
    }

    /**
     *  检查 jdbcUrl 是否非法
     * @param dbType
     * @param jdbcUrl
     * @throws APIException
     */
    public static void checkJdbcUrl(Integer dbType, String jdbcUrl) throws APIException {
        ValidateUtil.strNotBlank(jdbcUrl, "连接地址URL不能为空");

        String regex = "^jdbc:\\S+:(?:@//|//|@)\\S+:\\d+.*$";
        if (!Pattern.matches(regex, jdbcUrl)) {
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "["+jdbcUrl+"]的格式不正确！");
        }

        String jdbcUrlHead = "";
        switch (dbType) {
            case 0: // oracle
                jdbcUrlHead = "jdbc:oracle:thin:";
                break;
            case 1: // mysqlNew
                jdbcUrlHead = "jdbc:mysql://";
                break;
            case 2: // mysqlOld
                jdbcUrlHead = "jdbc:mysql://";
                break;
            case 3: // postgreSql
                jdbcUrlHead = "jdbc:postgresql://";
                break;
            case 4: // hive
                jdbcUrlHead = "jdbc:hive2://";
                break;
            case 5: // sqlserver
                jdbcUrlHead = "jdbc:sqlserver://";
                break;
            case 6: // huawei-hive
                jdbcUrlHead = "jdbc:hive2://";
                break;
            case 7: // gaussDB
                jdbcUrlHead = "jdbc:zenith:";
                break;
            default:
                break;
        }

        if(!jdbcUrl.startsWith(jdbcUrlHead)) {
            throw new APIException(ExceptionConstants.EXCEPTION_ERROR, "JDBC URL与数据库类型不对应！");
        }
    }
}
