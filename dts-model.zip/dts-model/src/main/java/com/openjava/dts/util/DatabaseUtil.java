package com.openjava.dts.util;

import com.openjava.dts.constants.DtsConstants;

/**
 * @author: lsw
 * @Date: 2019/9/24 11:40
 */
public final class DatabaseUtil {

    /** 工具类构造函数私有化 */
    private DatabaseUtil() {}

    /**
     * 获取数据库类型
     *
     * @param name 数据库类型名
     * @return 数据库类型
     */
    public static Integer getDatabaseTypeByName(String name) {
        Integer databaseType = null;
        switch (name) {
            case  DtsConstants.DATABASE_TYPE_NAME_ORACLE:
                databaseType = DtsConstants.DATABASE_TYPE_ORACLE;
                break;
            case  DtsConstants.DATABASE_TYPE_NAME_MYSQL_NEW:
                databaseType = DtsConstants.DATABASE_TYPE_MYSQL_NEW;
                break;
            case  DtsConstants.DATABASE_TYPE_NAME_POSTGRES:
                databaseType = DtsConstants.DATABASE_TYPE_POSTGRES;
                break;
            case  DtsConstants.DATABASE_TYPE_NAME_HIVE:
                databaseType = DtsConstants.DATABASE_TYPE_HIVE;
                break;
            case  DtsConstants.DATABASE_TYPE_NAME_SQL_SERVER:
                databaseType = DtsConstants.DATABASE_TYPE_SQL_SERVER;
                break;
            case  DtsConstants.DATABASE_TYPE_NAME_HIVE_HUAWEI:
                databaseType = DtsConstants.DATABASE_TYPE_HIVE_HUAWEI;
                break;
            case DtsConstants.DATABASE_TYPE_NAME_GAUSSDB:
                databaseType = DtsConstants.DATABASE_TYPE_GAUSSDB;
            default:
                break;
        }

        return databaseType;
    }
}
