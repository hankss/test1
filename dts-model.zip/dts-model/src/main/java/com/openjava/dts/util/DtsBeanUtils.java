package com.openjava.dts.util;

import com.openjava.dts.statistic.domain.DtsStatisticsTable;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author: lsw
 * @Date: 2019/10/15 13:56
 */
public class DtsBeanUtils {

    /**
     *
     *
     * @param target
     * @param source
     */
    public static void copyPropertiesNotBlank(Object target, Object source) {
        BeanUtils.copyProperties(source, target, getNullPropertyNames(source));
    }

    /**
     * 获取属性值为null的属性
     *
     * @param source 源实体
     * @return 属性集合
     */
    private static String[] getNullPropertyNames(Object source) {
        final BeanWrapper src = new BeanWrapperImpl(source);
        java.beans.PropertyDescriptor[] pds = src.getPropertyDescriptors();

        Set<String> emptyNames = new HashSet<>();
        for (java.beans.PropertyDescriptor pd : pds) {
            Object srcValue = src.getPropertyValue(pd.getName());

            if (srcValue == null) {
                //对象为null
                emptyNames.add(pd.getName());
            } else if (srcValue instanceof String && StringUtils.isBlank(srcValue.toString())) {
                //对象为字符串，且为空
                emptyNames.add(pd.getName());
            }
        }
        String[] result = new String[emptyNames.size()];
        return emptyNames.toArray(result);
    }

    public static List<DtsStatisticsTable> StatisticsTableListCopy(List<DtsStatisticsTable> src){
        List<DtsStatisticsTable> n = new ArrayList<>();
        for(DtsStatisticsTable i:src){
            DtsStatisticsTable item = new DtsStatisticsTable();
            BeanUtils.copyProperties(i, item);
            item.setTbid(null);
            n.add(item);
        }
        return n;
    }
}
