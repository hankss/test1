package com.openjava.dts.util;

import org.ljdp.component.exception.APIException;

public class DtsExceptionUtil {

    /**
     * 此类为正常向前端传递异常操作信息
     * @param e
     * @param code
     * @param message
     * @return
     */
    public static Exception getException(Exception e,int code,String message){
        if(e instanceof APIException)
            return e;
        else
            return new APIException(code, message);
    }
}
