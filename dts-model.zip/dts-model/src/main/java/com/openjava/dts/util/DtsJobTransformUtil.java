package com.openjava.dts.util;

import com.openjava.dts.constants.DtsConstants;
import com.openjava.dts.dataLake.domain.DatabaseInfoVo;
import com.openjava.dts.dataLake.domain.DlRescataColumn;
import com.openjava.dts.ddl.domain.DtsColumn;
import com.openjava.dts.ddl.domain.DtsDatasource;
import com.openjava.dts.ddl.domain.DtsTable;
import com.openjava.dts.ddl.dto.ColumnInfo;
import com.openjava.dts.ddl.vo.TableAddVo;
import com.openjava.dts.job.domain.DtsComponent;
import com.openjava.dts.job.domain.DtsComponentFieldMapping;
import com.openjava.dts.job.domain.DtsJob;
import com.openjava.dts.job.domain.DtsSyncJob;
import com.openjava.dts.job.dto.BatchSyncTableRequest;
import com.openjava.dts.job.dto.DtsItgBatchJobRequest;
import com.openjava.dts.job.dto.DtsItgJobRequest;
import com.openjava.dts.job.vo.DtsComponentRelatFieldVO;
import com.openjava.dts.job.vo.DtsJobBatchVo;
import com.openjava.dts.util.column.JavaSqlTypeEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.ljdp.component.exception.APIException;
import org.ljdp.component.sequence.ConcurrentSequence;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Slf4j
public class DtsJobTransformUtil {

    public static Map<String,Object> getDataFromeDtsItgJobReq(DtsItgJobRequest dtsItgJobRequest){
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("srcDtsTable",dtsItgJobRequestToSrcDtsTable(dtsItgJobRequest));
        return map;
    }

    public static DtsTable dtsItgJobRequestToSrcDtsTable(DtsItgJobRequest dtsItgJobRequest){
        DtsTable dtsTable = new DtsTable();
        dtsTable.setDatasourceId(dtsItgJobRequest.getSourceTableDatasourceId());
        if(dtsItgJobRequest.getIsNew() != null && dtsItgJobRequest.getIsNew()) {
            dtsTable.setTableId(ConcurrentSequence.getInstance().getSequence());
        }else
            dtsTable.setTableId(dtsItgJobRequest.getSourceTableId());
        dtsItgJobRequest.setSourceTableId(dtsTable.getTableId());
        dtsItgJobRequest.setNewSrcTableId(dtsTable.getTableId());
        dtsTable.setTableSource(dtsItgJobRequest.getSourceTableName());
        dtsTable.setTableComment(dtsItgJobRequest.getSourceTableComment());
        dtsTable.setCiphertext(dtsItgJobRequest.getSourceTableCiphertext());
        dtsTable.setQuerySql(dtsItgJobRequest.getSourceQuerySql());
        setTableVersion(dtsTable);
        return dtsTable;
    }

    public static DtsTable dtsItgJobRequestToTargetDtsTable(DtsItgJobRequest dtsItgJobRequest){
        DtsTable dtsTable = new DtsTable();
        if(dtsItgJobRequest.getSyncPosition() == 1) {
            if(dtsItgJobRequest.getIsNew() != null && dtsItgJobRequest.getIsNew())
                dtsTable.setTableId(ConcurrentSequence.getInstance().getSequence());
            else {
                dtsTable.setTableId(dtsItgJobRequest.getTargetTableId());
            }
            dtsTable.setTableSource(dtsItgJobRequest.getResourceCode());
            dtsItgJobRequest.setTargetTableName(dtsItgJobRequest.getResourceCode());
        }else {
            if(dtsItgJobRequest.getIsNew() != null && dtsItgJobRequest.getIsNew())
                dtsTable.setTableId(ConcurrentSequence.getInstance().getSequence());
            else
                dtsTable.setTableId(dtsItgJobRequest.getTargetTableId());
            dtsTable.setDatasourceId(dtsItgJobRequest.getTargetTableDatasourceId());
        }
        dtsItgJobRequest.setTargetTableId(dtsTable.getTableId());
        dtsItgJobRequest.setNewTargetTableId(dtsTable.getTableId());
        dtsTable.setTableSource(dtsItgJobRequest.getTargetTableName());
        dtsTable.setTableComment(dtsItgJobRequest.getTargetTableComment());
        dtsTable.setCiphertext(dtsItgJobRequest.getTargetTableCiphertext());
        dtsTable.setQuerySql(dtsItgJobRequest.getTargetQuerySql());
        setTableVersion(dtsTable);
        return dtsTable;
    }

    public static List<DtsColumn> dtsItgJobRequestToSrcDtsColumn(DtsItgJobRequest dtsItgJobRequest){
        List<DtsColumn> list = new ArrayList<DtsColumn>();
        if(dtsItgJobRequest.getSourceTableStruct() != null && dtsItgJobRequest.getSourceTableStruct().size()>0 ){
          for(ColumnInfo columnInfo:dtsItgJobRequest.getSourceTableStruct())
              list.add(columnInfoToDtsColumn(columnInfo,dtsItgJobRequest.getNewSrcTableId()));
        }
        return list;
    }

    public static List<DtsColumn> dtsItgJobRequestToTargetDtsColumn(DtsItgJobRequest dtsItgJobRequest)throws Exception{
        List<DtsColumn> list = new ArrayList<DtsColumn>();
        if(dtsItgJobRequest.getTargetTableStruct() != null && dtsItgJobRequest.getTargetTableStruct().size()>0 ){
            for(ColumnInfo columnInfo:dtsItgJobRequest.getTargetTableStruct()) {
                list.add(columnInfoToDtsColumn(columnInfo, dtsItgJobRequest.getNewTargetTableId()));
            }
            if(dtsItgJobRequest.getSyncPosition().intValue() == 1 && dtsItgJobRequest.getTargetIsNew().intValue() ==1)
                addResourceDefaultColumn(list,dtsItgJobRequest);
        }
        translateWriterColumnsType(dtsItgJobRequest.getTargetDdatabaseType(), list);
        return list;
    }

    public static List<DtsColumn> addResourceDefaultColumn(List<DtsColumn> list,DtsItgJobRequest dtsItgJobRequest){
        ColumnInfo idDC = new ColumnInfo();
        idDC.setColumnComment("ID");
        idDC.setColumnPrecision(Integer.valueOf(450));
        idDC.setColumnScale(0);
        idDC.setNullable(true);
        idDC.setColumnType("VARCHAR2");
        idDC.setColumnSource("ID_TOKIMNHJ");
        list.add(columnInfoToDtsColumn(idDC, dtsItgJobRequest.getNewTargetTableId()));

        ColumnInfo DIR_ID = new ColumnInfo();
        DIR_ID.setColumnComment("目录ID");
        DIR_ID.setColumnPrecision(Integer.valueOf(100));
        DIR_ID.setColumnScale(0);
        DIR_ID.setNullable(false);
        DIR_ID.setColumnType("VARCHAR2");
        DIR_ID.setColumnSource("DIR_ID_TOKIMNHJ");
        list.add(columnInfoToDtsColumn(DIR_ID, dtsItgJobRequest.getNewTargetTableId()));

        ColumnInfo ADDTIME = new ColumnInfo();
        ADDTIME.setColumnComment("增加时间");
        ADDTIME.setNullable(false);
        ADDTIME.setColumnType("Date");
        ADDTIME.setColumnSource("ADDTIME_TOKIMNHJ");
        list.add(columnInfoToDtsColumn(ADDTIME, dtsItgJobRequest.getNewTargetTableId()));

        ColumnInfo UPDATETIME = new ColumnInfo();
        UPDATETIME.setColumnComment("更新时间");
        UPDATETIME.setNullable(false);
        UPDATETIME.setColumnType("Date");
        UPDATETIME.setColumnSource("UPDATETIME_TOKIMNHJ");
        list.add(columnInfoToDtsColumn(UPDATETIME, dtsItgJobRequest.getNewTargetTableId()));

        ColumnInfo STATE = new ColumnInfo();
        STATE.setColumnComment("状态");
        STATE.setColumnPrecision(Integer.valueOf(50));
        STATE.setColumnScale(0);
        STATE.setNullable(false);
        STATE.setColumnType("VARCHAR2");
        STATE.setColumnSource("STATE_TOKIMNHJ");
        list.add(columnInfoToDtsColumn(STATE, dtsItgJobRequest.getNewTargetTableId()));

        ColumnInfo HASH = new ColumnInfo();
        HASH.setColumnComment("防窜改码");
        HASH.setColumnPrecision(Integer.valueOf(500));
        HASH.setColumnScale(0);
        HASH.setNullable(false);
        HASH.setColumnType("VARCHAR2");
        HASH.setColumnSource("HASH_TOKIMNHJ");
        list.add(columnInfoToDtsColumn(HASH, dtsItgJobRequest.getNewTargetTableId()));

        ColumnInfo DATA_HASH = new ColumnInfo();
        DATA_HASH.setColumnComment("防窜改时间");
        DATA_HASH.setNullable(false);
        DATA_HASH.setColumnType("Date");
        DATA_HASH.setColumnSource("DATA_HASH_TOKIMNHJ");
        list.add(columnInfoToDtsColumn(DATA_HASH, dtsItgJobRequest.getNewTargetTableId()));

        return list;
    }

    /**
     * 处理writer的列类型  来源数据库类型 -1:资源目录 0:Oracle 1:MySql高版本 2;Mysql低版本 3:PostgreSql 4:hive 5:SQL Server 6：华为hive
     * @param writerDbType
     * @param writerColumns
     */
    private static void translateWriterColumnsType(Integer writerDbType, List<DtsColumn> writerColumns) throws APIException {
        if (DtsConstants.DATABASE_TYPE_POSTGRES.equals(writerDbType)) {
            for (DtsColumn column : writerColumns) {
                JavaSqlTypeEnum columnTypeEnum = EnumUtil.getByName(column.getColumnType(), JavaSqlTypeEnum.class);
                if(checkColumnType(column,writerDbType,columnTypeEnum) == false)
                    break;
                String columnType = ColumnTypeTranslatorPostgreSql.getTranslateType(columnTypeEnum);
                column.setColumnType(columnType);
            }
        }else if (DtsConstants.DATABASE_TYPE_HIVE.equals(writerDbType) || DtsConstants.DATABASE_TYPE_HIVE_HUAWEI.equals(writerDbType)) {
            for (DtsColumn column : writerColumns) {
                JavaSqlTypeEnum columnTypeEnum = EnumUtil.getByName(column.getColumnType(), JavaSqlTypeEnum.class);
                if(checkColumnType(column,writerDbType,columnTypeEnum) == false)
                    break;
                String columnType = ColumnTypeTranslatorHiveHuawei.getTranslateType(columnTypeEnum,column.getColumnPrecision(),column.getColumnScale());
                column.setColumnType(columnType);
            }
        }else if (DtsConstants.DATABASE_TYPE_ORACLE.equals(writerDbType)) {
            for (DtsColumn column : writerColumns) {
                JavaSqlTypeEnum columnTypeEnum = EnumUtil.getByName(column.getColumnType(), JavaSqlTypeEnum.class);
                if(checkColumnType(column,writerDbType,columnTypeEnum) == false)
                    break;
                String columnType = ColumnTypeTranslatorOracle.getTranslateType(columnTypeEnum,column.getColumnPrecision(),column.getColumnScale());
                column.setColumnType(columnType);
            }
        }else if (DtsConstants.DATABASE_TYPE_MYSQL_NEW.equals(writerDbType) || DtsConstants.DATABASE_TYPE_MYSQL_OLD.equals(writerDbType)) {
            for (DtsColumn column : writerColumns) {//mysql 新旧版本略有不同,注意下
                JavaSqlTypeEnum columnTypeEnum = EnumUtil.getByName(column.getColumnType(), JavaSqlTypeEnum.class);
                if(checkColumnType(column,writerDbType,columnTypeEnum) == false)
                    break;
                String columnType = ColumnTypeTranslatorMysql.getTranslateType(columnTypeEnum,column.getColumnPrecision(),column.getColumnScale());
                column.setColumnType(columnType);
            }
        }else if (DtsConstants.DATABASE_TYPE_SQL_SERVER.equals(writerDbType)) {
            for (DtsColumn column : writerColumns) {
                JavaSqlTypeEnum columnTypeEnum = EnumUtil.getByName(column.getColumnType(), JavaSqlTypeEnum.class);
                if(checkColumnType(column,writerDbType,columnTypeEnum) == false)
                    break;
                String columnType = ColumnTypeTranslatorSql.getTranslateType(columnTypeEnum,column.getColumnPrecision(),column.getColumnScale());
                column.setColumnType(columnType);
            }
        }
    }

    private static boolean checkColumnType(DtsColumn column,Integer writerDbType,JavaSqlTypeEnum columnTypeEnum ){
        if(columnTypeEnum == null){
            log.error("字段映射有错,writerDbType:{}, DtsColumn:{}",writerDbType,JsonUtil.objectToJson(column));
            return false;
        }
        return true;
    }

    public static DtsJob dtsItgJobRequestToDtsJob(DtsItgJobRequest dtsItgJobRequest) throws Exception{
        DtsJob dtsJob = new DtsJob();
        BeanUtils.copyProperties(dtsItgJobRequest,dtsJob);
        if(dtsItgJobRequest.getCronValue() != null)
          dtsJob.setJobCron(DtsCronUtil.getCronByCronValue(dtsItgJobRequest.getCronValue()));
        if(dtsJob.getJobId() == null)
            dtsJob.setJobId(ConcurrentSequence.getInstance().getSequence());
        if(dtsJob.getStatus() == null)
            dtsJob.setStatus(1);
        if(dtsJob.getSyncPosition().intValue()==1)
            dtsJob.setTargetDdatabaseType(DtsConstants.DATABASE_TYPE_POSTGRES);
        return dtsJob;
    }

    public static DtsSyncJob dtsItgJobRequestToDtsSyncJob(DtsItgJobRequest dtsItgJobRequest) throws Exception{
        DtsSyncJob dtsSyncJob = new DtsSyncJob();
        BeanUtils.copyProperties(dtsItgJobRequest,dtsSyncJob);
        if(dtsItgJobRequest.getCronValue() != null)
            dtsSyncJob.setJobCron(DtsCronUtil.getCronByCronValue(dtsItgJobRequest.getCronValue()));
        if(dtsSyncJob.getId() == null)
            dtsSyncJob.setId(ConcurrentSequence.getInstance().getSequence());
        if(dtsSyncJob.getStatus() == null)
            dtsSyncJob.setStatus(1);
//        if(dtsJob.getSyncPosition().intValue()==1)
//            dtsJob.setTargetDdatabaseType(DtsConstants.DATABASE_TYPE_POSTGRES);
        return dtsSyncJob;
    }

    public static DtsColumn columnInfoToDtsColumn(ColumnInfo columnInfo,Long tableId){
        DtsColumn dtsColumn = new DtsColumn();
        BeanUtils.copyProperties(columnInfo,dtsColumn);
        if(dtsColumn.getColumnId() == null)
            dtsColumn.setColumnId(ConcurrentSequence.getInstance().getSequence());
        if(tableId != null)
            dtsColumn.setTableId(tableId);
        DtsJobTransformUtil.dtsColumnLengthConver(1,dtsColumn);
        return dtsColumn;
    }

    public static List<DtsColumn> getListDtsColumnFromListColumnInfo(List<ColumnInfo> list,Long tableId){
        List<DtsColumn> list1 = new ArrayList<>();
        for(ColumnInfo info:list){
            DtsColumn dc = columnInfoToDtsColumn(info,tableId);
            list1.add(dc);
        }
        return list1;

    }

    public static DtsColumn columnInfoToDtsColumn(ColumnInfo c){
        DtsColumn d = new DtsColumn();
        d.setTableId(c.getColumnId());
        d.setColumnComment(c.getColumnComment());
        d.setColumnIndex(c.getColumnIndex());
        d.setColumnPrecision(c.getColumnPrecision());
        d.setColumnScale(c.getColumnScale());
        d.setColumnSource(c.getColumnSource());
        d.setColumnType(c.getColumnType());
        d.setDefaultValue(c.getDefaultValue());
        d.setIsPrimaryKey(c.getIsPrimaryKey());
        d.setIsUpdateColumn(c.getIsUpdateColumn());
        d.setNullable(c.getNullable());
        return d;
    }

    public static List<DtsColumn> getListDtsColumnFromListColumnInfo(List<ColumnInfo> l){
       if(l != null && l.size()>0){
          List<DtsColumn> ldc = new ArrayList<>();
          for(ColumnInfo i:l){
              DtsColumn d = columnInfoToDtsColumn(i);
              ldc.add(d);
          }
          return ldc;
       }
       return null;
    }

    public static List<DtsTable> dtsItgJobRequestToTables(DtsItgJobRequest dtsItgJobRequest){
        List<DtsTable> list = new ArrayList<DtsTable>();
        DtsTable srcDtsTable = DtsJobTransformUtil.dtsItgJobRequestToSrcDtsTable(dtsItgJobRequest);
        DtsTable targetDtsTable = DtsJobTransformUtil.dtsItgJobRequestToTargetDtsTable(dtsItgJobRequest);
        list.add(srcDtsTable);
        list.add(targetDtsTable);
        return list;
    }

    public static List<DtsJobBatchVo> dtsItgBatchJobRequestToDtsJobBatchVo(DtsItgBatchJobRequest dtsItgBatchJobRequest) throws Exception {
        List<DtsJobBatchVo> listDtsJobBatchVos = new ArrayList<DtsJobBatchVo>();
        List<BatchSyncTableRequest> batchSyncTableRequestsList = dtsItgBatchJobRequest.getSyncTables();
        if(batchSyncTableRequestsList.isEmpty())
            throw new APIException(DtsConstants.EXCEPTION_ERROR,"没有同步表任务.");
        for(BatchSyncTableRequest currentItem:batchSyncTableRequestsList){
            DtsJobBatchVo dtsJobBatchVo = new DtsJobBatchVo();
            DtsJob dtsJob = new DtsJob();
            List<DtsTable> listDtsTable = new ArrayList<DtsTable>();
            BeanUtils.copyProperties(dtsItgBatchJobRequest,dtsJob);
            batchSyncTableRequestToDtsJob(currentItem,dtsJob);
            dtsJobBatchVo.setDtsJob(dtsJob);
            dtsJob.setSourceTableDatasourceId(dtsItgBatchJobRequest.getSourceTableDatasourceId());
            dtsJob.setTargetTableDatasourceId(dtsItgBatchJobRequest.getTargetTableDatasourceId());
            dtsJob.setSourceTableName(currentItem.getSrcTableName());
            dtsJob.setTargetTableName(currentItem.getTargetTableName());
            dtsJob.setResourceId(currentItem.getResourceId());
            dtsJob.setResourceName(currentItem.getResourceName());
            dtsJob.setSourceDdatabaseType(dtsItgBatchJobRequest.getSourceDatabaseType());
            dtsJob.setTargetDdatabaseType(dtsItgBatchJobRequest.getTargetDatabaseType());
            if(dtsItgBatchJobRequest.getCronValue() != null)
               dtsJob.setJobCron(DtsCronUtil.getCronByCronValue(dtsItgBatchJobRequest.getCronValue()));
            if(dtsJob.getSyncPosition().intValue()==1) {
                dtsJob.setTargetTableId(ConcurrentSequence.getInstance().getSequence());
                dtsJob.setTargetTableName(currentItem.getResourceName());
                dtsJob.setResourceCode(currentItem.getResourceCode());
                dtsJob.setResourcePath(dtsItgBatchJobRequest.getResourcePath());
                dtsJob.setResourcePathCode(dtsItgBatchJobRequest.getResourcePathCode());
                dtsJob.setTargetDdatabaseType(DtsConstants.DATABASE_TYPE_POSTGRES.intValue());
            }
            listDtsTable.add(DtsJobToDtsSrcTable(dtsJob,dtsItgBatchJobRequest,currentItem));
            listDtsTable.add(DtsJobToDtsTargetTable(dtsJob,dtsItgBatchJobRequest,currentItem));// to do add dtsColumn
            dtsJobBatchVo.setDtsTables(listDtsTable);
            listDtsJobBatchVos.add(dtsJobBatchVo);
        }
        return listDtsJobBatchVos;
    }

    public static DtsJob batchSyncTableRequestToDtsJob(BatchSyncTableRequest src,DtsJob target){
        //target.setSourceTableId(src.getSrcTableId());
        target.setSourceTableId(ConcurrentSequence.getInstance().getSequence());
        target.setSourceTableName(src.getSrcTableName());
        target.setSplitKey(src.getSplitKey());
        target.setIncrementField(src.getIncrementField());
        target.setTargetTableId(src.getTargetTableId());// to do targetTableName
        target.setJobName(src.getDtsJobName());
        return target;
    }

    public static DtsTable DtsJobToDtsSrcTable(DtsJob dtsJob,DtsItgBatchJobRequest dtsItgBatchJobRequest,BatchSyncTableRequest currentItem){
        DtsTable dtsTable = DtsJobToDtsInit(dtsJob);
        dtsTable.setDatasourceId(dtsItgBatchJobRequest.getSourceTableDatasourceId());
        dtsTable.setTableId(dtsJob.getSourceTableId());
        dtsTable.setTableSource(currentItem.getSrcTableName());
        dtsTable.setTableComment(currentItem.getSourceTableComment());
        dtsTable.setCiphertext(currentItem.getSourceTableCiphertext());
        dtsTable.setQuerySql(currentItem.getSourceQuerySql());
        initTableInfo(dtsJob,dtsTable,1);
        setTableVersion(dtsTable);
        return dtsTable;
    }

    public static DtsTable DtsJobToDtsTargetTable(DtsJob dtsJob,DtsItgBatchJobRequest dtsItgBatchJobRequest,BatchSyncTableRequest currentItem){
        DtsTable dtsTable = DtsJobToDtsInit(dtsJob);
        dtsTable.setTableSource(dtsItgBatchJobRequest.getSourceTableDatasourceId());
        if(dtsJob.getSyncPosition().intValue() ==1){
            dtsTable.setTableSource(currentItem.getResourceName());
            if(dtsTable.getTableId() == null){
                if(dtsJob.getTargetTableId() != null)
                    dtsTable.setTableId(dtsJob.getTargetTableId());
                else
                    dtsTable.setTableId(ConcurrentSequence.getInstance().getSequence());
            }
            dtsJob.setTargetTableId(dtsTable.getTableId());
        }else {
            dtsTable.setTableId(dtsJob.getTargetTableId());
            dtsTable.setDatasourceId(dtsItgBatchJobRequest.getTargetTableDatasourceId());
            dtsTable.setTableSource(currentItem.getTargetTableName());
        }
        dtsTable.setTableComment(currentItem.getTargetTableComment());
        dtsTable.setCiphertext(currentItem.getTargetTableCiphertext());
        dtsTable.setQuerySql(currentItem.getTargetQuerySql());
        initTableInfo(dtsJob,dtsTable,2);
        return dtsTable;
    }

    public static DtsColumn DtsJobToDtsColumn(DtsJob dtsJob,DtsColumn dtsColumn){
       return null;
    }

    public static DtsTable DtsJobToDtsInit(DtsJob dtsJob){
        DtsTable dtsTable = new DtsTable();
        setTableVersion(dtsTable);
        return dtsTable;
    }

    public static DtsTable setTableVersion(DtsTable dtsTable){
        if(dtsTable == null)
            return null;
        if(dtsTable.getVersion() == null)
            dtsTable.setVersion(1L);
        else
            dtsTable.setVersion(dtsTable.getVersion().longValue()+1L);
        return dtsTable;
    }

    public static String setLimitLenMsg(String message){
        if(StringUtils.isNotBlank(message)){
           if(message.contains("xception"))
               return StringUtils.substring(message,0,25);
           return message;
        }
        return "";
    }

    public static TableAddVo DtsItgJobRequestToTableAddVo(DtsItgJobRequest dtsItgJobRequest)throws Exception{
        TableAddVo tableAddVo = new TableAddVo();
        tableAddVo.setDatasourceId(dtsItgJobRequest.getTargetTableDatasourceId());
        tableAddVo.setTableName(dtsItgJobRequest.getTargetTableName());
        tableAddVo.setTableComments(dtsItgJobRequest.getTargetTableComment());
        List<DtsColumn> ListDtsColumn = dtsItgJobRequestToTargetDtsColumn(dtsItgJobRequest);
        tableAddVo.setColumnList(ListDtsColumn);
        return tableAddVo;
    }

    public static DtsColumn DlRescataColumnToDtsColumn(DlRescataColumn s,Long tableId){
        DtsColumn t = new DtsColumn();
        t.setColumnId(ConcurrentSequence.getCentumInstance().getSequence());
        t.setTableId(tableId);
        t.setColumnSource(s.getColumnDefinition());
        t.setColumnType(s.getDataTypeCode());
        if(s.getColumnLength() != null)
          t.setColumnPrecision(Integer.valueOf(s.getColumnLength().intValue()));
        else
          t.setColumnPrecision(100);// to do
        t.setDefaultValue(s.getDefaultValue());
        if(s.getIsPrimaryKey().intValue() == 1)
            t.setIsPrimaryKey(true);
        else
            t.setIsPrimaryKey(false);
        if(s.getColumnComment() != null)
          t.setColumnComment(s.getColumnComment());
        else
          t.setColumnComment(s.getColumnName());
        return t;
    }

    /**
     * 数据字段类型转换,转换长度大小,类型等 -根据实际拓展
     * @param databaseType -1:资源目录 0:Oracle 1:MySql高版本 2;Mysql低版本 3:PostgreSql 4:hive 5:SQL Server 6：华为hive
     * @param dtsColumn
     * @return
     */
    public static DtsColumn dtsColumnLengthConver(Integer databaseType,DtsColumn dtsColumn){
        if(databaseType == null) {
            return dtsColumn;
        }else if(databaseType.intValue() ==1 || databaseType.intValue() ==2){
            if(dtsColumn.getColumnType().toLowerCase().contains("longvar") || dtsColumn.getColumnType().toLowerCase().contains("text") || dtsColumn.getColumnType().toLowerCase().contains("date") || dtsColumn.getColumnType().toLowerCase().contains("time")){
                log.error("注意更改文本及类型的长度和小数位为0,列数据:{}",JsonUtil.objectToJson(dtsColumn));
                dtsColumn.setColumnPrecision(0);
                dtsColumn.setColumnScale(0);
            }
        }
        if(dtsColumn.getColumnScale() != null && dtsColumn.getColumnScale().intValue()<0) {
            log.error("重更改列数据,列原数据:{}",JsonUtil.objectToJson(dtsColumn));
            dtsColumn.setColumnScale(0);
        }
        if(dtsColumn.getColumnType().toLowerCase().contains("bigin") || dtsColumn.getColumnType().toLowerCase().contains("numbe")){
            if(dtsColumn.getColumnPrecision() == null || dtsColumn.getColumnPrecision().intValue()<=0) {
                log.error("重更改列数据,列原数据:{}",JsonUtil.objectToJson(dtsColumn));
                dtsColumn.setColumnPrecision(20);
            }
        }
        if(dtsColumn.getColumnType().toLowerCase().contains("char") || dtsColumn.getColumnType().toLowerCase().contains("var")){
            if(dtsColumn.getColumnPrecision() == null || dtsColumn.getColumnPrecision().intValue()<=0) {
                log.error("重更改列数据,列原数据:{}",JsonUtil.objectToJson(dtsColumn));
                dtsColumn.setColumnPrecision(100);
            }
        }
        if(dtsColumn.getColumnType().toLowerCase().contains("char") || dtsColumn.getColumnType().toLowerCase().contains("var")){
            if(dtsColumn.getColumnPrecision() == null || dtsColumn.getColumnPrecision().intValue()>20000) {
                log.error("重更改列数据,列原数据:{}",JsonUtil.objectToJson(dtsColumn));
                dtsColumn.setColumnPrecision(1000);
            }
        }
        return dtsColumn;
    }

    public static DtsJob getDtsJobFromDtsJobList(List<DtsJob> dtsJobList,String tableName){
       if(dtsJobList != null && dtsJobList.size()!=0) {
           for (DtsJob d : dtsJobList) {
               if (d.getSourceTableName().equals(tableName))
                   return d;
           }
       }
       return null;
    }

    public static DtsJob getDtsJobByParams(Integer syncPosition,String sourceDatasourceId,String sourceTableName,String targetDatasourceId,String targetTableName){
        DtsJob d = new DtsJob();
        d.setSyncPosition(syncPosition);
        d.setSourceTableName(sourceTableName);
        d.setSourceTableDatasourceId(sourceDatasourceId);
        d.setTargetTableName(targetTableName);
        d.setTargetTableDatasourceId(targetDatasourceId);
        return d;
    }

    public static void checkTableColumnEq(List<DtsColumn> srcColumn,List<DtsColumn> targetColumn) throws Exception{
        if(srcColumn == null || srcColumn.size()==0 || targetColumn == null || targetColumn.size()==0)
            throw new APIException(DtsConstants.EXCEPTION_ERROR,"源表和目标表字段不能为空!建立同步任务失败！");
        if(srcColumn.size() != targetColumn.size())
            throw new APIException(DtsConstants.EXCEPTION_ERROR,"源表和目标表字段不相等!建立同步任务失败！");
    }

    public static void initTableInfo(DtsJob dtsJob,DtsTable dtsTable,int type){
        if(dtsTable.getTableId() == null || dtsTable.getTableId().intValue()==0)
            dtsTable.setTableId(ConcurrentSequence.getInstance().getSequence());
        if(type == 1){
            if(dtsJob.getSourceTableId() == null)
                dtsJob.setSourceTableId(dtsTable.getTableId());
            if(dtsJob.getSourceTableName() == null)
                dtsJob.setSourceTableName(dtsTable.getTableSource());
        }else{
            if(dtsJob.getTargetTableId() == null)
                dtsJob.setTargetTableId(dtsTable.getTableId());
            if(dtsJob.getTargetTableName() == null)
                dtsJob.setTargetTableName(dtsTable.getTableSource());
        }
    }

    public static DtsDatasource dataLakeDatabaseInfoVo2DtsDatasource(DatabaseInfoVo s,DtsDatasource t){
       if(t == null){
           t = new DtsDatasource();
       }
        String url ="";
        //数据湖返回2：mpp(pg);3：oracle，转换成dts的类型
        if(s.getDatabaseType()!=null){
            if(s.getDatabaseType().longValue()==2L){
                t.setDatabaseType(DtsConstants.DATABASE_TYPE_POSTGRES);
                url = "jdbc:postgresql://"+s.getIp()+":"+s.getPort()+"/"+s.getDatabaseName();
                if(StringUtils.isNotBlank(s.getSchema())){
                    url += "?currentSchema="+s.getSchema();
                }
            }else if(s.getDatabaseType().longValue()==3L){
                t.setDatabaseType(DtsConstants.DATABASE_TYPE_ORACLE);
                url = "jdbc:oracle:thin:@"+s.getIp()+":"+s.getPort()+":"+s.getSchema();
            }
        }
       t.setUrl(url);
       t.setDatabaseName(s.getDatabaseName());
       t.setPassword(s.getPassword());
       t.setUsername(s.getUsername());
       t.setDatasourceId(ConcurrentSequence.getInstance().getSequence(""));
       t.setHostIp(t.getHostIp());
       t.setDatabaseUse(2);
       return t;
    }

    public static DtsJob DtsDatasource2DtsJob(DtsDatasource s,DtsJob t){
       t.setTargetTableDatasourceId(s.getDatasourceId());
       return t;
    }

    public static List<String> pageListDtsJobToListStr(Page<DtsJob> exsitTaskTable){
        List<String> strResult = new ArrayList<>();
        if(exsitTaskTable != null && exsitTaskTable.getContent().size()>0){
            List<DtsJob> exsitTaskTableContent = exsitTaskTable.getContent();
            for(DtsJob dtsJob:exsitTaskTableContent){
                if(dtsJob.getSourceTableName() != null)
                    strResult.add(dtsJob.getSourceTableName());
            }
        }
        return strResult;
    }

    public static DtsColumn getDtsColumnFromDtsComponentFiledMapping(DtsComponentFieldMapping d){
        DtsColumn t = new DtsColumn();
        t.setColumnId(d.getColumnId());
        t.setColumnSource(d.getColumnSource());
        t.setColumnType(d.getColumnType());
        t.setColumnIndex(d.getColumnIndex());
        t.setColumnPrecision(d.getColumnPrecision());
        t.setColumnScale(d.getColumnScale());
        t.setDefaultValue(d.getDefaultValue());
        t.setIsPrimaryKey(d.getIsPrimaryKey());
        t.setSort(d.getSort());
        return t;
    }

    public static DtsComponentRelatFieldVO getComponentRelatFieldVOByStr(String str){
        String[] sArr = str.split("@");
        DtsComponentRelatFieldVO obj = new DtsComponentRelatFieldVO();
        obj.setCid(sArr[0]);
        obj.setTableName(sArr[1]);
        obj.setFieldName(sArr[2]);
        return obj;
    }

    /**
     * 原版设计字段关联处理函数
     * @param newListMap
     * @param dtsComponent
     * @param relateStr
     * @return
     */
    public static Map<String,DtsComponent> getDtscomponentByStr(Map<String,DtsComponent> newListMap,DtsComponent dtsComponent,String relateStr){
        Map<String,DtsComponent> map = new HashMap<>();
        Assert.notNull(relateStr, "映射错误!");
        String[] itemList = relateStr.split("@");
        int i= 0;
        for(String s:itemList){
            String[] sArr = s.split("=");
            if(sArr[1].equals(dtsComponent.getCId())){
                map.put("tar", dtsComponent);
                continue;
            }
            DtsComponent d = getDtsComponentFromMapByCid(newListMap,sArr[1]);
            if(d != null){
                if(i==0){
                    map.put("src", dtsComponent);
                    continue;
                }else{
                    map.put("tar", dtsComponent);
                }
            }
            i++;
        }
        return map;
    }

    /**
     * 原版 componentId@tableName@fieldName=componentId@tableName@fieldName,componentId@tableName@fieldName=componentId@tableName@fieldName
     * @param newListMap
     * @param dtsComponent
     * @param relateStr
     * @return
     */
    public static DtsComponent getDtscomponentByStrA(Map<String,DtsComponent> newListMap,DtsComponent dtsComponent,String relateStr){
        Map<String,DtsComponent> map = new HashMap<>();
        Assert.notNull(relateStr, "映射错误!");
        String[] itemList = relateStr.split("@");
        int i= 0;
        for(String s:itemList){
            String[] sArr = s.split("=");
            if(sArr[1].equals(dtsComponent.getCId())){
               return dtsComponent;
            }
            DtsComponent d = getDtsComponentFromMapByCid(newListMap,sArr[1]);
            if(d != null){
                return d;
            }
        }
        return null;
    }

    /**
     * cId=4fba7319@tableName=A_APPLE01@fieldName=USER_NAME,cId=fd0975b2@fieldName=USER_NAME@tableName=A_APPLE02
     * @param newListMap
     * @param cid
     * @return
     */
    public static DtsComponent getDtsComponentFromMapByCid(Map<String,DtsComponent> newListMap,String cid){
        Set<Map.Entry<String,DtsComponent>> entry = newListMap.entrySet();
        for(Map.Entry<String,DtsComponent> i:entry){
           if(i.getValue().getCId().equals(cid))
               return i.getValue();
        }
        return null;
    }

    public static Map<String,String> getFieldStr(Map<String,List<DtsColumn>> colList,DtsComponent src,DtsComponent tar){
        String iStr = getFieldStr(colList.get("src"),src);
        String sStr = getInsertFieldStr(colList.get("tar"),tar);
        Map<String,String> map = new HashMap<>();
        map.put("insert", sStr);
        map.put("select", iStr);
        return map;
    }

    public static Map<String,String> getInsertFieldStr(Map<String,List<DtsColumn>> colList,DtsComponent src,DtsComponent tar){
        String iStr = getFieldStr(colList.get("src"),src);
        String sStr = getInsertFieldStr(colList.get("tar"),tar);
        Map<String,String> map = new HashMap<>();
        map.put("insert", sStr);
        map.put("select", iStr);
        return map;
    }

    public static String getFieldStr(List<DtsColumn> l,DtsComponent dc){
        String s = "";
        for(DtsColumn i:l){
            if(s.length()<1){
                s = dc.getTableName()+"."+i.getColumnSource();
            }else{
                s += ","+dc.getTableName()+"."+i.getColumnSource();
            }
        }
        return s;
    }

    public static String getInsertFieldStr(List<DtsColumn> l,DtsComponent dc){
        String s = "";
        for(DtsColumn i:l){
            if(s.length()<1){
                s = i.getColumnSource();
            }else{
                s += ","+i.getColumnSource();
            }
        }
        return s;
    }

    public static String getRelateSql(String item){
        //componentId@tableName@fieldName=componentId@tableName@fieldName
        item = item.replace("=", "=~");
        String string = item.replaceAll("(^|~)[^@]*@","");
        return string.replace("@", ".");
    }

    public static String getRelateSql(String[] item,Map<String,String> mapTable){
        //componentId@tableName@fieldName=componentId@tableName@fieldName  Id=4fba7319@tableName=A_APPLE01@fieldName=USER_NAME   -> _APPLE01.USER_NAME=
        String sqlWhereCon = "";
        for(String i:item){
            if(mapTable != null && mapTable.size()>0){
                Set<Map.Entry<String,String>> mEntry = mapTable.entrySet();
                for(Map.Entry<String,String> mi:mEntry){
                    if(i.contains(mi.getKey())){
                        i = i.replace(mi.getKey(), mi.getValue());
                    }
                }
            }
            Map<String,String> m = getMapFromRelaStr(i);
            if(sqlWhereCon.length()<2)
                sqlWhereCon = m.get("tableName")+"."+m.get("fieldName");
            else
                sqlWhereCon += "="+m.get("tableName")+"."+m.get("fieldName");
        }
        return sqlWhereCon;
    }

    public static Map<String,String>getMapFromRelaStr(String str){
        Map<String,String> m = new HashMap<>();
        String arr[] = str.split("@");
        for(String i:arr){
            String[] item = i.split("=");
            m.put(item[0], item[1]);
        }
        return m;
    }

    public static void getInsertSelectStr(Map<String,String> fieldMap,String insert,String select){
        if(org.apache.commons.lang3.StringUtils.isBlank(insert)){
            insert = fieldMap.get("insert");
        }else
            insert += ","+fieldMap.get("insert");

        if(org.apache.commons.lang3.StringUtils.isBlank(select)){
            select = fieldMap.get("select");
        }else
            select += ","+fieldMap.get("select");
    }

    public static void main(String[] args) {
        System.out.println(getRelateSql("componentId@tableName@fieldName=componentId@tableName@fieldName"));
    }

    /**
     * 需二次处理 id,componentid src tar sort 字段
     * @param job
     * @param c
     * @return
     */
    public static DtsComponentFieldMapping getDcFieldMappingByColunInfo(DtsSyncJob job, ColumnInfo c){
        DtsComponentFieldMapping t = new DtsComponentFieldMapping();
        t.setColumnId(ConcurrentSequence.getInstance().getSequence());
        t.setJobId(job.getId());
        t.setColumnSource(c.getColumnSource());
        t.setColumnType(c.getColumnType());
        t.setColumnPrecision(c.getColumnPrecision());
        t.setColumnScale(c.getColumnScale());
        t.setIsPrimaryKey(c.getIsPrimaryKey());
        t.setColumnComment(c.getColumnComment());
        return t;
    }

    public static String[] getInsertSelectSqlByMaps(String insertFieldStr, String selectFieldStr,Map<String,String> ...maps ){
        for(Map<String,String> m:maps){
            if(org.apache.commons.lang3.StringUtils.isBlank(insertFieldStr)){
                insertFieldStr = m.get("insert");
            }else
                insertFieldStr += ","+m.get("insert");
            if(org.apache.commons.lang3.StringUtils.isBlank(selectFieldStr)){
                selectFieldStr = m.get("select");
            }else
                selectFieldStr += ","+m.get("select");
        }
        return new String[]{insertFieldStr,selectFieldStr};
    }

    public static String getListColounField(List<DtsColumn> l){
      String s ="";
      if(l != null && l.size()>0){
        for(DtsColumn i:l)
            s +=","+i.getColumnSource();
      }
      return s;
    }

    public static Map<String,DtsColumn> getMapByListDtsColumn(List<DtsColumn> listTar){
        Map<String,DtsColumn> map = new HashMap<>();
        if(listTar != null){
            for(DtsColumn i:listTar){
                if(map.get(String.valueOf(i.getSort())) == null)
                  map.put(String.valueOf(i.getSort()), i);
            }
        }
        return map;
    }

    public static  List<DtsColumn> delPrimarkeyListDtsColumn(List<DtsColumn> l){
       for(DtsColumn i:l){
           if(i.getIsPrimaryKey().booleanValue() ==true){
               i.setIsPrimaryKey(Boolean.valueOf(false));
           }
       }
       return l;
    }
}
