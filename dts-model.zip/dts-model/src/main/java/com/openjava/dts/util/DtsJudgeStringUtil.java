package com.openjava.dts.util;

/**
 * @author 丘健里
 * @date 2020-04-10 11:21
 */
public class DtsJudgeStringUtil {

    /**
     * 这里是去掉归集库中的表名的规则，获取加规则之前的表名
     * 规则：o_参数_表名_四位标志
     *
     * @param tableName
     * @param prefixTableName
     * @return
     */
    public static String getTargetTableName(String tableName, String prefixTableName) {
        String str = tableName.toLowerCase();
        if (!str.contains("_")) {
            return str;
        }
        if (!str.contains(prefixTableName)) {
            return str;
        }
        //第一次去前面的
        String substring = str.substring(prefixTableName.length(), str.length());
        //第二次获取后面，第5位
        String five = substring.substring(substring.length() - 5, substring.length() - 4);
        //获取到后面4位
        String four = substring.substring(substring.length() - 4, substring.length());

        if (!("_").equals(five)) {
            return str;
        }

        if (!judgeIsSmallChar(four)) {
            return str;
        }
        return str.substring(prefixTableName.length(), str.length() - 5);
    }

    /**
     * 判断是否全是大写字母
     *
     * @param str
     */
    public static Boolean judgeIsBigChar(String str) {
        //true表示全部为大写字母
        return str.matches("[A-Z]+");
    }

    /**
     * 判断是否全是小写字母
     *
     * @param str
     * @return
     */
    public static Boolean judgeIsSmallChar(String str) {
        //true表示全部为小写字母
        return str.matches("[a-z]+");
    }

    /**
     * 获取字符串中的全部字母构成的字符串
     *
     * @param str
     * @return
     */
    public static String getAllCharFromString(String str) {
        //获取字符串中的字母
        return str.replaceAll("[^a-z^A-Z]", "");
    }
}
