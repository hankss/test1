package com.openjava.dts.util;

import com.openjava.dts.statistic.domain.DtsStatisticsTable;
import com.openjava.dts.statistic.vo.PostGreSqlVo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class DtsStatisticsUtil {

    public static DtsStatisticsTable getMysqlNewStatisticsTable(Map map){
        DtsStatisticsTable dtsStatisticsTable = new DtsStatisticsTable();
        try{
            dtsStatisticsTable.setTableName((String) map.get("TABLE_NAME"));
            Double rows = 0.00;
            if( map.get("TABLE_ROWS") != null && (map.get("TABLE_ROWS") instanceof String) == false) {
                rows = Double.valueOf(((BigInteger)map.get("TABLE_ROWS")).doubleValue());
                rows = DtsMathUtil.getRoundHalfUpDouble(rows.doubleValue() / 10000);
            }
            dtsStatisticsTable.setRows(rows);
            Double allSpace = 0.00;
            if(rows.doubleValue() > 0.1) {
                long dataLength =0l;
                if( map.get("DATA_LENGTH") != null && (map.get("DATA_LENGTH") instanceof String) == false )
                   dataLength = ((BigInteger)map.get("DATA_LENGTH")).longValue();
                long indexLength = 0l;
                if( map.get("INDEX_LENGTH") != null && (map.get("INDEX_LENGTH") instanceof String) == false)
                    indexLength = ((BigInteger )map.get("INDEX_LENGTH")).longValue();
                dtsStatisticsTable.setDataSpace(DtsMathUtil.getGBfromByte(dataLength));
                dtsStatisticsTable.setIndexSpace(DtsMathUtil.getGBfromByte(indexLength));
                allSpace = DtsMathUtil.getGBfromByte(dataLength+indexLength);
                if((allSpace.doubleValue()<0.01 && allSpace.doubleValue()>0) ||  allSpace.doubleValue() == 0d)
                    allSpace = Double.valueOf(0.01d);
                else
                    allSpace = DtsMathUtil.getRoundHalfUpDouble(allSpace);
            }else if(rows.doubleValue() == 0){
                allSpace = 0.00;
            }else
                allSpace = 0.01;
            dtsStatisticsTable.setAllSpace(allSpace);
        } catch (Exception e) {
            log.error("\n[DtsStatisticsUtil getMysqlNewStatisticsTable异常,传参:{] ]",JsonUtil.objectToJson(map),e);
            return null;
        }
        return dtsStatisticsTable;
    }

    public static DtsStatisticsTable getOracleStatisticsTable(Map map){
        DtsStatisticsTable dtsStatisticsTable = new DtsStatisticsTable();
        try{
            dtsStatisticsTable.setTableName((String) map.get("TABLE_NAME"));
            Double rows = 0.00;
            if(map.get("NUM_ROWS") != null &&  (map.get("NUM_ROWS") instanceof String) == false) {
                rows = Double.valueOf(((BigDecimal)map.get("NUM_ROWS")).doubleValue());
                rows = DtsMathUtil.getRoundHalfUpDouble(rows.doubleValue() / 10000);
            }
            dtsStatisticsTable.setRows(rows);
            Double allSpace = 0.00;
            if(rows.doubleValue() > 0.1) {
                if(map.get("GB") != null && (map.get("GB") instanceof String) == false) {
                    allSpace = Double.valueOf(((BigDecimal) map.get("GB")).doubleValue());
                    if((allSpace.doubleValue()<0.01 && allSpace.doubleValue()>0) || allSpace.doubleValue() == 0d )
                        allSpace = Double.valueOf(0.01d);
                    else
                        allSpace = DtsMathUtil.getRoundHalfUpDouble(allSpace);
                }
            }else if(rows.doubleValue() == 0){
                allSpace = 0.00;
            }else
                allSpace = 0.01;
            dtsStatisticsTable.setAllSpace(allSpace);
        } catch (Exception e) {
            log.error("\n[DtsStatisticsUtil getOracleStatisticsTable异常,传参:{} ]",JsonUtil.objectToJson(map),e);
            return null;
        }
        return dtsStatisticsTable;
    }

    public static DtsStatisticsTable getPostgresqlStatisticsTable(Map map){
        try {
            DtsStatisticsTable dtsStatisticsTable = new DtsStatisticsTable();
            dtsStatisticsTable.setTableName((String)map.get("table_name"));
            Double rows = 0.0;
            double rowcounts = 0d;
            if(map.get("reltuples") != null && (map.get("reltuples") instanceof String) == false) {
                float row = (float) map.get("reltuples");
                rowcounts = Double.valueOf(Float.valueOf(row).doubleValue());
            }
            if (rowcounts == 0)
                dtsStatisticsTable.setRows(0.0);
            else
                dtsStatisticsTable.setRows(DtsMathUtil.getRoundHalfUpDouble(rowcounts / 10000));
            rows = dtsStatisticsTable.getRows();
            Double allSpace = 0.00;
            if (rows.doubleValue() > 0.1) {
                double d = 0d;
                if(map.get("GB") != null && (map.get("GB") instanceof String) == false)
                     d = DtsMathUtil.getGBfromPgSize((String) map.get("GB"));
                if(d == 0)
                    d = 0.01d;
                dtsStatisticsTable.setAllSpace(d);
            } else if (rows.doubleValue() == 0) {
                allSpace  =  0.00;
                dtsStatisticsTable.setAllSpace(DtsMathUtil.getRoundHalfUpDouble(allSpace));
            } else {
                allSpace = 0.01;
                dtsStatisticsTable.setAllSpace(DtsMathUtil.getRoundHalfUpDouble(allSpace));
            }
            return dtsStatisticsTable;
        }catch (Exception e){
            log.error("\n[DtsStatisticsUtil getPostgresqlStatisticsTable ,传参:{} ]",JsonUtil.objectToJson(map),e);
            return null;
        }
    }

    public static String getNewMysqlDbName(String url){
        if(StringUtils.isBlank(url))
            return null;
        String pattern = ":\\d{3,5}[:/]{1}[^?]*";
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(url);
        if (m.find( )) {
            String re = m.group(0);
            re = re.replaceAll("^:", "");
            String db = (re.split("[:/]"))[1];
            return db;
        } else {
            return null;
        }
    }

    public static Integer getJdbcPort(String url){
        if(StringUtils.isBlank(url))
            return null;
        Pattern p = Pattern.compile(".*:(@//|//|@)\\S*:(\\d++).*");
        Matcher matcher = p.matcher(url);
        if (matcher.find()){
            return Integer.valueOf(matcher.group(2));
        }
        return null;
    }

    public static String getJdbcHost(String url){
        if(StringUtils.isBlank(url))
            return null;
        Pattern p = Pattern.compile(".*:(@//|//|@)(\\S*):\\d++.*");
        Matcher matcher = p.matcher(url);
        if (matcher.find()){
            return matcher.group(2);
        }
        return null;
    }

    public static String getJdbcDatabaseName(String url){
        if(StringUtils.isBlank(url))
            return null;
        Pattern p = Pattern.compile(".*:(@//|//|@)\\S*[/|:]((\\S*)(?=\\?)|\\S*)");
        Matcher matcher = p.matcher(url);
        if (matcher.find()){
            return matcher.group(2);
        }
        return null;
    }

    public static PostGreSqlVo getPgShema(String url){
        try {
            PostGreSqlVo postGreSqlVo = new PostGreSqlVo();
            if (StringUtils.isBlank(url))
                return null;
            String db = getNewMysqlDbName(url);
            postGreSqlVo.setDbName(db);
            String pattern = "(currentSchema|CURRENTSCHEMA|searchpath|SEARCHPATH)=([^&]*|)";
            Pattern r = Pattern.compile(pattern);
            Matcher m = r.matcher(url);
            if (m.find()) {
                String re = m.group(0);
                String[] rArr = re.split("=");
                postGreSqlVo.setSchema(rArr[1]);
            }
            return postGreSqlVo;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
    public static String getSqlserverJdbcDatabaseName(String url){
        if(StringUtils.isBlank(url))
            return null;
        Pattern p = Pattern.compile(".*:(@//|//|@)\\S*;(\\S*)=(\\S*)");
        Matcher matcher = p.matcher(url);
        if (matcher.find()){
            return matcher.group(3);
        }
        return null;
    }
}
