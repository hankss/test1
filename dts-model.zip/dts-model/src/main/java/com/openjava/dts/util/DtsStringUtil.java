package com.openjava.dts.util;

import com.openjava.dts.constants.DtsConstants;
import org.apache.commons.lang3.StringUtils;
import org.ljdp.component.sequence.ConcurrentSequence;

import javax.validation.constraints.Min;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author: lsw
 * @Date: 2019/8/29 15:08
 */
public class DtsStringUtil {

    /** 正则：数值型 */
    private static final String REQ_NUMBER = "^[0-9]+?$";

    private static final String NUMBER = "^[0-9-.]+?$";

    /**
     * 是否为数值类型
     * @param str
     * @return
     */
    public static boolean isNumberType(String str) {
        return str.matches(REQ_NUMBER);
    }

    /**
     * 是否为数值类型,多一个小数点
     *
     * @param str
     * @return
     */
    public static boolean isNumberTypeHaveDigit(String str) {
        return str.matches(NUMBER);
    }


    /**
     * 处理whereValue
     * @param whereValue
     * @param databaseType
     * @return
     */
    public static String dealSqlWhereValue(String whereValue, Integer databaseType) {
        if (StringUtils.isBlank(whereValue) || DtsStringUtil.isNumberType(whereValue)) {
            return whereValue;
        }

        whereValue = "\'" + whereValue + "\'";
        if (Objects.equals(databaseType, DtsConstants.DATABASE_TYPE_ORACLE)) {
            whereValue = " to_date( " + whereValue + ",'yyyy-mm-dd hh24:mi:ss')";
        }

        return whereValue;
    }

    /**
     * 模板替换
     * @param input
     * @param map
     * @return
     */
    public static String format(String input, Map<String, String> map) {
        for (Map.Entry<String, String> entry : map.entrySet()) {
            input = input.replace("{"+entry.getKey()+"}", entry.getValue());
        }
        input.replaceAll("\\{(.*)\\}","");
        return input;
    }

    public static String  getDouble(double d){
        java.text.DecimalFormat df = new java.text.DecimalFormat("#.##");
        return df.format(d);
    }

    public static Long getSequentId(){
        Long id;
        try {
            id = ConcurrentSequence.getInstance().getSequence();
            if (id == null) {
                Thread.sleep(200);
                id = ConcurrentSequence.getInstance().getSequence();
            }
        }catch (Exception e){
            e.printStackTrace();
            try {
                Thread.sleep(200);
            } catch (InterruptedException e1) {
                e1.printStackTrace();
            }
            id = ConcurrentSequence.getInstance().getSequence();
        }
        return id;
    }

    public static String getPgShema(String url){
        //jdbc:postgresql://219.135.182.2:5432/dts?searchpath=public
        url = "jdbc:postgresql://192.168.6.101:5432/dg12345?currentSchema=c##12345";
        if(StringUtils.isBlank(url))
            return null;
        String pattern = "currentSchema=([^&]*|)";
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(url);
        if (m.find( )) {
            String re = m.group(0);
            re = re.replaceAll("^:", "");
            String db = (re.split("[:/]"))[1];
            return db;
        } else {
            return null;
        }
    }

    //获取4位随机数(包含数字和字母)
    public static String getFourRandomNumber() {
        String[] array = new String[]{"0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
                "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N",
                "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
                "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n",
                "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};
        List<String> list = Arrays.asList(array);
        Collections.shuffle(list);
        return list.toString().replace(" ", "").replace(",", "").substring(1, 5);
    }

    /**
     * 格式化小数点位数,可以指定小数点位数
     *
     * @param str
     * @param digit
     * @return
     */
    public static String formatDecimalPlaces(String str, @Min(1) Integer digit) {
        if (StringUtils.isBlank(str)) {
            return null;
        }
        if (!DtsStringUtil.isNumberTypeHaveDigit(str)) {
            return str;
        }
        StringBuilder resultStr = new StringBuilder();
        if (!str.contains(".")) {
            //原来的值没有小数点
            StringBuilder subDigitString = new StringBuilder("0");
            for (int i = 0; i < digit - 1; i++) {
                subDigitString.append("0");
            }
            return resultStr.append(str).append(".").append(subDigitString.toString()).toString().replace(" ", "");
        }
        String[] split = str.split("\\.");
        StringBuilder sb = new StringBuilder("1");
        String s = sb.append(".").append(split[1]).toString();
        //这里是格式化小数点位数
        String str1 = String.valueOf(Double.parseDouble(s));
        //获取到小数点后面的string
        String[] split1 = str1.split("\\.");

        //这里是添加小数点位数
        //原来的值的小数点个数大于需要设置的小数点个数
        if (digit < split[1].length()) {
            //digit < split[1] 的数量
            String subDigitString = split1[1].substring(0, digit);
            return resultStr.append(split[0]).append(".").append(subDigitString).toString().replace(" ", "");
        }
        //原来的值的小数点个数小于需要设置的小数点个数
        if (digit > split[1].length()) {
            StringBuilder subDigitString = new StringBuilder("0");
            for (int i = 0; i < digit - split1[1].length() - 1; i++) {
                subDigitString.append("0");
            }
            return resultStr.append(split[0]).append(".").append(split1[1]).append(subDigitString.toString()).toString().replace(" ", "");
        }
        return str;
    }

    //格式化小数点位数,不指定小数点位数
    public static String formatDecimalPlaces(String str) {
        if (StringUtils.isBlank(str)) {
            return null;
        }
        if (!DtsStringUtil.isNumberTypeHaveDigit(str)) {
            return str;
        }
        if (!str.contains(".")) {
            return str;
        }
        String[] split = str.split("\\.");
        StringBuilder sb = new StringBuilder("1");
        String s = sb.append(".").append(split[1]).toString();
        //这里是格式化小数点位数
        String str1 = String.valueOf(Double.parseDouble(s));
        //获取到小数点后面的string
        String[] split1 = str1.split("\\.");
        StringBuilder resultStr = new StringBuilder();

        //如果是 .0
        if (1 == split1[1].length() && "0".equals(split1[1])) {
            return split[0];
        }

        return split[0].concat(".").concat(split1[1]).replace(" ", "");
    }

    public static void main(String[] args) {

    }
}
