package com.openjava.dts.util;

public class DtsTest {

    public static String getRelateSql(String item){
        //componentId@tableName@fieldName=componentId@tableName@fieldName


        item = item.replace("=", "=~");

        String string = item.replaceAll("(^|~)[^@]*@","");

        System.out.println(string);

        System.out.println("\r\n");

        return string.replace("@", ".");
    }

    public static void main(String[] args) {


        System.out.println(getRelateSql("componentId@tableName@fieldName=componentId@tableName@fieldName"));
    }
}
