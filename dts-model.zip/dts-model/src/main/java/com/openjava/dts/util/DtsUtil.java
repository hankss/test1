package com.openjava.dts.util;

import com.openjava.dts.ddl.domain.DtsColumn;
import com.openjava.dts.job.domain.DtsJob;

import java.util.List;

public class DtsUtil {

    public static boolean isDlLakeDb(DtsJob dtsJob){
        try {
            if(dtsJob.getSyncPosition() != null && dtsJob.getSyncPosition().intValue() ==1)
                return true;
            if(dtsJob.getSyncPosition() != null && dtsJob.getSyncPosition().intValue() ==2)
                return false;
            if(dtsJob.getResourceCode() != null && dtsJob.getResourceCode().length()>8)
                return true;
        }catch (Exception e){
            e.printStackTrace();
        }
        return false;
    }

    public static String  getWriteField(List<DtsColumn> readerColumns,List<DtsColumn> writerColumns,String readField){
        int i=0;
        for(DtsColumn item:readerColumns){
            if(readField.equals(item.getColumnSource()))
                return writerColumns.get(i).getColumnSource();
            i++;
        }
        return null;
    }
}
