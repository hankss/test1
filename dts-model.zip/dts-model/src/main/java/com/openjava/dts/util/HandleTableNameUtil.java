package com.openjava.dts.util;

import com.google.common.collect.Lists;
import com.openjava.dts.dataprovider.result.ColumnIndex;
import com.openjava.dts.ddl.dto.ColumnInfo;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.Collections;
import java.util.List;

/**
 * @author jianli
 * @date 2020-04-20 15:51
 */

public class HandleTableNameUtil {

    /**
     * 去掉归集库表中的前缀和后四位标识
     * 例如：表名为o_dmptest_yang_car_lu01_yvue,去掉附近项变成：yang_car_lu01
     *
     * @param tableName 源表表名
     * @return 去标志后的表名
     */
    public static String removeTableNameSign(String tableName) {
        if (StringUtils.isBlank(tableName)) {
            return tableName;
        }
        String one = tableName.substring(tableName.indexOf("_") + 1, tableName.length());
        String two = one.substring(one.indexOf("_") + 1, one.length());
        return two.substring(0, two.lastIndexOf("_"));
    }

    /**
     * 关联字段回显的时候去掉 7个字段
     *
     * @param list
     * @return
     */
    public static List<ColumnInfo> removeSevenColumn(List<ColumnInfo> list) {
        if (CollectionUtils.isEmpty(list)) {
            return Collections.emptyList();
        }
        List<ColumnInfo> resultList = Lists.newArrayList();
        for (ColumnInfo c : list) {
            if (c.getColumnSource().toUpperCase().equals("ID_TOKIMNHJ"))
                continue;
            if (c.getColumnSource().toUpperCase().equals("DIR_ID_TOKIMNHJ"))
                continue;
            if (c.getColumnSource().toUpperCase().equals("ADDTIME_TOKIMNHJ"))
                continue;
            if (c.getColumnSource().toUpperCase().equals("UPDATETIME_TOKIMNHJ"))
                continue;
            if (c.getColumnSource().toUpperCase().equals("STATE_TOKIMNHJ"))
                continue;
            if (c.getColumnSource().toUpperCase().equals("HASH_TOKIMNHJ"))
                continue;
            if (c.getColumnSource().toUpperCase().equals("DATA_HASH_TOKIMNHJ"))
                continue;
            resultList.add(c);
        }
        return resultList;
    }

    /**
     * 关联字段回显的时候去掉 7个字段
     *
     * @param list
     * @return
     */
    public static List<ColumnIndex> removeSevenColumnV2(List<ColumnIndex> list) {
        if (CollectionUtils.isEmpty(list)) {
            return Collections.emptyList();
        }
        List<ColumnIndex> resultList = Lists.newArrayList();
        for (ColumnIndex c : list) {
            if (c.getName().toUpperCase().equals("ID_TOKIMNHJ"))
                continue;
            if (c.getName().toUpperCase().equals("DIR_ID_TOKIMNHJ"))
                continue;
            if (c.getName().toUpperCase().equals("ADDTIME_TOKIMNHJ"))
                continue;
            if (c.getName().toUpperCase().equals("UPDATETIME_TOKIMNHJ"))
                continue;
            if (c.getName().toUpperCase().equals("STATE_TOKIMNHJ"))
                continue;
            if (c.getName().toUpperCase().equals("HASH_TOKIMNHJ"))
                continue;
            if (c.getName().toUpperCase().equals("DATA_HASH_TOKIMNHJ"))
                continue;
            resultList.add(c);
        }
        return resultList;
    }

    /**
     * 判断当前字段是不是7个字段中的一个
     * 这里是因为7个子单是固定的,所以这里就简单的使用一个if-else来做,虽然很涝
     *
     * @param columnName
     * @return
     */
    public static Boolean judgeSevenColumnIsExist(String columnName) {
        if (columnName.toUpperCase().equals("ID_TOKIMNHJ"))
            return true;
        if (columnName.toUpperCase().equals("DIR_ID_TOKIMNHJ"))
            return true;
        if (columnName.toUpperCase().equals("ADDTIME_TOKIMNHJ"))
            return true;
        if (columnName.toUpperCase().equals("UPDATETIME_TOKIMNHJ"))
            return true;
        if (columnName.toUpperCase().equals("STATE_TOKIMNHJ"))
            return true;
        if (columnName.toUpperCase().equals("HASH_TOKIMNHJ"))
            return true;
        if (columnName.toUpperCase().equals("DATA_HASH_TOKIMNHJ"))
            return true;
        return false;
    }

    //站内信中成功提醒和失败提醒转换成数字
    public static String defaultNoticeTransformation(String noticeType) {
        if (noticeType.contains(",")) {
            return "1,2";
        } else if (noticeType.contains("成功提醒")) {
            return "1";
        } else if (noticeType.contains("失败提醒")) {
            return "2";
        }
        return noticeType;
    }

    //保存的时候转换
    public static String noticeTypeTransformationSave(String noticeType) {
        StringBuilder sb = new StringBuilder();
        //以数字为标准
        if (noticeType.contains("1") || noticeType.contains("2")) {
            if (noticeType.contains("1,2")) {
                sb.append("1,2");
                return HandleTableNameUtil.noticeTypeTransformationChinese(sb.toString());
            } else if (noticeType.contains("1")) {
                sb.append("1");
            } else if (noticeType.contains("2")) {
                sb.append("2");
            }
            return HandleTableNameUtil.noticeTypeTransformationChinese(sb.toString());
        } else {
            if (noticeType.contains("成功提醒,失败提醒")) {
                sb.append("1,2");
                return HandleTableNameUtil.noticeTypeTransformationChinese(sb.toString());
            } else if (noticeType.contains("成功提醒")) {
                sb.append("1");
            } else if (noticeType.contains("失败提醒")) {
                sb.append("2");
            }
            return HandleTableNameUtil.noticeTypeTransformationChinese(sb.toString());
        }
    }

    //将1和2转成中文
    public static String noticeTypeTransformationChinese(String str) {
        if (str.equals("1")) {
            return "成功提醒";
        } else if (str.equals("2")) {
            return "失败提醒";
        } else if (str.equals("1,2")) {
            return "成功提醒,失败提醒";
        }
        return str;
    }

}
