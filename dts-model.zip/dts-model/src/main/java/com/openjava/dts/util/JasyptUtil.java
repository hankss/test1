package com.openjava.dts.util;

import com.openjava.dts.ddl.domain.DtsDatasource;
import com.openjava.dts.ddl.dto.DatasourceInfo;
import org.apache.commons.lang3.StringUtils;
import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.SimpleStringPBEConfig;

/**
 * @author 丘健里
 * @date 2020/1/7
 * 注意：生成的密文长度根据明文的长度确定
 * 1、第一种加密：将jasypt中使用的盐写在程序中
 * 2、第二种加密：将加密的salt写在配置文件中jasypt.encryptor.password，使用的地方直接注入StringEncryptor
 */
public class JasyptUtil {

    /**
     * salt
     */
    //private final static String salt = "OneSalt";
    public static String salt = "Lt4U6EgL19D2k_HY-AcD7-VAmq1OeLGqDdTTayXtH88";

    public static void setSalt(String str) {
        if (StringUtils.isNotBlank(str)) {
            JasyptUtil.salt = str;
        }
    }

    /**
     * 加密
     *
     * @param value 待加密明文
     * @return
     */
    public static String encryptText(String value) {
        if (value == null || "".equals(value)) {
            return "";
        }
        return cryptOr().encrypt(value);
    }

    /**
     * 解密
     *
     * @param value 待解密密文
     * @return
     */
    public static String decyptText(String value) {
        try {
            return cryptOr().decrypt(value);
        } catch (Exception e) {
            //解密时出现异常，返回原来的值
        }
        return value;
    }

    /**
     * @return
     */
    public static PooledPBEStringEncryptor cryptOr() {
        PooledPBEStringEncryptor encryptOr = new PooledPBEStringEncryptor();
        SimpleStringPBEConfig config = new SimpleStringPBEConfig();
        config.setPassword(salt);
        config.setAlgorithm("PBEWithMD5AndDES");
        config.setKeyObtentionIterations("1000");
        config.setPoolSize("1");
        config.setProviderName(null);
        config.setProviderClassName(null);
        config.setSaltGeneratorClassName("org.jasypt.salt.RandomSaltGenerator");
        //IvGeneratorClassName这个属性不设置，默认值为org.jasypt.salt.NoOpIVGenerator
        //config.setIvGeneratorClassName("org.jasypt.salt.NoOpIVGenerator");
        config.setStringOutputType("base64");
        encryptOr.setConfig(config);
        return encryptOr;
    }

    /**
     * 对DtsDatasource中的url、username、password进行解密
     *
     * @param d
     * @return
     */
    public static DtsDatasource decyptDtsDatasource(DtsDatasource d) {
        try {
            String url = decyptText(d.getUrl());
            d.setUrl(url);
        } catch (Exception e) {
            //出现异常，说明数据库中存的数据是明文
        }

        try {
            String username = decyptText(d.getUsername());
            d.setUsername(username);
        } catch (Exception e) {
            //出现异常，说明数据库中存的数据是明文
        }

        try {
            String password = decyptText(d.getPassword());
            d.setPassword(password);
        } catch (Exception e) {
            //出现异常，说明数据库中存的数据是明文
        }
        return d;
    }

    /**
     * 对DatasourceInfo中的JdbcUrl、Username、Password进行解密
     *
     * @param datasourceInfo
     * @return
     */
    public static DatasourceInfo decyptDatasourceInfo(DatasourceInfo datasourceInfo) {
        try {
            String jdbcUrl = decyptText(datasourceInfo.getJdbcUrl());
            datasourceInfo.setJdbcUrl(jdbcUrl);
        } catch (Exception e) {
            //出现异常，说明数据库中存的数据是明文
        }

        try {
            String username = decyptText(datasourceInfo.getUsername());
            datasourceInfo.setUsername(username);
        } catch (Exception e) {
            //出现异常，说明数据库中存的数据是明文
        }

        try {
            String password = decyptText(datasourceInfo.getPassword());
            datasourceInfo.setPassword(password);
        } catch (Exception e) {
            //出现异常，说明数据库中存的数据是明文
        }
        return datasourceInfo;
    }

    /**
     * 对DtsDatasource中的url、username、password进行加密
     *
     * @param dts
     * @return
     */
    public static DtsDatasource encryptDtsDatasource(DtsDatasource dts) {
        dts.setUrl(encryptText(dts.getUrl()));
        dts.setUsername(encryptText(dts.getUsername()));
        dts.setPassword(encryptText(dts.getPassword()));
        return dts;
    }

    /**
     * 对DtsDatasource中的url、username、password进行加密
     *
     * @param dts
     * @return
     */
    public static DatasourceInfo encryptDtsDatasourceInfo(DatasourceInfo dts) {
        //对url/username/password 进行加密
        dts.setJdbcUrl(JasyptUtil.encryptText(JasyptUtil.decyptText(dts.getJdbcUrl())));
        dts.setUsername(JasyptUtil.encryptText(JasyptUtil.decyptText(dts.getUsername())));
        dts.setPassword(JasyptUtil.encryptText(JasyptUtil.decyptText(dts.getPassword())));
        return dts;
    }

    /**
     * 例子
     *
     * @param args
     */
    public static void main(String[] args) {
        // 加密
        System.out.println(encryptText("145356uryt"));
        System.out.println(encryptText("145356uryt").length());
        // 解密
        System.out.println(decyptText("gtHBgYExkBDoAPuI5p2+twfQjzTFQBH2nvOPG2jJQH7IbVwKxTD8wj+HWczc6yuwwvSy10SrxQNNXvDisyD9KF9Neb+gvQ9OWWk/ljMA1dg6v9BKyF8BrAifoo7xTDmZ5VAgJsF5TV4="));

//        System.out.println(decyptText("q/M+YmHGYTH8E+16UMJ6e0HuDxfqcDu5nTJUzzvhENimXRvhO19HCs8BC7kqCzbL6+Rq1AZ0Q1Y="));

    }
}