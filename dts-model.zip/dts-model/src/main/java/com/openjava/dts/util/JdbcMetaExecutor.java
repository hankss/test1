package com.openjava.dts.util;


import com.openjava.dts.constants.DtsConstants;
import com.openjava.dts.ddl.domain.DtsDatasource;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.List;

/**
 * 数据库jdbc操作元数据工具
 * 
 * @author heziyou
 *
 */
public class JdbcMetaExecutor {
	private static Logger LOG = LoggerFactory.getLogger(JdbcMetaExecutor.class);

	String driver;
	String url;
	String username;
	String password;

	public JdbcMetaExecutor(DtsDatasource ds) {
		this.driver = ds.getJdbcDriverClass();
		this.url = ds.getUrl();
		this.username = ds.getUsername();
		this.password = ds.getPassword();
	}

	/**
	 * 释放资源
	 * 
	 * @param resultSet
	 * @param statement
	 * @param connection
	 */
	public static void release(ResultSet resultSet, Statement statement, Connection connection) {
		if (resultSet != null) {
			try {
				resultSet.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		// 垃圾回收 尽快回收对象
		resultSet = null;
		if (statement != null) {
			try {
				statement.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		statement = null;
		if (connection != null) {
			try {
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		connection = null;
	}

    /**
     * 执行建表、表加注释、表加主键、字段加注释
     * @param createTableSQL
     * @param tableCommentSQL
     * @param setPrimaryKeySQL
     * @param columnCommentList
     * @throws Exception
     */
	public void customExecuteSQL(String createTableSQL, String tableCommentSQL, String setPrimaryKeySQL, List<String> columnCommentList) throws Exception {
		Connection conn = null;
		Statement stat = null;

		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url, username, password);
			stat = conn.createStatement();
			// 在数据库中 创建 数据表
			if (StringUtils.isNotBlank(createTableSQL)) {
				System.out.println(createTableSQL);
				int r = stat.executeUpdate(createTableSQL);
//				System.out.println("Result="+r);
			}
			// 在数据库中 给表添加注释
			if (StringUtils.isNotBlank(tableCommentSQL)) {
				System.out.println(tableCommentSQL);
				int r = stat.executeUpdate(tableCommentSQL);
//				System.out.println("Result="+r);
			}
			// 在数据库中 给表设置主键
			if (StringUtils.isNotBlank(setPrimaryKeySQL)) {
				System.out.println(setPrimaryKeySQL);
				int r = stat.executeUpdate(setPrimaryKeySQL);
//				System.out.println("Result="+r);
			}
			// 在数据库中创建 给表字段设置注释
			if (null != columnCommentList && columnCommentList.size() > 0) {
				for (String columnComment : columnCommentList) {
					stat.executeUpdate(columnComment);
				}
			}
		} finally {
			release(null, stat, conn);
		}
	}

	/**
	 * 判断指定数据库中是否存在指定表
	 * 
	 * @param databaseType
	 * @param databaseName
	 * @param tableName
	 * @return
	 */
	public String queryTableExist(Integer databaseType, String databaseName, String tableName) {
		String oracleQuery = "SELECT COUNT(1) FROM USER_TAB_COMMENTS S WHERE S.TABLE_NAME = '"+ tableName+"'";
		String mysqlQuery = "SELECT	COUNT(1) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = '" + databaseName + "' AND table_name = '" + tableName + "'";
		//不带schema
		String pgSqlQuery = String.format("SELECT COUNT(1) FROM PG_CLASS WHERE RELNAME = '%s'", tableName);
		//带schema
		/*String pgSqlQuery = String.format("SELECT COUNT (1) FROM information_schema.tables " +
				"WHERE table_schema = 'public' AND table_type = 'BASE TABLE'" +
				" AND TABLE_NAME = '%s'", tableName);*/
//		String sqlServerQuery = "";

		Connection conn = null;
		Statement stat = null;
		ResultSet rs = null;
		
		try {
			conn = DriverManager.getConnection(url, username, password);
			stat = conn.createStatement();
			// 查询数据
			if (databaseType.equals(DtsConstants.DATABASE_TYPE_ORACLE)) {
				rs = stat.executeQuery(oracleQuery);
			} else if (databaseType.equals(DtsConstants.DATABASE_TYPE_MYSQL_NEW)
				|| databaseType.equals(DtsConstants.DATABASE_TYPE_MYSQL_OLD)) {
				rs = stat.executeQuery(mysqlQuery);
			} else if (DtsConstants.DATABASE_TYPE_POSTGRES.equals(databaseType)) {
				rs = stat.executeQuery(pgSqlQuery);
			} else {
//				throw new RuntimeException("不支持此数据类型");
			}
			
			while (rs.next()) {
				return rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			release(rs, stat, conn);
		}
		return null;
	}

	/**
	 * 在数据库中删除表
	 * 
	 * @param tableList
	 */
	public void dropTable(List<String> tableList) {
		if(null != tableList && tableList.size() > 0) {
			StringBuilder sb = new StringBuilder("DROP TABLE ");
			
			Connection conn = null;
			Statement stat = null;
			try {
				conn = DriverManager.getConnection(url, username, password);
				stat = conn.createStatement();
				for (String table : tableList) {
					stat.executeQuery(sb.append(table).toString());
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				release(null, stat, conn);
			}
		}
	}



    public static void main(String[] args) throws Exception
    {  
		// mysql - zhongliang
//		String driver="com.mysql.jdbc.Driver";
//		String url="jdbc:mysql://47.107.56.144:3306/contract?useUnicode=true&characterEncoding=utf-8&useSSL=false";
//	    String username="root";
//	    String password="liang@1217";

		// mysql - jiaHai
//		String driver = "com.mysql.cj.jdbc.Driver";
//		String url = "jdbc:mysql:///test?serverTimezone=UTC";
//		String username = "root";
//		String password = "root";

		// oracle
	    String driver="oracle.jdbc.OracleDriver";
		String url="jdbc:oracle:thin:@//nhc.smart-info.cn:8521/orcl";
	    String username="c##ljdp";
	    String password="ch#123456";



    }

}
