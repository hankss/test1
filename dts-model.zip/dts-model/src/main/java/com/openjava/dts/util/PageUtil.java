package com.openjava.dts.util;

import com.google.common.collect.Lists;
import org.ljdp.component.exception.APIException;
import org.ljdp.ui.bootstrap.TablePageImpl;

import java.util.Collections;
import java.util.List;

/**
 * @author 丘健里
 * @date 2020/3/11
 */
public class PageUtil {
    /**
     * 开始分页
     *
     * @param list
     * @param pageNum  页码
     * @param pageSize 每页多少条数据
     * @return
     */
    public static TablePageImpl startPage(List list, Integer pageNum, Integer pageSize) throws APIException {
        if (list == null || list.size() == 0) {
            return new TablePageImpl<>();
        }
        //默认当前页为第0页
        if ("".equals(pageNum) || 0 == pageNum) {
            pageNum = 1;
        } else {
            pageNum += 1;
        }
        //默认每页显示20条
        if ("".equals(pageSize)) {
            pageSize = 20;
        }

        Integer count = list.size(); // 记录总数
        Integer pageCount = 0; // 页数
        if (count % pageSize == 0) {
            pageCount = count / pageSize;
        } else {
            pageCount = count / pageSize + 1;
        }

        int fromIndex = 0; // 开始索引
        int toIndex = 0; // 结束索引

        if (!pageNum.equals(pageCount)) {
            fromIndex = (pageNum - 1) * pageSize;
            toIndex = fromIndex + pageSize;
        } else {
            fromIndex = (pageNum - 1) * pageSize;
            toIndex = count;
        }

        //引入公司的分页框架
        TablePageImpl tablePage = new TablePageImpl<>();
        List pageList = Lists.newArrayList();
        if (fromIndex >= count) {
            pageList = Collections.emptyList();
        } else {
            pageList = list.subList(fromIndex, toIndex);
        }
        tablePage.setTotal(list.size());//总数据量
        tablePage.setRows(pageList);//数据集
        tablePage.setTotalPage(pageCount); //总页数
        tablePage.setNumber(pageNum - 1); //当前页
        tablePage.setSize(pageSize);//每页显示多少数据

        return tablePage;
    }

    /**
     * 开始分页
     *
     * @param list
     * @param pageNum  页码
     * @param pageSize 每页多少条数据
     * @return
     */
    public static List startPageToList(List list, Integer pageNum, Integer pageSize) {
        if (list == null || list.size() == 0) {
            return Collections.emptyList();
        }
        //默认当前页为第0页
        if ("".equals(pageNum) || 0 == pageNum) {
            pageNum = 1;
        } else {
            pageNum += 1;
        }
        //默认每页显示20条
        if ("".equals(pageSize)) {
            pageSize = 20;
        }

        Integer count = list.size(); // 记录总数
        Integer pageCount = 0; // 页数
        if (count % pageSize == 0) {
            pageCount = count / pageSize;
        } else {
            pageCount = count / pageSize + 1;
        }

        int fromIndex = 0; // 开始索引
        int toIndex = 0; // 结束索引

        if (!pageNum.equals(pageCount)) {
            fromIndex = (pageNum - 1) * pageSize;
            toIndex = fromIndex + pageSize;
        } else {
            fromIndex = (pageNum - 1) * pageSize;
            toIndex = count;
        }
        if (fromIndex >= count) {
            return Collections.emptyList();
        }
        return list.subList(fromIndex, toIndex);
    }

    /**
     * 获取总页数
     *
     * @param pageSize 当前页大小
     * @param rows     总条数
     * @return 总页数
     */
    public static Integer getTotalPage(Integer pageSize, Integer rows) {
        if (null == pageSize || 0 == pageSize) {
            return 0;
        }
        if (null == rows || 0 == rows) {
            return 0;
        }
        int i = rows % pageSize;
        int totalPage = rows / pageSize;
        if (0 == i) {
            return totalPage;
        } else {
            return totalPage + 1;
        }
    }

}
