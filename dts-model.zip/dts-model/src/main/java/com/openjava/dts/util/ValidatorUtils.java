package com.openjava.dts.util;

import com.openjava.dts.constants.DtsConstants;
import org.ljdp.component.exception.APIException;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author hailang
 * @date 2019/10/03 10:10
 */
public class ValidatorUtils {

    private static Validator validator = Validation.buildDefaultValidatorFactory().getValidator();

    public static <T> Map<String, String> validate(T obj,Class<?> c) {
        Map<String, StringBuilder> errorMap = new HashMap<>();
        Set<ConstraintViolation<T>> set = validator.validate(obj,c);
        if (set != null && set.size() > 0) {
            String property = null;
            for (ConstraintViolation<T> cv : set) {
                property = cv.getPropertyPath().toString();
                if (errorMap.get(property) != null) {
                    errorMap.get(property).append("," + cv.getMessage());
                } else {
                    StringBuilder sb = new StringBuilder();
                    sb.append(cv.getMessage());
                    errorMap.put(property, sb);
                }
            }
        }
        return errorMap.entrySet().stream().collect(Collectors.toMap(k -> k.getKey(), v -> v.getValue().toString()));
    }

    public static void checkParam(Map<String, String> m) throws APIException{
        if(m != null && m.size()>0){
            String reStr = "";
            for(String key:m.keySet()){
                String value = m.get(key).toString();
                reStr += " "+value+"\r\n";
            }
            throw new APIException(DtsConstants.EXCEPTION_ERROR,reStr);
        }
    }

    /**
     * 直接使用验证
     * @param object
     * @param c
     * @param <T>
     * @throws Exception
     */
    public static <T> void checkParamAndTrException(T object, Class c) throws Exception{
        Map m = ValidatorUtils.validate(object, c);
        checkParam(m);
    }
}