package com.openjava.dts.util.column;

import com.openjava.dts.constants.DtsConstants;
import com.openjava.dts.ddl.domain.DtsColumn;
import com.openjava.dts.ddl.dto.ColumnInfo;
import com.openjava.dts.util.*;
import org.apache.commons.lang3.ObjectUtils;
import org.ljdp.component.exception.APIException;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author: lsw
 * @Date: 2020/3/5 15:19
 */
public class ColumnUtils {

    /**
     * 获取dts列信息
     *
     * @param columnInfos 列信 息
     * @return
     */
    public static List<DtsColumn> transformToDtsColumns(List<ColumnInfo> columnInfos) {
        if (CollectionUtils.isEmpty(columnInfos)) {
            return Collections.emptyList();
        }

        List<DtsColumn> dtsColumns = new ArrayList<>(columnInfos.size());
        for (ColumnInfo columnInfo : columnInfos) {
            DtsColumn dtsColumn = transformToDtsColumn(columnInfo);
            dtsColumns.add(dtsColumn);
        }

        return dtsColumns;
    }

    /**
     * 获取dts列信息
     *
     * @param columnInfo 列信息
     * @return 列信息
     */
    public static DtsColumn transformToDtsColumn(ColumnInfo columnInfo) {
        DtsColumn dtsColumn = new DtsColumn();
        dtsColumn.setColumnSource(columnInfo.getColumnSource());
        dtsColumn.setColumnComment(columnInfo.getColumnComment());
        dtsColumn.setColumnType(columnInfo.getColumnType());
        dtsColumn.setColumnScale(columnInfo.getColumnScale());
        dtsColumn.setColumnPrecision(columnInfo.getColumnPrecision());
        dtsColumn.setNullable(columnInfo.getNullable());
        dtsColumn.setDefaultValue(columnInfo.getDefaultValue());
        dtsColumn.setIsPrimaryKey(columnInfo.getIsPrimaryKey());
        dtsColumn.setColumnIndex(columnInfo.getColumnIndex());

        return dtsColumn;
    }

    /**
     * 处理writer的列类型  来源数据库类型 -1:资源目录 0:Oracle 1:MySql高版本 2;Mysql低版本 3:PostgreSql 4:hive 5:SQL Server 6：华为hive
     *
     * @param writerDbType
     * @param writerColumns
     */
    public static void translateWriterColumnsType(Integer writerDbType, List<DtsColumn> writerColumns) throws APIException {
        if (DtsConstants.DATABASE_TYPE_POSTGRES.equals(writerDbType)) {
            for (DtsColumn column : writerColumns) {
                if (column.getColumnType().equalsIgnoreCase("datetime")){
                    column.setColumnType("timestamp");
                    continue;
                }
                if (column.getColumnType().equalsIgnoreCase("longtext")){
                    column.setColumnType("text");
                    continue;
                }
                if (column.getColumnType().equalsIgnoreCase("tinyint")){
//                    column.setColumnType("int");
                    column.setColumnType("boolean");
                    continue;
                }
                if (column.getColumnType().equalsIgnoreCase("varchar2")){
                    column.setColumnType("varchar");
                    continue;
                }
                if (column.getColumnType().equalsIgnoreCase("number")){
                    column.setColumnType("decimal");
                    continue;
                }
                JavaSqlTypeEnum columnTypeEnum = EnumUtil.getByName(column.getColumnType(), JavaSqlTypeEnum.class);
                if (checkColumnType(column, writerDbType, columnTypeEnum) == false)
                    continue;
                String columnType = ColumnTypeTranslatorPostgreSql.getTranslateType(columnTypeEnum);
                column.setColumnType(columnType);
            }
        } else if (DtsConstants.DATABASE_TYPE_HIVE.equals(writerDbType) || DtsConstants.DATABASE_TYPE_HIVE_HUAWEI.equals(writerDbType)) {
            for (DtsColumn column : writerColumns) {
                JavaSqlTypeEnum columnTypeEnum = EnumUtil.getByName(column.getColumnType(), JavaSqlTypeEnum.class);
                if (checkColumnType(column, writerDbType, columnTypeEnum) == false)
                    break;
                String columnType = ColumnTypeTranslatorHiveHuawei.getTranslateType(columnTypeEnum, column.getColumnPrecision(), column.getColumnScale());
                column.setColumnType(columnType);
            }
        } else if (DtsConstants.DATABASE_TYPE_ORACLE.equals(writerDbType)) {
            for (DtsColumn column : writerColumns) {
                JavaSqlTypeEnum columnTypeEnum = EnumUtil.getByName(column.getColumnType(), JavaSqlTypeEnum.class);
                if (checkColumnType(column, writerDbType, columnTypeEnum) == false)
                    break;
                String columnType = ColumnTypeTranslatorOracle.getTranslateType(columnTypeEnum, column.getColumnPrecision(), column.getColumnScale());
                column.setColumnType(columnType);
            }
        } else if (DtsConstants.DATABASE_TYPE_MYSQL_NEW.equals(writerDbType) || DtsConstants.DATABASE_TYPE_MYSQL_OLD.equals(writerDbType)) {
            for (DtsColumn column : writerColumns) {//mysql 新旧版本略有不同,注意下
                JavaSqlTypeEnum columnTypeEnum = EnumUtil.getByName(column.getColumnType(), JavaSqlTypeEnum.class);
                if (checkColumnType(column, writerDbType, columnTypeEnum) == false)
                    break;
                String columnType = ColumnTypeTranslatorMysql.getTranslateType(columnTypeEnum, column.getColumnPrecision(), column.getColumnScale());
                column.setColumnType(columnType);
            }
        } else if (DtsConstants.DATABASE_TYPE_SQL_SERVER.equals(writerDbType)) {
            for (DtsColumn column : writerColumns) {
                JavaSqlTypeEnum columnTypeEnum = EnumUtil.getByName(column.getColumnType(), JavaSqlTypeEnum.class);
                if (checkColumnType(column, writerDbType, columnTypeEnum) == false)
                    break;
                String columnType = ColumnTypeTranslatorSql.getTranslateType(columnTypeEnum, column.getColumnPrecision(), column.getColumnScale());
                column.setColumnType(columnType);
            }
        }
    }

    private static boolean checkColumnType(DtsColumn column, Integer writerDbType, JavaSqlTypeEnum columnTypeEnum) {
        return columnTypeEnum != null;
    }

    /**
     * 处理writer的列类型  来源数据库类型 -1:资源目录 0:Oracle 1:MySql高版本 2;Mysql低版本 3:PostgreSql 4:hive 5:SQL Server 6：华为hive
     *
     * @param writerDbType
     * @param writerColumnInfos
     */
    public static void translateWriterColumnInfoType(Integer writerDbType, List<ColumnInfo> writerColumnInfos) throws APIException {
        if (DtsConstants.DATABASE_TYPE_POSTGRES.equals(writerDbType)) {
            for (ColumnInfo column : writerColumnInfos) {
                JavaSqlTypeEnum columnTypeEnum = EnumUtil.getByName(column.getColumnType(), JavaSqlTypeEnum.class);
                if (checkColumnInfoType(column, writerDbType, columnTypeEnum) == false)
                    break;
                String columnType = ColumnTypeTranslatorPostgreSql.getTranslateType(columnTypeEnum);
                column.setColumnType(columnType);
            }
        } else if (DtsConstants.DATABASE_TYPE_HIVE.equals(writerDbType) || DtsConstants.DATABASE_TYPE_HIVE_HUAWEI.equals(writerDbType)) {
            for (ColumnInfo column : writerColumnInfos) {
                JavaSqlTypeEnum columnTypeEnum = EnumUtil.getByName(column.getColumnType(), JavaSqlTypeEnum.class);
                if (checkColumnInfoType(column, writerDbType, columnTypeEnum) == false)
                    break;
                String columnType = ColumnTypeTranslatorHiveHuawei.getTranslateType(columnTypeEnum, column.getColumnPrecision(), column.getColumnScale());
                column.setColumnType(columnType);
            }
        } else if (DtsConstants.DATABASE_TYPE_ORACLE.equals(writerDbType)) {
            for (ColumnInfo column : writerColumnInfos) {
                JavaSqlTypeEnum columnTypeEnum = EnumUtil.getByName(column.getColumnType(), JavaSqlTypeEnum.class);
                if (checkColumnInfoType(column, writerDbType, columnTypeEnum) == false)
                    break;
                String columnType = ColumnTypeTranslatorOracle.getTranslateType(columnTypeEnum, column.getColumnPrecision(), column.getColumnScale());
                column.setColumnType(columnType);
            }
        } else if (DtsConstants.DATABASE_TYPE_MYSQL_NEW.equals(writerDbType) || DtsConstants.DATABASE_TYPE_MYSQL_OLD.equals(writerDbType)) {
            for (ColumnInfo column : writerColumnInfos) {//mysql 新旧版本略有不同,注意下
                JavaSqlTypeEnum columnTypeEnum = EnumUtil.getByName(column.getColumnType(), JavaSqlTypeEnum.class);
                if (checkColumnInfoType(column, writerDbType, columnTypeEnum) == false)
                    break;
                String columnType = ColumnTypeTranslatorMysql.getTranslateType(columnTypeEnum, column.getColumnPrecision(), column.getColumnScale());
                column.setColumnType(columnType);
            }
        } else if (DtsConstants.DATABASE_TYPE_SQL_SERVER.equals(writerDbType)) {
            for (ColumnInfo column : writerColumnInfos) {
                JavaSqlTypeEnum columnTypeEnum = EnumUtil.getByName(column.getColumnType(), JavaSqlTypeEnum.class);
                if (checkColumnInfoType(column, writerDbType, columnTypeEnum) == false)
                    break;
                String columnType = ColumnTypeTranslatorSql.getTranslateType(columnTypeEnum, column.getColumnPrecision(), column.getColumnScale());
                column.setColumnType(columnType);
            }
        }
    }

    private static boolean checkColumnInfoType(ColumnInfo column, Integer writerDbType, JavaSqlTypeEnum columnTypeEnum) {
        return columnTypeEnum != null;
    }
}
