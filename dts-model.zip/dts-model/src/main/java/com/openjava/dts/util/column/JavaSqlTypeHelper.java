package com.openjava.dts.util.column;

import org.springframework.util.CollectionUtils;

import java.util.*;

/**
 * Java数据库类型辅助类
 *
 * @author: lsw
 * @Date: 2020/2/25 10:29
 */
final public class JavaSqlTypeHelper {

    private static Set<String> STR_NAME_SET = Collections.emptySet();
    private static Set<String> NUM_NAME_SET = Collections.emptySet();
    private static Set<String> DATE_NAME_SET = Collections.emptySet();

    private static void initStrSet() {
        //字符串
        String charName = String.valueOf(JavaSqlTypeEnum.CHAR.getName());
        String ncharName = String.valueOf(JavaSqlTypeEnum.NCHAR.getName());
        String varcharName = String.valueOf(JavaSqlTypeEnum.VARCHAR.getName());
        String longvarcharName = String.valueOf(JavaSqlTypeEnum.LONGVARCHAR.getName());
        String nvarcharName = String.valueOf(JavaSqlTypeEnum.NVARCHAR.getName());
        String longnvarcharName = String.valueOf(JavaSqlTypeEnum.LONGNVARCHAR.getName());
        //字符串2
        String clobName = String.valueOf(JavaSqlTypeEnum.CLOB.getName());
        String nclobName = String.valueOf(JavaSqlTypeEnum.NCLOB.getName());

        Set<String> strNameSet = new HashSet<>(16);
        strNameSet.add(charName);
        strNameSet.add(ncharName);
        strNameSet.add(varcharName);
        strNameSet.add(longvarcharName);
        strNameSet.add(nvarcharName);
        strNameSet.add(longnvarcharName);
        strNameSet.add(clobName);
        strNameSet.add(nclobName);

        STR_NAME_SET = strNameSet;
    }

    private static void initNumSet() {
        //数值1
        String smallintName = String.valueOf(JavaSqlTypeEnum.SMALLINT.getName());
        String tinyintName = String.valueOf(JavaSqlTypeEnum.TINYINT.getName());
        String integerName = String.valueOf(JavaSqlTypeEnum.INTEGER.getName());
        String bigintName = String.valueOf(JavaSqlTypeEnum.BIGINT.getName());
        //数值2
        String numericName = String.valueOf(JavaSqlTypeEnum.NUMERIC.getName());
        String decimalName = String.valueOf(JavaSqlTypeEnum.DECIMAL.getName());
        //数值3
        String floatName = String.valueOf(JavaSqlTypeEnum.FLOAT.getName());
        String realName = String.valueOf(JavaSqlTypeEnum.REAL.getName());
        String doubleName = String.valueOf(JavaSqlTypeEnum.DOUBLE.getName());

        Set<String> numNameSet = new HashSet<>(16);
        numNameSet.add(smallintName);
        numNameSet.add(tinyintName);
        numNameSet.add(integerName);
        numNameSet.add(bigintName);
        numNameSet.add(numericName);
        numNameSet.add(decimalName);
        numNameSet.add(floatName);
        numNameSet.add(realName);
        numNameSet.add(doubleName);

        NUM_NAME_SET = numNameSet;
    }

    private static void initDate() {
        //时间
        String dateName = String.valueOf(JavaSqlTypeEnum.DATE.getName());

        //时间戳
        String timestampName = String.valueOf(JavaSqlTypeEnum.TIMESTAMP.getName());

        // TODO
        Set<String> dateNameSet = new HashSet<>(8);
        dateNameSet.add(dateName);
        dateNameSet.add(timestampName);

        DATE_NAME_SET = dateNameSet;
    }

    private static void initByteStream() {
        //字节流
        String binaryName = String.valueOf(JavaSqlTypeEnum.BINARY.getName());
        String varbinaryName = String.valueOf(JavaSqlTypeEnum.VARBINARY.getName());
        String blobName = String.valueOf(JavaSqlTypeEnum.BLOB.getName());
        String longvarbinaryName = String.valueOf(JavaSqlTypeEnum.LONGVARBINARY.getName());

    }

    private static void initOther() {
        //bool（bit）
        String booleanName = String.valueOf(JavaSqlTypeEnum.BOOLEAN.getName());
        String bitName = String.valueOf(JavaSqlTypeEnum.BIT.getName());

        //null
        String nullName = String.valueOf(JavaSqlTypeEnum.NULL.getName());


        //time


        //timestamp
    }

    public static Set<String> getStrNameSet() {
        if (CollectionUtils.isEmpty(STR_NAME_SET)) {
            initStrSet();
        }

        return STR_NAME_SET;
    }

    public static Set<String> getNumNameSet() {
        if (CollectionUtils.isEmpty(NUM_NAME_SET)) {
            initNumSet();
        }

        return NUM_NAME_SET;
    }

    public static Set<String> getDateNameSet() {
        if (CollectionUtils.isEmpty(DATE_NAME_SET)) {
            initDate();
        }

        return DATE_NAME_SET;
    }
}
