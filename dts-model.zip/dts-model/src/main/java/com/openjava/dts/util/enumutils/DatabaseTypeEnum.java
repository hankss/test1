package com.openjava.dts.util.enumutils;

/**
 * @author jianli
 * @date 2020-04-16 16:07
 * 策略模式+枚举，替代if-else
 */
public enum DatabaseTypeEnum {

    ONE("0") {
        @Override
        public String getName() {
            return "Oracle";
        }
    },
    TWO("1") {
        @Override
        public String getName() {
            return "MySql";
        }
    },
    THREE("2") {
        @Override
        public String getName() {
            return "Mysql";
        }
    },
    FOUR("3") {
        @Override
        public String getName() {
            return "PostgreSql";
        }
    },
    FIVE("4") {
        @Override
        public String getName() {
            return "hive";
        }
    },
    SIX("5") {
        @Override
        public String getName() {
            return "SQLServer";
        }
    },
    SEVER("6") {
        @Override
        public String getName() {
            return "华为hive";
        }
    },
    EIGHT("7") {
        @Override
        public String getName() {
            return "gaussdb";
        }
    },
    NINE("9") {
        @Override
        public String getName() {
            return "gaussdb";
        }
    };

    //枚举属性
    private final String tag;

    DatabaseTypeEnum(String tag) {
        this.tag = tag;
    }

    public String getTag() {
        return tag;
    }

    abstract String getName();

    public static String getMessageType(String num) {
        //循环枚举类，其实是循环定义在枚举类中的枚举
        for (DatabaseTypeEnum t : DatabaseTypeEnum.values()) {
            if (num != null && num.trim().equals(t.getTag())) {
                return t.getName();
            }
        }
        return null;
    }
}

