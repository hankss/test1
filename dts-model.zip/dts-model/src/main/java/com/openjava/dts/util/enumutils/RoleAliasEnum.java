package com.openjava.dts.util.enumutils;

/**
 * @author jianli
 * @date 2020-08-06 0006 10:03
 */
public class RoleAliasEnum {

    /**
     * 角色 —— 系统管理员
     */
    public static final String SYSTEM_ADMIN = "SYSAdmin";
    /**
     * 角色 —— 测试运维人员
     */
    public static final String MAINTAINER = "Maintainer";

    /**
     * 角色 —— 管理员
     */
    public static final String ADMIN = "Admin";
    /**
     * 角色 —— 审核员
     */
    public static final String AUDITOR = "Auditor";
    /**
     * 角色 —— 目录管理员
     */
    public static final String RESOURCE_ADMIN = "ResourceAdmin";
    /**
     * 角色 —— 科室管理员
     */
    public static final String DEPT_ADMIN = "DeptResourceAdmin";
    /**
     * 角色 —— 使用人员
     */
    public static final String USER = "User";
    /**
     * 角色 —— 委办局管理员
     */
//    public static final String WBJ_ADMIN = "WBJAdmin";

    /**
     * 角色 —— 委办局审核员
     */
//    public static final String WBJ_AUDITOR = "WBJAuditor";

    /**
     * 角色 —— 数据提供人
     */
    public static final String DATA_PROVIDER = "DataProvider";

}
