package com.openjava.dts.version.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import jdk.nashorn.internal.ir.annotations.Ignore;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;

/**
 * 实体
 * @author hl
 *
 */
@ApiModel("DtsTableVersion")
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@Entity
@Table(name = "DTS_TABLE_VERSION")
public class DtsTableVersion implements Persistable<Long>,Serializable {
	
	@ApiModelProperty("版本id")
	@Id
	@Column(name = "id")
	private Long id;
	
	@ApiModelProperty("资产id")
	@Max(9223372036854775806L)
	@Column(name = "dataasset_id")
	private Long dataassetId;
	
	@ApiModelProperty("资产明细id")
	@Max(9223372036854775806L)
	@Column(name = "dataasset_item_id")
	private Long dataassetItemId;
	
	@ApiModelProperty("数据源id")
	@Length(min=0, max=128)
	@Column(name = "datasource_id")
	private String datasourceId;
	
	@ApiModelProperty("表名")
	@Length(min=0, max=255)
	@Column(name = "table_name")
	private String tableName;
	
	@ApiModelProperty("版本更新时间")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "version_time")
	private Date versionTime;
	
	@ApiModelProperty("版本名字 V?版本")
	@Length(min=0, max=64)
	@Column(name = "version_name")
	private String versionName;
	
	@ApiModelProperty("变动描述")
	@Length(min=0, max=255)
	@Column(name = "version_desc")
	private String versionDesc;
	
	@ApiModelProperty("创建人")
	@Max(9223372036854775806L)
	@Column(name = "create_id")
	private Long createId;
	
	@ApiModelProperty("创建人名字")
	@Length(min=0, max=255)
	@Column(name = "create_name")
	private String createName;
	
	@ApiModelProperty("创建人id")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "create_time")
	private Date createTime;
	
	@ApiModelProperty("修改人")
	@Max(9223372036854775806L)
	@Column(name = "modify_id")
	private Long modifyId;
	
	@ApiModelProperty("修改名字")
	@Length(min=0, max=255)
	@Column(name = "modify_name")
	private String modifyName;
	
	@ApiModelProperty("修改时间")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modify_time")
	private Date modifyTime;
	
	
	@ApiModelProperty("是否新增")
	@Transient
    private Boolean isNew;
	
	@Transient
    @Override
    public Long getId() {
        return this.id;
	}
    
    @JsonIgnore
	@Transient
    @Override
    public boolean isNew() {
    	if(isNew != null) {
    		return isNew;
    	}
    	if(this.id != null) {
    		return false;
    	}
    	return true;
    }
    
}