package com.openjava.dts.version.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.domain.Persistable;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import java.io.Serializable;
import java.util.Date;

/**
 * 实体
 * @author hl
 *
 */
@ApiModel("DtsVersionDetail")
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@Entity
@Table(name = "DTS_VERSION_DETAIL")
public class DtsVersionDetail implements Persistable<Long>,Serializable {
	
	@ApiModelProperty("资产详情id")
	@Id
	@Column(name = "id")
	private Long id;
	
	@ApiModelProperty("版本id")
	@Length(min=0, max=255)
	@Column(name = "version_id")
	private String versionId;

	@ApiModelProperty("数据源id")
	@Length(min=0, max=128)
	@Column(name = "datasource_id")
	private String datasourceId;
	
	@ApiModelProperty("资产id")
	@Max(9223372036854775806L)
	@Column(name = "dataasset_id")
	private Long dataassetId;
	
	@ApiModelProperty("资产详细id")
	@Max(9223372036854775806L)
	@Column(name = "dataasset_item_id")
	private Long dataassetItemId;
	
	@ApiModelProperty("表名")
	@Length(min=0, max=255)
	@Column(name = "table_name")
	private String tableName;
	
	@ApiModelProperty("字段名")
	@Length(min=0, max=128)
	@Column(name = "field")
	private String field;
	
	@ApiModelProperty("字段类型")
	@Length(min=0, max=32)
	@Column(name = "field_type")
	private String fieldType;
	
	@ApiModelProperty("字段描述")
	@Length(min=0, max=1024)
	@Column(name = "field_comment")
	private String fieldComment;
	
	@ApiModelProperty("创建人")
	@Max(9223372036854775806L)
	@Column(name = "create_id")
	private Long createId;
	
	@ApiModelProperty("创建人名字")
	@Length(min=0, max=255)
	@Column(name = "create_name")
	private String createName;
	
	@ApiModelProperty("创建人id")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "create_time")
	private Date createTime;
	
	@ApiModelProperty("修改人")
	@Max(9223372036854775806L)
	@Column(name = "modify_id")
	private Long modifyId;
	
	@ApiModelProperty("修改名字")
	@Length(min=0, max=255)
	@Column(name = "modify_name")
	private String modifyName;
	
	@ApiModelProperty("修改时间")
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modify_time")
	private Date modifyTime;
	
	
	@ApiModelProperty("是否新增")
	@Transient
    private Boolean isNew;
	
	@Transient
    @Override
    public Long getId() {
        return this.id;
	}
    
    @JsonIgnore
    @Transient
    @Override
    public boolean isNew() {
    	if(isNew != null) {
    		return isNew;
    	}
    	if(this.id != null) {
    		return false;
    	}
    	return true;
    }
    
}