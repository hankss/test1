package com.openjava.dts.version.query;

import org.apache.commons.lang3.StringUtils;
import org.ljdp.core.db.RoDBQueryParam;
import org.springframework.format.annotation.DateTimeFormat;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 查询对象
 * @author hl
 *
 */
public class DtsTableVersionDBParam extends RoDBQueryParam {
	private Long eq_id;//id --主键查询
	
	private Long eq_dataassetId;//资产id = ?
	private Long eq_dataassetItemId;//资产明细id = ?
	private String eq_datasourceId;//数据源id = ?
	private String like_tableName;//表名 = ?
	private Long eq_createId;//创建人 = ?

	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date lt_createTime;//结束时间
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date gt_createTime;//开始时间

	public Date getLt_createTime() {
		return lt_createTime;
	}
	public void setLt_createTime(String lt_createTime) {
		if (StringUtils.isEmpty(lt_createTime)) {
			this.lt_createTime = null;
		}else {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			try {
				this.lt_createTime = sdf.parse(lt_createTime);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
	}
	public Date getGt_createTime() {
		return gt_createTime;
	}
	public void setGt_createTime(String gt_createTime) {
		if(StringUtils.isEmpty(gt_createTime)){
			this.gt_createTime = null;
		}else {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			try {
				this.gt_createTime = sdf.parse(gt_createTime);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Long getEq_id() {
		return eq_id;
	}
	public void setEq_id(Long id) {
		this.eq_id = id;
	}
	
	public Long getEq_dataassetId() {
		return eq_dataassetId;
	}
	public void setEq_dataassetId(Long dataassetId) {
		this.eq_dataassetId = dataassetId;
	}
	public Long getEq_dataassetItemId() {
		return eq_dataassetItemId;
	}
	public void setEq_dataassetItemId(Long dataassetItemId) {
		this.eq_dataassetItemId = dataassetItemId;
	}
	public String getEq_datasourceId() {
		return eq_datasourceId;
	}
	public void setEq_datasourceId(String datasourceId) {
		this.eq_datasourceId = datasourceId;
	}
	public String getLike_tableName() {
		return like_tableName;
	}
	public void setLike_tableName(String like_tableName) {
		this.like_tableName = like_tableName;
	}
	public Long getEq_createId() {
		return eq_createId;
	}
	public void setEq_createId(Long createId) {
		this.eq_createId = createId;
	}
}