package com.openjava.dts.version.query;

import org.ljdp.core.db.RoDBQueryParam;

/**
 * 查询对象
 * @author hl
 *
 */
public class DtsVersionDetailDBParam extends RoDBQueryParam {
	private Long eq_id;//id --主键查询
	
	private String eq_datasourceId;//数据源id = ?
	private Long eq_dataassetId;//资产id = ?
	private Long eq_dataassetItemId;//资产详细id = ?
	private String like_tableName;//表名 like ?

	private String eq_versionId; //版本id

	public String getEq_versionId() {
		return eq_versionId;
	}
	public void setEq_versionId(String eq_versionId) {
		this.eq_versionId = eq_versionId;
	}

	public Long getEq_id() {
		return eq_id;
	}
	public void setEq_id(Long id) {
		this.eq_id = id;
	}
	
	public String getEq_datasourceId() {
		return eq_datasourceId;
	}
	public void setEq_datasourceId(String datasourceId) {
		this.eq_datasourceId = datasourceId;
	}
	public Long getEq_dataassetId() {
		return eq_dataassetId;
	}
	public void setEq_dataassetId(Long dataassetId) {
		this.eq_dataassetId = dataassetId;
	}
	public Long getEq_dataassetItemId() {
		return eq_dataassetItemId;
	}
	public void setEq_dataassetItemId(Long dataassetItemId) {
		this.eq_dataassetItemId = dataassetItemId;
	}
	public String getLike_tableName() {
		return like_tableName;
	}
	public void setLike_tableName(String tableName) {
		this.like_tableName = tableName;
	}
}