package com.openjava.dts.xxljob.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author: lsw
 * @Date: 2019/8/10 15:01
 */
@ApiModel("任务日志列表页")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class XxlJobLogPage {
    @ApiModelProperty("总记录数")
    private Integer recordsTotal;

    @ApiModelProperty("页码")
    private Integer recordsFiltered;

    @ApiModelProperty("数据")
    private List<XxlJobLog> data;
}
