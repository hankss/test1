package com.openjava.dts.xxljob.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel("任务调度结果")
@Data
public class XxlResult {
    @ApiModelProperty("结果编码（200表示成功，其他失败）")
    private Integer code;
    private String msg;
    private String content;
}
