# Getting Started

### Reference Documentation

For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/3.3.5/maven-plugin)
* [Create an OCI image](https://docs.spring.io/spring-boot/3.3.5/maven-plugin/build-image.html)
* [Spring Data Elasticsearch (Access+Driver)](https://docs.spring.io/spring-boot/3.3.5/reference/data/nosql.html#data.nosql.elasticsearch)
* [Spring Boot DevTools](https://docs.spring.io/spring-boot/3.3.5/reference/using/devtools.html)
* [Thymeleaf](https://docs.spring.io/spring-boot/3.3.5/reference/web/servlet.html#web.servlet.spring-mvc.template-engines)
* [Spring Web](https://docs.spring.io/spring-boot/3.3.5/reference/web/servlet.html)

### Guides

The following guides illustrate how to use some features concretely:

* [Handling Form Submission](https://spring.io/guides/gs/handling-form-submission/)
* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/rest/)

### Maven Parent overrides

Due to Maven's design, elements are inherited from the parent POM to the project
POM.
While most of the inheritance is fine, it also inherits unwanted elements
like `<license>` and `<developers>` from the parent.
To prevent this, the project POM contains empty overrides for these elements.
If you manually switch to a different parent and actually want the inheritance,
you need to remove those overrides.

https://www.elastic.co/guide/cn/elasticsearch/guide/2.x/_talking_to_elasticsearch.html   官方文档

参考文档-重要

https://gitcode.csdn.net/65e8418c1a836825ed78bc92.html?dp_token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZCI6NjI5NzYsImV4cCI6MTczMTIzNTMyNSwiaWF0IjoxNzMwNjMwNTI1LCJ1c2VybmFtZSI6InFhendzeGhhaSJ9.68FXCg5HGklYCLM3GeQNPyz8z2J-IbLaF6EycIBydZk&spm=1001.2101.3001.6661.1&utm_medium=distribute.pc_relevant_t0.none-task-blog-2~default~BlogCommendFromBaidu~activity-1-135515805-blog-141287528.235%5Ev43%5Epc_blog_bottom_relevance_base6&depth_1-utm_source=distribute.pc_relevant_t0.none-task-blog-2~default~BlogCommendFromBaidu~activity-1-135515805-blog-141287528.235%5Ev43%5Epc_blog_bottom_relevance_base6&utm_relevant_index=1

put user
{
"settings": {
"number_of_shards": 1,
"number_of_replicas": 1
},
"mappings": {
"properties": {
"username": { "type": "text" },
"pwd": { "type": "text" },
"address": { "type": "text" }
}
}
}


post user/_doc/4
{
"username": "hang4",
"pwd": "lang4",
"address": "maoming4"
}


get /user/_search
{
"query":{
"match_all": {}
}
}


https://github.com/spring-projects/spring-data-elasticsearch
