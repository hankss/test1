package com.hl.elasticsearch.controller;

import cn.hutool.json.JSONUtil;
import com.hl.elasticsearch.entity.User;
import com.hl.elasticsearch.service.TestService;
import com.hl.elasticsearch.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Iterator;
import java.util.List;


@Controller
public class TestController {

    @Autowired
    UserService userService;

    @Autowired
    TestService testService;

    @GetMapping("/")
    public String hello(Model model) {
        model.addAttribute("name", "World");

        Iterable<User> iterable = userService.findAll();

        Iterator<User> it = iterable.iterator();
        while (it.hasNext()){
            User user = it.next();
            System.out.println(user.getUsername());
        }

        testService.t1();

        //System.out.println(JSONUtil.toJsonStr(iterable));

        return "index";
    }
}
