package com.hl.elasticsearch.repository;

import com.hl.elasticsearch.entity.User;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;


public interface UserRepository extends ElasticsearchRepository<User, String> {

    // 你可以在这里定义自定义查询方法

}