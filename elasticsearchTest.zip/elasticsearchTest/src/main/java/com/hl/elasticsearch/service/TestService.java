package com.hl.elasticsearch.service;

import org.apache.http.HttpHost;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.core.TimeValue;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
public class TestService {

    public void t1(){


        RestHighLevelClient client = new RestHighLevelClient(
                RestClient.builder(new HttpHost("127.0.0.1", 9200, "http"))
        );

        // 构建搜索请求
        SearchRequest searchRequest = new SearchRequest("user"); // 替换为实际的索引名称

        // 构建查询条件
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.query(QueryBuilders.matchAllQuery()); // 查询所有文档

        // 设置一些可选参数
        searchSourceBuilder.from(0); // 设置起始索引，默认为0
        searchSourceBuilder.size(10); // 设置返回结果的数量，默认为10
        searchSourceBuilder.timeout(new TimeValue(5000)); // 设置超时时间，默认为1分钟

        // 将查询条件设置到搜索请求中
        searchRequest.source(searchSourceBuilder);

        try {
            // 执行搜索请求
            SearchResponse searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);

            // 处理搜索响应
            System.out.println("Search took: " + searchResponse.getTook());

            // 获取搜索结果
            SearchHits hits = searchResponse.getHits();
            System.out.println("Total hits: " + hits.getTotalHits().value);



            // 遍历搜索结果
            for (SearchHit hit : hits.getHits()) {
                System.out.println("Document ID: " + hit.getId());
                System.out.println("Source: " + hit.getSourceAsString());
            }
        } catch (IOException e) {
            // 处理异常
            e.printStackTrace();
        } finally {
            try {
                // 关闭客户端连接
                client.close();
            } catch (IOException e) {
                // 处理关闭连接异常
                e.printStackTrace();
            }
        }


    }
}
