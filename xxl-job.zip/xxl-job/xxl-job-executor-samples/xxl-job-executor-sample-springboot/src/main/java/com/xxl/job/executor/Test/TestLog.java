package com.xxl.job.executor.Test;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TestLog {


    public static Logger log = LoggerFactory.getLogger(TestLog.class);

    public static void pr(){
        System.out.println("--------------pr-----------");
        log.info("---------log info------------");
        log.error("---------log err------------");
    }
}
